const { User } = require('../models/index');
const bcrypt = require('bcryptjs');

const authenticateUser = async (req, res, next) => {
  const { email, password } = req.body;

  try {
    // Find a user in the MongoDB collection based on the provided email
    const user = await User.findOne({ email });

    if (user) {
      // If the user is found, compare the provided password with the stored hashed password
      const isPasswordMatch = await bcrypt.compare(password, user.password);

      if (isPasswordMatch) {
        // If the passwords match, attach the user document to the request object
        req.user = user;
        next(); // Continue to the next middleware
      } else {
        // If the passwords do not match, send a 401 Unauthorized response
        return res.status(401).json({ message: 'You are unauthorized.' });
      }
    } else {
      // If no matching user is found, send a 401 Unauthorized response
      return res.status(401).json({ message: 'You are unauthorized.' });
    }
  } catch (error) {
    // Handle any errors that occur during the database query
    return res.status(500).json({ message: 'Internal Server Error.' });
  }
};

module.exports = authenticateUser;
