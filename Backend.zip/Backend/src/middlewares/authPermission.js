const passport = require('passport');
const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');
const { User, SuperAdmin } = require('../models');
const {roleService} = require('../services/index')

const verifyPermissionCallback = (req, resolve, reject) => async (err, user, info) => {
  if (err || info || !user) {
    return reject(new ApiError(httpStatus.UNAUTHORIZED, 'Please authenticate'));
  }
  req.user = user;

  

  try {
    const allData = await roleService.getRoleByName(user.role);
    const userRights = allData.functionalities;
    const requestData = req.body.data;
    // Check if all required rights are present and set to true in userRights
    const hasRequiredRights = requestData.every((requiredRight) => userRights.some((right) => right[requiredRight]));

    // console.log('User:', user);
    // console.log('UserData:', userData);
    // console.log('UserRights:', userRights);
    // console.log('requestData: ', requestData);
    // console.log('HasRequiredRights:', hasRequiredRights);

    resolve({ userRights, hasRequiredRights });

     // Check if all required rights are present and set to true in userRights
     if (!hasRequiredRights) {
      return reject(new ApiError(httpStatus.FORBIDDEN, 'Forbidden', { userRights }));
     }

    
  } catch (error) {
    console.error('Error in authPermission:', error); // Log the actual error
    return reject(new ApiError(httpStatus.INTERNAL_SERVER_ERROR, 'Internal Server Error'));
  }

};

const authPermission = () => async (req, res, next) => {
  return new Promise((resolve, reject) => {
    passport.authenticate('jwtStrategyForUserAndSuperAdmin', { session: false }, verifyPermissionCallback(req, resolve, reject))(req, res, next);
  })
    .then(({ userRights, hasRequiredRights }) => { 
      req.userRights = userRights;
      req.hasRequiredRights = hasRequiredRights;
      next()})
    .catch((err) => next(err));
};

module.exports = authPermission;
