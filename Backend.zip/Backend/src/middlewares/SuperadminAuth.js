const passport = require('passport');
const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');

const verifyCallbackForSuperadmin = (req, resolve, reject) => async (err, superadmin) => {
  if (err || !superadmin) {
    return reject(new ApiError(httpStatus.UNAUTHORIZED, 'Please authenticate as a Superadmin'));
  }
  req.superadmin = superadmin;
  resolve();
};
const authForSuperadmin = async (req, res, next) => {
  return new Promise((resolve, reject) => {
    passport.authenticate('jwtForSuperadmin', { session: false }, verifyCallbackForSuperadmin(req, resolve, reject))(
      req,
      res,
      next,
    );
  })
    .then(() => next())
    .catch((err) => next(err));
};

module.exports = authForSuperadmin;
