const mongoose = require('mongoose');

const dashboardStatusSchema = new mongoose.Schema({
  status: {
    type: Number,
    default: 1, // Default to dashboard
  },
  lastUpdated: {
    type: Date,
    default: Date.now,
  },
  email: { type: String },
  accessStartTime: { type: Date },
  accessExpireTime: { type: Date },
});

const DashboardStatus = mongoose.model('DashboardStatus', dashboardStatusSchema);

module.exports = DashboardStatus;
