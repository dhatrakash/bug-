const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');
const moment = require('moment/moment');

// func to set data utc and change format
const setDtm = (dtm) => {
  if (dtm instanceof Date) {
    return dtm.toISOString();
  }
  if (typeof dtm === 'string') {
    const date = moment.utc(dtm, 'YYYYMMDDHHmmss').format();
    if (date !== 'Invalid date') {
      return date;
    }
  }
  return dtm;
};

const partCodeSchema = mongoose.Schema(
  {
    partCode: {
      type: String,
      required: true,
      trim: true,
    },
    mac: {
      type: String,
      required: true,
      trim: true,
    },
    dtm: {
      type: String,
      required: true,
      index: true,
      set: setDtm,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
partCodeSchema.plugin(toJSON);
partCodeSchema.plugin(paginate);

/**
 * @typedef partCode
 */
const partCode = mongoose.model('partCode', partCodeSchema, 'partCode');

module.exports = partCode;
