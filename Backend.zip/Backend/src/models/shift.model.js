const mongoose = require('mongoose');
// const moment = require('moment/moment');

// Function to set date to Indian standards and change format
// const setIndianDate = (date) => {
//   if (date instanceof Date) {
//     return moment(date).format('YYYY-MM-DD'); // Adjust the format as needed
//   }
//   if (typeof date === 'string') {
//     const formattedDate = moment.utc(date, 'YYYYMMDDHHmmss').format('YYYY-MM-DD');
//     if (formattedDate !== 'Invalid date') {
//       return formattedDate;
//     }
//   }
//   return date;
// };

const shiftSchema = new mongoose.Schema(
  {
    shiftId: {
      type: mongoose.Schema.Types.ObjectId,
    },
    shiftName: { type: String, required: true },
    // date: {
    //   type: String,
    //   required: true,
    //   set: setIndianDate, // Apply the date formatting function
    // },
    startTime: { type: String, required: true },
    endTime: { type: String, required: true },
  },
  { timestamps: true },
);

shiftSchema.pre('save', function (next) {
  if (!this.shiftId) {
    this.shiftId = this._id;
  }
  next();
});
const Shift = mongoose.model('Shift', shiftSchema);

module.exports = Shift;
