module.exports.Token = require('./token.model');
module.exports.User = require('./user.model');
module.exports.SuperAdmin = require('./superAdmin.model');
module.exports.SuperAdminTokens = require('./superAdmin.token.model');
module.exports.Role = require('./role.model');
module.exports.Hardware = require('./hardware.model');
module.exports.DowntimeReason = require('./downtimeReason.model');
module.exports.partCode = require('./partcode.model');