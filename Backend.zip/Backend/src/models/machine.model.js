const mongoose = require('mongoose');

const machineSchema = mongoose.Schema({
  machineName: {
    type: String,
    required: true,
    unique: true,
  },
  machineId: {
    type: mongoose.Schema.Types.ObjectId,
    unique: true,
  },
  gatewayId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Gateway',
  },
  machine_type: {
    type: String,
    enum: ['hardwire', 'controller'],
    requried: true,
  },
  controllerType: {
    // select whichever is controller specific
    type: String,
    enum: ['fanuc', 'siemens', 'N/A'],
  },
  machineLocation: {
    facility: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Facility',
    },
    cell: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Cell',
    },
    layout: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Layout',
    },
    line: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Line',
    },
  },
  machineMake: String,
  mfgEmail: String,
  machineMakeYear: {
    type: Number,
    min: 1800,
    max: new Date().getFullYear(),
  },
  machineWarranty: Number,
  maintenancePerson: String,
  maintenanceContact: String,

  controllerMake: String,
  controllerModel: String,
  controllerMakeYear: {
    type: Number,
    min: 1800,
    max: new Date().getFullYear(),
  },
  publishTopic: String,
  subscribeTopic: String,
  machinePhoto: {
    base64: String,
    // contentType: String,
  },
  controllerPhoto: {
    // base64: Buffer,
    base64: String,
    // contentType: String,
  },
  powerSupplyRating: Number,
  inputMethod: {
    type: String,
    enum: ['STABILIZER', 'UPS', 'OTHER'],
  },
  downtimeReason: String,
  operatorId: String,
  partCode: String,
  lockRegister: String,
  lockCommand: String,
  unlockCommand: String,
  flushCommand: String,
});
machineSchema.pre('save', function (next) {
  if (!this.machineId) {
    this.machineId = this._id;
  }
  next();
}); // setting up _id to machineId
const Machine = mongoose.model('Machine', machineSchema);

module.exports = Machine;
