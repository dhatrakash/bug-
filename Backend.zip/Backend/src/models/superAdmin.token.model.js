const mongoose = require('mongoose');
const { toJSON } = require('./plugins');
const { tokenTypes } = require('../config/tokens');

const superAdminTokenSchema = mongoose.Schema(
  {
    token: {
      type: String,
      required: true,
      index: true,
    },
    superAdmin: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'SuperAdmins',
      required: true,
    },
    type: {
      type: String,
      enum: [tokenTypes.REFRESH, tokenTypes.RESET_PASSWORD, tokenTypes.VERIFY_EMAIL],
      required: true,
    },
    expires: {
      type: Date,
      required: true,
    },
    blacklisted: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
superAdminTokenSchema.plugin(toJSON);

/**
 * @typedef Token
 */
const Token = mongoose.model('superAdminToken', superAdminTokenSchema,'superAdminTokens');

module.exports = Token;
