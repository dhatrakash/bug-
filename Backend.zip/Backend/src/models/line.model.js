const mongoose = require('mongoose');

const lineSchema = mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
  },
  value: {
    type: String,
    required: true,
  },
});

const Line = mongoose.model('Line', lineSchema);

module.exports = Line;
