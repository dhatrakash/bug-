const mongoose = require('mongoose');

const facilitySchema = mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
  },
  value: {
    type: String,
    required: true,
  },
});

const Facility = mongoose.model('Facility', facilitySchema);

module.exports = Facility;
