const mongoose = require('mongoose');
const moment = require('moment/moment');

// func to set data utc and change format
const setDtm = (dtm) => {
  if (dtm instanceof Date) {
    return dtm.toISOString();
  }
  if (typeof dtm === 'string') {
    const date = moment.utc(dtm, 'YYYYMMDDHHmmss').format();
    if (date !== 'Invalid date') {
      return date;
    }
  }
  return dtm;
};

const hardwareDynamicSchema = new mongoose.Schema({
  data: {
    mac: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    // distinguish between hardwire and controller models
    machine_type: {
      type: String,
      enum: ['hardwire', 'controller'],
    },
    uid: {
      type: Number,
      required: false,
      trim: true,
      index: true,
    },
    dtm: {
      type: String,
      required: true,
      index: true,
      set: setDtm,
    },
    seq: Number,
    sig: Number,
    msg: String,
    io: [
      {
        sid: {
          default: 1,
          type: Number,
        },
        di1: {
          default: 0,
          type: Number,
          alias: 'machine_status',
        },
        di2: {
          type: Number,
          default: 0,
          alias: 'cycle_status',
        },
        di3: {
          type: Number,
          default: 0,
        },
        di4: {
          type: Number,
          default: 0,
        },
        a1: {
          type: Number, // analog input voltage // float
          decimal: true,
        },
        a2: {
          type: Number,
          decimal: true,
        },
        s1: {
          type: Number,
          decimal: true,
        }, // sensor value- float value precision 0.00
        p1: Number, // pulse counter
      },
    ],
    sysv: {
      type: Number,
      decimal: true,
    },
    modbus: [
      {
        type: mongoose.Schema.Types.Mixed,
      },
    ],
  },
});
hardwareDynamicSchema.index({ 'data.mac': 1, 'data.dtm': 1 }, { unique: true });
const HardwareDynamic = mongoose.model('HardwareDynamic', hardwareDynamicSchema, 'HardwareData');

module.exports = HardwareDynamic;
