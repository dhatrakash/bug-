const mongoose = require('mongoose');

const cellSchema = mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
  },
  value: {
    type: String,
    required: true,
  },
});

const Cell = mongoose.model('Cell', cellSchema);

module.exports = Cell;
