const mongoose = require('mongoose');

const machineGatewayAssociationSchema = new mongoose.Schema(
  {
    machineMappingId: {
      type: mongoose.Schema.Types.ObjectId,
      index: true,
    },
    machineId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Machine',
      required: true,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    mappings: [
      {
        mappingId: {
          type: mongoose.Schema.Types.ObjectId,
          required: true,
          ref() {
            return this.sensorNodeType === 'io' ? 'GatewayInputs' : 'GatewaySensorAssociation';
          },
        },
        deletedAt: {
          type: Date,
          default: null,
        },
        sensorNodeType: {
          type: String,
          enum: ['io', 'modbus'],
          required: true,
        },
        uniqueRef: {
          type: String,
          default() {
            return this._id;
          },
        },
      },
    ],
  },
  {
    timestamps: true,
  },
);

// Partial index excluding documents where mappings.deletedAt is not null
// partialFilterExpression: { 'mappings.deletedAt': null } This option creates a partial index,
//meaning that the index only includes documents that satisfy a specified filter expression.
// In this case, the index will only include documents where the deletedAt field within
//the mappings array is null. This is useful for indexing only a subset of documents based on a condition.
machineGatewayAssociationSchema.index(
  { machineId: 1, 'mappings.deletedAt': 1 },
  { unique: true, partialFilterExpression: { 'mappings.deletedAt': null } },
);

machineGatewayAssociationSchema.pre('save', function (next) {
  if (!this.machineMappingId) {
    this.machineMappingId = this._id;
  }
  next();
});

const MachineGatewayAssociation = mongoose.model(
  'MachineGatewayAssociation',
  machineGatewayAssociationSchema,
  'MachineMappings',
);

module.exports = MachineGatewayAssociation;
