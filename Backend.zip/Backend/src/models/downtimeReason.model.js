const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');

const downtimeReasonSchema = mongoose.Schema(
  {
    reason_id: {
      type: Number,
      required: true,
      unique: true,
    },
    reason: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    state: {
      type: String,
      enum: ['Planned', 'Unplanned'],
      default: 'Unplanned',
    },
    color: {
      type: String,
      trim: true,
      default: '#9D2006',
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
downtimeReasonSchema.plugin(toJSON);
downtimeReasonSchema.plugin(paginate);

/**
 * Check if downtime reason is taken
 * @param {string} reason - The downtime reason
 * @returns {Promise<boolean>}
 */
downtimeReasonSchema.statics.isReasonTaken = async function (reason) {
  const downtimeReason = await this.findOne({ reason: reason });
  return !!downtimeReason;
};

/**
 * @typedef downtimeReason
 */
const downtimeReason = mongoose.model('downtimeReason', downtimeReasonSchema, 'downtimeReasons');

module.exports = downtimeReason;
