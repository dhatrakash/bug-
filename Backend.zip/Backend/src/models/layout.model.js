const mongoose = require('mongoose');

const layoutSchema = mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
  },
  value: {
    type: String,
    required: true,
  },
});

const Layout = mongoose.model('Layout', layoutSchema);

module.exports = Layout;
