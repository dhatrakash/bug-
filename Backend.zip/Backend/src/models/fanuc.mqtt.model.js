const mongoose = require('mongoose');

const fanucControlSchema = mongoose.Schema({
  observation: {
    time: Number,
    machine: {
      type: String,
      index: true,
    },
    name: {
      type: String,
      index: true,
    },
    marker: [],
  },
  state: {
    time: Number,
    data: mongoose.Schema.Types.Mixed,
  },
});
fanucControlSchema.index({ 'observation.name': 1, 'observation.time': 1, 'observation.machine': 1 }, { unique: true });
const FanucControl = mongoose.model('FanucControl', fanucControlSchema);
module.exports = FanucControl;
