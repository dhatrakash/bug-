const mongoose = require('mongoose');

const moment = require('moment-timezone');

const utilityDemoSchema = mongoose.Schema(
  {
    companyName: {
      type: String,
      //required: true,
      //unique: true,
    },
    contactPersonName: {
      type: String,
    },
    contactPersonNumber: {
      type: String,
    },
    email: {
      type: String,
    },
    address: {
      type: String,
    },
    city: {
      type: String,
    },
    numOfMachines: {
      type: Number,
    },
    numOfHardwireMachines: {
      type: Number,
    },
    numOfControllerMachines: {
      type: Number,
    },
    demoReportDuration: {
      type: String,
    },
    demoType: {
      type: String,
      enum: ['Inside', 'Promotional', 'End-user'],
    },
    lastAccessDate: {
      type: Date,
      //default: null, // Initialize to null when a new document is created

      default: () => moment().tz('Asia/Kolkata').toDate(),
    },
  },
  { timestamps: true },
);

// Create a virtual field for the date as a string for easier comparison
utilityDemoSchema.virtual('lastAccessDateString').get(function () {
  if (this.lastAccessDate) {
    return this.lastAccessDate.toDateString();
  }
  return null;
});
// companyName: string;
// contactPersonName: string;
// contactPersonNumber: string;
// email: string;
// address: string;
// city: string;
// numOfMachines: number;
// numOfHardwireMachines: number;
// numOfControllerMachines: number;
// demoReportDuration: string;
// demoType: string;

const UtilityDemo = mongoose.model('UtilityDemo', utilityDemoSchema);

module.exports = UtilityDemo;
