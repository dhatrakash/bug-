const mongoose = require('mongoose');

const GatewaySensorAssociationSchema = mongoose.Schema(
  {
    mappingId: {
      type: mongoose.Schema.Types.ObjectId, // id of this object
      index: true,
    },
    sensorNodeName: {
      type: String,
      required: true,
    },
    slaveId: {
      type: String,
      required: true,
    },
    tag: {
      type: String,
      required: true,
    },
    sensorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Sensor',
      required: true,
    },
    gatewayId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Gateway',
      required: true,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  { timestamps: true },
);

GatewaySensorAssociationSchema.index({ gatewayId: 1, slaveId: 1, tag: 1 }, { unique: true }); // unique combination of three keys
GatewaySensorAssociationSchema.pre('save', function (next) {
  if (!this.mappingId) {
    this.mappingId = this._id;
  }
  next();
}); // setting up _id to mappingId
const GatewaySensorAssociation = mongoose.model('GatewaySensorAssociation', GatewaySensorAssociationSchema);

module.exports = GatewaySensorAssociation;
