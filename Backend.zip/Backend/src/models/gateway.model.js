const mongoose = require('mongoose');

const gatewaySchema = mongoose.Schema({
  gatewayId: {
    type: mongoose.Schema.Types.ObjectId,
    index: true,
  },
  macId: {
    type: String,
    required: true,
    unique: true,
    index: true,
  },
  name: {
    type: String,
    required: true,
  },
  ip: {
    type: String,
    required: true,
  },
  port: {
    type: Number,
    required: true,
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  issuedDate: {
    type: Date,
    default: Date.now,
  },
  updatedDate: {
    type: Date,
  },
});

// func to update date whenever isActive status is changed
gatewaySchema.pre('save', function (next) {
  if (this.isModified('isActive')) {
    this.updatedDate = new Date();
  }
  next();
});
gatewaySchema.pre('save', function (next) {
  if (!this.gatewayId) {
    this.gatewayId = this._id;
  }
  next();
}); // setting up _id to mappingId
const Gateway = mongoose.model('Gateway', gatewaySchema);

module.exports = Gateway;
