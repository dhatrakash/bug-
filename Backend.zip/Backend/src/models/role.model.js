const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');

const RoleSchema = mongoose.Schema(
  {
    role: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    },
    functionalities: {
      type: Array,
      required: true,
    },
  },
  {
    timestamps: true,
  },
);

// add plugin that converts mongoose to json
RoleSchema.plugin(toJSON);
RoleSchema.plugin(paginate);

/**
 * Check if role is taken
 * @param {string} roleString - The user's email
 * @returns {Promise<boolean>}
 */
RoleSchema.statics.isRoleTaken = async function (roleString) {
  const role = await this.findOne({ role: roleString });
  return !!role;
};

/**
 * @typedef Role
 */
const Role = mongoose.model('Role', RoleSchema, 'rolesAndRights');

module.exports = Role;
