const mongoose = require('mongoose');

const GatewayInputsSchema = mongoose.Schema(
  {
    mappingId: {
      type: mongoose.Schema.Types.ObjectId, // id of this object
      index: true,
    },
    sensorNodeName: {
      type: String,
      required: true,
    },
    sensorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Sensor',
      required: true,
    },
    gatewayId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Gateway',
      required: true,
    },
    slaveId: {
      type: String,
      default: '1',
      required: true,
    },
    tag: {
      type: String,
      enum: ['di1', 'di2', 'di3', 'di4'],
      required: true,
    },
    // diId: {
    //   type: String,
    //   enum: ['di1', 'di2', 'di3', 'di4'],
    //   required: true,
    // },
    // tag: {
    //   type: String,
    //   required: true,
    // },
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  { timestamps: true },
);
GatewayInputsSchema.pre('save', function (next) {
  this.slaveId = '1';
  if (!this.mappingId) {
    this.mappingId = this._id;
  }
  next();
}); // setting up _id to mappingId
GatewayInputsSchema.index({ gatewayId: 1, tag: 1, deletedAt: 1 }, { unique: true });
const GatewayInputs = mongoose.model('GatewayInputs', GatewayInputsSchema);

module.exports = GatewayInputs;
