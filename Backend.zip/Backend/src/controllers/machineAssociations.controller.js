const MachineMappingService = require('../services/machineAssociations.service');

// Controller method for creating a mapping
const createMappingController = async (req, res) => {
  try {
    const associationData = req.body; // Assuming the data is in the request body
    const createdAssociation = await MachineMappingService.createMapping(associationData);
    res.status(201).json(createdAssociation);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller method for updating a mapping
const updateMappingController = async (req, res) => {
  try {
    const { machineMappingId, uniqueRef } = req.params;
    const associationData = req.body; // Assuming the data is in the request body
    const updatedMapping = await MachineMappingService.updateMapping(machineMappingId, uniqueRef, associationData);
    res.status(200).json(updatedMapping);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller method for soft deleting a whole mapping
const softDeleteWholeMappingController = async (req, res) => {
  try {
    const { machineMappingId } = req.params; // Assuming the ID is in the request parameters
    const updatedResult = await MachineMappingService.softDeleteWholeMapping(machineMappingId);
    res.status(200).json(updatedResult);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller method for soft deleting a specific mapping
const softDeleteMappingController = async (req, res) => {
  try {
    const { machineMappingId, mappingId } = req.params; // Assuming both IDs are in the request parameters
    const updatedMapping = await MachineMappingService.softDeleteMapping(machineMappingId, mappingId);
    res.status(200).json(updatedMapping);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller methods for finding active and inactive mappings
const findActiveMappingsController = async (req, res) => {
  try {
    const { machineId } = req.params; // Assuming machineId is in the request parameters
    const result = await MachineMappingService.findActiveMappings(machineId);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const findInActiveMappingsController = async (req, res) => {
  try {
    const { machineId } = req.params; // Assuming machineId is in the request parameters
    const result = await MachineMappingService.findInActiveMappings(machineId);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller method for finding a mapping by machineMappingId
const findMappingByMachineMappingIdController = async (req, res) => {
  try {
    const { machineMappingId } = req.params; // Assuming machineMappingId is in the request parameters
    const result = await MachineMappingService.findMappingByMachineMappingId(machineMappingId);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller method for deleting a mapping
const deleteMappingController = async (req, res) => {
  try {
    const { machineMappingId } = req.params; // Assuming machineMappingId is in the request parameters
    const result = await MachineMappingService.deleteMapping(machineMappingId);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  createMappingController,
  updateMappingController,
  softDeleteWholeMappingController,
  softDeleteMappingController,
  findActiveMappingsController,
  findInActiveMappingsController,
  findMappingByMachineMappingIdController,
  deleteMappingController,
};
