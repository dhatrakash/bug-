module.exports.authController = require('./auth.controller');
module.exports.userController = require('./user.controller');
module.exports.superAdminController = require('./superAdmin.controller');
module.exports.superAdminAuthController = require('./superAdminAuth.controller');
module.exports.roleController = require('./role.controller');
module.exports.DowntimeReasonController = require('./downtimeReason.controller');
module.exports.partcodeController = require('./partcode.controller');