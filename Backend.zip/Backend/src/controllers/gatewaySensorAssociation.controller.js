const GatewaySensorAssociation = require('../services/GatewaySensorSlaveMapping.service');

const retriveAllMapping = async (req, res) => {
  try {
    const mappings = await GatewaySensorAssociation.getAllGatewaySensorAssociations();
    res.status(201).json(mappings);
  } catch (error) {
    res.status(500).json({ error: `Unable to fetch gateway sensor mappings ${error}` });
  }
};

const create = async (req, res) => {
  try {
    const associationData = req.body;
    const createdMapping = await GatewaySensorAssociation.createGatewaySensorAssociation(associationData);
    if (!createdMapping) res.status(422)(`Failed to create wrong input`);
    res.status(201).json(createdMapping);
  } catch (error) {
    res.status(500).json({ error: `Unable create gateway sensor mappings ${error}` });
  }
};

const createMultiple = async (req, res) => {
  try {
    const { gatewayId } = req.body;
    const { slaveId } = req.body;
    const { associationData } = req.body;

    const createdMappings = await GatewaySensorAssociation.createMultipleAssociations(gatewayId, slaveId, associationData);
    if (!createdMappings || createdMappings.length === 0) {
      return res.status(400).json({ error: 'Failed to create mappings. Check your input data.' });
    }
    res.status(201).json(createdMappings);
  } catch (error) {
    res.status(500).json({ error: `Unable create multiple gateway sensor mappings${error}` });
  }
};

const findByMappingId = async (req, res) => {
  try {
    const { mappingId } = req.params;
    const association = await GatewaySensorAssociation.getGatewaySensorAssociationById(mappingId);

    if (!association) {
      return res.status(404).json({ error: 'GatewaySensorAssociation not found' });
    }

    res.status(200).json(association);
  } catch (error) {
    res.status(500).json({ error: `Unable to get GatewaySensorAssociation: ${error.message}` });
  }
};

const findByMappingGatewayId = async (req, res) => {
  try {
    const { gatewayId } = req.params;
    const association = await GatewaySensorAssociation.findMappingByGatewayId(gatewayId);

    if (!association) {
      return res.status(404).json({ error: 'GatewaySensorAssociation not found' });
    }

    res.status(200).json(association);
  } catch (error) {
    res.status(500).json({ error: `Unable to get GatewaySensorAssociation: ${error.message}` });
  }
};

const findByMappingSlaveid = async (req, res) => {
  try {
    const { gatewayId, slaveId } = req.params;
    const association = await GatewaySensorAssociation.findMappingBySlaveId(gatewayId, slaveId);

    if (!association) {
      return res.status(404).json({ error: 'GatewaySensorAssociation not found' });
    }

    res.status(200).json(association);
  } catch (error) {
    res.status(500).json({ error: `Unable to get GatewaySensorAssociation: ${error.message}` });
  }
};

const findByMappingTag = async (req, res) => {
  try {
    const { gatewayId, slaveId, tag } = req.params;
    const association = await GatewaySensorAssociation.findMappingByTag(gatewayId, slaveId, tag);
    if (!association) {
      return res.status(404).json({ error: 'GatewaySensorAssociation not found' });
    }

    res.status(200).json(association);
  } catch (error) {
    res.status(500).json({ error: `Unable to get GatewaySensorAssociation: ${error.message}` });
  }
};

const updateAssociation = async (req, res) => {
  try {
    const { mappingId } = req.params;
    const updatedData = req.body;
    const updatedAssociation = await GatewaySensorAssociation.updateGatewaySensorAssociationById(mappingId, updatedData);
    if (!updatedAssociation) {
      return res.status(400).json({ error: 'failed to update' });
    }
    res.status(200).json(updatedAssociation);
  } catch (error) {
    res.status(500).json({ error: `Unable to updated GatewaySensorAssociation: ${error.message}` });
  }
};
const deleteAssociationsById = async (req, res) => {
  try {
    const { mappingId } = req.params;
    const association = await GatewaySensorAssociation.deleteGatewaySensorAssociationById(mappingId);
    if (!association) {
      return res.status(404).json({ error: 'GatewaySensorAssociation not found' });
    }

    res.status(200).json(association);
  } catch (error) {
    res.status(500).json({ error: `Unable to soft1 Delete GatewaySensorAssociation: ${error.message}` });
  }
};

const softDeleteByMappingId = async (req, res) => {
  try {
    const { mappingId } = req.params;
    const association = await GatewaySensorAssociation.softDeleteAssociations(mappingId);
    if (!association) {
      return res.status(404).json({ error: 'GatewaySensorAssociation not found' });
    }

    res.status(200).json(association);
  } catch (error) {
    res.status(500).json({ error: `Unable to soft1 Delete GatewaySensorAssociation: ${error.message}` });
  }
};

const softDeleteByTag = async (req, res) => {
  try {
    const { gatewayId, tag, slaveId } = req.params;
    const association = await GatewaySensorAssociation.softDeleteByTag(gatewayId, slaveId, tag);
    if (!association) {
      return res.status(404).json({ error: 'GatewaySensorAssociation not found' });
    }

    res.status(200).json(association);
  } catch (error) {
    res.status(500).json({ error: `Unable to soft1 Delete GatewaySensorAssociation: ${error.message}` });
  }
};

const softDeleteBySlaveId = async (req, res) => {
  try {
    const { slaveId, gatewayId } = req.params;
    const association = await GatewaySensorAssociation.softDeleteBySlaveId(gatewayId, slaveId);
    if (!association) {
      return res.status(404).json({ error: 'GatewaySensorAssociation not found' });
    }

    res.status(200).json(association);
  } catch (error) {
    res.status(500).json({ error: `Unable to soft2 Delete GatewaySensorAssociation: ${error.message}` });
  }
};

const softDeleteBySensorId = async (req, res) => {
  try {
    const { sensorId } = req.params;
    const association = await GatewaySensorAssociation.softDeleteBySensorId(sensorId);

    if (!association) {
      return res.status(404).json({ error: 'GatewaySensorAssociation not found' });
    }

    res.status(200).json(association);
  } catch (error) {
    res.status(500).json({ error: `Unable to soft3 Delete GatewaySensorAssociation: ${error.message}` });
  }
};

module.exports = {
  retriveAllMapping,
  create,
  createMultiple,
  findByMappingId,
  findByMappingGatewayId,
  findByMappingSlaveid,
  updateAssociation,
  deleteAssociationsById,
  softDeleteByMappingId,
  softDeleteByTag,
  softDeleteBySlaveId,
  softDeleteBySensorId,
  findByMappingTag,
};
