const cellService = require('../services/cell.service');

exports.createCell = async (req, res) => {
  try {
    const createdCell = await cellService.createCell(req.body);
    return res.status(201).json({ createdCell });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

exports.findCellById = async (req, res) => {
  try {
    const { cellId } = req.params;
    const cell = await cellService.findCellById(cellId);
    res.status(200).json(cell);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.findCells = async (req, res) => {
  try {
    const cells = await cellService.findAllCells();
    res.status(200).json(cells);
  } catch (error) {
    res.status(500).json({ error: 'something went wrong while fetching cells' });
  }
};

exports.updateCell = async (req, res) => {
  try {
    const _id = req.params.id;
    const updateData = req.body;
    const updatedCell = await cellService.updateCell(_id, updateData);

    res.status(200).json(updatedCell);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
exports.deleteCell = async (req, res) => {
  try {
    const _id = req.params.cellId;
    const deletedCell = await cellService.deleteCell(_id);
    res.status(200).json(deletedCell);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getCells = async (req, res) => {
  try {
    const cells = await cellService.findAllCells();
    res.status(200).json(cells);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
