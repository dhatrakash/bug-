const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const { superAdminAuthService, superAdminService, superAdminTokenService, emailService } = require('../services');

const loginSuperAdmin = catchAsync(async (req, res) => {
  const { email, password } = req.body;
  const superAdmin = await superAdminAuthService.loginSuperAdminWithEmailAndPassword(email, password);
  const tokens = await superAdminTokenService.generateAuthTokens(superAdmin);
  res.send({ superAdmin, tokens });
});

const logoutSuperAdmin = catchAsync(async (req, res) => {
  await superAdminAuthService.logoutsuperAdmin(req.body.refreshToken);
  res.status(httpStatus.NO_CONTENT).send();
});

const refreshTokens = catchAsync(async (req, res) => {
  const tokens = await superAdminAuthService.refreshAuth(req.body.refreshToken);
  res.send({ ...tokens });
});

const sendVerificationEmail = catchAsync(async (req, res) => {
  const verifyEmailToken = await superAdminTokenService.generateVerifyEmailToken(req.user);
  await emailService.sendVerificationEmail(req.user.email, verifyEmailToken);
  res.status(httpStatus.NO_CONTENT).send();
});

const verifyEmail = catchAsync(async (req, res) => {
  await superAdminAuthService.verifyEmail(req.query.token);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = {
  loginSuperAdmin,
  logoutSuperAdmin,
  refreshTokens,
  sendVerificationEmail,
  verifyEmail,
};
