const lineService = require('../services/line.service');

exports.createLine = async (req, res) => {
  // if (err) {
  //   return res.status(500).json({ error: err.message });
  // }
  try {
    const createdLine = await lineService.createLine(req.body);
    return res.status(201).json({ createdLine });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

exports.findLineById = async (req, res) => {
  try {
    const { lineId } = req.params;
    const line = await lineService.findLineById(lineId);
    res.status(200).json(line);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.findLines = async (req, res) => {
  try {
    const lines = await lineService.findAllLines();
    res.status(200).json(lines);
  } catch (error) {
    console.error('Error fetching lines:', error); // Log the error
    res.status(500).json({ error: 'something went wrong while fetching lines' });
  }
};

exports.updateLine = async (req, res) => {
  try {
    const _id = req.params.id;
    const updateData = req.body;
    const updatedLine = await lineService.updateLine(_id, updateData);

    res.status(200).json(updatedLine);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
exports.deleteLine = async (req, res) => {
  try {
    const _id = req.params.lineId;
    const deletedLine = await lineService.deleteLine(_id);
    res.status(200).json(deletedLine);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getLines = async (req, res) => {
  try {
    const lines = await lineService.findAllLines();
    res.status(200).json(lines);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
