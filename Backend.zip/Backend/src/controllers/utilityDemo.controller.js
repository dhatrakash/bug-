const utilityDemoService = require('../services/utilityDemo.service');
const generateOTP = require('../utils/otp-generator.js');
const DashboardStatus = require('../models/dashboardStatus.model');

// Create a new utilityDemo
exports.createUtilityDemo = async (req, res) => {
  try {
    const createdUtilityDemo = await utilityDemoService.createUtilityDemo(req.body);
    return res.status(201).json({ createdUtilityDemo });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

// Send an OTP
exports.sendOtp = async (req, res) => {
  try {
    const { email } = req.body; // Get the recipient's email from the request body
    const generatedOTP = generateOTP(); // Generate the OTP (you need to implement this function)

    // Send the OTP via email
    await utilityDemoService.sendOTP(email, generatedOTP);

    res.status(200).json({ message: 'OTP sent successfully' });
  } catch (error) {
    console.error('Error sending OTP:', error);
    res.status(500).json({ error: 'Error sending OTP' });
  }
};

// Send CRM update
exports.sendCRMUpdate = async (req, res) => {
  try {
    const { formData } = req.body;
    const companyEmail = process.env.CRM_UPDATE_EMAIL;
    console.log('the form data received from frontren', formData);
    await utilityDemoService.sendCRMUpdate(companyEmail, formData);
    res.status(200).json({ message: 'CRM update Email sent successfully' });
  } catch (error) {
    console.error('Error sending CRM update:', error);
    res.status(500).json({ error: 'Error sending CRM update' });
  }
};

// Verify the OTP
exports.verifyOtp = async (req, res) => {
  try {
    const { email, otp } = req.body;
    const message = await utilityDemoService.verifyOtp(email, otp);
    res.status(200).json({ message });
  } catch (error) {
    console.error('Error verifying OTP:', error);
    res.status(500).json({ error: 'Error verifying OTP' });
  }
};

// // Restrict access to the dashboard
// exports.restrictAccessToDashboard = async (req, res) => {
//   const { email } = req.query; // Get the email from the request query

//   if (!email) {
//     return res.status(400).json({ error: 'Email is required' });
//   }

//   try {
//     // Check if the user has access based on the lastAccessDate
//     const hasAccess = await utilityDemoService.hasAccessToDashboard(email);

//     if (!hasAccess) {
//       console.log(`Access denied for email: ${email}`);
//       return res.status(403).json({ error: 'Access denied' });
//     }

//     console.log(`Access granted for email: ${email}`);
//     return res.status(200).json({ message: 'Access granted' });
//   } catch (error) {
//     console.error(`Error checking access to dashboard for email: ${email}`, error);
//     return res.status(400).json({ error: error.message });
//   }
// };

// Add dashboard status
exports.addDashboardStatus = async (req, res) => {
  try {
    const { email } = req.body;
    const statusDoc = await utilityDemoService.addDashboardStatus(email);

    if (statusDoc) {
      console.log('Dashboard status document updated or created:', statusDoc);
      res.json({ message: 'Dashboard status updated successfully' });
    } else {
      console.log('Error updating dashboard status');
      res.status(500).json({ error: 'Error updating dashboard status' });
    }
  } catch (error) {
    console.error('Error updating dashboard status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Get dashboard status
exports.getDashboardStatus = async (req, res) => {
  try {
    const { email } = req.body;
    const status = await utilityDemoService.getDashboardStatus(email);

    if (status !== -1) {
      res.json({ message: 'Dashboard status retrieved successfully', status });
    } else {
      res.status(200).json({ message: 'Dashboard status not found' });
    }
  } catch (error) {
    console.error('Error getting dashboard status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
