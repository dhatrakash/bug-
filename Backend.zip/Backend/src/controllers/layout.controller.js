const layoutService = require('../services/layout.service');

exports.createLayout = async (req, res) => {
  // if (err) {
  //   return res.status(500).json({ error: err.message });
  // }
  try {
    const createdLayout = await layoutService.createLayout(req.body);
    return res.status(201).json({ createdLayout });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

exports.findLayoutById = async (req, res) => {
  try {
    const { layoutId } = req.params;
    const layout = await layoutService.findLayoutById(layoutId);
    res.status(200).json(layout);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.findLayouts = async (req, res) => {
  try {
    const layouts = await layoutService.findAllLayouts();
    res.status(200).json(layouts);
  } catch (error) {
    res.status(500).json({ error: 'something went wrong while fetching layouts' });
  }
};

exports.updateLayout = async (req, res) => {
  try {
    const _id = req.params.id;
    const updateData = req.body;
    const updatedLayout = await layoutService.updateLayout(_id, updateData);

    res.status(200).json(updatedLayout);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
exports.deleteLayout = async (req, res) => {
  try {
    const _id = req.params.layoutId;
    const deletedLayout = await layoutService.deleteLayout(_id);
    res.status(200).json(deletedLayout);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getLayouts = async (req, res) => {
  try {
    const layouts = await layoutService.findAllLayouts();
    res.status(200).json(layouts);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
