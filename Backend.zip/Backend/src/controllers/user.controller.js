const httpStatus = require('http-status');
const pick = require('../utils/pick');
const ApiError = require('../utils/ApiError');
const catchAsync = require('../utils/catchAsync');
const { userService, tokenService } = require('../services');

const register = catchAsync(async (req, res) => {
  const user = await userService.createUser(req.body);
  const tokens = await tokenService.generateAuthTokens(user);
  res.status(httpStatus.CREATED).send({ user, tokens });
});

const getUsers = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  const result = await userService.queryUsers(filter, options);
  res.send(result);
});

const getUser = catchAsync(async (req, res) => {
  const user = await userService.getUserById(req.params.userId);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  res.send(user);
});

const updateUser = catchAsync(async (req, res) => {
  const user = await userService.updateUserById(req.params.userId, req.body);
  res.send(user);
});

const deleteUser = catchAsync(async (req, res) => {
  await userService.deleteUserById(req.params.userId);
  res.status(httpStatus.NO_CONTENT).send();
});

const viewAddUserForm = catchAsync(async (req, res) => {
  res.status(200).send({ msg: 'true' });
})

const viewCreateMachineForm = catchAsync(async (req, res) => {
  res.status(200).send({ msg: 'true' });
})

const getRoleByName = catchAsync(async (req, res) => {
  const user = await userService.getRoleByName(req.body.roleName);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Role not found');
  }
  res.send(user);
});

const viewAllMachines = catchAsync(async (req, res) => {
  res.status(200).send({ msg: 'true' });
});

const viewAddSensor = catchAsync(async (req, res) => {
  res.status(200).send({ msg: 'true' });
});

const permission = catchAsync(async (req, res) => {
  const { userRights, hasRequiredRights } = req; 
  const trueUserRights = userService.userRights(userRights);
    if (hasRequiredRights) {
        res.status(200).send({ msg: 'success', trueUserRights });
    } else {
        res.status(403).send({ msg: 'Forbidden', trueUserRights });
    }
});

module.exports = {
  register,
  getUsers,
  getUser,
  updateUser,
  deleteUser,
  viewAddUserForm,
  viewCreateMachineForm,
  getRoleByName,
  viewAllMachines,
  viewAddSensor,
  permission,
};
