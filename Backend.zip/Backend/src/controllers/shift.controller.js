const shiftService = require('../services/shift.service');

exports.createShift = async (req, res) => {
  try {
    const createdShift = await shiftService.createShift(req.body);
    return res.status(201).json({ createdShift });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

exports.findShifts = async (req, res) => {
  try {
    const shifts = await shiftService.findShifts();
    if (shifts[0]) return res.status(201).json(shifts);
    return res.status(404).json({ message: 'No shifts found' });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

exports.updateShift = async (req, res) => {
  try {
    const { shiftId } = req.params;
    const shiftData = req.body;
    const updatedShift = await shiftService.updateShift(shiftId, shiftData);
    if (updatedShift) return res.status(201).json({ updatedShift });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};
exports.findShiftById = async (req, res) => {
  try {
    const { shiftId } = req.params;
    const shift = await shiftService.findShiftById(shiftId);
    if (shift) return res.status(201).json(shift);
    return res.status(404).json({ error: `shift not found` });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};
exports.deleteShift = async (req, res) => {
  try {
    const { shiftId } = req.params;
    const deletedShift = await shiftService.deleteShift(shiftId);
    if (deletedShift) return res.status(200).json(deletedShift);
    return res.status(404).json({ error: 'Shift not found' });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};
