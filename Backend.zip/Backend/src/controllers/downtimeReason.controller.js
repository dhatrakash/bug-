const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const { DowntimeReasonService } = require('../services/index');

const createReason = catchAsync(async (req, res) => {
  try {
    const reasonData = await DowntimeReasonService.createReason(req.body);
    res.status(httpStatus.CREATED).send(reasonData);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const getReasondataByReasonid = catchAsync(async (req, res) => {
  try {
    const { reason_id } = req.body;
    const reasonData = await DowntimeReasonService.getReasondataByReasonid(reason_id);
    res.status(httpStatus.OK).send(reasonData);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const deleteReasonsData = catchAsync(async (req, res) => {
  try {
    const { reason_id } = req.body;
    await DowntimeReasonService.deleteReasonData(reason_id);
    res.status(httpStatus.OK).send({ msg: 'Downtime reason data succesfully deleted.' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const updateReasonData = catchAsync(async (req, res) => {
  try {
    await DowntimeReasonService.updateReasonData(req.body);
    res.status(httpStatus.OK).send({ msg: 'Downtime reason data succesfully Updated.' });
  } catch (error) {
    if (error.statusCode === 400) {
      res.status(httpStatus.BAD_REQUEST).json({ error: error.message });
    }
    res.status(httpStatus.INTERNAL_SERVER_ERROR).json({ error: error.message });
  }
});

module.exports = {
  createReason,
  getReasondataByReasonid,
  deleteReasonsData,
  updateReasonData,
};
