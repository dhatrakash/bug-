const hardwareService = require('../services/hardware.service');
const pipeline = require('../services/pipeline.services');
const catchAsync = require('../utils/catchAsync');

exports.getDataByTimeFrame = async function (req, res) {
  try {
    const foundData = await hardwareService.findDataByTimeFrame(req.body);
    res.status(200).json({ message: 'These are matching Records from hardware-routes', foundData });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while fetching data.' });
  }
};

exports.partProduceTable = async (req, res) => {
  const { interval, date } = req.body;

  try {
    const data = await hardwareService.fetchDataByTimeInterval(interval, date);
    res.status(200).json({ message: 'These are matching Records from hardware-routes', data });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while fetching data.' });
  }
};

exports.oeeChart = async function (req, res) {
  const { startDate, endDate, interval, mac } = req.body;
  try {
    const machineData = await hardwareService.oeeCalculation(startDate, endDate, interval, mac);
    res.status(200).json({ message: 'These are matching Records from hardware-routes', machineData });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while fetching data.' });
  }
};

exports.machineReport = async function (req, res) {
  const { startDate, endDate, mac } = req.body;

  try {
    const data = await hardwareService.machineSpecific(startDate, endDate, mac);

    res.status(200).json({ message: 'These are matching Records from hardware-routes', data });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while fetching data.' });
  }
};

exports.companyOEE = async function (req, res) {
  const { startDate, endDate, interval } = req.body;
  try {
    const oeeData = await hardwareService.allMachineOEE(startDate, endDate, interval);
    res.status(200).json({ message: 'These are matching Records from hardware-routes', oeeData });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while fetching data.' });
  }
};

exports.pdfGenerator = async function (req, res) {
  const { startDate, endDate, mac } = req.body;

  try {
    const dataForPDF = await hardwareService.dataForPDF(startDate, endDate, mac);
    res.status(200).json({ message: 'These are matching Records from hardware-routes', dataForPDF });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while fetching data.' });
  }
};

exports.getPipelineData = catchAsync(async (req, res) => {
  try {
    const { startDate, endDate } = req.body;
    const results = await pipeline.kavitsu(startDate, endDate);
    res.status(200).json({ message: 'These are matching Records from hardware-routes', results });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while fetching data.' });
  }
});

exports.createHardware = async (req, res) => {
  try {
    const createdHardware = await hardwareService.createHardware(req.body);
    res.status(200).json({ message: 'Hardware Succesfully inserted into db.', createdHardware });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while fetching data.' });
  }
};

exports.getUptime = async (req, res) => {
  try {
    const { startDate, endDate } = req.body;
    const result = await hardwareService.getChartData(startDate, endDate);
    res.status(201).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getUptime = async (req, res) => {
  try {
    const { startDate, endDate } = req.body;
    const result = await hardwareService.getChartData(startDate, endDate);
    res.status(201).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
