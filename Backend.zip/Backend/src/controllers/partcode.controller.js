const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const { partcodeService } = require('../services');

const createPartCode = catchAsync(async (req, res) => {
  try {
    const partCode = await partcodeService.createPartCode(req.body);
    res.status(httpStatus.CREATED).send(partCode);
  } catch (error) {
    res.status(httpStatus.INTERNAL_SERVER_ERROR).json({ error: error.message });
  }
});

const getPartCodeData = catchAsync(async (req, res) => {
  try {
    const { startDate, endDate, mac } = req.body;
    const partCode = await partcodeService.getPartCodeData(startDate, endDate, mac);
    if (partCode.length === 0) {
      res.status(httpStatus.OK).json({ msg: "There's nothing to show here within these timestamp." });
    } else {
      res.status(httpStatus.OK).send(partCode);
    }
  } catch (error) {
    res.status(httpStatus.INTERNAL_SERVER_ERROR).json({ error: error.message });
  }
});

module.exports = {
  createPartCode,
  getPartCodeData,
};
