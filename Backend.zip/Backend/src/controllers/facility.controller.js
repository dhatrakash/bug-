const facilityService = require('../services/facility.service');

exports.createFacility = async (req, res) => {
  try {
    const createdFacility = await facilityService.createFacility(req.body);
    return res.status(201).json({ createdFacility });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

exports.findFacilityById = async (req, res) => {
  try {
    const { facilityId } = req.params;
    const facility = await facilityService.findFacilityById(facilityId);
    res.status(200).json(facility);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.findFacilities = async (req, res) => {
  try {
    const facilities = await facilityService.findAllFacilities();
    res.status(200).json(facilities);
  } catch (error) {
    res.status(500).json({ error: 'something went wrong while fetching facilities' });
  }
};

exports.updateFacility = async (req, res) => {
  try {
    const _id = req.params.id;
    const updateData = req.body;
    const updatedFacility = await facilityService.updateFacility(_id, updateData);
    res.status(200).json(updatedFacility);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deleteFacility = async (req, res) => {
  try {
    const _id = req.params.facilityId;
    const deletedFacility = await facilityService.deleteFacility(_id);
    res.status(200).json(deletedFacility);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getFacilities = async (req, res) => {
  try {
    const facilities = await facilityService.findAllFacilities();
    res.status(200).json(facilities);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
