const httpStatus = require('http-status');
const pick = require('../utils/pick');
const ApiError = require('../utils/ApiError');
const catchAsync = require('../utils/catchAsync');
const { superAdminService, roleService } = require('../services/index');

const getSuperAdmins = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  const result = await superAdminService.querySuperAdmins(filter, options);
  res.send(result);
});

const getSuperAdmin = catchAsync(async (req, res) => {
  const superAdmin = await superAdminService.getsuperAdminById(req.params.superAdminId);
  if (!superAdmin) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Super-Admin not found');
  }
  res.send(superAdmin);
});

const updateSuperAdmin = catchAsync(async (req, res) => {
  const superAdmin = await superAdminService.updateSuperAdminById(req.params.superAdminId, req.body);
  res.send(superAdmin);
});

const deleteSuperAdmin = catchAsync(async (req, res) => {
  await superAdminService.deletesuperAdminById(req.params.superAdminId);
  res.status(httpStatus.NO_CONTENT).send();
});

const viewAddUserForm = catchAsync(async (req, res) => {
  res.status(200).send({ msg: 'true' });
});

const updatePermissions = async (req, res) => {
  try {
    await roleService.updatePermissions(req.body).then(() => {
      return res.status(200).json({ message: 'Permissions updated successfully' });
    });
  } catch (error) {
    return error;
  }
};

const viewCreateMachineForm = catchAsync(async (req, res) => {
  res.status(200).send({ msg: 'true' });
});

const viewAllMachines = catchAsync(async (req, res) => {
  res.status(200).send({ msg: 'true' });
});

const viewAddSensor = catchAsync(async (req, res) => {
  res.status(200).send({ msg: 'true' });
});

const getAllUsers = async (req, res) => {
  try {
    const data = await superAdminService.getAllUsers();
    if (!data) {
      res.status(200).send({ msg: "There's nothing to show here." });
    }
    res.status(200).send({ data });
  } catch (error) {
    return error;
  }
};

module.exports = {
  getSuperAdmin,
  getSuperAdmins,
  updateSuperAdmin,
  deleteSuperAdmin,
  viewAddUserForm,
  updatePermissions,
  viewCreateMachineForm,
  viewAllMachines,
  viewAddSensor,
  getAllUsers,
};
