const httpStatus = require('http-status');
const pick = require('../utils/pick');
const ApiError = require('../utils/ApiError');
const catchAsync = require('../utils/catchAsync');
const { roleService } = require('../services');

const createRole = catchAsync(async (req, res) => {
  const role = await roleService.createRole(req.body);
  res.status(httpStatus.CREATED).send(role);
});

const getRoles = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  const result = await roleService.queryRoles(filter, options);
  res.send(result);
});

const getRole = catchAsync(async (req, res) => {
  const user = await roleService.getRoleById(req.body.roleId);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Role not found');
  }
  res.send(user);
});

const getRoleByName = catchAsync(async (req, res) => {
  const user = await roleService.getRoleByName(req.body.roleName);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Role not found');
  }
  res.send(user);
});

const addFunctionalityToRole = catchAsync(async (req, res) => {
  const role = await roleService.addFunctionalityToRole(req.body);
  res.send(role);
});

const deleteFunctionalityToRole = catchAsync(async (req, res) => {
  const role = await roleService.deleteFunctionalityToRole(req.body);
  res.send(role);
});

const deleteRole = catchAsync(async (req, res) => {
  await roleService.deleteRoleById(req.body.roleId);
  res.status(httpStatus.NO_CONTENT).send();
});

const getAll = catchAsync(async (req, res) => {
  const allDoc = await roleService.getAll();
  res.send(allDoc);
});

module.exports = {
  createRole,
  getRoles,
  getRole,
  getRoleByName,
  addFunctionalityToRole,
  deleteFunctionalityToRole,
  deleteRole,
  getAll,
};
