const GatewayInputService = require('../services/gatewayInputs.service');

// Create Gateway Input
const createGatewayInputController = async (req, res) => {
  try {
    const associationData = req.body; // Assuming the request body contains the data
    const result = await GatewayInputService.createGatewayInput(associationData);
    return res.status(201).json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

// Get Gateway Inputs by Mapping ID
const getGatewayInputsByMappingIdController = async (req, res) => {
  try {
    const { mappingId } = req.params;
    const result = await GatewayInputService.gatewayInputsByMappingId(mappingId);
    return res.status(200).json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};
// Get Gateway Inputs by Gateway ID
const getGatewayInputsAll = async (req, res) => {
  try {
    const result = await GatewayInputService.getAllGatewayInputs();
    return res.status(200).json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

// Get Gateway Inputs by Gateway ID
const getGatewayInputsByGatewayIdController = async (req, res) => {
  try {
    const { gatewayId } = req.params;
    const result = await GatewayInputService.gatewayInputsByGatewayId(gatewayId);
    return res.status(200).json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

// Get Gateway Inputs by Gateway ID and DI ID
const getGatewayInputsByGatewayIdDiIdController = async (req, res) => {
  try {
    const { gatewayId, diId } = req.params;
    const result = await GatewayInputService.gatewayInputsByGatewayIdDiId(gatewayId, diId);
    return res.status(200).json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

// Update Gateway Inputs by Mapping ID
const updateGatewayInputsByIdController = async (req, res) => {
  try {
    const { mappingId } = req.params;
    const updatedData = req.body; // Assuming the request body contains the updated data
    const result = await GatewayInputService.updateGatewayInputsById(mappingId, updatedData);
    return res.status(200).json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

// Soft Delete Gateway Inputs by Mapping ID
const softDeleteGatewayInputsByMappingIdController = async (req, res) => {
  try {
    const { mappingId } = req.params;
    const result = await GatewayInputService.softDeletegatewayInputsByMappingId(mappingId);
    return res.status(200).json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

// Soft Delete Gateway Inputs by Gateway ID
const softDeleteGatewayInputsByGatewayIdController = async (req, res) => {
  try {
    const { gatewayId } = req.params;
    const result = await GatewayInputService.softDeleteGatewayInputsByGatewayId(gatewayId);
    return res.status(200).json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

// Soft Delete Gateway Inputs by Gateway ID and DI ID
const softDeleteGatewayInputsByGatewayIdDiIdController = async (req, res) => {
  try {
    const { gatewayId, diId } = req.params;
    const result = await GatewayInputService.softDeleteGatewayInputsByGatewayIdDiId(gatewayId, diId);
    return res.status(200).json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

const deleteGatewayInputByMappingId = async (req, res) => {
  try {
    const { mappingId } = req.params;
    const result = await GatewayInputService.deleteGatewayInputByMappingId(mappingId);
    return res.status(200).json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

module.exports = {
  createGatewayInputController,
  getGatewayInputsAll,
  getGatewayInputsByMappingIdController,
  getGatewayInputsByGatewayIdController,
  getGatewayInputsByGatewayIdDiIdController,
  updateGatewayInputsByIdController,
  deleteGatewayInputByMappingId,
  softDeleteGatewayInputsByMappingIdController,
  softDeleteGatewayInputsByGatewayIdController,
  softDeleteGatewayInputsByGatewayIdDiIdController,
};
