const moment = require('moment');
const logger = require('../config/logger');
const HardwareDynamicService = require('../services/hardwareDynamic.service');

const findUptimeDataByMachineId = async (req, res) => {
  try {
    const { machineId, startDate, endDate } = req.body;

    // Validate machineId
    if (!machineId || typeof machineId !== 'string') {
      return res.status(400).json({ error: 'Invalid machineId' });
    }

    const result = await HardwareDynamicService.machineProductionStatusByTimeFrame(machineId, startDate, endDate);
    if (!result || result.length === 0) {
      return res.status(404).json({ error: 'No data found' });
    }
    res.status(200).json({ result });
  } catch (error) {
    res.status(500).json({ error: `Internal server error${error}` });
  }
};

const machineProductionStatusByRecentHour = async (req, res) => {
  try {
    const { machineId, hours } = req.body;

    // Validate machineId
    if (!machineId || typeof machineId !== 'string') {
      return res.status(400).json({ error: 'Invalid machineId' });
    }

    const result = await HardwareDynamicService.machineProductionStatusByRecentHour(machineId, hours);
    if (!result || result.length === 0) {
      return res.status(404).json({ error: 'No data found' });
    }
    res.status(200).json({ result });
  } catch (error) {
    res.status(500).json({ error: `Internal server error${error}` });
  }
};

const machineDataAsperSensorUse = async (req, res) => {
  try {
    const { machineId, startDate, endDate, sensorUse } = req.body;
    // Validate machineId
    if (!machineId || typeof machineId !== 'string') {
      return res.status(400).json({ error: 'Invalid machineId' });
    }

    const result = await HardwareDynamicService.machineDataAsperSensorUse(machineId, startDate, endDate, sensorUse);
    if (!result || result.length === 0) {
      return res.status(404).json({ error: 'No data found' });
    }
    res.status(200).json({ result });
  } catch (error) {
    res.status(500).json({ error: `Internal server error${error}` });
  }
};

const machineDataByTimeFrame = async (req, res) => {
  try {
    const { machineId, startDate, endDate } = req.body;

    // Validate machineId
    if (!machineId || typeof machineId !== 'string') {
      return res.status(400).json({ error: 'Invalid machineId' });
    }

    const result = await HardwareDynamicService.machineDataByTimeFrame(machineId, startDate, endDate);
    if (!result || result.length === 0) {
      return res.status(404).json({ error: 'No data found' });
    }
    res.status(200).json({ result });
  } catch (error) {
    res.status(500).json({ error: `Internal server error${error}` });
  }
};

const partCountByTimeFrame = async (req, res) => {
  try {
    const { machineId, startDate, endDate } = req.body;

    // Validate machineId
    if (!machineId || typeof machineId !== 'string') {
      return res.status(400).json({ error: 'Invalid machineId' });
    }

    const partCount = await HardwareDynamicService.partCountByMachineId(machineId, startDate, endDate);
    if (!partCount || partCount.length === 0) {
      return res.status(404).json({ error: 'No data found' });
    }
    res.status(200).json({ partCount });
  } catch (error) {
    res.status(500).json({ error: `Internal server error${error}` });
  }
};

const macchineOeeCalculationByInterval = async (req, res) => {
  try {
    const { machineId, startDate, endDate, interval } = req.body;

    // Validate machineId
    if (!machineId || typeof machineId !== 'string') {
      return res.status(400).json({ error: 'Invalid machineId' });
    }

    const oeeData = await HardwareDynamicService.macchineOeeCalculationByInterval(startDate, endDate, interval, machineId);
    if (!oeeData || oeeData.length === 0) {
      return res.status(404).json({ error: 'No data found' });
    }
    res.status(200).json({ oeeData });
  } catch (error) {
    res.status(500).json({ error: `Internal server error${error}` });
  }
};

const machineDataByMappingId = async (req, res) => {
  try {
    logger.debug(`Sending data request to service : ${moment().format('YYYY/MM/DD HH:mm:ss.SSS')}`);
    const productiveValue = { valueForOne: null };
    const { machineId, mappingId, hours } = req.body;
    const data = await HardwareDynamicService.machineDataByMappingId(machineId, mappingId, hours, productiveValue);
    logger.debug(`Recieved Data : \n${JSON.stringify(data)}`);

    if (!data[0]) {
      res.json({
        status: 'success',
        code: 200,
        message: 'No data found',
        productiveValue: productiveValue.valueForOne,
        data,
      });
    } else {
      res.json({
        status: 'success',
        code: 200,
        message: '',
        productiveValue: productiveValue.valueForOne,

        data,
      });
    }
    logger.debug(`Sent data to client : ${moment().format('YYYY/MM/DD HH:mm:ss.SSS')}`);
  } catch (error) {
    console.log(error);
    logger.error(`Failed to fetch data => ${error}`);
    res.json({
      status: 'Fail',
      code: 500,
      error: `Server error while finding data ${error}`,
    });
  }
};

const machineDataByMappingIdTimeFrame = async (machineId, mappingId, startDate, endDate, productiveValue) => {
  try {
    logger.debug(`Sending data request to service : ${moment().format('YYYY/MM/DD HH:mm:ss.SSS')}`);
    const data = await HardwareDynamicService.machineDataByMappingIdTimeFrame(
      machineId,
      mappingId,
      startDate,
      endDate,
      productiveValue,
    );
    logger.debug(`Recieved Data : \n${JSON.stringify(data)}`);

    if (!data[0]) {
      return {
        status: 'success',
        code: 200,
        message: 'No data found',
        productiveValue: productiveValue.valueForOne,
        data,
      };
    }
    if (data) {
      return {
        status: 'success',
        code: 200,
        message: 'Data found',
        productiveValue: productiveValue.valueForOne,
        data,
      };
    }

    logger.debug(`Sent data to client : ${moment().format('YYYY/MM/DD HH:mm:ss.SSS')}`);
  } catch (error) {
    logger.error(`Failed to fetch data => ${error}`);
    return {
      status: 'Fail',
      code: 500,
      error: `Server error while finding data ${error.message}`,
    };
  }
};
module.exports = {
  findUptimeDataByMachineId,
  machineProductionStatusByRecentHour,
  machineDataAsperSensorUse,
  machineDataByTimeFrame,
  partCountByTimeFrame,
  macchineOeeCalculationByInterval,
  machineDataByMappingId,
  machineDataByMappingIdTimeFrame, // method for mayur
};
