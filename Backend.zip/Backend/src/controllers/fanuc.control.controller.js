const moment = require('moment');
const logger = require('../config/logger');
const fanucControlService = require('../services/fanuc.control.service');

const findAllDataByMachineName = async (req, res) => {
  try {
    const { machine, hours } = req.params;
    const data = await fanucControlService.findAllDataByMachineName(machine, hours);

    if (!data[0]) {
      return res.status(404).json({ error: 'No data found' });
    }

    res.status(201).json(data);
  } catch (error) {
    res.status(500).json({ error: `Server error while finding uptime data for machine: ${error}` });
  }
};

const findAllMachines = async (req, res) => {
  try {
    const data = await fanucControlService.findMachineList();

    if (!data[0]) {
      return res.status(404).json({ error: 'No data found' });
    }

    res.status(201).json(data);
  } catch (error) {
    res.status(500).json({ error: `Server error while finding machine list: ${error}` });
  }
};
const findDataByName = async (req, res) => {
  try {
    const { machine, observationName, hours } = req.params; // Destructure the parameters
    const data = await fanucControlService.findDataByName(machine, observationName, hours);

    if (!data[0]) {
      return res.status(404).json({ error: 'No data found' });
    }

    res.status(201).json(data);
  } catch (error) {
    res.status(500).json({ error: `Server error while finding feed data for machine: ${error}` });
  }
};
const findUptimeFeedByHour = async (req, res) => {
  try {
    const { machine, hours } = req.params;
    const data = await fanucControlService.findUptimeFeedByHour(machine, hours);

    if (!data[0]) {
      return res.status(404).json({ error: 'No data found' });
    }

    res.status(201).json(data);
  } catch (error) {
    res.status(500).json({ error: `Server error while finding feed & uptime data for machine: ${error}` });
  }
};

const findPartNameByHours = async (req, res) => {
  try {
    const { machine, hours } = req.params;
    const data = await fanucControlService.partNameByHours(machine, hours);

    if (!data[0]) {
      return res.status(404).json({ error: 'No data found' });
    }

    res.status(201).json(data);
  } catch (error) {
    res.status(500).json({ error: `Server error while finding part data for machine: ${error}` });
  }
};

const latestMachineAlarmsMessages = async (req, res) => {
  try {
    logger.debug(`Sending data request to service : ${moment().format('YYYY/MM/DD HH:mm:ss.SSS')}`);
    const data = await fanucControlService.latestCriticalData();
    logger.debug(`Recieved Data : \n${JSON.stringify(data)}`);

    logger.debug(`Received data from service : ${moment().format('YYYY/MM/DD HH:mm:ss.SSS')}`);

    if (!data[0]) {
      return res.status(200).json({
        status: 'success',
        code: 200,
        message: 'No data found',
        data,
      });
    }

    res.status(200).json({
      status: 'success',
      code: 200,
      data,
    });

    logger.debug(`Sent data to client : ${moment().format('YYYY/MM/DD HH:mm:ss.SSS')}`);
  } catch (error) {
    res.status(500).json({
      status: 'Fail',
      code: 500,
      error: `Server error while finding alarms and machines ${error}`,
    });
  }
};

const totalAlarmsByHours = async (req, res) => {
  try {
    const { machineName } = req.body;
    logger.debug(`Sending data request to service : ${moment().format('YYYY/MM/DD HH:mm:ss.SSS')}`);
    let data = await fanucControlService.totalAlarmsByHours(machineName);
    logger.debug(`Recieved Data : \n${JSON.stringify(data)}`);

    logger.debug(`Received data from service : ${moment().format('YYYY/MM/DD HH:mm:ss.SSS')}`);

    if (!data[0]) {
      res.status(200).json({
        status: 'success',
        code: 200,
        message: 'No data found',
        data,
      });
    } else {
      data = data.map((item) => ({
        ...item,
        startTime: moment(item.startTime).format('YYYY/MM/DD HH:mm:ss.SSS'),
        endTime: moment(item.endTime).format('YYYY/MM/DD HH:mm:ss.SSS'),
      }));

      res.json({
        status: 'success',
        code: 200,
        message: '',
        data,
      });
    }
    logger.debug(`Sent data to client : ${moment().format('YYYY/MM/DD HH:mm:ss.SSS')}`);
  } catch (error) {
    res.status(500).json({
      status: 'Fail',
      code: 500,
      error: `Server error while finding alarms and machines ${error}`,
    });
  }
};
module.exports = {
  findUptimeFeedByHour,
  findPartNameByHours,
  findDataByName,
  findAllDataByMachineName,
  findAllMachines,
  latestMachineAlarmsMessages,
  totalAlarmsByHours,
};
