const moment = require('moment');
const logger = require('../config/logger');
const cloudDataSevice = require('../services/cycleData.services');

const cycleDataAnalysis = async (req, res) => {
  try {
    logger.debug(`Sending data request to service : ${moment().format('YYYY/MM/DD HH:mm:ss.SSS')}`);
    const { machineName, startDate, endDate } = req.body;
    let data = await cloudDataSevice.processCycleData(machineName, startDate, endDate);
    logger.debug(`Recieved Data : \n${JSON.stringify(data)}`);
    if (!data[0]) {
      res.json({
        status: 'success',
        code: 200,
        message: 'No data found',
        data,
      });
    } else {
      data = data.map((item) => ({
        ...item,
        starttime: moment(item.starttime).format('YYYY/MM/DD HH:mm:ss.SSS'),
        endtime: moment(item.endtime).format('YYYY/MM/DD HH:mm:ss.SSS'),
      }));

      res.json({
        status: 'success',
        code: 200,
        message: '',
        data,
      });
    }
    logger.debug(`Sent data to client : ${moment().format('YYYY/MM/DD HH:mm:ss.SSS')}`);
  } catch (error) {
    logger.error(`Failed to fetch data => ${error}`);
    return {
      status: 'Fail',
      code: 500,
      error: `Server error while finding data ${error.message}`,
    };
  }
};

module.exports = {
  cycleDataAnalysis,
};
