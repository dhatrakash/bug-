const controllerService = require('../services/controller.services');

exports.allMachineOEEData = async function (req, res) {
  try {
    const { startDate, endDate, interval } = req.body;
    const machineData = await controllerService.allMachineOEE(startDate, endDate, interval);
    res.status(200).json({ message: 'These are matching Records from hardware-routes', machineData });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.partProduceTable = async (req, res) => {
  const { date, interval } = req.body;
  try {
    const data = await controllerService.partProduce(interval, date);
    res.status(200).json({ message: 'Matching Records', data });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.selectedMachineOEEData = async function (req, res) {
  try {
    const { startDate, endDate, interval, machineName } = req.body;

    const machineData = await controllerService.machineSpecificData(startDate, endDate, interval, machineName);

    res.status(200).json({ message: 'These are matching Records from hardware-routes', machineData });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.createPdf = async function (req, res) {
  try {
    const { startDate, endDate, machineName } = req.body;

    const machineData = await controllerService.fanucDataForPDF(startDate, endDate, machineName);

    res.status(200).json({ message: 'These are matching Records from hardware-routes', machineData });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.dynamicPdf = async function (req, res) {
  try {
    const { startDate, endDate, interval, machineName } = req.body;

    const machineData = await controllerService.dynamicPdfGenerator(startDate, endDate, interval, machineName);

    res.status(200).json({ message: 'These are matching Records from hardware-routes', machineData });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.companyReport = async function (req, res) {
  try {
    const { startDate, endDate, interval} = req.body;
    const machineData = await controllerService.companyReport(startDate, endDate, interval);

    res.status(200).json({ message: 'These are matching Records from hardware-routes', machineData });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};