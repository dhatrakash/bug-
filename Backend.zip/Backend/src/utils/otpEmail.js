const nodemailer = require('nodemailer');

const EMAIL = process.env.Email;
const PASSWORD = process.env.PASSWORD;
// Function to send an email
const sendOTPEmail = (to, subject, text) => {
  const mailOptions = {
    from: EMAIL,
    to,
    subject,
    text,
  };

  const transporter = nodemailer.createTransport({
    host: 'smtp.hostinger.com',
    port: 465,
    secure: true,
    auth: {
      user: EMAIL,
      pass: PASSWORD,
    },
  });

  return new Promise((resolve, reject) => {
    transporter.sendMail(mailOptions, (error, response) => {
      if (error) {
        console.error('Error sending email:', error);
        reject(error);
      } else {
        console.log('Otp sent to Email successfully.');
        resolve(response);
      }
    });
  });
};

module.exports = sendOTPEmail;
