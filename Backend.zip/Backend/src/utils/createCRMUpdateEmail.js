const Mailgen = require('mailgen');

const mailGenerator = new Mailgen({
  theme: 'salted',
  product: {
    name: 'Wathare Infotech Solutions',
    link: 'https://wathare.com/contact-us/',
  },
});

const createCRMUpdateEmail = (formData) => {
  // Define a mapping of original keys to display names
  const keyToDisplayName = {
    companyName: 'Company Name',
    contactPersonName: 'Contact Person Name',
    contactPersonNumber: 'Contact Person Number',
    email: 'Email',
    address: 'Address',
    city: 'City',
    numOfMachines: 'Number of Machines',
    numOfHardwireMachines: 'Number of Hardwire Machines',
    numOfControllerMachines: 'Number of Controller Machines',
    demoReportDuration: 'Demo Report Duration',
    demoType: 'Demo Type',
  };

  // Create an array to store form data
  const formDataItems = [];
  console.log('Form Data:', formData);

  // Loop through the formData and add each item to the email template
  for (const key in formData) {
    if (formData.hasOwnProperty(key)) {
      formDataItems.push({
        key: keyToDisplayName[key] || key, // Use the display name or the original key
        value: formData[key],
      });
    }
  }

  const emailContent = {
    body: {
      name: 'Sourabh',
      intro: 'Here are the recent submitted FormDetails for CRM Utility Demo:',
      table: {
        data: formDataItems, // Use the array of form data items
      },
      outro: `${formData.contactPersonName} has Access to Dashboard`,
    },
  };
  console.log('Generated Email Content:', emailContent);

  // Add line breaks to create gaps
  emailContent.body.intro += '<br><br>'; // Add two line breaks after the intro
  emailContent.body.outro += '<br><br>'; // Add two line breaks before the outro

  return mailGenerator.generate(emailContent);
};

module.exports = createCRMUpdateEmail;
