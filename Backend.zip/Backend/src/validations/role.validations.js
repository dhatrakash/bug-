const Joi = require('joi');
const { objectId } = require('./custom.validation');

const createRole = {
  body: Joi.object().keys({
    role: Joi.string().required(),
  }),
};

const addFunctToRole = {
  body: Joi.object().keys({
    roleName: Joi.string().required(),
    functionalityName: Joi.string().required(),
  }),
};

const deleteFunctToRole = {
  body: Joi.object().keys({
    roleName: Joi.string().required(),
    functionalityName: Joi.string().required(),
  }),
};

const getRoleByID = {
  body: Joi.object().keys({
    roleId: Joi.required().custom(objectId),
  }),
};

const getRoleByName = {
  body: Joi.object().keys({
    roleName: Joi.string().required(),
  }),
};
const deleteRoleById = {
  body: Joi.object().keys({
    roleId: Joi.required().custom(objectId),
  }),
};

module.exports = {
  createRole,
  addFunctToRole,
  deleteFunctToRole,
  getRoleByID,
  getRoleByName,
  deleteRoleById,
};
