const Joi = require('joi');

const createReason = {
  body: Joi.object().keys({
    reason_id: Joi.number().required(),
    reason: Joi.string().required(),
  }),
};

const getReasondataByReasonid = {
  body: Joi.object().keys({
    reason_id: Joi.number().required(),
  }),
};

const deleteReasonsData = {
  body: Joi.object().keys({
    reason_id: Joi.number().required(),
  }),
};

const updateReasonData = {
  body: Joi.object().keys({
    reason_id: Joi.number().required(),
    update_field: Joi.string().required().valid('state', 'color', 'reason'),
    value: Joi.string().required(),
  }),
};

module.exports = {
  createReason,
  getReasondataByReasonid,
  deleteReasonsData,
  updateReasonData,
};
