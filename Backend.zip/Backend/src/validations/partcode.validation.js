const Joi = require('joi');
const isoDateWithZRegex = /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z)$/;

const createPartCode = {
  body: Joi.object().keys({
    partCode: Joi.string().required(),
    mac: Joi.string().required(),
    dtm: Joi.string().regex(isoDateWithZRegex).required(),
  }),
};

const getPartCode = {
  body: Joi.object().keys({
    mac: Joi.string().required(),
    startDate: Joi.string().regex(isoDateWithZRegex).required(),
    endDate: Joi.string().regex(isoDateWithZRegex).required(),
  }),
};

module.exports = {
  createPartCode,
  getPartCode,
};
