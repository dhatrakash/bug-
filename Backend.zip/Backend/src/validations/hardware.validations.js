const Joi = require('joi');
const { password } = require('./custom.validation');
const isoDateWithZRegex = /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z)$/;

const getDataByTimeFrame = {
  body: Joi.object().keys({
    mac: Joi.string().required(),
    hours: Joi.number().min(1).required(),
  }),
};

const partProduceTable = {
  body: Joi.object().keys({
    date: Joi.string().regex(isoDateWithZRegex).required(),
    interval: Joi.number().min(1).required(),
  }),
};

const oeeChart = {
  body: Joi.object().keys({
    startDate: Joi.string().regex(isoDateWithZRegex).required(),
    endDate: Joi.string().regex(isoDateWithZRegex).required(),
    interval: Joi.number().min(1).required(),
    mac: Joi.string().required(),
  }),
};

const companyOEE = {
  body: Joi.object().keys({
    email: Joi.string().required().email(),
    password: Joi.string().required().custom(password),
    startDate: Joi.string().regex(isoDateWithZRegex).required(),
    endDate: Joi.string().regex(isoDateWithZRegex).required(),
    interval: Joi.number().min(1).required(),
  }),
};

const pdfGenerator = {
  body: Joi.object().keys({
    startDate: Joi.string().regex(isoDateWithZRegex).required(),
    endDate: Joi.string().regex(isoDateWithZRegex).required(),
    mac: Joi.string().required(),
  }),
};
const machineReport = {
  body: Joi.object().keys({
    startDate: Joi.string().regex(isoDateWithZRegex).required(),
    endDate: Joi.string().regex(isoDateWithZRegex).required(),
    mac: Joi.string().required(),
  }),
};

const getPipelineData = {
  body: Joi.object().keys({
    startDate: Joi.string().regex(isoDateWithZRegex).required(),
    endDate: Joi.string().regex(isoDateWithZRegex).required(),
  }),
};

module.exports = {
  getDataByTimeFrame,
  partProduceTable,
  getPipelineData,
  oeeChart,
  companyOEE,
  pdfGenerator,
  machineReport,
};
