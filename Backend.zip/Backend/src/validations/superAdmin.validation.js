const Joi = require('joi');
const { password, objectId } = require('./custom.validation');

const getSuperAdmins = {
  query: Joi.object().keys({
    name: Joi.string(),
    role: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

const getSuperAdmin = {
  params: Joi.object().keys({
    superAdminId: Joi.string().custom(objectId),
  }),
};

const updateSuperAdmin = {
  params: Joi.object().keys({
    superAdminId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      email: Joi.string().email(),
      password: Joi.string().custom(password),
      name: Joi.string(),
    })
    .min(1),
};

const deleteSuperAdmin = {
  params: Joi.object().keys({
    superAdminId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  getSuperAdmins,
  getSuperAdmin,
  updateSuperAdmin,
  deleteSuperAdmin,
};
