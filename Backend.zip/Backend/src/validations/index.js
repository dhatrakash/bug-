module.exports.authValidation = require('./auth.validation');
module.exports.userValidation = require('./user.validation');
module.exports.RoleValidation = require('./role.validations');
module.exports.hardwareValidation = require('./hardware.validations');
module.exports.DowntimeReasonValidation = require('./downtimeReason.validation');
module.exports.partcodeValidation = require('./partcode.validation');
