const MachineGatewayAssociation = require('../models/machineMapping.model');
const GatewaySensorAssociation = require('../models/GatewaySensorAssociation.model');
const GatewayIoAssociation = require('../models/GatewayInputs.model');
const Sensor = require('../models/sensor.model');
const Gateway = require('../models/gateway.model');

const createMapping = async (associationData) => {
  try {
    const { machineId, mappings } = associationData;

    // Check if there is an existing mapping for the given machineId
    const existingMachineMapping = await MachineGatewayAssociation.findOne({
      machineId,
      isActive: true,
    });

    if (existingMachineMapping) {
      // Check for duplicate mappings in the existing mapping
      mappings.forEach((newMapping) => {
        const isDuplicate = existingMachineMapping.mappings.some((existingMapping) => {
          return (
            existingMapping.mappingId.toString() === newMapping.mappingId &&
            existingMapping.sensorNodeType === newMapping.sensorNodeType
          );
        });

        if (isDuplicate) {
          throw new Error('Duplicate mapping detected');
        }

        // Add the new mapping to the existing mapping
        existingMachineMapping.mappings.push(newMapping);
      });

      // Save the updated existing mapping
      await existingMachineMapping.save();
      return existingMachineMapping;
    }

    // If no existing mapping, perform the initial checks and create a new association
    const mappingPromises = mappings.map(async (document) => {
      const gatewayAssociationId = document.mappingId;
      if (document.sensorNodeType === 'modbus') {
        // Check if a GatewaySensorAssociation exists for the given mappingId
        const gatewaySensorAssociation = await GatewaySensorAssociation.findOne({
          mappingId: gatewayAssociationId,
        });
        if (!gatewaySensorAssociation) {
          throw new Error('Wrong mapping Id in slave');
        }
      }
      if (document.sensorNodeType === 'io') {
        // Check if a GatewayIoAssociation exists for the given mappingId
        const gatewayIoAssociation = await GatewayIoAssociation.findOne({
          mappingId: gatewayAssociationId,
        });
        if (!gatewayIoAssociation) {
          throw new Error('Wrong mapping Id in IO');
        }
      }
    });

    await Promise.all(mappingPromises);

    // Create the new association if all mappingIds are valid
    const createdAssociation = await MachineGatewayAssociation.create(associationData);
    return createdAssociation;
  } catch (error) {
    throw new Error(`Failed to create the mapping: ${error.message}`);
  }
};

const updateMapping = async (machineMappingId, uniqueRef, associationData) => {
  try {
    const { mappingId, sensorNodeType } = associationData;

    const existingMachineMapping = await MachineGatewayAssociation.findOne({
      machineMappingId,
    });

    if (!existingMachineMapping) {
      throw new Error('Failed to find existing machine mapping to update');
    }

    // Find the index of the mapping to update in the mappings array using uniqueRef
    const mappingIndex = existingMachineMapping.mappings.findIndex((m) => m.uniqueRef === uniqueRef);

    if (mappingIndex === -1) {
      throw new Error('Mapping to update not found');
    }

    // Update the mapping with the new data
    existingMachineMapping.mappings[mappingIndex].mappingId = mappingId;
    existingMachineMapping.mappings[mappingIndex].sensorNodeType = sensorNodeType;

    // Save the updated machine mapping
    await existingMachineMapping.save();

    return existingMachineMapping;
  } catch (error) {
    throw new Error(`Failed to update the mapping: ${error.message}`);
  }
};

const softDeleteWholeMapping = async (machineMappingId) => {
  try {
    const result = await MachineGatewayAssociation.findOne({ machineMappingId });
    result.isActive = false;
    const updatedMapping = result.mappings.map((document) => ({
      ...document,
      deletedAt: Date.now(),
    }));
    result.mappings = updatedMapping;
    const updatedResult = await result.save();
    return updatedResult;
  } catch (error) {
    throw new Error(` Failed to softDelete the mapping`);
  }
};
// const softDeleteMapping = async (machineMappingId, mappingId) => {
//   try {
//     // finding the mapping
//     const existingMachineMapping = await MachineGatewayAssociation.findOne({
//       machineMappingId,
//       isActive: true,
//     });

//     if (!existingMachineMapping) {
//       console.error('Failed to find existing machine mapping to update');
//       throw new Error('Failed to find existing machine mapping to update');
//     }
//     console.log('Existing Machine Mapping:', existingMachineMapping);

//     // Add more logging to check the data

//     // find the mapping which needed to delete
//     const mappingToDelete = existingMachineMapping.mappings.find(
//       (mapping) => mapping.mappingId.toString() === mappingId.trim(),
//     );

//     if (!mappingToDelete) {
//       console.error('Mapping to delete not found');
//       throw new Error('Mapping to delete not found');
//     }
//     console.log('Mapping to Delete:', mappingToDelete);

//     // set it to the current date
//     mappingToDelete.deletedAt = new Date();
//     // set this whole mapping to inactive
//     existingMachineMapping.isActive = false;
//     await existingMachineMapping.save();
//     console.log('Updated Machine Mapping:', existingMachineMapping);

//     const remainingMappings = existingMachineMapping.mappings.filter((mapping) => mapping.deletedAt === null);
//     console.log('Remaining Mappings:', remainingMappings);

//     const updatedMapping = await createMapping({
//       machineId: existingMachineMapping.machineId,
//       mappings: remainingMappings,
//     });
//     console.log('Updated Mapping:', updatedMapping);

//     return updatedMapping;
//   } catch (error) {
//     console.error(`Failed to delete the mapping: ${error.message}`);
//     throw new Error(`Failed to delete the mapping: ${error.message}`);
//   }
// };

const softDeleteMapping = async (machineMappingId, mappingId) => {
  try {
    // Finding the mapping
    const existingMachineMapping = await MachineGatewayAssociation.findOne({
      machineMappingId,
      isActive: true,
    });

    if (!existingMachineMapping) {
      console.error('Failed to find existing machine mapping to update');
      throw new Error('Failed to find existing machine mapping to update');
    }
    console.log('Existing Machine Mapping:', existingMachineMapping);

    // Find the mapping to delete
    const mappingToDelete = existingMachineMapping.mappings.find(
      (mapping) => mapping.mappingId.toString() === mappingId.trim(),
    );

    if (!mappingToDelete) {
      console.error('Mapping to delete not found');
      throw new Error('Mapping to delete not found');
    }
    console.log('Mapping to Delete:', mappingToDelete);

    // Set deletedAt to the current date
    mappingToDelete.deletedAt = new Date();

    // Create a new document with isActive as true and mappings excluding the deleted one
    const newMachineMapping = new MachineGatewayAssociation({
      machineMappingId,
      machineId: existingMachineMapping.machineId,
      isActive: true,
      mappings: existingMachineMapping.mappings.filter((mapping) => mapping.deletedAt === null),
    });

    // Save the new document
    await newMachineMapping.save();

    // Set isActive to false in the previous document
    existingMachineMapping.isActive = false;
    existingMachineMapping.deletedAt = new Date();
    await existingMachineMapping.save();

    console.log('New Machine Mapping:', newMachineMapping);

    return newMachineMapping;
  } catch (error) {
    console.error(`Failed to delete the mapping: ${error.message}`);
    throw new Error(`Failed to delete the mapping: ${error.message}`);
  }
};

const findActiveMappings = async (machineId) => {
  try {
    const result = await MachineGatewayAssociation.findOne({ machineId, isActive: true }).populate('mappings.mappingId');
    if (!result) {
      throw new Error(`No document found`);
    }
    return result;
  } catch (error) {
    throw new Error(`Failed to find active mappings of machineId ${machineId}`);
  }
};
const findInActiveMappings = async (machineId) => {
  try {
    const result = await MachineGatewayAssociation.findOne({ machineId, isActive: false });
    if (!result) {
      throw new Error(`No document found`);
    }
    return result;
  } catch (error) {
    throw new Error(`Failed to find inactive mappings of machineId ${machineId} : ${error}`);
  }
};
const findMappingByMachineMappingId = async (machineMappingId) => {
  try {
    const result = await MachineGatewayAssociation.findOne({ machineMappingId }).populate('mappings.mappingId');
    if (!result) {
      throw new Error(`No document found`);
    }
    return result;
  } catch (error) {
    throw new Error(`Failed to find  mappings of machineId ${machineMappingId}`);
  }
};
const deleteMapping = async (machineMappingId) => {
  try {
    const result = await MachineGatewayAssociation.findOneAndDelete({ machineMappingId });
    return result;
  } catch (error) {
    throw new Error(` Failed to Delete the mapping`);
  }
};
const findNodesByMachineId = async (machineId) => {
  try {
    const machineMapping = await MachineGatewayAssociation.findOne({ machineId, isActive: true }).populate(
      'mappings.mappingId',
    );
    if (!machineMapping) {
      throw new Error('No mappings found');
    }
    const result = machineMapping.mappings.map(async (mapping) => {
      const sensor = await Sensor.findOne({ sensorId: mapping.mappingId.sensorId });
      const gateway = await Gateway.findOne({ gatewayId: mapping.mappingId.gatewayId });
      if (!sensor || !gateway) return;
      // Use parseInt to ensure sid is an integer
      const sid = mapping.sensorNodeType === 'modbus' ? parseInt(mapping.mappingId.slaveId, 10) : 1;
      return {
        field: mapping.sensorNodeType,
        tag: mapping.mappingId.tag,
        sid,
        mac: gateway.macId,
        sensorUse: sensor.sensorUse,
      };
    });

    // Use Promise.all to await all the async operations
    const resolvedResult = await Promise.all(result);
    return resolvedResult;
  } catch (error) {
    throw new Error(`Failed to fetch associations by machineId: ${error.message}`);
  }
};

// findNodesByMachineId('6527df4eb6d619f612b8c50f');
module.exports = {
  createMapping,
  findActiveMappings,
  findInActiveMappings,
  findMappingByMachineMappingId,
  deleteMapping,
  softDeleteWholeMapping,
  softDeleteMapping,
  updateMapping,
  findNodesByMachineId,
};
