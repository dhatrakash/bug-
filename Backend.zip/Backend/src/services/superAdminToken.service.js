const jwt = require('jsonwebtoken');
const moment = require('moment');
const httpStatus = require('http-status');
const config = require('../config/config');
const superAdminServices = require('./superAdmin.service');
const { SuperAdminTokens } = require('../models');
const ApiError = require('../utils/ApiError');
const { tokenTypes } = require('../config/tokens');


/**
 * Generate token
 * @param {ObjectId} userId
 * @param {Moment} expires
 * @param {string} type
 * @param {string} [secret]
 * @returns {string}
 */
const generateToken = (superAdminId, expires, type, secret = config.jwt.secret) => {
  const payload = {
    sub: superAdminId,
    iat: moment().unix(),
    exp: expires.unix(),
    type,
  };
  return jwt.sign(payload, secret);
};

/**
 * Save a token
 * @param {string} token
 * @param {ObjectId} superAdminId
 * @param {Moment} expires
 * @param {string} type
 * @param {boolean} [blacklisted]
 * @returns {Promise<Token>}
 */
const saveSuperAdminToken = async (token, superAdminId, expires, type, blacklisted = false) => {
  const tokenDoc = await SuperAdminTokens.create({
    token,
    superAdmin: superAdminId,
    expires: expires.toDate(),
    type,
    blacklisted,
  });
  return tokenDoc;
};

/**
 * Verify token and return token doc (or throw an error if it is not valid)
 * @param {string} token
 * @param {string} type
 * @returns {Promise<Token>}
 */
const verifySuperAdminToken = async (token, type) => {
  const payload = jwt.verify(token, config.jwt.secret);
  const tokenDoc = await SuperAdminTokens.findOne({ token, type, superAdmin: payload.sub, blacklisted: false });
  if (!tokenDoc) {
    throw new Error('Super-Admin Token not found');
  }
  return tokenDoc;
};

/**
 * Generate auth tokens
 * @param {SuperAdmin} SuperAdmin
 * @returns {Promise<Object>}
 */
const generateAuthTokens = async (SuperAdmin) => {
  const accessTokenExpires = moment().add(config.jwt.accessExpirationMinutes, 'minutes');
  const accessToken = generateToken(SuperAdmin.id, accessTokenExpires, tokenTypes.ACCESS);

  const refreshTokenExpires = moment().add(config.jwt.refreshExpirationDays, 'days');
  const refreshToken = generateToken(SuperAdmin.id, refreshTokenExpires, tokenTypes.REFRESH);
  await saveSuperAdminToken(refreshToken, SuperAdmin.id, refreshTokenExpires, tokenTypes.REFRESH);

  return {
    access: {
      token: accessToken,
      expires: accessTokenExpires.toDate(),
    },
    refresh: {
      token: refreshToken,
      expires: refreshTokenExpires.toDate(),
    },
  };
};

/**
 * Generate reset password token
 * @param {string} email
 * @returns {Promise<string>}
 */
const generateResetPasswordToken = async (email) => {
  const superAdmin = await superAdminServices.getsuperAdminByEmail(email);
  if (!superAdmin) {
    throw new ApiError(httpStatus.NOT_FOUND, 'No Super-Admin found with this email');
  }
  const expires = moment().add(config.jwt.resetPasswordExpirationMinutes, 'minutes');
  const resetPasswordToken = generateToken(superAdmin.id, expires, tokenTypes.RESET_PASSWORD);
  await saveSuperAdminToken(resetPasswordToken, superAdmin.id, expires, tokenTypes.RESET_PASSWORD);
  return resetPasswordToken;
};

/**
 * Generate verify email token
 * @param {SuperAdmin} superAdmin
 * @returns {Promise<string>}
 */
const generateVerifyEmailToken = async (superAdmin) => {
  const expires = moment().add(config.jwt.verifyEmailExpirationMinutes, 'minutes');
  const verifyEmailToken = generateToken(superAdmin.id, expires, tokenTypes.VERIFY_EMAIL);
  await saveSuperAdminToken(verifyEmailToken, superAdmin.id, expires, tokenTypes.VERIFY_EMAIL);
  return verifyEmailToken;
};

module.exports = {
  generateToken,
  saveSuperAdminToken,
  verifySuperAdminToken,
  generateAuthTokens,
  generateResetPasswordToken,
  generateVerifyEmailToken,
};
