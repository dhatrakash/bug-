const moment = require('moment');
const controllerPipe = require('./controllerPipe.services');
const Fanuc = require('../models/fanuc.mqtt.model');

const allMachineOEE = async (startDate, endDate, interval) => {
  try {
    startDate = moment(startDate).subtract(5, 'hours').subtract(30, 'minutes');
    endDate = moment(endDate).subtract(5, 'hours').subtract(30, 'minutes');

    const results = [];
    while (startDate.isBefore(endDate)) {
      const currentHourStart = startDate.clone();
      let currentHourEnd = startDate.clone().add(interval, 'hour');

      if (currentHourStart.isAfter(endDate.clone().subtract(interval, 'hour'))) {
        currentHourEnd = endDate.clone();
      }

      const resultArray = {
        hour: currentHourStart.clone().add(5, 'hours').add(30, 'minutes').utc().format(),
        machineON: 0,
        productionTime: 0,
        idealTime: 0,
        production: 0,
        reportTime: currentHourEnd.diff(currentHourStart, 'second'),
        OEE: 0,
        autoMode0: 0,
        autoMode1: 0,
        autoMode6: 0,
      };

      const data = await controllerPipe.allMachineData(
        currentHourStart.valueOf(),
        currentHourEnd.valueOf(),
        resultArray.reportTime,
      );

      resultArray.productionTime = data.productionTime;
      resultArray.idealTime = data.idleTime;
      resultArray.production = data.productCount;
      resultArray.OEE = data.availability * data.performance * data.quality * 100;
      // resultArray.autoMode0 = data.autoMode0;
      // resultArray.autoMode1 = data.autoMode1;
      // resultArray.autoMode6 = data.autoMode6;
      resultArray.machineON = data.machineON;

      results.push(resultArray);

      startDate.add(interval, 'hour');
    }

    return results;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};

const partProduce = async (interval, date) => {
  try {
    endDate = moment(date).subtract(5, 'hours').subtract(30, 'minutes');
    const startDate = endDate.clone().subtract(interval, 'hours');
    const data = await controllerPipe.productCountByMachineName(startDate.valueOf(), endDate.valueOf());
    return data;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};

const machineSpecificData = async (startDate, endDate, interval, machineName) => {
  try {
    startDate = moment(startDate).subtract(5, 'hours').subtract(30, 'minutes');
    endDate = moment(endDate).subtract(5, 'hours').subtract(30, 'minutes');


    const results = [];
    while (startDate.isBefore(endDate)) {
      const currentHourStart = startDate.clone();
      let currentHourEnd = startDate.clone().add(interval, 'hour');

      if (currentHourStart.isAfter(endDate.clone().subtract(interval, 'hour'))) {
        currentHourEnd = endDate.clone();
      }

      const resultArray = {
        hour: (currentHourStart.clone().add(5, 'hours').add(30, 'minutes')).utc().format(),
        machineON: 0,
        productionTime: 0,
        idleTime: 0,
        production: 0,
        OEE: 0,
        reportTime: currentHourEnd.diff(currentHourStart, 'second'),
        autoMode0: 0,
        autoMode1: 0,
        autoMode6: 0,
      };

      const data = await controllerPipe.selectedMachineData(
        currentHourStart.valueOf(),
        currentHourEnd.valueOf(),
        resultArray.reportTime,
        machineName,
      );

      resultArray.productionTime = data.productionTime;
      resultArray.idleTime = data.idleTime;
      resultArray.production = data.productCount;
      resultArray.OEE = data.availability * data.performance * data.quality * 100;
      resultArray.autoMode0 = data.autoMode0;
      resultArray.autoMode1 = data.autoMode1;
      resultArray.autoMode6 = data.autoMode6;
      resultArray.machineON = data.machineON;

      results.push(resultArray);

      startDate.add(interval, 'hour');
    }

    return results;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};

const fanucDataForPDF = async (startDate, endDate, machineName) => {
  try {
    startDate = moment(startDate).subtract(5, 'hours').subtract(30, 'minutes');
    endDate = moment(endDate).subtract(5, 'hours').subtract(30, 'minutes');

    const resultArray = {
      startDate: startDate,
      endDate: endDate,
      reportTime: endDate.diff(startDate, 'second'),
      machineOnTime: 0,
      rejectionQuantity: 0,
      actualProduction: 0,
      part_2055566_3rd: 9,
      production: 0,
      targetProduction: 400,
      firstCycle: 0,
      lastCycle: 0,
      part_8PEE027000161N_2ND: 120,
      avgCycleTime: 0,
      productionTime: 0,
      idleTime: 0,
      mhrLoss: 0,
    };

    const data = await controllerPipe.selectedMachineData(
      startDate.valueOf(),
      endDate.valueOf(),
      resultArray.reportTime,
      machineName,
    );

    resultArray.machineOnTime = data.machineON;
    resultArray.actualProduction = data.productCount;
    resultArray.production = data.productCount;
    resultArray.productionTime = data.productionTime;
    resultArray.idleTime = data.idleTime;

    return resultArray;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};

const dynamicPdfGenerator = async (startDate, endDate, interval, machineName) => {
  try {
    startDate = moment(startDate).subtract(5, 'hours').subtract(30, 'minutes');
    endDate = moment(endDate).subtract(5, 'hours').subtract(30, 'minutes');

    const results = [];
    while (startDate.isBefore(endDate)) {
      const currentHourStart = startDate.clone();
      let currentHourEnd = startDate.clone().add(interval, 'hour');

      if (currentHourStart.isAfter(endDate.clone().subtract(interval, 'hour'))) {
        currentHourEnd = endDate.clone();
      }

      const resultArray = {
        startDate: currentHourStart.clone().add(5, 'hours').add(30, 'minutes').utc().format(),
        endDate: currentHourEnd.clone().add(5, 'hours').add(30, 'minutes').utc().format(),
        reportTime: currentHourEnd.diff(currentHourStart, 'second'),
        machineON: 0,
        rejectionQuantity: 0,
        actualProduction: 0,
        productionTime: 0,
        idleTime: 0,
        production: 0,
        availability: 0,
        performance: 0,
        quality: 0,
        OEE: 0,
        targetProduction: 0,
      };

      const data = await controllerPipe.dynamicPdfGenerator(
        currentHourStart.valueOf(),
        currentHourEnd.valueOf(),
        resultArray.reportTime,
        machineName,
      );

      resultArray.productionTime = data.productionTime;
      resultArray.idleTime = data.idleTime;
      resultArray.production = data.productCount;
      resultArray.OEE = data.availability * data.performance * data.quality * 100;
      resultArray.machineON = data.machineON;
      resultArray.actualProduction = data.productCount;
      resultArray.availability = data.availability;
      resultArray.performance = data.performance;

      results.push(resultArray);

      startDate.add(interval, 'hour');
    }

    return results;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};

const companyReport = async (startDate, endDate, interval) => {
  try {
    startDate = moment(startDate).subtract(5, 'hours').subtract(30, 'minutes');
    endDate = moment(endDate).subtract(5, 'hours').subtract(30, 'minutes');
    const results = [];
    while (startDate.isBefore(endDate)) {
      const currentHourStart = startDate.clone();
      let currentHourEnd = startDate.clone().add(interval, 'hour');

      if (currentHourStart.isAfter(endDate.clone().subtract(interval, 'hour'))) {
        currentHourEnd = endDate.clone();
      }

      const resultArray = {
        startDate: currentHourStart.clone().add(5, 'hours').add(30, 'minutes').utc().format(),
        endDate: currentHourEnd.clone().add(5, 'hours').add(30, 'minutes').utc().format(),
        reportTime: currentHourEnd.diff(currentHourStart, 'second'),
        machineON: 0,
        rejectionQuantity: 0,
        actualProduction: 0,
        productionTime: 0,
        idleTime: 0,
        production: 0,
        availability: 0,
        performance: 0,
        quality: 0,
        OEE: 0,
        targetProduction: 0,
      };

      const data = await controllerPipe.companyReport(
        currentHourStart.valueOf(),
        currentHourEnd.valueOf(),
        resultArray.reportTime,
      );
      resultArray.productionTime = data.productionTime;
      resultArray.idleTime = data.idleTime;
      resultArray.production = data.productCount;
      resultArray.OEE = data.availability * data.performance * data.quality * 100;
      resultArray.machineON = data.machineON;
      resultArray.actualProduction = data.productCount;
      resultArray.availability = data.availability;
      resultArray.performance = data.performance;

      results.push(resultArray);

      startDate.add(interval, 'hour');
    }

    return results;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};

module.exports = {
  // controller data fetch
  allMachineOEE,
  // part produce data fetch
  partProduce,
  // fetching OEE data of selecteed machine
  machineSpecificData,
  // data for pdf generate.
  fanucDataForPDF,
  // data for machine pdf
  dynamicPdfGenerator,
  // data for comany pdf
  companyReport
};
