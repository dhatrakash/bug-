const moment = require('moment');
const Hardware = require('../models/hardware.model');
const pipeline = require('../services/pipeline.services');

const findDataByTimeFrame = async (requestBody) => {
  const hours = parseInt(requestBody.hours, 10);
  if (hours < 1) throw new Error(`hours should be more than 1`);
  const { mac } = requestBody;
  // Subtract the hours from the current date and time
  const startTime = moment().subtract(hours, 'hours').format();
  const endTime = moment().format();
  const pipeline = [
    {
      $match: {
        'data.mac': mac,
        'data.dtm': { $gte: startTime, $lte: endTime },
      },
    },
  ];

  const foundData = await Hardware.aggregate(pipeline);
  return foundData;
};

const findDataByTimeFrame1 = async (reqQuery) => {
  // hardware data => machineId return => uptime_data
  const hours = parseInt(reqQuery.hours, 10);
  const { mac } = reqQuery;
  // Subtract the hours from the current date and time
  const startTime = moment().subtract(hours, 'hours').utc().format();
  const endTime = moment().utc().format();

  const foundData = await Hardware.find({
    'data.mac': mac,
    'data.dtm': { $gte: startTime, $lte: endTime },
  });

  return foundData;
};

const fetchDataByTimeInterval = async (interval, date) => {
  try {
    const selectedDate = moment.utc(date);
    const startDate = selectedDate.clone().subtract(interval, 'hours').format();
    const endDate = selectedDate.utc().format();
    const data = await pipeline.productCountByMac(startDate, endDate);

    return data;
  } catch (err) {
    console.log(err);
  }
};

const oeeCalculation = async (startDate, endDate, interval, mac) => {
  const windowStart = moment.utc(startDate);
  const windowEnd = moment.utc(endDate);

  const results = [];
  while (windowStart.isBefore(windowEnd)) {
    const currentHourStart = windowStart.clone();
    const currentHourEnd = windowStart.clone().add(interval, 'hour');
    const resultArray = {
      hour: currentHourStart.utc().format(),
      productionTime: 0,
      idealTime: 0,
      production: 0,
      OEE: 0,
    };
    const data = await pipeline.selectedMachineData(currentHourStart.utc().format(), currentHourEnd.utc().format(), mac);

    resultArray.productionTime = data.productionTime;
    resultArray.idealTime = data.idealTime;
    resultArray.production = data.productCount;
    resultArray.OEE = data.availability * data.performance * data.quality;

    results.push(resultArray);
    windowStart.add(interval, 'hour');
  }
  return results;
};

const allMachineOEE = async (startDate, endDate, interval) => {
  const windowStart = moment.utc(startDate);
  const windowEnd = moment.utc(endDate);

  const results = [];
  while (windowStart.isBefore(windowEnd)) {
    const currentHourStart = windowStart.clone();
    const currentHourEnd = windowStart.clone().add(interval, 'hour');
    const resultArray = {
      hour: currentHourStart.utc().format(),
      machineON: 0,
      productionTime: 0,
      idealTime: 0,
      production: 0,
      OEE: 0,
      reportTime: interval * 3600,
    };

    const data = await pipeline.allMachineData(currentHourStart.utc().format(), currentHourEnd.utc().format());

    resultArray.machineON = data.machineON;
    resultArray.productionTime = data.productionTime;
    resultArray.idealTime = data.idealTime;
    resultArray.production = data.productCount;
    resultArray.OEE = data.availability * data.performance * data.quality;

    results.push(resultArray);
    windowStart.add(interval, 'hour');
  }

  return results;
};

const machineSpecific = async (startDate, endDate, mac) => {
  const windowStart = moment.utc(startDate);
  const windowEnd = moment.utc(endDate);

  const results = [];
  while (windowStart.isBefore(windowEnd)) {
    const currentHourStart = windowStart.clone();
    const currentHourEnd = windowStart.clone().add(0.25, 'hour');
    const resultArray = {
      hour: currentHourStart.utc().format(),
      productionTime: 0,
      idealTime: 0,
      production: 0,
      OEE: 0,
    };

    const data = await pipeline.selectedMachineData(currentHourStart.utc().format(), currentHourEnd.utc().format(), mac);

    resultArray.productionTime = data.productionTime;
    resultArray.idealTime = data.idealTime;
    resultArray.production = data.productCount;
    resultArray.OEE = data.availability * data.performance * data.quality;
    results.push(resultArray);
    windowStart.add(0.25, 'hour');
  }
  return results;
};

const dataForPDF = async (startDate, endDate, mac) => {
  const datafetch = await pipeline.selectedMachineData(startDate, endDate, mac);

  const resultArray = {
    startDate: startDate,
    endDate: endDate,
    totalHour: 22,
    machineOnTime: 0,
    rejectionQuantity: 0,
    actualProduction: 0,
    part_2055566_3rd: 9,
    production: 0,
    targetProduction: 400,
    firstCycle: 0,
    lastCycle: 0,
    part_8PEE027000161N_2ND: 120,
    avgCycleTime: 0,
    productionTime: 0,
    idealTime: 0,
    mhrLoss: 0,
  };

  resultArray.machineOnTime = datafetch.productionTime + datafetch.idealTime;
  resultArray.actualProduction = datafetch.productCount;
  resultArray.production = datafetch.productCount;
  resultArray.productionTime = datafetch.productionTime;
  resultArray.idealTime = datafetch.idealTime;

  return resultArray;
};

const createHardware = async (hardwareData) => {
  try {
    const createdHardware = await Hardware.create(hardwareData);
    return createdHardware;
  } catch (error) {
    throw new Error('Failed to create hardware error');
  }
};
const getChartData = async (startDate, endDate) => {
  try {
    // Convert startDate and endDate to Date objects for comparison
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate);

    // Check if startDate is greater than or equal to endDate
    if (startDateObj >= endDateObj) {
      throw new Error('startDate must be less than endDate.');
    }

    const mac = '608A10B603EC';
    const foundData = await Hardware.find({
      'data.mac': mac,
      'data.dtm': { $gt: startDate, $lt: endDate },
    }).sort({
      'data.dtm': 1,
    });
    const result = foundData.map((document) => ({
      dtm: document.data.dtm,
      productionStatus: document.data.io.di1,
    }));
    return result;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};
module.exports = {
  // req.body based post
  findDataByTimeFrame,
  // parts count
  fetchDataByTimeInterval,
  // OEE,parts count,performance time,ideal time
  oeeCalculation,
  // OEE calculation include all machine.
  allMachineOEE,
  // machine specific data fetch
  machineSpecific,
  // data for pdf generation.
  dataForPDF,
  // data for adding hardware.
  createHardware,

  getChartData,
};
