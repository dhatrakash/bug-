const GatewaySensorAssociation = require('./GatewaySensorSlaveMapping.service');
const Gateway = require('../models/gateway.model');
// Create a new gateway
const createGateway = async (gatewayData) => {
  const gateway = await Gateway.create(gatewayData);
  return gateway;
};
// Get all gateways
const getAllGateways = async () => {
  const gateway = await Gateway.find();
  return gateway;
};

// Get a gateway by ID
const getGatewayById = async (gatewayId) => {
  const gateway = await Gateway.findOne({ gatewayId });
  return gateway;
};

// Update a gateway by ID
const updateGateway = async (gatewayId, gatewayData) => {
  const gateway = await Gateway.findOneAndUpdate({ gatewayId }, gatewayData, { new: true });
  return gateway;
};

// Delete a gateway by ID
const deleteGateway = async (gatewayId) => {
  const gateway = await Gateway.findOneAndRemove({ gatewayId });
  await GatewaySensorAssociation.softDeleteByGatewayId(gatewayId);

  return gateway;
};

module.exports = {
  // gateway
  createGateway,
  getAllGateways,
  getGatewayById,
  updateGateway,
  deleteGateway,
};
