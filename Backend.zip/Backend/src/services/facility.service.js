const Facility = require('../models/facility.model');

const createFacility = async (data) => {
  try {
    const facilityData = {
      ...data,
      facilityLocation: data.facilityLocation,
    };
    const createdFacility = await Facility.create(facilityData);
    return createdFacility;
  } catch (error) {
    throw new Error(`Failed to create facility: ${error}`);
  }
};

const findAllFacilities = async () => {
  try {
    const facilities = await Facility.find();
    // console.log('Facilities:', facilities); // Log the facilities
    return facilities;
  } catch (error) {
    throw new Error(`Failed to retrieve Facility data: ${error}`);
  }
};

const findFacilityById = async (id) => {
  try {
    const facility = await Facility.findOne({ _id: id });
    return facility;
  } catch (error) {
    throw new Error(`Failed to retrieve facility data: ${error}`);
  }
};

const updateFacility = async (_id, updateBody) => {
  const updatedData = new Facility(updateBody);
  try {
    const updatedFacility = await Facility.findOneAndUpdate({ _id }, updatedData, { new: true });
    if (!updatedFacility) throw new Error(`No facility found with _id ${_id}`);

    return updatedFacility;
  } catch (error) {
    throw new Error(`Failed to update facility data: ${error}`);
  }
};

const deleteFacility = async (_id) => {
  try {
    await Facility.deleteOne({ _id: _id });
    return true;
  } catch (error) {
    throw new Error(`Failed to delete facility: ${error}`);
  }
};

module.exports = {
  // facility
  createFacility,
  findAllFacilities,
  findFacilityById,
  updateFacility,
  deleteFacility,
};
