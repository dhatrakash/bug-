const httpStatus = require('http-status');
const { DowntimeReason } = require('../models/index');
const ApiError = require('../utils/ApiError');

/**
 * Create a Downtime Reason
 * @param {Object} requestBody
 * @returns {Promise<DowntimeReason>}
 */
const createReason = async (requestBody) => {
  if (await DowntimeReason.isReasonTaken(requestBody.reason)) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Downtime Reason already taken.');
  }
  return DowntimeReason.create(requestBody);
};

/**
 * Get reason data by reason id
 * @param {number} reason_id
 * @returns {Promise<DowntimeReason>}
 */
const getReasondataByReasonid = async (reason_id) => {
  const data = await DowntimeReason.find({ reason_id: reason_id });
  if (data.length === 0) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Downtime reason data not found.');
  }
  return data;
};

const getAllReasons = async () => {
  const result = await DowntimeReason.find();
  return result;
};
/**
 * Delete reason data by reason id
 * @param {number} reason_id
 * @returns {Promise<void>}
 */
const deleteReasonData = async (reason_id) => {
  const result = await DowntimeReason.deleteOne({ reason_id: reason_id });
  if (result.deletedCount === 0) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Downtime reason data not found.');
  }
  return result;
};

/**
 * Update state, color, or reason based on update_field in the request body.
 * @param {object} updateData - The request body containing the update field and value.
 * @returns {Promise<DowntimeReason>} - The updated DowntimeReason document.
 */

const updateReasonData = async (updateData) => {
  const allowedFields = ['state', 'color', 'reason'];
  const { reason_id, update_field, value } = updateData;

  // Validate that the update_field is one of the allowed fields.
  if (!allowedFields.includes(update_field)) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Invalid update fields.');
  }

  // Validate and update the 'state' field if it's 'state'.
  if (update_field === 'state') {
    if (value !== 'Planned' && value !== 'Unplanned') {
      throw new ApiError(httpStatus.BAD_REQUEST, 'Invalid state value.');
    }
  }

  // Find the document by reason_id and update the specified field.
  const filter = { reason_id };
  const update = { [update_field]: value };
  const options = { new: true }; // Return the updated document.

  // Perform the update and return the updated document.
  const updatedReasonDoc = await DowntimeReason.findOneAndUpdate(filter, update, options);
  if (!updatedReasonDoc) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Downtime reason data not found.');
  }

  return updatedReasonDoc;
};

module.exports = {
  createReason,
  getReasondataByReasonid,
  getAllReasons,
  deleteReasonData,
  updateReasonData,
};
