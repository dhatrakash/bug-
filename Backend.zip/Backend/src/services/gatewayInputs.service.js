const GatewayInputs = require('../models/GatewayInputs.model');

const createGatewayInput = async (associationData) => {
  try {
    const duplicate = await GatewayInputs.findOne({
      gatewayId: associationData.gatewayId,
      // diId: associationData.diId,
      tag: associationData.tag,
      deletedAt: null,
    });
    if (duplicate) {
      return {
        error: `this association already exists please update it or create new combination of gateway, inputs`,
      };
    }
    const newAssociation = new GatewayInputs(associationData);
    const savedAssociation = await newAssociation.save();
    return savedAssociation;
  } catch (error) {
    throw new Error(`Failed to create GatewayInputs: ${error}`);
  }
};

const getAllGatewayInputs = async () => {
  try {
    const association = await GatewayInputs.find();
    if (!association[0]) {
      throw new Error('GatewayInputs not found');
    }
    return association;
  } catch (error) {
    throw new Error(`Failed to get GatewayInputs: ${error.message}`);
  }
};

const gatewayInputsByMappingId = async (mappingId) => {
  try {
    const association = await GatewayInputs.findOne({ mappingId });
    if (!association) {
      throw new Error('GatewayInputs not found');
    }
    return association;
  } catch (error) {
    throw new Error(`Failed to get GatewayInputs: ${error.message}`);
  }
};

const gatewayInputsByGatewayId = async (gatewayId) => {
  try {
    const association = await GatewayInputs.find({ gatewayId }).populate('sensorId');
    if (!association[0]) {
      throw new Error('GatewayInputs not found');
    }
    return association;
  } catch (error) {
    throw new Error(`Failed to get GatewayInputs: ${error.message}`);
  }
};

const gatewayInputsByGatewayIdDiId = async (gatewayId, tag) => {
  try {
    const association = await GatewayInputs.findOne({
      gatewayId,
      tag,
      deletedAt: null,
    });
    if (!association) {
      throw new Error('GatewayInputs not found');
    }
    return association;
  } catch (error) {
    throw new Error(`Failed to get GatewayInputs: ${error.message}`);
  }
};

// Update a GatewaySensorAssociation by ID
const updateGatewayInputsById = async (mappingId, updatedData) => {
  try {
    const association = await GatewayInputs.findOneAndUpdate({ mappingId }, updatedData, { new: true });
    if (!association) {
      throw new Error('GatewayInputs not found');
    }
    return association;
  } catch (error) {
    throw new Error(`Failed to update GatewayInputs: ${error.message}`);
  }
};

const softDeletegatewayInputsByMappingId = async (mappingId) => {
  try {
    const currentDate = new Date();
    const query = { mappingId, deletedAt: null };
    const updateOperation = { $set: { deletedAt: currentDate } };
    const result = await GatewayInputs.updateOne(query, updateOperation);
    return result;
  } catch (error) {
    throw new Error(`Failed to update GatewayInputs: ${error.message}`);
  }
};

const softDeleteGatewayInputsByGatewayId = async (gatewayId) => {
  try {
    const currentDate = new Date();
    const query = { gatewayId, deletedAt: null };
    const updateOperation = { $set: { deletedAt: currentDate } };
    const result = await GatewayInputs.updateMany(query, updateOperation);
    return result;
  } catch (error) {
    throw new Error(`Failed to update GatewayInputs: ${error.message}`);
  }
};

const softDeleteGatewayInputsByGatewayIdDiId = async (gatewayId, tag) => {
  try {
    const currentDate = new Date();
    const query = { gatewayId, tag, deletedAt: null };
    const updateOperation = { $set: { deletedAt: currentDate } };
    const result = await GatewayInputs.updateOne(query, updateOperation);
    return result;
  } catch (error) {
    throw new Error(`Failed to update GatewayInputs: ${error.message}`);
  }
};

const deleteGatewayInputByMappingId = async (mappingId) => {
  try {
    const deletedInput = await GatewayInputs.findOneAndRemove({ mappingId });
    return deletedInput;
  } catch (error) {
    throw new Error(`Failed to delete GatewayInputs: ${error.message}`);
  }
};

module.exports = {
  createGatewayInput,
  getAllGatewayInputs,
  gatewayInputsByMappingId,
  gatewayInputsByGatewayId,
  gatewayInputsByGatewayIdDiId,
  updateGatewayInputsById,
  deleteGatewayInputByMappingId,
  softDeletegatewayInputsByMappingId,
  softDeleteGatewayInputsByGatewayId,
  softDeleteGatewayInputsByGatewayIdDiId,
};
