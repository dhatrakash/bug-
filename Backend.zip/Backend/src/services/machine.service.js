const Machine = require('../models/machine.model');
const GatewayService = require('./gateway.service');
const Facility = require('../models/facility.model');
const Cell = require('../models/cell.model');
const Layout = require('../models/layout.model');
const Line = require('../models/line.model');
const logger = require('../config/logger');

const createMachine = async (data, files) => {
  try {
    const facility = await Facility.findOne({ name: data.machineLocation.facility });
    const cell = await Cell.findOne({ name: data.machineLocation.cell });
    const layout = await Layout.findOne({ name: data.machineLocation.layout });
    const line = await Line.findOne({ name: data.machineLocation.line });

    const machineData = {
      ...data,
      machinePhoto: files.machinePhoto
        ? {
            base64: files.machinePhoto[0].buffer.toString('base64'),
            mimetype: 'image/png',
          }
        : undefined,
      controllerPhoto: files.controllerPhoto
        ? {
            base64: files.controllerPhoto[0].buffer.toString('base64'),
            mimetype: 'image/png',
          }
        : undefined,
      machineLocation: {
        facility: facility ? facility._id : undefined,
        cell: cell ? cell._id : undefined,
        layout: layout ? layout._id : undefined,
        line: line ? line._id : undefined,
      },
    };
    const createdMachine = await Machine.create(machineData);
    if (!createdMachine) {
      throw new Error('Machine creation failed.');
    }

    return createdMachine;
  } catch (error) {
    throw new Error(`Failed to create machine: ${error}`);
  }
};

const findAllMachines = async () => {
  try {
    const machines = await Machine.find();
    return machines;
  } catch (error) {
    throw new Error(`Failed to retrieve hardwire data: ${error}`);
  }
};

const findMachineById = async (id) => {
  try {
    const machine = await Machine.findOne({ machineId: id });
    return machine;
  } catch (error) {
    throw new Error(`Failed to retrieve machine data: ${error}`);
  }
};

// async function to delete a machine from the database
const deleteMachine = async (id) => {
  try {
    // retrieve the machine from the database using the machineId
    const deletedMachine = await Machine.deleteOne({ machineId: id });
    // return the deleted machine
    return deletedMachine;
  } catch (error) {
    // throw an error if the machine cannot be retrieved
    throw new Error(`Failed to retrieve hardwire data: ${error}`);
  }
};

// update machine added support for images
const updateMachine = async (id, updateData, files) => {
  try {
    const machine = await Machine.findOne({ machineId: id });
    if (machine === null) throw new Error(`Machine Not found`);
    const updatedMachine = await Machine.findByIdAndUpdate(machine._id, updateData, {
      new: true, // Return the updated machine after update
    });
    if (files) {
      if (files.machinePhoto) {
        // Update the machine's photo with files.machinePhoto[0].buffer
        updatedMachine.machinePhoto = {
          mimetype: 'image/png', // Adjust the mimetype as needed
          base64: files.machinePhoto[0].buffer.toString('base64'),
        };
      }
      if (files.controllerPhoto) {
        // Update the controller's photo with files.controllerPhoto[0].buffer
        updatedMachine.controllerPhoto = {
          mimetype: 'image/png', // Adjust the mimetype as needed
          base64: files.controllerPhoto[0].buffer.toString('base64'),
        };
      }
      // Save the updated machine with images
      await updatedMachine.save();
    }
    return updatedMachine;
  } catch (error) {
    throw new Error(`Failed to update machine: ${error}`);
  }
};

const updateGateway = async (machineId, gatewayId) => {
  try {
    const machine = await findMachineById(machineId);
    const gateway = await GatewayService.getGatewayById(gatewayId);

    if (!machine || !gateway) throw new Error(`Failed to find machine or gateway`);
    machine.gatewayId = gatewayId;
    const updatedMachine = await machine.save();
    return updatedMachine;
  } catch (error) {
    throw new Error(`Failed to update gateway: ${error}`);
  }
};

// createHardwareModelForMachine('65115715fd11334461017ad7');
const findMachinesByGatewayId = async (gatewayId) => {
  try {
    const machines = await Machine.find({ gatewayId });
    logger.debug(machines);
  } catch (error) {
    logger.error(`Error in service layer ${error}`);
  }
};
// findMachinesByGatewayId('654f454d8b0a1f3022de68d9');
module.exports = {
  createMachine,
  findAllMachines,
  findMachineById,
  updateMachine,
  deleteMachine,
  updateGateway,
  findMachinesByGatewayId,
};
