process.setMaxListeners(30);
const puppeteer = require('puppeteer');
const TelegramBot = require('node-telegram-bot-api');
const cron = require('node-cron');
const logger = require('../../config/logger');
const machineService = require('../../services/machine.service');
const botToken = process.env.TELEGRAM_BOT_TOKEN; // Bot Token
const chatId = process.env.TELEGRAM_GROUP_CHAT_ID; // Telegram chat id

const bot = new TelegramBot(botToken, { polling: false });

const captureAndSendPdf = async () => {
  const browser = await puppeteer.launch({ headless: 'new' });
  const page = await browser.newPage();
  const machineName = await machineService.findAllMachines();

  const filteredMachineNames = machineName
    .filter((item) => item.machineName.startsWith(process.env.MACHINE_NAME_FOR_TELEGRAM))
    .map((item) => item.machineName);
  try {
    const baseMachineUrl = 'http://localhost:3001/machine-report/';
    const machineUrls = filteredMachineNames.map((machineName) => baseMachineUrl + machineName);
    for (const machineUrl of machineUrls) {
      function delay(timeout) {
        return new Promise((resolve) => setTimeout(resolve, timeout));
      }
      await delay(5000, await page.goto(machineUrl));

      const elementHandle = await page.$('#pdf-reports');
      if (elementHandle) {
        const pdfOptions = { format: 'A4', printBackground: true };
        const pdfBuffer = await page.pdf(pdfOptions);

        let currentMachineName = machineUrl.split('/').pop();
        bot
          .sendDocument(chatId, pdfBuffer, {
            caption: 'Machine Report For the machine ' + currentMachineName,
            filename: currentMachineName + '_report.pdf',
          })
          .then(() => logger.debug(machineUrl + ' PDF sent to Telegram.'))
          .catch((error) => logger.error('Error sending Combined PDF to Telegram:', error));
        bot.stopPolling();
      }
    }
  } catch (error) {
    logger.error('Error capturing PDF:', error);
  }
};

const job = cron.schedule('0 0 */1 * * *', captureAndSendPdf);
job.start();
