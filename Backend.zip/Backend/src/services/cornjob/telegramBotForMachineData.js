const TelegramBot = require('node-telegram-bot-api');
const cron = require('node-cron');
const controllerService = require('../../services/controller.services');
const machineService = require('../../services/machine.service');
const moment = require('moment');
const logger = require('../../config/logger');

const botToken = process.env.TELEGRAM_BOT_TOKEN; // Bot Token
const chatId = process.env.TELEGRAM_GROUP_CHAT_ID; // Telegram chat id

const bot = new TelegramBot(botToken, { polling: false });

const sendMachineData = async () => {
  try {
    const machineName = await machineService.findAllMachines();
    const filteredMachineNames = machineName
      .filter((item) => item.machineName.startsWith(process.env.MACHINE_NAME_FOR_TELEGRAM))
      .map((item) => item.machineName);
    let startDate = moment.utc().tz('Asia/Kolkata').clone().subtract(1, 'hour').format('YYYY-MM-DDTHH:mm:ss[Z]');
    let endDate = moment.utc().tz('Asia/Kolkata').clone().format('YYYY-MM-DDTHH:mm:ss[Z]');
    let allMachineData = [];

    for (const machineName of filteredMachineNames) {
      const serviceData = await controllerService.machineSpecificData(startDate, endDate, 1, machineName);

      const extractedData = serviceData.map((item) => ({
        machineName: machineName,
        productionTime: item.productionTime,
        idleTime: item.idleTime,
        production: item.production,
      }));

      allMachineData.push(...extractedData);
    }

    const headerData =
      'Pragati Machines Data' +
      '\nTime Interval of ' +
      moment.utc().tz('Asia/Kolkata').subtract(1, 'hour').format('DD/MM/YYYY HH:mm:ss') +
      ' to ' +
      moment.utc().tz('Asia/Kolkata').format('DD/MM/YYYY HH:mm:ss') +
      '\n';

    function formatDuration(duration) {
      const minutes = Math.floor(duration.asMinutes());
      const seconds = Math.floor(duration.asSeconds() % 60);

      return `${minutes} Minutes ${seconds} Seconds`;
    }
    const formattedData = allMachineData
      .map((item) => {
        const productionDuration = moment.duration(item.productionTime, 'seconds');
        const idleDuration = moment.duration(item.idleTime, 'seconds');

        const formattedProductionTime = formatDuration(productionDuration);
        const formattedIdleTime = formatDuration(idleDuration);

        return `
          Machine Name: ${item.machineName}
          Production Time: ${formattedProductionTime}
          Idle Time: ${formattedIdleTime}
          Part count : ${item.production}
          -------------------------------
        `;
      })
      .join('');
    bot.sendMessage(chatId, headerData + formattedData).then(() => {
      logger.debug(process.env.MACHINE_NAME_FOR_TELEGRAM+' Machines Data Sent to Telegram at ' + endDate);
      bot.stopPolling();
    });
  } catch (error) {
    logger.error('Error For Sending Machine Data  to Telegram :', error);
  }
};

const job = cron.schedule('0 0 */1 * * *', sendMachineData);
job.start();
