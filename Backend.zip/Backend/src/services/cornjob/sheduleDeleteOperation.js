const moment = require('moment');
const cron = require('node-cron');
const Fanuc = require('../../models/fanuc.mqtt.model');
const logger = require('../../config/logger');

const deleteAndUpdateJob = new cron.schedule('*/10 * * * * *', async () => {
  try {
    // delete unrealted
    const deleteMachineResult = await Fanuc.deleteMany({
      $or: [{ 'observation.machine': 'datta_dmg' }, { 'observation.machine': 'datta_f2' }],
    });
    const deleteNameResult = await Fanuc.deleteMany({
      'observation.name': { $in: ['axis', 'focas_perf'] },
    });
    const deletedEmptyAlarms = await Fanuc.deleteMany({
      'observation.name': 'alarms',
      'state.data.alarms': { $exists: true, $eq: [] },
    });

    // update docs
    const deletedMachineCount = deleteMachineResult.deletedCount;
    const deletedNameCount = deleteNameResult.deletedCount;
    const deletedEmptyAlarmsCount = deletedEmptyAlarms.deletedCount;

    const updateState = await Fanuc.updateMany(
      { 'observation.name': 'state' },
      {
        $unset: {
          'state.data.timers': 1,
          'state.data.modal': 1,
        },
      },
    );
    const updateProduction = await Fanuc.updateMany(
      { 'observation.name': 'production' },
      {
        $unset: {
          'state.data.program.executing': 1,
          'state.data.program.current.size_b': 1,
          'state.data.program.current.modified': 1,
          'state.data.program.selected.size_b': 1,
          'state.data.program.selected.modified': 1,
          'state.time': 1,
        },
      },
    );
    const updateSpindle = await Fanuc.updateMany(
      { 'observation.name': 'spindle' },
      {
        $unset: {
          'state.data.load': 1,
          'state.data.load_eu': 1,
          'state.data.gearratio': 1,
          'state.data.temperature': 1,
          'state.data.temperature_eu': 1,
          'state.data.power': 1,
          'state.data.power_eu': 1,
          'state.data.status_lnk': 1,
          'state.data.status_ssa': 1,
          'state.data.status_sca': 1,
          'state.data.status_cme': 1,
          'state.data.status_cer': 1,
          'state.data.status_sne': 1,
          'state.data.status_fre': 1,
          'state.data.status_cre': 1,
          'state.data.coder_feedback': 1,
          'state.data.loop_deviation': 1,
          'state.data.sync_error': 1,
          'state.data.position': 1,
          'state.data.position_eu': 1,
          'state.data.error': 1,
          'state.data.warning': 1,
          'state.data.speed_eu': 1,
          'state.data.maxrpm_eu': 1,
        },
      },
    );
    const updatedCount = updateState.modifiedCount + updateSpindle.modifiedCount + updateProduction.modifiedCount;

    const currentDate = moment().format('DD/MM/YYYY HH:mm:ss ');

    logger.debug(
      `Deleted \x1b[32m${deletedMachineCount}\x1b[0m documents with other machines \n \t\x1b[32m${deletedNameCount}\x1b[0m documents unrelated topics, \n \t\x1b[32m${deletedEmptyAlarmsCount}\x1b[0m documents with empty Alarms.\n\tUpdated \x1b[32m${updatedCount}\x1b[0m documents with state,spindle,production. ${currentDate}`,
    );
  } catch (error) {
    logger.error('Error deleting or updating documents:', error);
  }
});

deleteAndUpdateJob.start();
