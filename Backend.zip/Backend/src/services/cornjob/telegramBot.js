const puppeteer = require('puppeteer');
const axios = require('axios');
const FormData = require('form-data');
const stream = require('stream');
const cron = require('node-cron');
const logger = require('../../config/logger');

const botToken = '6569857865:AAEI5QtaD8qSSLUAU_LwKYqhQ_BUUBDJNqs'; // Bot Token
const chatId = '-4046915760'; // telegram chat id

async function captureAndSendScreenshot() {
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();
  logger.debug('Telegram BOT _____');

  try {
    // Navigate to the URL where your React.js component is hosted
    await page.goto('http://localhost:3001/demo-dashboard/monthly-report');

    // Add a delay of 10 seconds to ensure the chart is loaded (adjust the delay as needed)
    await page.waitForTimeout(10000);

    const elementHandle = await page.$('#monthly-report');
    if (elementHandle) {
      const screenshotOptions = { type: 'png' };
      const screenshotBuffer = await elementHandle.screenshot(screenshotOptions);

      // Create a readable stream from the screenshotBuffer
      const imageStream = new stream.PassThrough();
      imageStream.end(screenshotBuffer);

      // Send the screenshot to the Telegram bot
      const telegramApiEndpoint = `https://api.telegram.org/bot${botToken}/sendPhoto`;
      const formData = new FormData();
      formData.append('chat_id', chatId);
      formData.append('photo', imageStream, {
        filename: 'screenshot.png',
        contentType: 'image/png',
      });

      try {
        await axios.post(telegramApiEndpoint, formData, {
          headers: {
            ...formData.getHeaders(),
          },
        });
        logger.debug('Screenshot sent to Telegram.');
      } catch (error) {
        logger.error('Error sending screenshot to Telegram:', error);
      }
    } else {
      logger.error('Chart element not found');
    }
  } catch (error) {
    logger.error('Error capturing screenshot:', error);
  } finally {
    await browser.close();
  }
}

const job = cron.schedule('*/3 * * * * *', () => {
  logger.debug('Running captureAndSendScreenshot every 3 seconds');
  captureAndSendScreenshot();
});

// Start the cron job
job.start();
module.exports = {
  captureAndSendScreenshot,
};
