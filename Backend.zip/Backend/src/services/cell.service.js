const Cell = require('../models/cell.model');

const createCell = async (data) => {
  try {
    const cellData = {
      ...data,
      cellLocation: data.cellLocation,
    };
    const createdCell = await Cell.create(cellData);
    return createdCell;
  } catch (error) {
    throw new Error(`Failed to create cell: ${error}`);
  }
};

const findAllCells = async () => {
  try {
    const cells = await Cell.find();
    return cells;
  } catch (error) {
    throw new Error(`Failed to retrieve Cell data: ${error}`);
  }
};

const findCellById = async (id) => {
  try {
    const cell = await Cell.findOne({ _id: id });
    return cell;
  } catch (error) {
    throw new Error(`Failed to retrieve cell data: ${error}`);
  }
};

const updateCell = async (_id, updateBody) => {
  const updatedData = new Cell(updateBody);
  try {
    const updatedCell = await Cell.findOneAndUpdate({ _id }, updatedData, { new: true });
    return updatedCell;
  } catch (error) {
    throw new Error(`Failed to update cell data: ${error}`);
  }
};

const deleteCell = async (_id) => {
  try {
    await Cell.deleteOne({ _id: _id });
    return true;
  } catch (error) {
    throw new Error(`Failed to delete cell: ${error}`);
  }
};

module.exports = {
  // cell
  createCell,
  findAllCells,
  findCellById,
  updateCell,
  deleteCell,
};
