const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');
const { SuperAdmin, User } = require('../models');
const roleService = require('../services/role.service');

/**
 * Create a superAdmin
 * @param {Object} requestBody
 * @returns {Promise<User>}
 */
const createSuperAdmin = async (requestBody) => {
  if (await SuperAdmin.isEmailTaken(requestBody.email)) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Email already taken');
  }
  const roleId = await roleService.getRoleByName('superAdmin');
  requestBody.roleId = roleId.id;
  return await SuperAdmin.create(requestBody);
};

/**
 * Query for superAdmin
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default = 10)
 * @param {number} [options.page] - Current page (default = 1)
 * @returns {Promise<QueryResult>}
 */
const querySuperAdmins = async (filter, options) => {
  const users = await SuperAdmin.paginate(filter, options);
  return users;
};

/**
 * Get superAdmin by id
 * @param {ObjectId} id
 * @returns {Promise<User>}
 */
const getsuperAdminById = async (id) => {
  return SuperAdmin.findById(id);
};

/**
 * Get superAdmin by email
 * @param {string} email
 * @returns {Promise<User>}
 */
const getsuperAdminByEmail = async (email) => {
  return SuperAdmin.findOne({ email });
};

/**
 * Update superAdmin by id
 * @param {ObjectId} userId
 * @param {Object} updateBody
 * @returns {Promise<User>}
 */
const updateSuperAdminById = async (userId, updateBody) => {
  const superAdminId = await getsuperAdminById(userId);
  if (!superAdminId) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Super-Admin not found');
  }
  if (updateBody.email && (await SuperAdmin.isEmailTaken(updateBody.email, userId))) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Email already taken');
  }
  Object.assign(superAdminId, updateBody);
  SuperAdmin.save();
  return superAdminId;
};

/**
 * Delete superAdmin by id
 * @param {ObjectId} userId
 * @returns {Promise<User>}
 */
const deletesuperAdminById = async (userId) => {
  const superAdmin = await getsuperAdminById(userId);
  if (!superAdmin) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Super-Admin not found');
  }
  SuperAdmin.remove();
  return superAdmin;
};

const getAllUsers = async () => {
  try {
    const usersData = await User.find({});
    const data = await usersData.map((user) => ({
      _id: user._id || null,
      name: user.name || null,
      email: user.email || null,
      role: user.role || null,
      compName: user.compName || null,
    }));
    return data;
  } catch (error) {
    return error;
  }
};

module.exports = {
  createSuperAdmin,
  querySuperAdmins,
  getsuperAdminById,
  getsuperAdminByEmail,
  updateSuperAdminById,
  deletesuperAdminById,
  getAllUsers,
};
