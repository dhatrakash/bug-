const httpStatus = require('http-status');
const superAdminTokenService = require('./superAdminToken.service');
const superAdminService = require('./superAdmin.service');
const {SuperAdminTokens} = require('../models/index');
const ApiError = require('../utils/ApiError');
const { tokenTypes } = require('../config/tokens');

/**
 * Login with username and password
 * @param {string} email
 * @param {string} password
 * @returns {Promise<User>}
 */
const loginSuperAdminWithEmailAndPassword = async (email, password) => {
  const superAdmin = await superAdminService.getsuperAdminByEmail(email);
  if (!superAdmin || !(await superAdmin.isPasswordMatch(password))) {
    throw new ApiError(httpStatus.UNAUTHORIZED, 'Incorrect email or password');
  }
  return superAdmin;
};

/**
 * Logout
 * @param {string} refreshToken
 * @returns {Promise}
 */
const logoutsuperAdmin = async (refreshToken) => {
  const refreshTokenDoc = await SuperAdminTokens.findOne({ token: refreshToken, type: tokenTypes.REFRESH, blacklisted: false });
  if (!refreshTokenDoc) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Not found');
  }
  await SuperAdminTokens.deleteOne({_id: refreshTokenDoc._id });
  
};

/**
 * Refresh auth tokens
 * @param {string} refreshToken
 * @returns {Promise<Object>}
 */
const refreshAuth = async (refreshToken) => {
  try {
    const refreshTokenDoc = await superAdminTokenService.verifySuperAdminToken(refreshToken, tokenTypes.REFRESH);
    const superAdmin = await superAdminService.getsuperAdminById(refreshTokenDoc.superAdmin);
    if (!user) {
      throw new Error();
    }
    await refreshTokenDoc.remove();
    return superAdminTokenService.generateAuthTokens(superAdmin);
  } catch (error) {
    throw new ApiError(httpStatus.UNAUTHORIZED, 'Please authenticate');
  }
};

/**
 * Reset password
 * @param {string} resetPasswordToken
 * @param {string} newPassword
 * @returns {Promise}
 */
const resetPassword = async (resetPasswordToken, newPassword) => {
  try {
    const resetPasswordTokenDoc = await superAdminTokenService.verifySuperAdminToken(resetPasswordToken, tokenTypes.RESET_PASSWORD);
    const superAdmin = await superAdminService.getsuperAdminById(resetPasswordTokenDoc.superAdmin);
    if (!superAdmin) {
      throw new Error();
    }
    await superAdminService.updateSuperAdminById(superAdmin.id, { password: newPassword });
    await superAdminToken.deleteMany({ superAdmin: superAdmin.id, type: tokenTypes.RESET_PASSWORD });
  } catch (error) {
    throw new ApiError(httpStatus.UNAUTHORIZED, 'Password reset failed');
  }
};

/**
 * Verify email
 * @param {string} verifyEmailToken
 * @returns {Promise}
 */
const verifyEmail = async (verifyEmailToken) => {
  try {
    const verifyEmailTokenDoc = await superAdminTokenService.verifySuperAdminToken(verifyEmailToken, tokenTypes.VERIFY_EMAIL);
    const superAdmin = await userService.getUserById(verifyEmailTokenDoc.user);
    if (!superAdmin) {
      throw new Error();
    }
    await superAdminToken.deleteMany({ superAdmin: superAdmin.id, type: tokenTypes.VERIFY_EMAIL });
    await superAdminService.updateSuperAdminById(superAdmin.id, { isEmailVerified: true });
  } catch (error) {
    throw new ApiError(httpStatus.UNAUTHORIZED, 'Email verification failed');
  }
};

module.exports = {
  loginSuperAdminWithEmailAndPassword,
  logoutsuperAdmin,
  refreshAuth,
  resetPassword,
  verifyEmail,
};
