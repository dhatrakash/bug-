const UtilityDemo = require('../models/utilityDemo.model');
const sendOTPEmail = require('../utils/otpEmail.js');
const sendCRMUpdateEmail = require('../utils/crmUpdateMail.js');
const createCRMUpdateEmail = require('../utils/createCRMUpdateEmail');
const DashboardStatus = require('../models/dashboardStatus.model.js');

const otpStore = {}; // Initialize the OTP store

// Function to create a new utilityDemo
const createUtilityDemo = async (data) => {
  try {
    const utilityDemoData = {
      ...data,
    };
    const createdUtilityDemo = await UtilityDemo.create(utilityDemoData);
    return createdUtilityDemo;
  } catch (error) {
    throw new Error(`Failed to create utilityDemo: ${error}`);
  }
};

// Function to send OTP via email
const sendOTP = async (to, otp) => {
  try {
    const otpEmailContent = `Your OTP code is: ${otp}`;
    await sendOTPEmail(to, 'OTP Verification', otpEmailContent);
    otpStore[to] = otp;
  } catch (error) {
    console.error('Error sending OTP:', error);
    throw new Error('Error sending OTP');
  }
};

// // Function to send CRM Update via email
// const sendCRMUpdate = async (to, formData) => {
//   try {
//     // Create email content for CRM Update
//     const crmEmailContent =
//`New form submission for CRM Update:\nCompany Name: ${formData.companyName}\nContact Person: ${formData.contactPersonName}`;
//     // Send email with CRM Update content
//     await sendCRMUpdateEmail(to, 'New Form Submission', crmEmailContent);
//   } catch (error) {
//     console.error('Error sending CRM Update:', error);

//     throw new Error('Error sending CRM Update Email');
//   }
// };

const sendCRMUpdate = async (to, formData) => {
  try {
    console.log('sending form data to mailgen', formData);
    const crmEmailContent = createCRMUpdateEmail(formData);
    // Send the email with the generated content
    await sendCRMUpdateEmail(to, 'New Form Submission for Demo', crmEmailContent);
  } catch (error) {
    console.error('Error sending CRM Update:', error);
    throw new Error('Error sending CRM Update Email');
  }
};

// Function to verify OTP
const verifyOtp = async (email, otp) => {
  try {
    // Check if the OTP exists in the store (you may replace otpStore with user.lastAccessDate)
    if (!otpStore[email]) {
      throw new Error('OTP not found. Please request a new OTP.');
    }

    // Check if the entered OTP matches the stored OTP
    if (otpStore[email] !== otp) {
      throw new Error('Invalid OTP. Please try again.');
    }

    // Clear the OTP (remove it from the store)
    delete otpStore[email];
    // Set the user's last access date to the current date and time
    const lastAccessDate = new Date();
    await UtilityDemo.updateOne({ email }, { lastAccessDate });

    return 'OTP verified successfully';
  } catch (error) {
    // Handle the error by throwing an exception with an error message
    throw new Error('Error verifying OTP: ' + error.message);
  }
};

//  Function to check if the user has access to the dashboard
// const hasAccessToDashboard = async (email) => {
//   try {
//     // Find the user in the database
//     const user = await UtilityDemo.findOne({ email });

//     // If the user is not found, return false
//     if (!user) {
//       return false; // User not found
//     }

//     // Get the current timestamp and the last access timestamp
//     const currentTimestamp = new Date();
//     const lastAccessTimestamp = new Date(user.lastAccessDate);

//     // Calculate the difference between the two timestamps
//     const timeDifference = currentTimestamp - lastAccessTimestamp;
//     const oneDay = 1000 * 60 * 60 * 24; // One day in milliseconds

//     // Return true if the difference is less than or equal to one day
//     return timeDifference <= oneDay;
//   } catch (error) {
//     console.error('Error checking access to dashboard:', error);
//     return false;
//   }
// };

// Function to add dashboard status
const addDashboardStatus = async (email) => {
  try {
    const currentTime = new Date();
    const accessExpireTime = new Date(currentTime);
    accessExpireTime.setDate(currentTime.getDate() + 1); // 1 day from the current time

    const statusDoc = await DashboardStatus.findOneAndUpdate(
      { email },
      {
        email,
        status: 1,
        accessStartTime: currentTime,
        accessExpireTime,
      },
      { upsert: true, new: true },
    );

    return statusDoc;
  } catch (error) {
    throw new Error(`Failed to update dashboard status: ${error}`);
  }
};

// Function to get dashboard status
const getDashboardStatus = async (email) => {
  try {
    const statusDoc = await DashboardStatus.findOne({ email });

    if (statusDoc) {
      const currentTime = new Date();
      console.log('Current Time:', currentTime);
      console.log('Access Expire Time:', statusDoc.accessExpireTime);

      if (currentTime >= statusDoc.accessExpireTime) {
        await statusDoc.updateOne({ status: 0, lastUpdated: currentTime });
        console.log('Dashboard status updated to 0');
        return 0;
      } else {
        console.log('Status document found but not updated');
        return statusDoc.status;
      }
    } else {
      console.log('Status document not found');
      return -1;
    }
  } catch (error) {
    throw new Error(`Failed to get dashboard status: ${error}`);
  }
};

module.exports = {
  otpStore,
  createUtilityDemo,
  sendOTP,
  sendCRMUpdate,
  verifyOtp,
  //  hasAccessToDashboard,
  addDashboardStatus,
  getDashboardStatus,
};
