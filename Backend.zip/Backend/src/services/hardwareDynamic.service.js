const moment = require('moment');

const HardwareDynamic = require('../models/hardwareDynamic.model');
const machineAssociationService = require('./machineAssociations.service');
const Sensor = require('../models/sensor.model');
const Gateway = require('../models/gateway.model');

// dynamic pipeline test method
const findData = async (machineId, startDate, endDate) => {
  try {
    // Convert startDate and endDate to Date objects for comparison
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate);

    // Check if startDate is greater than or equal to endDate
    if (startDateObj >= endDateObj) {
      throw new Error('startDate must be less than endDate.');
    }
    // find all mappings based on machineId
    const mappings = await machineAssociationService.findNodesByMachineId(machineId);
    if (!mappings) {
      throw new Error('No mappings found');
    }
    // Filter mappings to include only those with sensorUse 'UPTIME'
    const uptimeMappings = mappings.filter((document) => document.sensorUse === 'PRODUCTIVE');
    // Define variables
    let io = 'data.';
    let io2 = 'data.';
    let tag = '';
    let tag2 = '';
    let sid1 = 1;
    let sid2 = 1;
    // boolean value choose 1 for uptime 0 downtime
    const value = 1;
    // Build 'io' and 'tag' strings based on 'uptimeMappings'
    uptimeMappings.forEach((document, index) => {
      if (index === 0) {
        io += document.field;
        tag += document.tag;
        if (document.sid) sid1 = parseInt(document.sid, 10);
      }
      if (index === 1) {
        io2 += document.field;
        tag2 += document.tag;
        if (document.sid) sid2 = parseInt(document.sid, 10);
      }
    });

    // Create the valueToMatch objects
    const valueToMatch1 = {
      $elemMatch: {
        [tag]: value,
        sid: sid1,
      },
    };

    const valueToMatch2 = {
      $elemMatch: {
        [tag2]: value,
        sid: sid2,
      },
    };

    // when you have only one register to calculate uptime using valueToProject1

    const valueToProject1 = {
      'data.dtm': 1,
      [io]: {
        $filter: {
          input: `$${io}`,
          as: 'data',
          cond: { $eq: ['$$data.sid', sid1] },
        },
      },
    };

    const valueToProject2 = {
      'data.dtm': 1,
      [io]: {
        $filter: {
          input: `$${io}`,
          as: 'data',
          cond: { $eq: ['$$data.sid', sid1] },
        },
      },
      [io2]: {
        $filter: {
          input: `$${io2}`,
          as: 'data',
          cond: { $eq: ['$$data.sid', sid2] },
        },
      },
    };

    // Define the dynamicPipe based on the number of 'uptimeMappings'
    let dynamicPipe = [];

    if (uptimeMappings.length === 1) {
      dynamicPipe = [
        {
          $match: {
            [io]: valueToMatch1,
            'data.dtm': { $gte: startDate, $lte: endDate },
          },
        },
        {
          $project: valueToProject1,
        },
        {
          $unwind: `$${io}`,
        },
        {
          $group: {
            _id: '$data.dtm',
            productionStatus: { $first: `$${io}.${tag}` },
          },
        },
        {
          $project: {
            dtm: '$_id',
            productionStatus: 1,
            _id: 0,
          },
        },
      ];
    } else {
      dynamicPipe = [
        {
          $match: {
            $and: [{ [io]: valueToMatch1 }, { [io2]: valueToMatch2 }],
            'data.dtm': { $gte: startDate, $lte: endDate },
          },
        },
        {
          $project: valueToProject2,
        },
        {
          $unwind: `$${io2}`,
        },
        {
          $group: {
            _id: '$data.dtm',
            productionStatus1: { $first: `$${io2}.${tag2}` },
          },
        },
        {
          $unwind: `$${io}`,
        },
        {
          $group: {
            _id: '$data.dtm',
            productionStatus: { $first: `$${io}.${tag}` },
          },
        },
        {
          $project: {
            dtm: '$_id',
            productionStatus1: 1,
            productionStatus: 1,
            _id: 0,
          },
        },
      ];
    }
    const foundData = await HardwareDynamic.aggregate(dynamicPipe);
    return foundData;
  } catch (error) {
    throw new Error(`${error}`);
  }
};

const machineProductionStatusByTimeFrame = async (machineId, startDate, endDate) => {
  try {
    // Convert startDate and endDate to Date objects for comparison
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate);

    // Check if startDate is greater than or equal to endDate
    if (startDateObj >= endDateObj) {
      throw new Error('startDate must be less than endDate.');
    }
    // find all mappings based on machineId
    const mappings = await machineAssociationService.findNodesByMachineId(machineId);
    if (!mappings) {
      throw new Error('No mappings found');
    }
    // Filter mappings to include only those with sensorUse 'UPTIME'
    const uptimeMappings = mappings.filter((document) => document.sensorUse === 'PRODUCTIVE');
    // Define variables
    let io = 'data.';
    let io2 = 'data.';
    let tag = '';
    let tag2 = '';
    let sid1 = 1;
    let sid2 = 1;
    let mac = '';
    // Build 'io' and 'tag' strings based on 'uptimeMappings'
    uptimeMappings.forEach((document, index) => {
      if (index === 0) {
        io += document.field;
        tag += document.tag;
        mac = document.mac;
        if (document.sid) sid1 = parseInt(document.sid, 10);
      }
      if (index === 1) {
        io2 += document.field;
        tag2 += document.tag;
        if (document.sid) sid2 = parseInt(document.sid, 10);
      }
    });
    // Create the valueToMatch objects
    // const valueToMatch1 = {
    //   $elemMatch: {
    //     sid: sid1,
    //   },
    // };

    // const valueToMatch2 = {
    //   $elemMatch: {
    //     sid: sid2,
    //   },
    // };

    // Define the dynamicPipe based on the number of 'uptimeMappings'
    let dynamicPipe = [];

    if (uptimeMappings.length === 1) {
      dynamicPipe = [
        {
          $match: {
            // [io]: valueToMatch1,
            'data.dtm': { $gte: startDate, $lte: endDate },
            'data.mac': mac,
          },
        },
        {
          $project: {
            _id: 0,
            dtm: '$data.dtm',
            productionStatus: {
              $arrayElemAt: [
                {
                  $map: {
                    input: {
                      $filter: {
                        input: `$${io}`,
                        as: 'data',
                        cond: { $eq: ['$$data.sid', sid1] },
                      },
                    },
                    as: 'item',
                    in: `$$item.${tag}`,
                  },
                },
                0,
              ],
            },
          },
        },
      ];
    } else {
      dynamicPipe = [
        {
          $match: {
            // $and: [{ [io]: valueToMatch1 }, { [io2]: valueToMatch2 }],
            // [io]: valueToMatch1,
            // [io2]: valueToMatch2,
            'data.dtm': { $gte: startDate, $lte: endDate },
            'data.mac': mac,
          },
        },

        {
          $project: {
            _id: 0,
            dtm: '$data.dtm',
            productionStatus1: {
              $arrayElemAt: [
                {
                  $map: {
                    input: {
                      $filter: {
                        input: `$${io2}`,
                        as: 'data',
                        cond: { $eq: ['$$data.sid', sid2] },
                      },
                    },
                    as: 'item',
                    in: `$$item.${tag2}`,
                  },
                },
                0,
              ],
            },
            productionStatus: {
              $arrayElemAt: [
                {
                  $map: {
                    input: {
                      $filter: {
                        input: `$${io}`,
                        as: 'data',
                        cond: { $eq: ['$$data.sid', sid1] },
                      },
                    },
                    as: 'item',
                    in: `$$item.${tag}`,
                  },
                },
                0,
              ],
            },
          },
        },
      ];
    }
    const foundData = await HardwareDynamic.aggregate(dynamicPipe);
    return foundData;
  } catch (error) {
    throw new Error(`${error}`);
  }
};

const machineDataByMappingId = async (machineId, mappingId, hours, productiveValue) => {
  try {
    // validate hours
    const hoursInt = parseInt(hours, 10);
    if (hoursInt < 1) throw new Error(`hours should be more than 1`);
    // calculate start and end dates

    const startDate = moment().subtract(hours, 'hours').format();
    const endDate = moment().format();

    const machineMapping = await machineAssociationService.findActiveMappings(machineId);
    if (!machineMapping) {
      throw new Error(`Cannot find mapping for machine ID ${machineId}`);
    }

    // Find the required mapping
    const requiredMapping = machineMapping.mappings.find(
      (document) => document.mappingId.mappingId.toString() === mappingId,
    );

    if (!requiredMapping) throw new Error(`No matching mappingId found in this machine ${machineId}`);

    const currentSensorId = requiredMapping.mappingId.sensorId;
    const currentGatewayId = requiredMapping.mappingId.gatewayId;

    const currentSensor = await Sensor.findOne({ sensorId: currentSensorId });
    const currentGateway = await Gateway.findOne({ gatewayId: currentGatewayId });
    // adding sending value for one
    const updatedProductive = productiveValue;
    updatedProductive.valueForOne = currentSensor.valueForOne ? currentSensor.valueForOne : null;

    let { slaveId } = requiredMapping.mappingId;
    const { tag } = requiredMapping.mappingId;
    const { macId } = currentGateway;
    slaveId = parseInt(slaveId, 10);
    const sensorNodeType = `data.${requiredMapping.sensorNodeType}`;

    const dynamicPipe = [
      {
        $match: {
          'data.dtm': { $gte: startDate, $lte: endDate },
          'data.mac': macId,
        },
      },
      {
        $project: {
          _id: 0,
          'data.dtm': 1,
          [sensorNodeType]: {
            $filter: {
              input: `$${sensorNodeType}`,
              as: 'data',
              cond: { $eq: ['$$data.sid', slaveId] },
            },
          },
        },
      },
      {
        $unwind: `$${sensorNodeType}`,
      },
      {
        $group: {
          _id: '$data.dtm',
          value: { $first: `$${sensorNodeType}.${tag}` },
        },
      },

      {
        $project: {
          dtm: '$_id',
          value: 1,
          _id: 0,
        },
      },
      {
        $sort: { dtm: 1 },
      },
    ];
    const foundData = await HardwareDynamic.aggregate(dynamicPipe);
    return foundData;
  } catch (error) {
    console.log(error);
    throw new Error(`Failed to retrieve data ${error}`);
  }
};

const machineDataByMappingIdTimeFrame = async (machineId, mappingId, startDate, endDate, productiveValue) => {
  try {
    // Convert startDate and endDate to Date objects for comparison
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate);
    // Check if startDate is greater than or equal to endDate
    if (startDateObj >= endDateObj) {
      throw new Error('startDate must be less than endDate.');
    }
    const machineMapping = await machineAssociationService.findActiveMappings(machineId);
    if (!machineMapping) {
      throw new Error(`Cannot find mapping for machine ID ${machineId}`);
    }

    // Find the required mapping
    const requiredMapping = machineMapping.mappings.find(
      (document) => document.mappingId.mappingId.toString() === mappingId,
    );

    if (!requiredMapping) throw new Error(`No matching mappingId found in this machine ${machineId}`);

    const currentSensorId = requiredMapping.mappingId.sensorId;
    const currentGatewayId = requiredMapping.mappingId.gatewayId;

    const currentSensor = await Sensor.findOne({ sensorId: currentSensorId });
    const currentGateway = await Gateway.findOne({ gatewayId: currentGatewayId });

    // adding sending value for one
    const updatedProductive = productiveValue;
    updatedProductive.valueForOne = currentSensor.valueForOne;

    let { slaveId } = requiredMapping.mappingId;
    const { tag } = requiredMapping.mappingId;
    const { macId } = currentGateway;
    slaveId = parseInt(slaveId, 10);
    const sensorNodeType = `data.${requiredMapping.sensorNodeType}`;

    const dynamicPipe = [
      {
        $match: {
          'data.dtm': { $gte: startDate, $lte: endDate },
          'data.mac': macId,
        },
      },
      {
        $project: {
          _id: 0,
          'data.dtm': 1,
          [sensorNodeType]: {
            $filter: {
              input: `$${sensorNodeType}`,
              as: 'data',
              cond: { $eq: ['$$data.sid', slaveId] },
            },
          },
        },
      },
      {
        $unwind: `$${sensorNodeType}`,
      },
      {
        $group: {
          _id: '$data.dtm',
          value: { $first: `$${sensorNodeType}.${tag}` },
        },
      },

      {
        $project: {
          dtm: '$_id',
          value: 1,
          _id: 0,
        },
      },
      {
        $sort: { dtm: 1 },
      },
    ];
    const foundData = await HardwareDynamic.aggregate(dynamicPipe);
    return foundData;
  } catch (error) {
    throw new Error(`Failed to retrieve data ${error}`);
  }
};

const machineProductionStatusByRecentHour = async (machineId, hours) => {
  try {
    const hoursInt = parseInt(hours, 10);
    if (hoursInt < 1) throw new Error(`hours should be more than 1`);
    const startTime = moment().subtract(hours, 'hours').format();
    const endTime = moment().format();
    // find all mappings based on machineId
    const mappings = await machineAssociationService.findNodesByMachineId(machineId);
    if (!mappings) {
      throw new Error('No mappings found');
    }
    // Filter mappings to include only those with sensorUse 'UPTIME'
    const uptimeMappings = mappings.filter((document) => document.sensorUse === 'PRODUCTIVE');
    // Define variables
    let io = 'data.';
    let io2 = 'data.';
    let tag = '';
    let tag2 = '';
    let sid1 = 1;
    let sid2 = 1;
    let mac = '';
    // Build 'io' and 'tag' strings based on 'uptimeMappings'
    uptimeMappings.forEach((document, index) => {
      if (index === 0) {
        io += document.field;
        tag += document.tag;
        mac = document.mac;
        if (document.sid) sid1 = parseInt(document.sid, 10);
      }
      if (index === 1) {
        io2 += document.field;
        tag2 += document.tag;
        if (document.sid) sid2 = parseInt(document.sid, 10);
      }
    });

    // Define the dynamicPipe based on the number of 'uptimeMappings'
    let dynamicPipe = [];

    if (uptimeMappings.length === 1) {
      dynamicPipe = [
        {
          $match: {
            'data.dtm': { $gte: startTime, $lte: endTime },
            'data.mac': mac,
          },
        },
        {
          $project: {
            _id: 0,
            dtm: '$data.dtm',
            productionStatus: {
              $arrayElemAt: [
                {
                  $map: {
                    input: {
                      $filter: {
                        input: `$${io}`,
                        as: 'data',
                        cond: { $eq: ['$$data.sid', sid1] },
                      },
                    },
                    as: 'item',
                    in: `$$item.${tag}`,
                  },
                },
                0,
              ],
            },
          },
        },
      ];
    } else {
      dynamicPipe = [
        {
          $match: {
            'data.dtm': { $gte: startTime, $lte: endTime },
            'data.mac': mac,
          },
        },

        {
          $project: {
            _id: 0,
            dtm: '$data.dtm',
            productionStatus1: {
              $arrayElemAt: [
                {
                  $map: {
                    input: {
                      $filter: {
                        input: `$${io2}`,
                        as: 'data',
                        cond: { $eq: ['$$data.sid', sid2] },
                      },
                    },
                    as: 'item',
                    in: `$$item.${tag2}`,
                  },
                },
                0,
              ],
            },
            productionStatus: {
              $arrayElemAt: [
                {
                  $map: {
                    input: {
                      $filter: {
                        input: `$${io}`,
                        as: 'data',
                        cond: { $eq: ['$$data.sid', sid1] },
                      },
                    },
                    as: 'item',
                    in: `$$item.${tag}`,
                  },
                },
                0,
              ],
            },
          },
        },
      ];
    }
    const foundData = await HardwareDynamic.aggregate(dynamicPipe);
    return foundData;
  } catch (error) {
    throw new Error(`${error}`);
  }
};

const machineDataAsperSensorUse = async (machineId, startDate, endDate, sensorUse) => {
  try {
    // Convert startDate and endDate to Date objects for comparison
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate);

    // Check if startDate is greater than or equal to endDate
    if (startDateObj >= endDateObj) {
      throw new Error('startDate must be less than endDate.');
    }
    // find all mappings based on machineId
    const mappings = await machineAssociationService.findNodesByMachineId(machineId);
    if (!mappings) {
      throw new Error('No mappings found for this type of sensoruse', sensorUse, 'in this machine');
    }
    // Filter mappings to include only those with sensorUse 'UPTIME'
    const uptimeMappings = mappings.filter((document) => document.sensorUse === sensorUse);
    if (uptimeMappings.length === 0) {
      throw new Error('No mappings found for this type of sensoruse', sensorUse, 'in this machine');
    }
    // Define variables
    let io = 'data.';
    let io2 = 'data.';
    let tag = '';
    let tag2 = '';
    let sid1 = 1;
    let sid2 = 1;
    let mac = '';
    const outputFieldName1 = `${sensorUse}_data1`;
    const outputFieldName2 = `${sensorUse}_data2`;

    // Build 'io' and 'tag' strings based on 'uptimeMappings'
    uptimeMappings.forEach((document, index) => {
      if (index === 0) {
        io += document.field;
        tag += document.tag;
        mac = document.mac;
        if (document.sid) sid1 = parseInt(document.sid, 10);
      }
      if (index === 1) {
        io2 += document.field;
        tag2 += document.tag;
        if (document.sid) sid2 = parseInt(document.sid, 10);
      }
    });

    // Define the dynamicPipe based on the number of 'uptimeMappings'
    let dynamicPipe = [];

    if (uptimeMappings.length === 1) {
      dynamicPipe = [
        {
          $match: {
            // [io]: valueToMatch1,
            'data.dtm': { $gte: startDate, $lte: endDate },
            'data.mac': mac,
          },
        },
        {
          $project: {
            _id: 0,
            dtm: '$data.dtm',
            [outputFieldName1]: {
              $arrayElemAt: [
                {
                  $map: {
                    input: {
                      $filter: {
                        input: `$${io}`,
                        as: 'data',
                        cond: { $eq: ['$$data.sid', sid1] },
                      },
                    },
                    as: 'item',
                    in: `$$item.${tag}`,
                  },
                },
                0,
              ],
            },
          },
        },
      ];
    } else {
      dynamicPipe = [
        {
          $match: {
            'data.dtm': { $gte: startDate, $lte: endDate },
            'data.mac': mac,
          },
        },

        {
          $project: {
            _id: 0,
            dtm: '$data.dtm',
            [outputFieldName2]: {
              $arrayElemAt: [
                {
                  $map: {
                    input: {
                      $filter: {
                        input: `$${io2}`,
                        as: 'data',
                        cond: { $eq: ['$$data.sid', sid2] },
                      },
                    },
                    as: 'item',
                    in: `$$item.${tag2}`,
                  },
                },
                0,
              ],
            },
            [outputFieldName1]: {
              $arrayElemAt: [
                {
                  $map: {
                    input: {
                      $filter: {
                        input: `$${io}`,
                        as: 'data',
                        cond: { $eq: ['$$data.sid', sid1] },
                      },
                    },
                    as: 'item',
                    in: `$$item.${tag}`,
                  },
                },
                0,
              ],
            },
          },
        },
      ];
    }
    const foundData = await HardwareDynamic.aggregate(dynamicPipe);
    return foundData;
  } catch (error) {
    throw new Error(error);
  }
};
const machineDataByTimeFrame = async (machineId, startDate, endDate) => {
  try {
    const data = {
      productionTime: 0,
      idleTime: 0,
      machineON: 0,
      productCount: 0,
      availability: 0,
      performance: 0,
      quality: 0,
    };

    // Find mappings based on the provided machineId
    const mappings = await machineAssociationService.findNodesByMachineId(machineId);
    if (!mappings) {
      throw new Error('No mappings found');
    }
    // Filter mappings to include only those with sensorUse 'UPTIME'
    const uptimeMappings = mappings.filter((document) => document.sensorUse === 'PRODUCTIVE');
    if (uptimeMappings.length === 0) {
      throw new Error('No mappings found for this type of PRODUCTIVE in this machine');
    }
    const partCountMappings = mappings.filter((document) => document.sensorUse === 'PARTCOUNT');
    if (uptimeMappings.length === 0) {
      throw new Error('No mappings found for this type of PARTCOUNT in this machine');
    }
    let field1 = 'data.';
    let field2 = 'data.';
    let tag = '';
    let tag2 = '';
    let sid1 = 1;
    let sid2 = 1;
    let mac = '';

    // Build 'io' and 'tag' strings based on 'uptimeMappings'
    uptimeMappings.forEach((document, index) => {
      if (index === 0) {
        field1 += document.field;
        tag += document.tag;
        mac = document.mac;
        if (document.sid) sid1 = parseInt(document.sid, 10);
      }
      if (index === 1) {
        field2 += document.field;
        tag2 += document.tag;
        if (document.sid) sid2 = parseInt(document.sid, 10);
      }
    });
    // Build 'io' and 'tag' strings based on 'uptimeMappings'
    partCountMappings.forEach((document, index) => {
      if (index === 0) {
        field2 += document.field;
        tag2 += document.tag;
        if (document.sid) sid2 = parseInt(document.sid, 10);
      }
    });
    // Dynamically build aggregation pipeline based on mappings
    const pipeline = [
      {
        $match: {
          'data.dtm': {
            $gte: startDate,
            $lte: endDate,
          },
          // Add a match for machineId here
          'data.mac': mac,
        },
      },
      {
        $group: {
          _id: '$data.mac',
          machineON: { $sum: 1 },
          production_time: {
            $sum: {
              $arrayElemAt: [
                {
                  $map: {
                    input: {
                      $filter: {
                        input: `$${field1}`,
                        as: 'data',
                        cond: { $eq: ['$$data.sid', sid1] },
                      },
                    },
                    as: 'item',
                    in: `$$item.${tag}`,
                  },
                },
                0,
              ],
            },
          },
          idle_Time: {
            $sum: {
              $cond: [
                {
                  $eq: [
                    {
                      $arrayElemAt: [
                        {
                          $map: {
                            input: {
                              $filter: {
                                input: `$${field1}`,
                                as: 'data',
                                cond: { $eq: ['$$data.sid', sid1] },
                              },
                            },
                            as: 'item',
                            in: `$$item.${tag}`,
                          },
                        },
                        0,
                      ],
                    },
                    0,
                  ],
                },
                1,
                0,
              ],
            },
          },
          product_Count: {
            $sum: {
              $arrayElemAt: [
                {
                  $map: {
                    input: {
                      $filter: {
                        input: `$${field2}`,
                        as: 'data',
                        cond: { $eq: ['$$data.sid', sid2] },
                      },
                    },
                    as: 'item',
                    in: `$$item.${tag2}`,
                  },
                },
                0,
              ],
            },
          },
        },
      },
      {
        $project: {
          _id: 0,
          production_time: 1,
          idle_Time: 1,
          product_Count: 1,
          machineON: 1,
          availability: {
            $cond: [{ $eq: ['$machineON', 0] }, 0, { $round: [{ $divide: ['$production_time', '$machineON'] }, 3] }],
          },
          performance: {
            $cond: [
              { $eq: ['$production_time', 0] },
              0,
              { $round: [{ $divide: [{ $multiply: [20, '$product_Count'] }, '$production_time'] }, 3] },
            ],
          },
          quality: {
            $cond: [
              { $eq: ['$product_Count', 0] },
              0,
              { $round: [{ $divide: [{ $subtract: ['$product_Count', 0] }, '$product_Count'] }, 3] },
            ],
          },
        },
      },
    ];

    const resultGenerated = await HardwareDynamic.aggregate(pipeline);

    if (resultGenerated.length !== 0) {
      const result = resultGenerated[0];
      data.productionTime = result.production_time;
      data.idleTime = result.idle_Time;
      data.machineON = result.machineON;
      data.productCount = result.product_Count;
      data.availability = result.availability;
      data.performance = result.performance;
      data.quality = result.quality;
      data.oee = parseFloat((result.availability * result.performance * result.quality * 100).toFixed(3));
    }
    return data;
  } catch (error) {
    throw new Error(`${error}`);
  }
};

const partCountByMachineId = async (machineId, startDate, endDate) => {
  try {
    // Convert startDate and endDate to Date objects for comparison
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate);

    // Check if startDate is greater than or equal to endDate
    if (startDateObj >= endDateObj) {
      throw new Error('startDate must be less than endDate.');
    }
    // Find all mappings based on machineId
    const mappings = await machineAssociationService.findNodesByMachineId(machineId);

    if (mappings.length === 0) {
      throw new Error('No mappings found for this machine.');
    }

    // Filter mappings to include only those with sensorUse 'PARTCOUNT'
    const partCountMappings = mappings.filter((document) => document.sensorUse === 'PARTCOUNT');

    if (partCountMappings.length === 0) {
      throw new Error('No PARTCOUNT mappings found for this machine.');
    }

    // Define variables
    let fieldName = 'data.';
    let tag = '';
    let sid1 = 1;
    let mac = '';
    const value = 1;

    // Build 'io' and 'tag' strings based on 'partCountMappings'
    partCountMappings.forEach((document, index) => {
      if (index === 0) {
        fieldName += document.field;
        tag += document.tag;
        mac = document.mac;
        if (document.sid) sid1 = parseInt(document.sid, 10);
      }
    });

    const valueToMatch1 = {
      $elemMatch: {
        [tag]: value,
        sid: sid1,
      },
    };
    const totalCountPipeline = [
      {
        $match: {
          [fieldName]: valueToMatch1,
          'data.dtm': { $gte: startDate, $lte: endDate },
          'data.mac': mac,
        },
      },
      {
        $group: {
          _id: '$data.mac',
          total_count: { $sum: 1 },
        },
      },
      {
        $project: {
          _id: 0,
          mac: '$_id',
          total_count: 1,
        },
      },
    ];
    // Run the aggregation
    const result = await HardwareDynamic.aggregate(totalCountPipeline);

    if (result.length > 0) {
      return result[0].total_count;
    }
  } catch (error) {
    throw new Error(`Failed to find the part count of specific machineId: ${error.message}`);
  }
};

const macchineOeeCalculationByInterval = async (startDate, endDate, interval, machineId) => {
  try {
    const windowStart = moment.utc(startDate);
    const windowEnd = moment.utc(endDate);

    const results = [];
    while (windowStart.isBefore(windowEnd)) {
      const currentHourStart = windowStart.clone();
      const currentHourEnd = windowStart.clone().add(interval, 'hour');
      const resultArray = {
        hour: currentHourStart.utc().format(),
        productionTime: 0,
        idleTime: 0,
        production: 0,
        OEE: 0,
      };
      // eslint-disable-next-line no-await-in-loop
      const data = await machineDataByTimeFrame(machineId, currentHourStart.utc().format(), currentHourEnd.utc().format());
      resultArray.productionTime = data.productionTime;
      resultArray.idleTime = data.idleTime;
      resultArray.production = data.productCount;
      resultArray.OEE = data.oee;

      results.push(resultArray);
      windowStart.add(interval, 'hour');
    }
    return results;
  } catch (error) {
    throw new Error(`Failed to find oee calculation ${error}`);
  }
};

module.exports = {
  machineProductionStatusByTimeFrame,
  machineProductionStatusByRecentHour,
  machineDataAsperSensorUse,
  machineDataByTimeFrame,
  partCountByMachineId,
  macchineOeeCalculationByInterval,
  machineDataByMappingId, // by hours
  machineDataByMappingIdTimeFrame, // start end dates
};

// sharing mappingId with everymachine or sharing global mappings
// energy monitoring with gateway
