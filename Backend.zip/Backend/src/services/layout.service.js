const Layout = require('../models/layout.model');

const createLayout = async (data) => {
  try {
    const layoutData = {
      ...data,
      layoutLocation: data.layoutLocation,
    };
    const createdLayout = await Layout.create(layoutData);
    return createdLayout;
  } catch (error) {
    throw new Error(`Failed to create layout: ${error}`);
  }
};

const findAllLayouts = async () => {
  try {
    const layouts = await Layout.find();
    // console.log('Layouts:', layouts); // Log the layouts
    return layouts;
  } catch (error) {
    throw new Error(`Failed to retrieve Layout data: ${error}`);
  }
};

const findLayoutById = async (id) => {
  try {
    const layout = await Layout.findOne({ _id: id });
    return layout;
  } catch (error) {
    throw new Error(`Failed to retrieve layout data: ${error}`);
  }
};

const updateLayout = async (_id, updateBody) => {
  const updatedData = new Layout(updateBody);
  try {
    const updatedLayout = await Layout.findOneAndUpdate({ _id }, updatedData, { new: true });
    return updatedLayout;
  } catch (error) {
    throw new Error(`Failed to update layout data: ${error}`);
  }
};

const deleteLayout = async (_id) => {
  try {
    await Layout.deleteOne({ _id });
    return true;
  } catch (error) {
    throw new Error(`Failed to delete layout: ${error}`);
  }
};

module.exports = {
  // layout
  createLayout,
  findAllLayouts,
  findLayoutById,
  updateLayout,
  deleteLayout,
};
