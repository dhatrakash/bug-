const httpStatus = require('http-status');
const { Role } = require('../models');
const ApiError = require('../utils/ApiError');

/**
 * Create a user
 * @param {Object} userBody
 * @returns {Promise<Role>}
 */
const createRole = async (userBody) => {
  if (await Role.isRoleTaken(userBody.role)) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Role already taken');
  }
  return Role.create(userBody);
};

/**
 * Query for roles
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default = 10)
 * @param {number} [options.page] - Current page (default = 1)
 * @returns {Promise<QueryResult>}
 */
const queryRoles = async (filter, options) => {
  const roles = await Role.paginate(filter, options);
  return roles;
};

/**
 * Get role by id
 * @param {ObjectId} roleId
 * @returns {Promise<Role>}
 */
const getRoleById = async (id) => {
  return Role.findById(id);
};

/**
 * Get role by email
 * @param {string} roleName
 * @returns {Promise<Role>}
 */
const getRoleByName = async (roleName) => {
  return Role.findOne({ role: roleName });
};

/**
 * Add Functionality To Role
 * @param {Object} updateBody
 * @returns {Promise<Role>}
 */
const addFunctionalityToRole = async (updateBody) => {
  try {
    // Find the role by its name
    const role = await Role.findOne({ role: updateBody.roleName });

    if (!role) {
      throw new Error('Role not found');
    }

    // Check if the functionality is already in the array
    if (!role.functionalities.includes(updateBody.functionalityName)) {
      // Add the functionality to the array
      role.functionalities.push(updateBody.functionalityName);

      // Save the updated role to the database
      await role.save();

      return role;
    } else {
      throw new Error('Functionality already exists in the role');
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

/**
 * Delete Functionality To Role
 * @param {Object} updateBody
 * @returns {Promise<Role>}
 */
const deleteFunctionalityToRole = async (updateBody) => {
  try {
    // Find the role by its name
    const role = await Role.findOne({ role: updateBody.roleName });

    if (!role) {
      throw new Error('Role not found');
    }

    // Check if the functionality is in the array
    const index = role.functionalities.indexOf(updateBody.functionalityName);
    if (index !== -1) {
      // Remove the functionality from the array
      role.functionalities.splice(index, 1);

      // Save the updated role to the database
      await role.save();

      return role;
    } else {
      throw new Error('Functionality not found in the role');
    }
  } catch (error) {
    throw new Error(error.message);
  }
};

/**
 * Delete role by id
 * @param {ObjectId} roleId
 * @returns {Promise<Role>}
 */
const deleteRoleById = async (roleId) => {
  const role = await getRoleById(roleId);
  if (!role) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Role not found');
  }
  await Role.findByIdAndDelete(roleId);
  return role;
};

/**
 * Delete role by id
 * @param {String} role
 * @returns {Promise<Role>}
 */
const deleteRoleByName = async (role) => {
  const roles = await getRoleByName(role);
  if (!roles) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Role not found');
  }
  await roles.remove();
  return roles;
};

/**
 * @returns {Promise<Role>}
 */
const getAll = async () => {
  const rolesData = await Role.find({});
  const formattedData = {};
  for (const roleData of rolesData) {
    const roleName = roleData.role;
    const functionalities = roleData.functionalities;
    formattedData[roleName] = functionalities;
  }
  return formattedData;
};

const updatePermissions = async (rolesAndFunctionalities) => {
  try {
    // Loop through the roles and update functionalities
    for (const role of Object.keys(rolesAndFunctionalities)) {
      const functionalities = rolesAndFunctionalities[role];

      // Find the role in the database by name
      const existingRole = await Role.findOne({ role });

      if (!existingRole) {
        // Handle the case where the role does not exist
        throw new ApiError(httpStatus.NOT_FOUND, `Role "${role}" not found`);
      }

      // Update the role's functionalities with the new ones
      existingRole.functionalities = functionalities;

      // Save the updated role to the database
      await existingRole.save();
    }
  } catch (error) {
    throw error; // You can handle or customize the error handling here
  }
};

module.exports = {
  createRole,
  queryRoles,
  getRoleById,
  getRoleByName,
  addFunctionalityToRole,
  deleteFunctionalityToRole,
  deleteRoleById,
  deleteRoleByName,
  getAll,
  updatePermissions,
};
