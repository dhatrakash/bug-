const logger = require('../config/logger');
const moment = require('moment');
const Fanuc = require('../models/fanuc.mqtt.model');

const findProductionData = async (startTime, endTime, machineName) => {
  const productive = [
    {
      $match: {
        'observation.machine': machineName,
        'observation.name': 'state',
        'observation.time': {
          $gte: startTime,
          $lte: endTime,
        },
      },
    },
    {
      $project: {
        _id: 0,
        ts: '$observation.time',
        value: '$state.data.run',
      },
    },
  ];
  const productionStatus = await Fanuc.aggregate(productive);
  productionStatus.sort((a, b) => a.ts - b.ts);
  return productionStatus;
};

const findPartCountData = async (startTime, endTime, machineName) => {
  const gcodePartCount = [
    {
      $match: {
        'observation.machine': machineName,
        'observation.name': 'gcode',
        'observation.time': {
          $gte: startTime,
          $lte: endTime,
        },
        'state.data.blocks': {
          $elemMatch: {
            BlockText: 'M40',
          },
        },
      },
    },
    {
      $project: {
        _id: 0,
        ts: '$observation.time',
        matchedBlock: {
          $arrayElemAt: [
            {
              $filter: {
                input: '$state.data.blocks',
                as: 'block',
                cond: {
                  $eq: ['$$block.BlockText', 'M40'],
                },
              },
            },
            0,
          ],
        },
      },
    },
    {
      $sort: {
        ts: 1,
      },
    },
  ];


  const productCount = [
    {
      $match: {
        'observation.machine': machineName,
        'observation.name': 'production',
        'observation.time': {
          $gte: startTime,
          $lte: endTime,
        },
      },
    },
    {
      $project: {
        _id: 0,
        ts: '$observation.time',
        value: '$state.data.pieces.produced',
        partName: '$state.data.program.current.comment',
      },
    },
    {
      $sort: {
        ts: 1,
      },
    },
    {
      $group: {
        _id: '$value',
        ts: { $first: '$ts' },
        partName: { $first: '$partName' },
      },
    },
    {
      $project: {
        _id: 0,
        ts: 1,
        partName: 1,
        value: '$_id',
      },
    },
    {
      $sort: {
        ts: 1,
      },
    },
  ];
  let productionStatus = [];
  if (machineName.startsWith('mahabal')) {
    productionStatus = await Fanuc.aggregate(gcodePartCount);
  } else {
    productionStatus = await Fanuc.aggregate(productCount);
  }

  productionStatus.sort((a, b) => a.ts - b.ts);

  return productionStatus;
};
const findFeedSpeedRpm = async (startTime, endTime, machineName) => {
  startDate = moment(startTime).subtract(5, 'hours').subtract(30, 'minutes').valueOf();
  endDate = moment(endTime).subtract(5, 'hours').subtract(30, 'minutes').valueOf();
  const feed = [
    {
      $match: {
        'observation.machine': machineName,
        'observation.name': 'state',
        'observation.time': {
          $gte: startDate,
          $lte: endDate,
        },
      },
    },
    {
      $project: {
        _id: 0,
        ts: '$observation.time',
        feed: '$state.data.override.feed',
      },
    },
    {
      $group: {
        _id: '$ts',
        feed: { $first: '$feed' },
      },
    },
  ];
  const speed = [
    {
      $match: {
        'observation.machine': machineName,
        'observation.name': 'spindle',
        'observation.time': {
          $gte: startTime,
          $lte: endTime,
        },
      },
    },
    {
      $project: {
        _id: 0,
        ts: '$observation.time',
        speed: '$state.data.speed',
      },
    },
    {
      $group: {
        _id: '$ts',
        speed: { $first: '$speed' },
      },
    },
  ];
  const rpm = [
    {
      $match: {
        'observation.machine': machineName,
        'observation.name': 'spindle',
        'observation.time': {
          $gte: startTime,
          $lte: endTime,
        },
      },
    },
    {
      $project: {
        _id: 0,
        ts: '$observation.time',
        rpm: '$state.data.maxrpm',
      },
    },
    {
      $group: {
        _id: '$ts',
        rpm: { $first: '$rpm' },
      },
    },
  ];

  const feedData = await Fanuc.aggregate(feed);
  const speedData = await Fanuc.aggregate(speed);
  const rpmData = await Fanuc.aggregate(rpm);

  const avgRpm = rpmData.reduce((sum, item) => sum + item.rpm, 0) / rpmData.length;
  const avgSpeed = speedData.reduce((sum, item) => sum + item.speed, 0) / speedData.length;
  const avgFeed = feedData.reduce((sum, item) => sum + item.feed, 0) / feedData.length;

  const data = {
    rpm: avgRpm,
    speed: avgSpeed,
    feed: avgFeed,
  };

  return data;
};

const handleSortAndUpdatingSrno = (doneQuantity) => {
  const doneQuantityGroups = {};
  let doneQuantityFinalArray = [];
  const sortingDoneQuantityGroupItems = [];
  let currentIndex = 0;
  let continueIterating = true;

  // removing duplicate
  const isDuplicate = (obj1, obj2) => obj1.machineid === obj2.machineid && obj1.endtime.getTime() === obj2.endtime.getTime();

  doneQuantity = doneQuantity.filter((item, index, arr) => {
    return arr.findIndex((obj) => isDuplicate(item, obj)) === index;
  });

  doneQuantity.forEach((item) => {
    if (!doneQuantityGroups[item.machineid]) {
      doneQuantityGroups[item.machineid] = [];
    }
    doneQuantityGroups[item.machineid].push(item);
  });

  while (continueIterating) {
    continueIterating = false;

    for (const machineid in doneQuantityGroups) {
      if (doneQuantityGroups[machineid][currentIndex]) {
        let currentSt = doneQuantityGroups[machineid][currentIndex].starttime;
        let currentEt = doneQuantityGroups[machineid][currentIndex].endtime;
        let timeDiff = currentEt - currentSt;
        if (timeDiff > 13000) sortingDoneQuantityGroupItems.push(doneQuantityGroups[machineid][currentIndex]);
        continueIterating = true;
      }
    }

    sortingDoneQuantityGroupItems.sort((a, b) => a.endtime - b.endtime);

    for (i = 0; i < sortingDoneQuantityGroupItems.length; i++) {
      doneQuantityFinalArray.push(sortingDoneQuantityGroupItems[i]);
    }
    sortingDoneQuantityGroupItems.length = 0; // Clear the sortingArray
    currentIndex++;
  }

  doneQuantityFinalArray.forEach((item, index) => {
    item.srno = index + 1;
  });

  logger.debug(`Data sorting completed ok`);
  return doneQuantityFinalArray;
};
const processCycleData = async (machineName, startDate, endDate) => {
  try {
    const startTime = moment(startDate).subtract(5, 'hours').subtract(30, 'minutes').valueOf();
    const endTime = moment(endDate).subtract(5, 'hours').subtract(30, 'minutes').valueOf();
    console.log('startTime', startTime);
    console.log('endTime', endTime);
    let doneQuantity = [];
    let prevSt = {};
    let prevEt = {};
    let stIdx = {};
    const starttime = {};
    const endtime = {};
    const partName = {};
    const partCount = {};
    let srno = doneQuantity.length;
    const machineId = machineName;
    prevEt[machineId] = moment(startTime);
    prevSt[machineId] = moment(startTime);

    const productionData = await findProductionData(startTime, endTime, machineName);
    const partCountData = await findPartCountData(startTime, endTime, machineName);

    stIdx[machineId] = 0;
    for (const cycle of productionData) {
      if (!starttime[machineId]) {
        starttime[machineId] = [];
      }
      if (cycle.value === 3) {
        // 3 fanuc, 1 hardwire
        starttime[machineId].push(cycle.ts);
      }
    }

    for (const part of partCountData) {
      if (!endtime[machineId]) {
        endtime[machineId] = [];
      }
      endtime[machineId].push(part.ts);

      if (!partCount[machineId]) {
        partCount[machineId] = [];
      }
      partCount[machineId].push(part.value);

      if (!partName[machineId]) {
        partName[machineId] = [];
      }
      partName[machineId].push(part.partName);
    }
    for (const machineId of Object.keys(stIdx)) {
      if (srno > 0) {
        let lastTime;
        for (let i = srno - 1; i >= 0; i--) {
          if (doneQuantity[i].machineid === machineId) {
            lastTime = moment(doneQuantity[i].endtime).unix();
            break;
          }
        }

        while (
          moment(starttime[machineId][stIdx[machineId]]).unix() <= lastTime &&
          starttime[machineId].length > stIdx[machineId]
        ) {
          stIdx[machineId]++;
        }
      }
    }

    for (const machineId of Object.keys(endtime)) {
      console.log(machineId);
      if (starttime[machineId].length > stIdx[machineId]) {
        const machineEndTimeArray = endtime[machineId];
        const machineEndPartName = partName[machineId];
        const machineEndPartcount = partCount[machineId];
        let index = 0;
        for (const time of machineEndTimeArray) {
          const currentPartName = machineEndPartName[index];
          const currentPartCount = machineEndPartcount[index];
          index++;

          const et = moment(time);
          if (starttime[machineId][stIdx[machineId]] > time) {
            if (prevSt[machineId].isBefore(et)) {
              srno++;
              var temp = {
                srno: srno,
                machineid: machineId,
                starttime: prevEt[machineId].toDate(),
                endtime: et.toDate(),
                partname: currentPartName,
                partcount: currentPartCount,
              };

              doneQuantity.push(temp);
              prevSt[machineId] = prevEt[machineId];
              prevEt[machineId] = et;
            } else {
              logger.debug(`Skipping at ${moment(time).format('YYYY/MM/DD HH:mm:ss.SSS')}`);
            }
            continue;
          }
          srno++;
          const st = moment(starttime[machineId][stIdx[machineId]]);
          var temp = {
            srno: srno,
            machineid: machineId,
            starttime: st.toDate(), //st.format('YYYY/MM/DD HH:mm:ss.SSS'),
            endtime: et.toDate(), //et.format('YYYY/MM/DD HH:mm:ss.SSS')
            partname: currentPartName,
            partcount: currentPartCount,
          };

          doneQuantity.push(temp);
          while (starttime[machineId].length > stIdx[machineId] && starttime[machineId][stIdx[machineId]] < time)
            stIdx[machineId]++;
          if (starttime[machineId].length <= stIdx[machineId]) break;
          prevEt[machineId] = et;
          prevSt[machineId] = st;
        }
      }
    }
    doneQuantity = handleSortAndUpdatingSrno(doneQuantity);

    if (doneQuantity.length > 0) {
      for (i = 0; i < doneQuantity.length; i++) {
        let productionStartTime = moment(doneQuantity[i].starttime);
        let productionEndTime = moment(doneQuantity[i].endtime);
        let idleStartTime = moment(doneQuantity[i + 1]?.starttime);
        let idleEndTime = moment(doneQuantity[i].endtime);

        let productionDuration = productionEndTime.diff(productionStartTime, 'seconds');
        doneQuantity[i].productionDuration = productionDuration;

        if (i + 1 < doneQuantity.length) {
          let idleDuration = idleStartTime.diff(idleEndTime, 'seconds');
          if (idleDuration >= 0) {
            doneQuantity[i + 1].idleDuration = idleDuration;
          }
        }
      }
      logger.debug(`Job Start Time,  :-${doneQuantity[0].starttime}`);
      logger.debug(`Job Stop Time :-${doneQuantity[doneQuantity.length - 1].endtime}`);
    }
    return doneQuantity;
  } catch (error) {
    console.error(error);
  }
};

const erpResponse = async (startDate) => {
  try {
    const machineNames = ['mahabal1'];
    startDate = moment(startDate);
    const endDate = startDate.clone().add(1, 'days');
    const data = [];
    let srno = 1;
    for (const machineName of machineNames) {
      const currentCycleData = await processCycleData(machineName, startDate, endDate);

      const feedSpeedRpmData = await findFeedSpeedRpm(startDate, endDate, machineName);
      if (!currentCycleData[0]) {
        continue;
      }
      let idle = 0;
      let productive = 0;
      for (const item of currentCycleData) {
        idle += item.idleDuration ? item.idleDuration : 0;
        productive += item.productionDuration ? item.productionDuration : 0;
      }
      const response = {
        srno: srno++,
        JobCardNo: 'Job11111',
        Shift: '1',
        idletime: idle,
        MchineID: machineName,
        ProcessID: 'Prod1',
        OperatorID: 'Eng01',
        SetUpTime: idle,
        StartTime: currentCycleData[0].starttime,
        EndTime: currentCycleData[currentCycleData.length - 1].endtime,
        OKQty: currentCycleData.length,
        NotOKQty: 0,
        ToolNo: '30',
        productiontime: productive,
        ListStopage: [
          {
            PowerLoss: 'PID2',
            Cleaning: 'PID2',
          },
        ],
        ListEnergyconsumed: [
          {
            Temp: 0,
            Speed: 0,
            'M/C parameter 3': 0,
            'M/C parameter 4': 0,
          },
        ],
        ListOPSpecification: [
          {
            Feed: feedSpeedRpmData.feed,
            Speed: feedSpeedRpmData.speed,
            RPM: feedSpeedRpmData.rpm,
          },
        ],
      };
      data.push(response);
    }
    console.log(data[0]);
  } catch (error) {
    console.log(error);
    throw new Error(`error in erp repsonse ${error}`);
  }
};
module.exports = {
  processCycleData,
};
