const { partCode } = require('../models');

/**
 * Create a partCode
 * @param {Object} requestBody
 * @returns {Promise<partCode>}
 */
const createPartCode = async (requestBody) => {
  try {
    return await partCode.create(requestBody);
  } catch (error) {
    throw new Error(error.message);
  }
};

/**
 * Get a partCode data within timestamp
 * @param {Object} requestBody
 * @returns {Promise<partCode>}
 */
const getPartCodeData = async (startTime, endTime, mac) => {
  try {
    const pipelineArray = [
      {
        $match: {
          dtm: { $gte: startTime, $lte: endTime },
          mac: mac,
        },
      },
      {
        $project: {
          _id: 0,
          dtm: 1,
          partCode: 1,
        },
      },
      {
        $unwind: '$dtm',
      },
    ];
    const result = await partCode.aggregate(pipelineArray);
    return result;
  } catch (error) {
    throw new Error(error.message);
  }
};

module.exports = {
  createPartCode,
  getPartCodeData,
};
