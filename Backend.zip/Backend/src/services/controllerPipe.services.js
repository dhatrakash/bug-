const moment = require('moment');
const Fanuc = require('../models/fanuc.mqtt.model');

const allMachineData = async (startDate, endDate, reportTime) => {
  try {
    const result = {
      productionTime: 0,
      idleTime: 0,
      machineON: 0,
      autoMode0: 0,
      autoMode1: 0,
      autoMode6: 0,
      productCount: 0,
      availability: 0,
      performance: 0,
      quality: 0,
    };

    const time = moment.utc(startDate);
    const endDummyTimming = time.subtract(8, 'hour').valueOf();

    const startDoc = [
      {
        $match: {
          'observation.time': {
            $gte: endDummyTimming,
            $lte: startDate,
          },
          'observation.name': 'state',
        },
      },
      {
        $sort: {
          'observation.time': -1,
        },
      },
      {
        $group: {
          _id: '$observation.machine', // Group by 'observation.machine'
          latestDocument: { $first: '$$ROOT' }, // Get the latest document within each group
        },
      },
      {
        $replaceRoot: { newRoot: '$latestDocument' }, // Replace the root document with the latest document
      },
      {
        $set: {
          'observation.time': startDate,
        },
      },
      {
        $project: {
          _id: 0,
          'observation.time': 1,
          'observation.machine': 1,
          'state.data.run': 1,
        },
      },
    ];

    const resultdata = await Fanuc.aggregate(startDoc);

    const pipeline = [
      {
        $match: {
          'observation.time': {
            $gte: startDate,
            $lte: endDate,
          },
          'observation.name': 'state',
        },
      },
      {
        $group: {
          _id: '$observation.machine',
        },
      },
      {
        $group: {
          _id: null,
          machineNames: { $push: '$_id' },
        },
      },

      {
        $project: {
          _id: 0,
          machineNames: 1,
        },
      },
    ];

    const machinedata = await Fanuc.aggregate(pipeline);
    if (machinedata.length === 0) {
      return result;
    }
    const machinenames = machinedata[0].machineNames;

    const dummyDocumentStart = [];
    machinenames.forEach((machineName) => {
      const document = resultdata.find((doc) => doc['observation.machine'] === machineName);

      if (document) {
        dummyDocumentStart.push(document);
      } else {
        dummyDocumentStart.push({ observation: { time: startDate, machine: machineName }, state: { data: { run: 0 } } });
      }
    });

    const endDoc = [
      {
        $match: {
          'observation.time': {
            $gte: startDate,
            $lte: endDate,
          },
          'observation.name': 'state',
        },
      },
      {
        $sort: {
          'observation.time': -1,
        },
      },
      {
        $group: {
          _id: '$observation.machine', // Group by 'observation.machine'
          latestDocument: { $first: '$$ROOT' }, // Get the latest document within each group
        },
      },
      {
        $replaceRoot: { newRoot: '$latestDocument' }, // Replace the root document with the latest document
      },
      {
        $set: {
          'observation.time': endDate,
        },
      },
      {
        $project: {
          _id: 0,
          'observation.time': 1,
          'observation.machine': 1,
          'state.data.run': 1,
        },
      },
    ];

    const dummyDocumentEnd = await Fanuc.aggregate(endDoc);

    const check = [
      {
        $match: {
          'observation.time': {
            $gte: startDate,
            $lt: endDate,
          },
          $or: [{ 'observation.name': 'state' }, { 'observation.name': 'production' }],
        },
      },

      {
        $facet: {
          data1: [
            {
              $match: {
                'observation.name': 'state',
              },
            },
            {
              $sort: { 'observation.time': 1 },
            },
            {
              $group: {
                _id: null,
                allDocuments: { $push: '$$ROOT' },
              },
            },
            {
              $addFields: {
                allDocuments: { $concatArrays: [dummyDocumentStart, '$allDocuments', dummyDocumentEnd] },
              },
            },
            {
              $unwind: '$allDocuments', // Unwind the concatenated array
            },
            {
              $group: {
                _id: '$allDocuments.observation.machine', // Group by machine
                documents: { $push: '$allDocuments' }, // Push documents into an array
              },
            },

            {
              $set: {
                documents: {
                  $map: {
                    input: { $range: [0, { $subtract: [{ $size: '$documents' }, 1] }] }, // Iterate through the documents
                    as: 'index',
                    in: {
                      $mergeObjects: [
                        { $arrayElemAt: ['$documents', '$$index'] },
                        {
                          idleTime: {
                            $cond: [
                              { $eq: [{ $arrayElemAt: ['$documents.state.data.run', '$$index'] }, 0] },
                              {
                                $subtract: [
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', { $add: ['$$index', 1] }] },
                                      0,
                                    ],
                                  },
                                  {
                                    $ifNull: [{ $arrayElemAt: ['$documents.observation.time', '$$index'] }, 0],
                                  },
                                ],
                              },
                              0,
                            ],
                          },
                          productionTime: {
                            $cond: [
                              { $ne: [{ $arrayElemAt: ['$documents.state.data.run', '$$index'] }, 0] },
                              {
                                $subtract: [
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', { $add: ['$$index', 1] }] },
                                      0,
                                    ],
                                  },
                                  {
                                    $ifNull: [{ $arrayElemAt: ['$documents.observation.time', '$$index'] }, 0],
                                  },
                                ],
                              },
                              0,
                            ],
                          },
                        },
                      ],
                    },
                  },
                },
              },
            },
            {
              $unwind: '$documents',
            },
            {
              $group: {
                _id: '$_id',
                production_time: { $sum: '$documents.productionTime' },
                idle_Time: { $sum : '$documents.idleTime' },
              },
            },
            {
              $project: {
                _id: 1,
                production_time: 1,
                idle_Time: 1,
              },
            },
            {
              $group: {
                _id: null,
                productionTime: { $avg: '$production_time' },
                idleTime: { $avg: '$idle_Time' },
              },
            },
            {
              $project: {
                _id: 0,
                productionTime: 1,
                idleTime: 1,
              },
            },
           ],

          data2: [
            {
              $match: {
               'observation.name': 'production',
              },
            },
            {
              $project: {
                _id: 0,
                ts: '$observation.time',
                value: '$state.data.pieces.produced',
                partName: '$state.data.program.current.comment',
                machineName : '$observation.machine'
              },
            },
            {
              $sort: {
                ts: 1,
              },
            },
            {
              $group: {
              _id: {machineName:'$machineName',value : '$value'},
             },
            },
            {
              $group : {
                _id:"$_id.machineName",
                count: { $sum: 1 }
              }
            },
            {
              $project: {
                modifiedCount: {
                  $subtract: ['$count', 1],
                }
              }
            },
            {
              $group: {
                _id: null,
                productCount: { $sum: '$modifiedCount' },
              }
            },
            {
              $project: {
                _id: 0,
                productCount: 1,
              }
            },
          ],
        },
       },
      {
        $project: {
          _id: 0,
          production_time: '$data1.productionTime',
          idle_Time: '$data1.idleTime',
          productCount: '$data2.productCount',
        }},
    ];

    const data = await Fanuc.aggregate(check);

    if (data[0].production_time.length !== 0) {
      result.productionTime = data[0].production_time[0] / 1000;
      result.idleTime = data[0].idle_Time[0] / 1000;
      result.machineON = result.productionTime + result.idleTime;
      result.productCount = data[0].productCount[0];
      if (typeof result.productCount === 'undefined' || result.productCount === 0) {
        result.quality = 1;
        result.productCount = 0;
      } else {
        result.quality = result.productCount / result.productCount;
      }
      result.availability = result.machineON / reportTime;
      result.performance = result.productionTime / result.machineON;
    }

    return result;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};

const productCountByMachineName = async (startDate, endDate) => {
  try {
    const totalCount = [
      {
        $match: {
          'observation.time': { $gte: startDate, $lte: endDate },
          'observation.name': 'production',
        },
      },
      {
        $project: {
          productName: '$state.data.program.current.comment',
          productCount: '$state.data.pieces.produced',
          time: '$observation.time',
          machine: '$observation.machine',
        },
      },
      {
        $sort: { time: -1 },
      },
      {
        $group: {
          _id: { machine: '$machine', productName: '$productName' },
          latestProductCount: { $first: '$productCount' },
          lastProductCount: { $last: '$productCount' },
        },
      },
      {
        $group: {
          _id: '$_id.machine',
          partcount: { $sum: '$latestProductCount' },
          count: { $sum: '$lastProductCount' },
        },
      },
      {
        $project: {
          total_count: { $subtract: ['$partcount', '$count'] },
          Name: '$_id',
          _id: 0,
        },
      },
    ];

    const data = await Fanuc.aggregate(totalCount);
    return data;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};

const selectedMachineData = async (startDate, endDate, reportTime, machineName) => {
  try {
    const result = {
      productionTime: 0,
      idleTime: 0,
      machineON: 0,
      autoMode0: 0,
      autoMode1: 0,
      autoMode6: 0,
      productCount: 0,
      availability: 0,
      performance: 0,
      quality: 0,
    };

    const dummyDocumentEnd = {
      observation: {
        time: endDate,
        name: 'state',
        machine: machineName,
      },
      state: {
        data: {
          run: 0,
        },
      },
    };

    const time = moment.utc(startDate);
    const endDummyTimming = time.subtract(8, 'hour').valueOf();

    const startDoc = [
      {
        $match: {
          'observation.time': {
            $lte: startDate,
            $gte: endDummyTimming,
          },
          'observation.name': 'state',
          'observation.machine': machineName,
        },
      },
      {
        $sort: { 'observation.time': -1 },
      },
      {
        $limit: 1,
      },
      {
        $addFields: {
          'observation.time': startDate,
        },
      },
    ];

    const resultdata = await Fanuc.aggregate(startDoc);
    let dummyDocumentStart = {};
    if (resultdata.length === 0) {
      dummyDocumentStart = {
        observation: {
          time: startDate,
          name: 'state',
          machine: machineName,
        },
        state: {
          data: {
            run: 0,
          },
        },
      };
    } else {
      dummyDocumentStart = resultdata[0];
    }

    const check = [
      {
        $match: {
          'observation.time': {
            $gte: startDate,
            $lt: endDate,
          },
          'observation.machine': machineName,
          $or: [{ 'observation.name': 'state' }, { 'observation.name': 'production' }],
        },
      },

      {
        $facet: {
          data1: [
            {
              $match: {
                'observation.name': 'state',
              },
            },
            {
              $sort: { 'observation.time': 1 },
            },
            {
              $group: {
                _id: null,
                documents1: { $push: '$$ROOT' },
              },
            },
            {
              $project: {
                _id: 0,
                documents: { $concatArrays: [[dummyDocumentStart], '$documents1'] },
              },
            },
            {
              $addFields: {
                documents: { $concatArrays: ['$documents', [dummyDocumentEnd]] },
              },
            },
            {
              $set: {
                documents: {
                  $map: {
                    input: { $range: [0, { $subtract: [{ $size: '$documents' }, 1] }] },
                    as: 'index',
                    in: {
                      $mergeObjects: [
                        { $arrayElemAt: ['$documents', '$$index'] },

                        {
                          idleTime: {
                            $cond: [
                              { $eq: [{ $arrayElemAt: ['$documents.state.data.run', '$$index'] }, 0] }, // 1
                              {
                                $subtract: [
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', { $add: ['$$index', 1] }] },
                                      0,
                                    ], // 2 time - 1 time
                                  },
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', '$$index'] }, // + odea
                                      0,
                                    ],
                                  },
                                ],
                              },

                              0,
                            ],
                          },

                          productionTime: {
                            $cond: [
                              { $ne: [{ $arrayElemAt: ['$documents.state.data.run', '$$index'] }, 0] },
                              {
                                $subtract: [
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', { $add: ['$$index', 1] }] },
                                      0,
                                    ],
                                  },
                                  {
                                    $ifNull: [{ $arrayElemAt: ['$documents.observation.time', '$$index'] }, 0],
                                  },
                                ],
                              },
                              0,
                            ],
                          },
                        },
                      ],
                    },
                  },
                },
              },
            },
            {
              $unwind: '$documents',
            },
            {
              $group: {
                _id: null,
                production_time: { $sum: '$documents.productionTime' },
                idle_Time: { $sum: '$documents.idleTime' },
              },
            },
            {
              $project: {
                _id: 0,
                production_time: 1,
                idle_Time: 1,
              },
            },
          ],

          data2: [
            {
              $match: {
                'observation.name': 'production'
                },
            },
            {
              $project: {
                _id: 0,
                ts: '$observation.time',
                value: '$state.data.pieces.produced',
                partName: '$state.data.program.current.comment'
              },
            },
            {
              $sort: {
                ts: 1,
              },
            },
            {
              $group: {
                _id: '$value',
                ts: { $first: '$ts' },
              }
            },
            {
              $project: {
                _id: 0,
                ts: 1,
                value: '$_id',
                partName: 1,
              }
            },
            {
              $count: 'partCount', 
            },
            {
              $project: {
                _id: 0,
                productCount : {$subtract : [ '$partCount',1]}
              }
            }
          ],
        },
      },
      {
        $project: {
          _id: 0,
          production_time: '$data1.production_time',
          idle_Time: '$data1.idle_Time',
          productCount: '$data2.productCount',
        },
      },
    ];

    const data = await Fanuc.aggregate(check);

    if (data[0].production_time.length !== 0) {
      result.productionTime = data[0].production_time[0] / 1000;
      result.idleTime = data[0].idle_Time[0] / 1000;
      result.machineON = result.productionTime + result.idleTime;
      result.productCount = data[0].productCount[0];
      if (typeof result.productCount === 'undefined'|| result.productCount === 0) {
        result.quality = 1;
        result.productCount = 0;
      } else {
        result.quality = result.productCount / result.productCount;
      }
      result.availability = result.machineON / reportTime;
      result.performance = result.productionTime / result.machineON;
    }

    return result;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};

const pdfGenerator = async (startDate, endDate, machineName) => {
  try {
    const result = {
      productionTime: 0,
      idleTime: 0,
      machineON: 0,
      productCount: 0,
    };

    const dummyDocumentEnd = {
      observation: {
        time: endDate,
        name: 'state',
        machine: machineName,
      },
      state: {
        data: {
          run: 0,
        },
      },
    };

    const time = moment.utc(startDate);
    const endDummyTimming = time.subtract(1, 'hour').valueOf();

    const startDoc = [
      {
        $match: {
          'observation.time': {
            $lte: startDate,
            $gte: endDummyTimming,
          },
          'observation.name': 'state',
          'observation.machine': machineName,
        },
      },
      {
        $sort: { 'observation.time': -1 },
      },
      {
        $limit: 1,
      },
      {
        $addFields: {
          'observation.time': startDate,
        },
      },
    ];

    const resultdata = await Fanuc.aggregate(startDoc);
    let dummyDocumentStart = {};

    if (resultdata.length === 0) {
      dummyDocumentStart = {
        observation: {
          time: startDate,
          name: 'state',
          machine: machineName,
        },
        state: {
          data: {
            run: 0,
          },
        },
      };
    } else {
      dummyDocumentStart = resultdata[0];
    }

    const check = [
      {
        $match: {
          'observation.time': {
            $gte: startDate,
            $lt: endDate,
          },
          'observation.machine': machineName,
          $or: [{ 'observation.name': 'state' }, { 'observation.name': 'production' }],
        },
      },

      {
        $facet: {
          data1: [
            {
              $match: {
                'observation.name': 'state',
              },
            },
            {
              $sort: { 'observation.time': 1 },
            },
            {
              $group: {
                _id: null,
                documents1: { $push: '$$ROOT' },
              },
            },
            {
              $project: {
                _id: 0,
                documents: { $concatArrays: [[dummyDocumentStart], '$documents1'] },
              },
            },
            {
              $addFields: {
                documents: { $concatArrays: ['$documents', [dummyDocumentEnd]] },
              },
            },
            {
              $set: {
                documents: {
                  $map: {
                    input: { $range: [0, { $subtract: [{ $size: '$documents' }, 1] }] },
                    as: 'index',
                    in: {
                      $mergeObjects: [
                        { $arrayElemAt: ['$documents', '$$index'] },

                        {
                          idleTime: {
                            $cond: [
                              { $eq: [{ $arrayElemAt: ['$documents.state.data.run', '$$index'] }, 0] }, // 1
                              {
                                $subtract: [
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', { $add: ['$$index', 1] }] },
                                      0,
                                    ], // 2 time - 1 time
                                  },
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', '$$index'] }, // + odea
                                      0,
                                    ],
                                  },
                                ],
                              },

                              0,
                            ],
                          },

                          productionTime: {
                            $cond: [
                              { $ne: [{ $arrayElemAt: ['$documents.state.data.run', '$$index'] }, 0] },
                              {
                                $subtract: [
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', { $add: ['$$index', 1] }] },
                                      0,
                                    ],
                                  },
                                  {
                                    $ifNull: [{ $arrayElemAt: ['$documents.observation.time', '$$index'] }, 0],
                                  },
                                ],
                              },
                              0,
                            ],
                          },
                        },
                      ],
                    },
                  },
                },
              },
            },
            {
              $unwind: '$documents',
            },
            {
              $group: {
                _id: null,
                production_time: { $sum: '$documents.productionTime' },
                idle_Time: { $sum: '$documents.idleTime' },
              },
            },
            {
              $project: {
                _id: 0,
                production_time: 1,
                idle_Time: 1,
              },
            },
          ],

          data2: [
            {
              $match: {
                'observation.time': { $gte: startDate, $lte: endDate },
                'observation.name': 'production',
              },
            },
            {
              $project: {
                productName: '$state.data.program.current.comment',
                productCount: '$state.data.pieces.produced',
                time: '$observation.time',
              },
            },
            {
              $sort: { time: -1 },
            },
            {
              $group: {
                _id: '$productName',
                latestProductCount: { $first: '$productCount' },
                lastProductCount: { $last: '$productCount' },
              },
            },
            {
              $group: {
                _id: null,
                partcount: { $sum: '$latestProductCount' },
                count: { $sum: '$lastProductCount' },
              },
            },
            {
              $project: {
                _id: 0,
                productCount: { $subtract: ['$partcount', '$count'] },
              },
            },
          ],
        },
      },
      {
        $project: {
          _id: 0,
          production_time: '$data1.production_time',
          idle_Time: '$data1.idle_Time',
          productCount: '$data2.productCount',
        },
      },
    ];

    const data = await Fanuc.aggregate(check);

    if (data[0].production_time.length !== 0) {
      result.productionTime = data[0].production_time[0] / 1000;
      result.idleTime = data[0].idle_Time[0] / 1000;
      result.machineON = result.productionTime + result.idleTime;
      result.productCount = data[0].productCount[0];
    }

    return result;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};

const dynamicPdfGenerator = async (startDate, endDate, reportTime, machineName) => {
  try {
    
    const result = {
      productionTime: 0,
      idleTime: 0,
      machineON: 0,
      autoMode0: 0,
      autoMode1: 0,
      autoMode6: 0,
      productCount: 0,
      availability: 0,
      performance: 0,
      quality: 0,
    };
    const dummyDocumentEnd = {
      observation: {
        time: endDate,
        name: 'state',
        machine: machineName,
      },
      state: {
        data: {
          run: 0,
        },
      },
    };

    const time = moment.utc(startDate);
    const endDummyTimming = time.subtract(8, 'hour').valueOf();

    const startDoc = [
      {
        $match: {
          'observation.time': {
            $lte: startDate,
            $gte: endDummyTimming,
          },
          'observation.name': 'state',
          'observation.machine': machineName,
        },
      },
      {
        $sort: { 'observation.time': -1 },
      },
      {
        $limit: 1,
      },
      {
        $addFields: {
          'observation.time': startDate,
        },
      },
    ];

    const resultdata = await Fanuc.aggregate(startDoc);
    let dummyDocumentStart = {};
    if (resultdata.length === 0) {
      dummyDocumentStart = {
        observation: {
          time: startDate,
          name: 'state',
          machine: machineName,
        },
        state: {
          data: {
            run: 0,
          },
        },
      };
    } else {
      dummyDocumentStart = resultdata[0];
    }

    const check = [
      {
        $match: {
          'observation.time': {
            $gte: startDate,
            $lt: endDate,
          },
          'observation.machine': machineName,
          $or: [{ 'observation.name': 'state' }, { 'observation.name': 'production' }],
        },
      },

      {
        $facet: {
          data1: [
            {
              $match: {
                'observation.name': 'state',
              },
            },
            {
              $sort: { 'observation.time': 1 },
            },
            {
              $group: {
                _id: null,
                documents1: { $push: '$$ROOT' },
              },
            },
            {
              $project: {
                _id: 0,
                documents: { $concatArrays: [[dummyDocumentStart], '$documents1'] },
              },
            },
            {
              $addFields: {
                documents: { $concatArrays: ['$documents', [dummyDocumentEnd]] },
              },
            },
            {
              $set: {
                documents: {
                  $map: {
                    input: { $range: [0, { $subtract: [{ $size: '$documents' }, 1] }] },
                    as: 'index',
                    in: {
                      $mergeObjects: [
                        { $arrayElemAt: ['$documents', '$$index'] },

                        {
                          idleTime: {
                            $cond: [
                              { $eq: [{ $arrayElemAt: ['$documents.state.data.run', '$$index'] }, 0] }, // 1
                              {
                                $subtract: [
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', { $add: ['$$index', 1] }] },
                                      0,
                                    ], // 2 time - 1 time
                                  },
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', '$$index'] }, // + odea
                                      0,
                                    ],
                                  },
                                ],
                              },

                              0,
                            ],
                          },

                          productionTime: {
                            $cond: [
                              { $ne: [{ $arrayElemAt: ['$documents.state.data.run', '$$index'] }, 0] },
                              {
                                $subtract: [
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', { $add: ['$$index', 1] }] },
                                      0,
                                    ],
                                  },
                                  {
                                    $ifNull: [{ $arrayElemAt: ['$documents.observation.time', '$$index'] }, 0],
                                  },
                                ],
                              },
                              0,
                            ],
                          },
                        },
                      ],
                    },
                  },
                },
              },
            },
            {
              $unwind: '$documents',
            },
            {
              $group: {
                _id: null,
                production_time: { $sum: '$documents.productionTime' },
                idle_Time: { $sum: '$documents.idleTime' },
              },
            },
            {
              $project: {
                _id: 0,
                production_time: 1,
                idle_Time: 1,
              },
            },
          ],

          data2: [
            {
              $match: {
                'observation.name': 'production'
                },
            },
            {
              $project: {
                _id: 0,
                ts: '$observation.time',
                value: '$state.data.pieces.produced',
                partName: '$state.data.program.current.comment'
              },
            },
            {
              $sort: {
                ts: 1,
              },
            },
            {
              $group: {
                _id: '$value',
                ts: { $first: '$ts' },
              }
            },
            {
              $project: {
                _id: 0,
                ts: 1,
                value: '$_id',
                partName: 1,
              }
            },
            {
              $count: 'partCount', 
            },
            {
              $project: {
                _id: 0,
                productCount : {$subtract : [ '$partCount',1]}
              }
            }
          ],
        },
      },
      {
        $project: {
          _id: 0,
          production_time: '$data1.production_time',
          idle_Time: '$data1.idle_Time',
          productCount: '$data2.productCount',
        },
      },
    ];

    const data = await Fanuc.aggregate(check);
   if (data[0].production_time.length !== 0) {
      result.productionTime = data[0].production_time[0] / 1000;
      result.idleTime = data[0].idle_Time[0] / 1000;
      result.machineON = result.productionTime + result.idleTime;
      result.productCount = data[0].productCount[0];
      if (typeof result.productCount === 'undefined'|| result.productCount===0) {
        result.quality = 1;
        result.productCount = 0;
      } else {
        result.quality = result.productCount / result.productCount;
      }
      result.availability = result.machineON / reportTime;
      if (result.machineON !== 0) result.performance = result.productionTime / result.machineON;
    }

    return result;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};

const companyReport = async (startDate, endDate, reportTime) => {
  try {
    const result = {
      productionTime: 0,
      idleTime: 0,
      machineON: 0,
      productCount: 0,
      availability: 0,
      performance: 0,
      quality: 0,
    };

    const time = moment.utc(startDate);
    const endDummyTimming = time.subtract(8, 'hour').valueOf();

    const startDoc = [
      {
        $match: {
          'observation.time': {
            $gte: endDummyTimming,
            $lte: startDate,
          },
          'observation.name': 'state',
        },
      },
      {
        $sort: {
          'observation.time': -1,
        },
      },
      {
        $group: {
          _id: '$observation.machine', // Group by 'observation.machine'
          latestDocument: { $first: '$$ROOT' }, // Get the latest document within each group
        },
      },
      {
        $replaceRoot: { newRoot: '$latestDocument' }, // Replace the root document with the latest document
      },
      {
        $set: {
          'observation.time': startDate,
        },
      },
      {
        $project: {
          _id: 0,
          'observation.time': 1,
          'observation.machine': 1,
          'state.data.run': 1,
        },
      },
    ];

    const resultdata = await Fanuc.aggregate(startDoc);

    const pipeline = [
      {
        $match: {
          'observation.time': {
            $gte: startDate,
            $lte: endDate,
          },
          'observation.name': 'state',
        },
      },
      {
        $group: {
          _id: '$observation.machine',
        },
      },
      {
        $group: {
          _id: null,
          machineNames: { $push: '$_id' },
        },
      },

      {
        $project: {
          _id: 0,
          machineNames: 1,
        },
      },
    ];

    const machinedata = await Fanuc.aggregate(pipeline);
    if (machinedata.length === 0) {
      return result;
    }
    const machinenames = machinedata[0].machineNames;

    const dummyDocumentStart = [];
    machinenames.forEach((machineName) => {
      const document = resultdata.find((doc) => doc['observation.machine'] === machineName);

      if (document) {
        dummyDocumentStart.push(document);
      } else {
        dummyDocumentStart.push({ observation: { time: startDate, machine: machineName }, state: { data: { run: 0 } } });
      }
    });

    const endDoc = [
      {
        $match: {
          'observation.time': {
            $gte: startDate,
            $lte: endDate,
          },
          'observation.name': 'state',
        },
      },
      {
        $sort: {
          'observation.time': -1,
        },
      },
      {
        $group: {
          _id: '$observation.machine', // Group by 'observation.machine'
          latestDocument: { $first: '$$ROOT' }, // Get the latest document within each group
        },
      },
      {
        $replaceRoot: { newRoot: '$latestDocument' }, // Replace the root document with the latest document
      },
      {
        $set: {
          'observation.time': endDate,
        },
      },
      {
        $project: {
          _id: 0,
          'observation.time': 1,
          'observation.machine': 1,
          'state.data.run': 1,
        },
      },
    ];

    const dummyDocumentEnd = await Fanuc.aggregate(endDoc);

    const check = [
      {
        $match: {
          'observation.time': {
            $gte: startDate,
            $lt: endDate,
          },
          $or: [{ 'observation.name': 'state' }, { 'observation.name': 'production' }],
        },
      },

      {
        $facet: {
          data1: [
            {
              $match: {
                'observation.time': {
                  $gte: startDate,
                  $lte: endDate,
                },
                'observation.name': 'state',
              },
            },
            {
              $sort: { 'observation.time': 1 },
            },
            {
              $group: {
                _id: null,
                allDocuments: { $push: '$$ROOT' },
              },
            },
            {
              $addFields: {
                allDocuments: { $concatArrays: [dummyDocumentStart, '$allDocuments', dummyDocumentEnd] },
              },
            },
            {
              $unwind: '$allDocuments', // Unwind the concatenated array
            },
            {
              $group: {
                _id: '$allDocuments.observation.machine', // Group by machine
                documents: { $push: '$allDocuments' }, // Push documents into an array
              },
            },

            {
              $set: {
                documents: {
                  $map: {
                    input: { $range: [0, { $subtract: [{ $size: '$documents' }, 1] }] }, // Iterate through the documents
                    as: 'index',
                    in: {
                      $mergeObjects: [
                        { $arrayElemAt: ['$documents', '$$index'] },
                        {
                          idleTime: {
                            $cond: [
                              { $eq: [{ $arrayElemAt: ['$documents.state.data.run', '$$index'] }, 0] },
                              {
                                $subtract: [
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', { $add: ['$$index', 1] }] },
                                      0,
                                    ],
                                  },
                                  {
                                    $ifNull: [{ $arrayElemAt: ['$documents.observation.time', '$$index'] }, 0],
                                  },
                                ],
                              },
                              0,
                            ],
                          },
                          productionTime: {
                            $cond: [
                              { $ne: [{ $arrayElemAt: ['$documents.state.data.run', '$$index'] }, 0] },
                              {
                                $subtract: [
                                  {
                                    $ifNull: [
                                      { $arrayElemAt: ['$documents.observation.time', { $add: ['$$index', 1] }] },
                                      0,
                                    ],
                                  },
                                  {
                                    $ifNull: [{ $arrayElemAt: ['$documents.observation.time', '$$index'] }, 0],
                                  },
                                ],
                              },
                              0,
                            ],
                          },
                        },
                      ],
                    },
                  },
                },
              },
            },
            {
              $unwind: '$documents',
            },
            {
              $group: {
                _id: '$_id',
                production_time: { $sum: '$documents.productionTime' },
                idle_Time: { $sum : '$documents.idleTime' },
              },
            },
            {
              $project: {
                _id: 1,
                production_time: 1,
                idle_Time: 1,
              },
            },
            {
              $group: {
                _id: null,
                productionTime: { $avg: '$production_time' },
                idleTime: { $avg: '$idle_Time' },
              },
            },
            {
              $project: {
                _id: 0,
                productionTime: 1,
                idleTime: 1,
              },
            },
           ],

          data2: [
            {
              $match: {
               'observation.name': 'production',
              },
            },
            {
              $project: {
                _id: 0,
                ts: '$observation.time',
                value: '$state.data.pieces.produced',
                partName: '$state.data.program.current.comment',
                machineName : '$observation.machine'
              },
            },
            {
              $sort: {
                ts: 1,
              },
            },
            {
              $group: {
              _id: {machineName:'$machineName',value : '$value'},
             },
            },
            {
              $group : {
                _id:"$_id.machineName",
                count: { $sum: 1 }
              }
            },
            {
              $project: {
                modifiedCount: {
                  $subtract: ['$count', 1],
                }
              }
            },
            {
              $group: {
                _id: null,
                productCount: { $sum: '$modifiedCount' },
              }
            },
            {
              $project: {
                _id: 0,
                productCount: 1,
              }
            },
          ],
        },
       },
      {
        $project: {
          _id: 0,
          production_time: '$data1.productionTime',
          idle_Time: '$data1.idleTime',
          productCount: '$data2.productCount',
        }},
    ];

    const data = await Fanuc.aggregate(check);
    if (data[0].production_time.length !== 0) {
      result.productionTime = data[0].production_time[0] / 1000;
      result.idleTime = data[0].idle_Time[0] / 1000;
      result.machineON = result.productionTime + result.idleTime;
      result.productCount = data[0].productCount[0];
      if (typeof result.productCount === 'undefined'|| result.productCount === 0) {
        result.quality = 1;
        result.productCount = 0;
      } else {
        result.quality = result.productCount / result.productCount;
      }
      result.availability = result.machineON / reportTime;
      result.performance = result.productionTime / result.machineON;
    }

    return result;
  } catch (error) {
    throw new Error(`Failed to find hardware data error: ${error.message}`);
  }
};

module.exports = {
  // fetch OEE data of all machine
  allMachineData,
  // part count by machine name
  productCountByMachineName,
  // fetch OEE data of selected machine
  selectedMachineData,
  // fetch  data of selected machine for pdf
  pdfGenerator,
  // fetch data in interval for pdf
  dynamicPdfGenerator,
  // fetch comapny data in interval for pdf
  companyReport
};
