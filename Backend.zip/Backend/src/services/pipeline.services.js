const Hardware = require('../models/hardware.model');
const Fanuc = require('../models/fanuc.mqtt.model');

const time = async () => {
  const result = [
    {
      $sort: { 'observation.time': 1 }, // Sort documents by timestamp in ascending order
    },
    {
      $group: {
        _id: null, // Group all documents into a single group
        documents: { $push: '$$ROOT' }, // Store all documents in an array
      },
    },
    {
      $set: {
        documents: {
          $map: {
            input: { $range: [0, { $size: '$documents' }] },
            as: 'index',
            in: {
              $mergeObjects: [
                { $arrayElemAt: ['$documents', '$$index'] },
                {
                  performanceIncrement: {
                    $cond: [
                      { $ne: ['$documents.state.data.run', 0] },
                      {
                        $subtract: [
                          { $ifNull: [{ $arrayElemAt: ['$documents.observation.time', { $add: ['$$index', 1] }] }, 0] },
                          { $ifNull: [{ $arrayElemAt: ['$documents.observation.time', '$$index'] }, 0] },
                        ],
                      },
                      0,
                    ],
                  },
                  idleIncrement: {
                    $cond: [
                      { $eq: ['$documents.state.data.run', 0] },
                      {
                        $subtract: [
                          { $ifNull: [{ $arrayElemAt: ['$documents.observation.time', { $add: ['$$index', 1] }] }, 0] },
                          { $ifNull: [{ $arrayElemAt: ['$documents.observation.time', '$$index'] }, 0] },
                        ],
                      },
                      0,
                    ],
                  },
                },
              ],
            },
          },
        },
      },
    },
    {
      $unwind: '$documents', // Unwind the array of documents
    },
    {
      $replaceRoot: { newRoot: '$documents' }, // Replace the root with the modified documents
    },
    {
      $project: {
        _id: 0, // Exclude _id field
        'observation.time': 1,
        performanceIncrement: 1,
        idleIncrement: 1,
      },
    },
  ];
  const resultGenerated = await Fanuc.aggregate(result);

  return resultGenerated;
};

const allMachineData = async (startDate, endDate) => {
  const data = {
    productionTime: 0,
    idealTime: 0,
    machineON: 0,
    productCount: 0,
    availability: 0,
    performance: 0,
    quality: 0,
  };

  const results = [
    {
      $match: {
        'data.dtm': {
          $gte: startDate,
          $lte: endDate,
        },
      },
    },

    {
      $group: {
        _id: '$data.mac',
        machineON: { $sum: 1 },
        production_time: {
          $sum: {
            $cond: [{ $eq: ['$data.io.di1', 1] }, 1, 0],
          },
        },
        ideal_Time: {
          $sum: {
            $cond: [{ $eq: ['$data.io.di1', 0] }, 1, 0],
          },
        },
        product_Count: {
          $sum: {
            $cond: [{ $eq: ['$data.io.di2', 1] }, 1, 0],
          },
        },
      },
    },

    {
      $project: {
        _id: 0,
        production_time: 1,
        ideal_Time: 1,
        product_Count: 1,
        machineON: 1,

        availability: {
          $cond: [{ $eq: ['$total_time', 0] }, 0, { $round: [{ $divide: ['$production_time', '$machineON'] }, 3] }],
        },
        perfomance: {
          $cond: [
            { $eq: ['$production_time', 0] },
            0,
            { $round: [{ $divide: [{ $multiply: [20, '$product_Count'] }, '$production_time'] }, 3] }, // Calculate availability
          ],
        },
        quality: {
          $cond: [
            { $eq: ['$product_Count', 0] },
            0,
            { $round: [{ $divide: [{ $subtract: ['$product_Count', 0] }, '$product_Count'] }, 3] },
          ],
        },
      },
    },
  ];

  const resultGenerated = await Hardware.aggregate(results);

  if (resultGenerated.length !== 0) {
    const result = resultGenerated[0];
    data.productionTime = result.production_time;
    data.idealTime = result.ideal_Time;
    data.machineON = result.machineON;
    data.productCount = result.product_Count;
    data.availability = result.availability;
    data.performance = result.perfomance;
    data.quality = result.quality;
  }

  return data;
};

const productCountByMac = async (startDate, endDate) => {
  const totalCount = [
    {
      $match: {
        'data.io.di2': 1,
        'data.dtm': {
          $gte: startDate,
          $lte: endDate,
        },
      },
    },
    {
      $group: {
        _id: '$data.mac',
        total_count: { $sum: 1 },
      },
    },
    {
      $project: {
        _id: 0,
        mac: '$_id',
        total_count: 1,
      },
    },
  ];

  const data = await Hardware.aggregate(totalCount);

  return data;
};

const selectedMachineData = async (startDate, endDate, mac) => {
  const data = {
    productionTime: 0,
    idealTime: 0,
    productCount: 0,
    availability: 0,
    performance: 0,
    quality: 0,
  };
  const machineReport = [
    {
      $match: {
        'data.mac': mac,
        'data.dtm': {
          $gte: startDate,
          $lte: endDate,
        },
      },
    },

    {
      $group: {
        _id: null,

        total_time: { $sum: 1 },

        productionTime: {
          $sum: {
            $cond: [{ $eq: ['$data.io.di1', 1] }, 1, 0],
          },
        },

        idealTime: {
          $sum: {
            $cond: [{ $eq: ['$data.io.di1', 0] }, 1, 0],
          },
        },

        productCount: {
          $sum: {
            $cond: [{ $eq: ['$data.io.di2', 1] }, 1, 0],
          },
        },
      },
    },

    {
      $project: {
        _id: 0,
        productionTime: 1,
        idealTime: 1,
        productCount: 1,
        total_time: 1,

        availability: {
          $cond: [{ $eq: ['$total_time', 0] }, 0, { $round: [{ $divide: ['$productionTime', '$total_time'] }, 3] }],
        },
        perfomance: {
          $cond: [
            { $eq: ['$productionTime', 0] }, // Check if total_time is 0 to avoid division by zero
            0, // Set availability to 0 if true
            { $round: [{ $divide: [{ $multiply: [20, '$productCount'] }, '$productionTime'] }, 3] }, // Calculate availability
          ],
        },
        quality: {
          $cond: [
            { $eq: ['$productCount', 0] },
            0, // Set availability to 0 if true
            { $round: [{ $divide: [{ $subtract: ['$productCount', 0] }, '$productCount'] }, 3] },
          ],
        },
      },
    },
  ];

  const reportGenerate = await Hardware.aggregate(machineReport);

  if (reportGenerate.length !== 0) {
    data.productionTime = reportGenerate[0].productionTime;
    data.idealTime = reportGenerate[0].idealTime;
    data.productCount = reportGenerate[0].productCount;
    data.availability = reportGenerate[0].availability;
    data.performance = reportGenerate[0].perfomance;
    data.quality = reportGenerate[0].quality;
  }

  return data;
};

const kavitsu = async (startDate, endDate) => {
  const data = {
    machineON: 0,
    productionTime: 0,
    idealTime: 0,
    partCount: 0,
  };
  const pipeline = [
    {
      $match: {
        'data.dtm': {
          $gte: startDate,
          $lte: endDate,
        },
        'data.mac': '608A10B603EC',
      },
    },
    {
      $sort: { 'data.dtm': 1 },
    },
    {
      $facet: {
        idle_time: [
          {
            $match: {
              $or: [
                { 'data.io.di1': 0 },
                {
                  'data.modbus': {
                    $elemMatch: {
                      di5: 0,
                    },
                  },
                },
              ],
            },
          },
          {
            $group: {
              _id: null,
              downtime: { $sum: 1 },
            },
          },
          {
            $project: {
              _id: 0,
              downtime: 1,
            },
          },
        ],
        production_time: [
          {
            $match: {
              'data.io.di1': 1,
              'data.modbus': {
                $elemMatch: {
                  di5: 1,
                },
              },
            },
          },
          {
            $group: {
              _id: null,
              uptime: { $sum: 1 },
            },
          },
          {
            $project: {
              _id: 0,
              uptime: 1,
            },
          },
        ],
        totalTime: [
          {
            $group: {
              _id: null,
              totalTime: { $sum: 1 },
            },
          },
          {
            $project: {
              _id: 0,
              totalTime: 1,
            },
          },
        ],
        product_count: [
          {
            $match: {
              'data.io.di2': 1,
            },
          },
          {
            $group: {
              _id: null,
              product_count: { $sum: 1 },
            },
          },
          {
            $project: {
              _id: 0,
              product_count: 1,
            },
          },
        ],
      },
    },
  ];

  const result = await Hardware.aggregate(pipeline);

  data.machineON = result[0].totalTime[0].totalTime;
  data.productionTime = result[0].production_time[0].uptime;
  data.idealTime = result[0].idle_time[0].downtime;
  data.partCount = result[0].product_count[0].product_count;

  return data;
};

// selectedMachineData('2023-07-02T00:00:00Z','2023-07-03T00:00:00Z','608A10B60822');
// allMachineData('2023-07-02T00:00:00Z','2023-07-03T00:00:00Z');
// productCountByMac('2023-07-02T00:00:00Z','2023-07-03T00:00:00Z');
// kavitsu('2023-10-02T11:30:00Z','2023-10-02T19:00:00Z')

module.exports = {
  // Data fetch colllectively of all machine
  allMachineData,
  // Product count group by machine mac
  productCountByMac,
  // Data fetch of machine of selected mac
  selectedMachineData,
  // Data for kavetsu
  kavitsu,

  time,
};
