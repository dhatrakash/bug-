const Line = require('../models/line.model');

const createLine = async (data) => {
  try {
    const lineData = {
      ...data,
      lineLocation: data.lineLocation,
    };
    const createdLine = await Line.create(lineData);
    return createdLine;
  } catch (error) {
    throw new Error(`Failed to create line: ${error}`);
  }
};

const findAllLines = async () => {
  try {
    const lines = await Line.find();
    return lines;
  } catch (error) {
    throw new Error(`Failed to retrieve Line data: ${error}`);
  }
};

const findLineById = async (id) => {
  try {
    const line = await Line.findOne({ _id: id });
    return line;
  } catch (error) {
    throw new Error(`Failed to retrieve line data: ${error}`);
  }
};

const updateLine = async (_id, updateBody) => {
  const updatedLine = new Line(updateBody);
  try {
    await Line.updateOne({ _id }, updatedLine);
    return updatedLine;
  } catch (error) {
    throw new Error(`Failed to update line data: ${error}`);
  }
};

const deleteLine = async (_id) => {
  try {
    await Line.deleteOne({ _id });
    return true;
  } catch (error) {
    throw new Error(`Failed to delete line: ${error}`);
  }
};

module.exports = {
  // line
  createLine,
  findAllLines,
  findLineById,
  updateLine,
  deleteLine,
};
