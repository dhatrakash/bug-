const socketIo = require('socket.io');
const controllerService = require('./controller.services');
const cors = require('cors');
const moment = require('moment');

module.exports = (server) => {
  const corsOptions = {
    origin: 'http://localhost:3001', // Adjust this to match your frontend's origin
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true,
  };
  const io = socketIo(server, {
    cors: corsOptions,
  });

  io.on('connection', (socket) => {
    console.log(`User connected: Socket ID - ${socket.id}`);

    socket.on('disconnect', () => {
      console.log(`User disconnected: Socket ID - ${socket.id}`);
    });

    socket.on('disconnectRequest', () => {
      console.log(`Received disconnect request from: ${socket.id}`);
      socket.disconnect(true); // Disconnect the socket
    });

    socket.on('allMachineOee', async (requestData) => {
      try {
        console.log(`Received 'allMachineOee' event from Socket ID - ${socket.id}`);
        const { startDate, endDate, interval } = requestData;
        const results = await controllerService.allMachineOEE(startDate, endDate, interval);
        socket.emit('allMachineOEE', results);
      } catch (e) {
        console.error('Error in allMachineOEE: ', e);
        socket.emit('allMachineOEEError', 'Failed to fetch OEE data');
      }
    });

    socket.on('partProduce', async (requestData) => {
      try {
        console.log(`Received 'partProduce' event from Socket ID - ${socket.id}`);
        const { interval, date } = requestData;
        console.log('date ' + date);
        console.log('interval ' + interval);
        const data = await controllerService.partProduce(interval, date);
        socket.emit('partProduce', data);
      } catch (e) {
        console.error('Error in partProduce: ', e);
        socket.emit('partProduceError', 'Failed to fetch part produce data');
      }
    });

    socket.on('machineSpecificData', async (requestData) => {
      try {
        console.log(`Received 'machineSpecificData' event from Socket ID - ${socket.id}`);

        const { startDate, endDate, interval, machineName } = requestData;

        setInterval(async () => {
          let endDate = moment();
          let startDate = moment().subtract(24, 'hour').format('YYYY-MM-DD HH:mm:ss');

          endDate = moment().format('YYYY-MM-DD HH:mm:ss');

          const results = await controllerService.machineSpecificData(startDate, endDate, interval, machineName);

          socket.emit('machineSpecificData', results);
        }, 3000);
      } catch (e) {
        console.error('Error in machineSpecificData: ', error);
        socket.emit('machineSpecificDataError', 'Failed to fetch machine-specific data');
      }
    });

    socket.on('compareOeeData', async (requestData) => {
      const { startDate, endDate, interval, machineName } = requestData;

      try {
        console.log(`Received 'compareOeeData' event from Socket ID - ${socket.id}`);

        setInterval(async () => {
          let endDate = moment();
          let startDate = moment().subtract(48, 'hour').format('YYYY-MM-DD HH:mm:ss');
          endDate = moment().format('YYYY-MM-DD HH:mm:ss');
          const results = await controllerService.machineSpecificData(startDate, endDate, interval, machineName);
          socket.emit('compareOeeData', results);
        }, 5000);
      } catch (e) {
        console.error('Error in partProduce: ', e);
        socket.emit('partProduceError', 'Failed to fetch part produce data');
      }
    });
  });
};
