// machineId => get all sensor mappings
const Hardware = require('../models/hardware.model');

const test = async (startDate, endDate) => {
  const data = {
    machineON: 0,
    cycleON: 0,
    spindleON: 0,
    partCount: 0,
  };

  const pipeline = [
    {
      $match: {
        'data.dtm': {
          $gte: startDate,
          $lte: endDate,
        },
        'data.mac': '608A10B603EC',
      },
    },
    {
      $facet: {
        idle_time: [
          {
            $match: {
              $or: [
                { 'data.io.di1': 0 },
                {
                  'data.modbus': {
                    $elemMatch: {
                      di5: 0,
                      sid: 50,
                    },
                  },
                },
              ],
            },
          },
          {
            $group: {
              _id: null,
              downtime: { $sum: 1 },
            },
          },
          {
            $project: {
              _id: 0,
              downtime: 1,
            },
          },
        ],
        production_time: [
          {
            $match: {
              'data.io.di1': 1,
              'data.modbus': {
                $elemMatch: {
                  di5: 1,
                },
              },
            },
          },
          {
            $group: {
              _id: null,
              uptime: { $sum: 1 },
            },
          },
          {
            $project: {
              _id: 0,
              uptime: 1,
            },
          },
        ],
        totalTime: [
          {
            $group: {
              _id: null,
              totalTime: { $sum: 1 },
            },
          },
          {
            $project: {
              _id: 0,
              totalTime: 1,
            },
          },
        ],
        product_count: [
          {
            $match: {
              'data.io.di2': 1,
            },
          },
          {
            $group: {
              _id: null,
              product_count: { $sum: 1 },
            },
          },
          {
            $project: {
              _id: 0,
              product_count: 1,
            },
          },
        ],
      },
    },
  ];

  const result = await Hardware.aggregate(pipeline);

  data.machineON = result[0].totalTime[0].totalTime;
  data.cycleON = result[0].production_time[0].uptime;
  data.spindleON = result[0].idle_time[0].downtime;
  data.partCount = result[0].product_count[0].product_count;

  return data;
};

// test('2022-09-01T00:00:00Z','2023-10-03T00:00:00Z');
