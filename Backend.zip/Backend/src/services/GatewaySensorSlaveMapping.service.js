const GatewaySensorAssociation = require('../models/GatewaySensorAssociation.model');

// Create a new GatewaySensorAssociation
const createGatewaySensorAssociation = async (associationData) => {
  try {
    const oldRecord = await GatewaySensorAssociation.findOne({
      gatewayId: associationData.gatewayId,
      slaveId: associationData.slaveId,
      tag: associationData.tag,
      deletedAt: null,
    });
    if (oldRecord) {
      return {
        error: `this association already exists please update it or create new combination of gateway, slave and tag`,
      };
    }
    const newAssociation = new GatewaySensorAssociation(associationData);
    const savedAssociation = await newAssociation.save();
    return savedAssociation;
  } catch (error) {
    throw new Error(`Failed to create GatewaySensorAssociation: ${error}`);
  }
};

const createMultipleAssociations = async (gatewayId, slaveId, associationData) => {
  try {
    const createdAssociations = [];

    // Use a for...of loop to work with async/await inside forEach
    // eslint-disable-next-line no-restricted-syntax
    for (const data of associationData) {
      // eslint-disable-next-line no-await-in-loop
      const oldRecord = await GatewaySensorAssociation.findOne({
        gatewayId,
        slaveId,
        tag: data.tag,
        deletedAt: null,
      });

      if (oldRecord) {
        return {
          error: `This association already exists. Please update it or create a new combination of gateway, slave, and tag.`,
        };
      }

      const newAssociation = new GatewaySensorAssociation({
        gatewayId,
        slaveId,
        sensorId: data.sensorId,
        sensorNodeName: data.sensorNodeName,
        tag: data.tag,
      });

      // eslint-disable-next-line no-await-in-loop
      const savedAssociation = await newAssociation.save();
      createdAssociations.push(savedAssociation);
    }
    return createdAssociations;
  } catch (error) {
    throw new Error(`Failed to create multiple associations: ${error}`);
  }
};

// Get a GatewaySensorAssociation by ID
const getGatewaySensorAssociationById = async (mappingId) => {
  try {
    const association = await GatewaySensorAssociation.findOne({ mappingId }).populate('sensorId').populate('gatewayId');
    if (!association) {
      throw new Error('GatewaySensorAssociation not found');
    }
    return association;
  } catch (error) {
    throw new Error(`Failed to get GatewaySensorAssociation: ${error.message}`);
  }
};

const findMappingByGatewayId = async (gatewayId) => {
  try {
    const association = await GatewaySensorAssociation.find({ gatewayId }).populate('sensorId');
    if (!association[0]) {
      throw new Error('GatewaySensorAssociation not found');
    }
    return association;
  } catch (error) {
    throw new Error(`Failed to get GatewaySensorAssociation: ${error.message}`);
  }
};

const findMappingBySlaveId = async (gatewayId, slaveId) => {
  try {
    const association = await GatewaySensorAssociation.find({ gatewayId, slaveId });
    if (!association) {
      throw new Error('GatewaySensorAssociation not found');
    }
    return association;
  } catch (error) {
    throw new Error(`Failed to get GatewaySensorAssociation: ${error.message}`);
  }
};

const findMappingByTag = async (gatewayId, slaveId, tag) => {
  try {
    const association = await GatewaySensorAssociation.findOne({ gatewayId, slaveId, tag });
    if (!association) {
      throw new Error('GatewaySensorAssociation not found');
    }
    return association;
  } catch (error) {
    throw new Error(`Failed to get GatewaySensorAssociation: ${error.message}`);
  }
};

// Update a GatewaySensorAssociation by ID
const updateGatewaySensorAssociationById = async (mappingId, updatedData) => {
  try {
    const association = await GatewaySensorAssociation.findOneAndUpdate({ mappingId }, updatedData, { new: true });
    if (!association) {
      throw new Error('GatewaySensorAssociation not found');
    }
    return association;
  } catch (error) {
    throw new Error(`Failed to update GatewaySensorAssociation: ${error.message}`);
  }
};

// Delete a GatewaySensorAssociation by ID
const deleteGatewaySensorAssociationById = async (mappingId) => {
  try {
    const association = await GatewaySensorAssociation.findOneAndRemove({ mappingId });
    if (!association) {
      return { 'Error ': 'Not Gateway-Sensor-Associations found here' };
    }
    return association;
  } catch (error) {
    throw new Error(`Failed to delete GatewaySensorAssociation: ${error.message}`);
  }
};

// Get all GatewaySensorAssociations
const getAllGatewaySensorAssociations = async () => {
  try {
    const associations = await GatewaySensorAssociation.find();
    return associations;
  } catch (error) {
    throw new Error(`Failed to get GatewaySensorAssociations: ${error.message}`);
  }
};

const softDeleteAssociations = async (mappingId) => {
  try {
    const associations = await GatewaySensorAssociation.findOne({ mappingId });
    associations.deletedAt = Date.now();
    return await associations.save();
  } catch (error) {
    throw new Error(`Failed to soft Delete GatewaySensorAssociations: ${error.message}`);
  }
};

const softDeleteByTag = async (gatewayId, slaveId, tag) => {
  try {
    const associations = await GatewaySensorAssociation.findOne({ gatewayId, slaveId, tag });
    associations.deletedAt = Date.now();
    return await associations.save();
  } catch (error) {
    throw new Error(`Failed to soft Delete GatewaySensorAssociations: ${error.message}`);
  }
};

const softDeleteBySlaveId = async (gatewayId, slaveId) => {
  try {
    const currentDate = new Date();
    const query = { slaveId, gatewayId, deletedAt: null };
    const existingDocs = await GatewaySensorAssociation.find(query);

    if (existingDocs.length === 0) {
      return { nModified: 0 }; // No documents found to update
    }

    const updateOperation = { $set: { deletedAt: currentDate } };
    const result = await GatewaySensorAssociation.updateMany(query, updateOperation);
    return result;
  } catch (error) {
    throw new Error(`Failed to soft Delete slaves in GatewaySensorAssociations: ${error}`);
  }
};

const softDeleteBySensorId = async (sensorId) => {
  try {
    const currentDate = new Date();
    const query = { sensorId, deletedAt: null };
    const updateOperation = { $set: { deletedAt: currentDate } };
    const result = await GatewaySensorAssociation.updateMany(query, updateOperation);
    return result;
  } catch (error) {
    throw new Error(`Failed to soft delete GatewaySensorAssociations: ${error}`);
  }
};

const softDeleteByGatewayId = async (gatewayId) => {
  try {
    const currentDate = new Date();
    const query = { gatewayId, deletedAt: null };
    const updateOperation = { $set: { deletedAt: currentDate } };
    const result = await GatewaySensorAssociation.updateMany(query, updateOperation);
    return result;
  } catch (error) {
    throw new Error(`Failed to soft delete GatewaySensorAssociations: ${error}`);
  }
};
module.exports = {
  createGatewaySensorAssociation, // create one
  createMultipleAssociations, // create multiple
  getAllGatewaySensorAssociations, // find all
  getGatewaySensorAssociationById, // find by mapping Id
  findMappingByGatewayId, // find by gatewayId
  findMappingBySlaveId, // find by slaveId
  findMappingByTag, // find by tag
  updateGatewaySensorAssociationById, // update by mappingId
  deleteGatewaySensorAssociationById, // delete by mappingId
  softDeleteAssociations, // soft delete by mappingId
  softDeleteBySlaveId, // soft delete by slaveId-gatewayId
  softDeleteBySensorId, // soft delete by sensorId (delete all which are mapping related to sensor regardless of it's gateway or slaves)
  softDeleteByTag, // soft delete specific sensor with tag slave gatewayId
  softDeleteByGatewayId, // soft delete all mapping by gatewayId when deleting gateway
};
