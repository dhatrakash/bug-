const moment = require('moment');
const Fanuc = require('../models/fanuc.mqtt.model');

const findAllDataByMachineName = async (machineName, hours) => {
  const startTime = moment().subtract(hours, 'hours').valueOf();

  const result = await Fanuc.aggregate([
    {
      $match: {
        'observation.machine': machineName,
        'observation.time': { $gte: startTime },
      },
    },
  ]);
  return result;
};

const findMachineList = async () => {
  try {
    const machines = await Fanuc.aggregate([
      {
        $group: { _id: '$observation.machine' },
      },
      {
        $project: {
          _id: 0,
          machineName: '$_id',
        },
      },
    ]);
    machines.shift();
    return machines;
  } catch (error) {
    throw new Error(`Failed find machine list ${error} `);
  }
};


// const findSweepData = async (machineName, hours) => {
//   const startTime = moment().subtract(hours, 'hours').valueOf();

//   const name = 'sweep';
//   const pipeline = [
//     {
//       $match: {
//         'observation.name': name,
//         'observation.machine': machineName,
//         'observation.time': {
//           $gte: startTime,
//         },
//       },
//     },
//     {
//       $project: {
//         _id: 0,
//         time: '$observation.time',
//         sweep: '$state.data.online',
//       },
//     },
//   ];
//   const result = await Fanuc.aggregate(pipeline);
//   const uniqueTimesSet = new Set();
//   const uniqueResult = result.filter((item) => {
//     const isUnique = !uniqueTimesSet.has(item.time);
//     uniqueTimesSet.add(item.time);
//     return isUnique;
//   });

//   return uniqueResult;
//   // return result;
// };
// const getRawUptimeFeedData = async (machineName, hours) => {
//   const startTime = moment().subtract(hours, 'hours').valueOf();

//   const name = 'state';
//   const pipeline = [
//     {
//       $match: {
//         'observation.machine': machineName,
//         'observation.time': {
//           $gte: startTime,
//           // $lt: endTime,
//         },
//         'observation.name': name,
//       },
//     },
//     {
//       $unwind: '$observation.marker',
//     },
//     {
//       $project: {
//         _id: 0,
//         spindle: '$observation.marker.number',
//         time: '$observation.time',
//         run: '$state.data.run',
//         feed: '$state.data.override.feed',
//       },
//     },
//     {
//       $group: {
//         _id: '$time',
//         spindle: { $first: '$spindle' },
//         run: { $first: '$run' },
//         feed: { $first: '$feed' },
//       },
//     },
//     {
//       $sort: {
//         _id: 1,
//       },
//     },
//     {
//       $project: {
//         _id: 0,
//         spindle: 1,
//         time: '$_id',
//         run: 1,
//         feed: 1,
//         sweep: { $literal: true },
//       },
//     },
//   ];
//   const result = await Fanuc.aggregate(pipeline);
//   return result;
//   // if (result.length < 1) return result;
//   // let mergedResult = [...result];
//   // if (result[0].time !== startTime) {
//   //   result.unshift({
//   //     time: startTime,
//   //     run: result[0].run,
//   //     spindle: result[0].spindle,
//   //     feed: result[0].feed,
//   //   });
//   // }
//   // result.forEach((document, index) => {
//   //   if (index + 1 < result.length) {
//   //     const currentDate = document.time;
//   //     const nextDate = result[index + 1].time;
//   //     const diffTime = (nextDate - currentDate) / 1000;
//   //     const dataGenerated = [];
//   //     if (diffTime < 3000) {
//   //       let newDtm = document.time;
//   //       for (let i = 0; i <= diffTime - 2; i++) {
//   //         newDtm += 1000;
//   //         dataGenerated.push({
//   //           spindle: document.spindle,
//   //           feed: document.feed,
//   //           run: document.run,
//   //           time: newDtm,
//   //         });
//   //       }
//   //     }
//   //     if (dataGenerated.length >= 1) {
//   //       mergedResult = [...dataGenerated, ...mergedResult];
//   //     }
//   //   }
//   // });
//   // mergedResult.sort((a, b) => (a.time > b.time ? 1 : -1));
//   // // console.log(mergedResult);
//   // return mergedResult;
// };
const getRawUptimeFeedData = async (machineName, hours) => {
  const startTime = moment().subtract(hours, 'hours').valueOf();

  const name = 'state';
  const pipeline = [
    {
      $match: {
        'observation.machine': machineName,
        'observation.time': {
          $gte: startTime,
          // $lt: endTime,
        },
        'observation.name': name,
      },
    },
    {
      $unwind: '$observation.marker',
    },
    {
      $project: {
        _id: 0,
        spindle: '$observation.marker.number',
        time: '$observation.time',
        run: '$state.data.run',
        feed: '$state.data.override.feed',
      },
    },
    {
      $group: {
        _id: '$time',
        spindle: { $first: '$spindle' },
        run: { $first: '$run' },
        feed: { $first: '$feed' },
      },
    },
    {
      $sort: {
        _id: 1,
      },
    },
    {
      $project: {
        _id: 0,
        spindle: 1,
        time: '$_id',
        run: 1,
        feed: 1,
      },
    },
  ];
  let result = await Fanuc.aggregate(pipeline);
  result.sort((a, b) => (a.time > b.time ? 1 : -1));
  return result;
};

const processUptimeFeedData = (rawData) => {
  let spindle1Productive = false;
  let spindle2Productive = false;
  let spindle1Maintenance = false;
  let spindle2Maintenance = false;

  for (let i = rawData.length - 1; i >= 0; i--) {
    const data = rawData[i];

    if (data.spindle === 1) {
      spindle1Productive = data.run === 3;
      spindle1Maintenance = data.run === 1;
    }

    if (data.spindle === 2) {
      spindle2Productive = data.run === 3;
      spindle2Maintenance = data.run === 1;
    }

    if (spindle1Productive || spindle2Productive) {
      data.run = 3;
    } else if (!spindle1Productive && !spindle2Productive && !spindle2Maintenance && !spindle1Maintenance) {
      data.run = 0;
    } else if (spindle1Maintenance || spindle2Maintenance) {
      data.run = 1;
    }
  }

  return rawData;
};

// const findUptimeFeedByHour = async (machineName, hours) => {
//   const rawUptimeFeedData = await getRawUptimeFeedData(machineName, hours);
//   let processedUptimeFeedData = processUptimeFeedData(rawUptimeFeedData);
//   const sweepData = await findSweepData(machineName, hours);
//   const feedMappings = {
//     mahabal1: {
//       255: 0,
//       245: 10,
//       235: 20,
//       225: 30,
//       215: 40,
//       205: 50,
//       195: 60,
//       185: 70,
//       175: 80,
//       165: 90,
//       155: 100,
//     },
//     sanmati_vmc03: {
//       255: 0,
//       245: 10,
//       235: 20,
//       225: 30,
//       215: 40,
//       205: 50,
//       195: 60,
//       185: 70,
//       175: 80,
//       165: 90,
//       155: 100,
//     },
//   };
//   if (feedMappings[machineName]) {
//     const currentFeedMapping = feedMappings[machineName];
//     processedUptimeFeedData = processedUptimeFeedData.map((data) => ({
//       ...data,
//       feed: currentFeedMapping[data.feed] !== undefined ? currentFeedMapping[data.feed] : data.feed,
//     }));
//   }
//   const mergedData = [...processedUptimeFeedData];
//   for (let i = 0; i < sweepData.length; i += 1) {
//     const sweepItem = sweepData[i];
//     const isUniqueTime = mergedData.every((mergedItem) => mergedItem.time !== sweepItem.time);
//     if (isUniqueTime) {
//       mergedData.push(sweepItem);
//     }
//   }
//   mergedData.sort((a, b) => (a.time > b.time ? 1 : -1));
//   const finalResult = [];
//   for (let i = 0; i < mergedData.length; i += 1) {
//     mergedData[i].time = moment(mergedData[i].time).format('YYYY-MM-DD HH:mm:ss');
//     // uncomment this if you want old data of feed run spindle in the sweep objects
//     if (!mergedData[i].feed && mergedData[i - 1]) {
//       mergedData[i].feed = mergedData[i - 1].feed;
//       mergedData[i].spindle = mergedData[i - 1].spindle;
//       mergedData[i].run = mergedData[i - 1].run;
//     }
//     if(mergedData[i].feed){
//       finalResult.push(mergedData[i]);
//     }

//   }
//   return finalResult;
// };
const findUptimeFeedByHour = async (machineName, hours) => {
  const rawUptimeFeedData = await getRawUptimeFeedData(machineName, hours);
  let processedUptimeFeedData = processUptimeFeedData(rawUptimeFeedData);
  const feedMappings = {
    mahabal1: {
      255: 0,
      245: 10,
      235: 20,
      225: 30,
      215: 40,
      205: 50,
      195: 60,
      185: 70,
      175: 80,
      165: 90,
      155: 100,
    },
  };
  if (feedMappings[machineName]) {
    const currentFeedMapping = feedMappings[machineName];
    processedUptimeFeedData = processedUptimeFeedData.map((data) => ({
      ...data,
      feed: currentFeedMapping[data.feed] !== undefined ? currentFeedMapping[data.feed] : data.feed,
    }));
  }

  const formattedData = processedUptimeFeedData.map((data) => ({
    ...data,
    time: moment(data.time).format('YYYY-MM-DD HH:mm:ss'),
  }));
  console.log(formattedData)
  return formattedData;
  console.log(processedUptimeFeedData)
  return processedUptimeFeedData;
};

// const findDataByName = async (machineName, topicName, hours) => {
//   const startTime = moment().subtract(hours, 'hours').valueOf();
  
//   // Fetch the primary data based on the topicName.
//   const result = await Fanuc.aggregate([
//     {
//       $match: {
//         'observation.machine': machineName,
//         'observation.time': { $gte: startTime },
//         'observation.name': topicName,
//       },
//     },
//     {
//       $project: {
//         _id : 0,
//         time: '$observation.time',  
//         formattedTime: {
//           $dateToString: {
//             format: '%Y-%m-%d %H:%M:%S',
//             date: {
//               $add: [
//                 {
//                   $toDate: '$observation.time'
//                 },
//                 5 * 60 * 60 * 1000, 
//                 30 * 60 * 1000      
//               ]
//             }
//           }
//         },
//         partName: '$state.data.program.current.comment',
//       }
//     }
//   ]);

  
//   const sweepData = await findSweepData(machineName, hours);


//   const mergedData = [...result];
//   for (let i = 0; i < sweepData.length; i += 1) {
//     const sweepItem = sweepData[i];
//     const isUniqueTime = mergedData.every((mergedItem) => mergedItem.time !== sweepItem.time);
//     if (isUniqueTime) {
//       mergedData.push({ ...sweepItem, formattedTime: moment(sweepItem.time).format('YYYY-MM-DD HH:mm:ss') });
//     }
//   }

//   mergedData.sort((a, b) => (a.time > b.time ? 1 : -1));

  
//   const finalResult = mergedData.map(item => ({
//     ...item,
//     time: item.formattedTime || moment(item.time).format('YYYY-MM-DD HH:mm:ss'),
//     sweep: item.sweep !== undefined ? item.sweep : null, 
//   }));

//   return finalResult;
// };
const findDataByName = async (machineName, topicName, hours) => {
  const startTime = moment().subtract(hours, 'hours').valueOf();
  
  const result = await Fanuc.aggregate([
    {
      $match: {
        'observation.machine': machineName,
        'observation.time': { $gte: startTime },
        'observation.name': topicName,
      },
    },
    {
      $project: {
        _id : 0,
        time: {
          $dateToString: {
            format: '%Y-%m-%d %H:%M:%S', // Specify the desired format here
            date: {
              $add: [
                {
                  $toDate: '$observation.time'
                },
                5 * 60 * 60 * 1000, // 5 hours in milliseconds
                30 * 60 * 1000      // 30 minutes in milliseconds
              ]
            }
          }
        },
        partName: '$state.data.program.current.comment'
      }
    }
  ]);

  return result;
};

const partNameByHours = async (machineName, hours) => {
  const startTime = moment().subtract(hours, 'hours').valueOf();
  const name = 'production';
  const pipeline = [
    {
      $match: {
        'observation.machine': machineName,
        'observation.time': {
          $gte: startTime,
        },
        'observation.name': name,
      },
    },
    {
      $project: {
        _id: 0,
        time: '$observation.time',
        partName: '$state.data.program.current.comment',
      },
    },
    {
      $sort: {
        time: 1,
      },
    },
  ];

  const foundData = await Fanuc.aggregate(pipeline);
  return foundData;
};
const latestCriticalData = async () => {
  try {
    const startTime = moment().subtract(29, 'hours').valueOf();
    const pipeline = [
      {
        $match: {
          'observation.name': 'alarms',
          'observation.time': {
            $gte: startTime,
          },
        },
      },
      {
        $unwind: '$state.data.alarms',
      },
      {
        $project: {
          _id: 0,
          type: '$observation.name',
          documentTs: '$observation.time',
          machineName: '$observation.machine',
          message: '$state.data.alarms.message',
          timeTriggered: '$state.data.alarms.time_triggered',
          timeCleared: '$state.data.alarms.time_cleared',
          timeElapsed: '$state.data.alarms.time_elapsed',
          isTriggered: '$state.data.alarms.is_triggered',
          triggerCount: '$state.data.alarms.trigger_count',
        },
      },
      {
        $sort: {
          documentTs: -1,
        },
      },
      {
        $group: {
          _id: { message: '$message', machineName: '$machineName' },
          latestRecord: { $first: '$$ROOT' },
        },
      },

      {
        $replaceRoot: { newRoot: '$latestRecord' },
      },
      {
        $match: {
          isTriggered: true,
        },
      },
      {
        $project: {
          _id: 0,
        },
      },
    ];
    const pipeline2 = [
      {
        $match: {
          'observation.name': 'messages',
          'observation.time': {
            $gte: startTime,
          },
        },
      },
      {
        $unwind: '$state.data.messages',
      },
      {
        $project: {
          _id: 0,
          type: '$observation.name',
          documentTs: '$observation.time',
          machineName: '$observation.machine',
          message: '$state.data.messages.message',
          timeTriggered: '$state.data.messages.time_triggered',
          timeElapsed: '$state.data.messages.time_elapsed',
          isTriggered: '$state.data.messages.is_triggered',
          triggerCount: '$state.data.messages.trigger_count',
        },
      },
      {
        $sort: {
          documentTs: -1,
        },
      },
      {
        $group: {
          _id: { message: '$message', machineName: '$machineName' },
          latestRecord: { $first: '$$ROOT' },
        },
      },
      {
        $replaceRoot: { newRoot: '$latestRecord' },
      },
      {
        $match: {
          isTriggered: true,
        },
      },
      {
        $project: {
          _id: 0,
        },
      },
    ];
    const alarms = await Fanuc.aggregate(pipeline);
    const messages = await Fanuc.aggregate(pipeline2);
    const result = [...alarms, ...messages];
    return result;
  } catch (error) {
    throw new Error(`Failed to find the data Server Error: ${error}`);
  }
};

const totalAlarmsByHours = async (machineName) => {
  try {
    const result = [];
    for (let i = 24; i > 0; i -= 1) {
      const startTime = moment().subtract(i, 'hours').valueOf();
      const endTime = moment()
        .subtract(i - 1, 'hours')
        .valueOf();
      const pipeLine = [
        {
          $match: {
            'observation.machine': machineName,
            'observation.time': {
              $gte: startTime,
              $lte: endTime,
            },
          },
        },
        {
          $unwind: '$state.data.alarms',
        },
        {
          $project: {
            _id: 0,
            type: '$observation.name',
            documentTs: '$observation.time',
            machineName: '$observation.machine',
            timeTriggered: '$state.data.alarms.time_triggered',
            isTriggered: '$state.data.alarms.is_triggered',
          },
        },
        {
          $match: {
            isTriggered: true,
          },
        },
        {
          $project: {
            _id: 0,
          },
        },
      ];
      const alarms = await Fanuc.aggregate(pipeLine);
      const data = {
        startTime,
        endTime,
        alarmCount: alarms.length,
      };
      result.push(data);
    }
    return result;
  } catch (error) {
    throw new Error(`Failed to find the data Server Error: ${error}`);
  }
};

module.exports = {
  findUptimeFeedByHour,
  partNameByHours,
  findDataByName,
  findAllDataByMachineName,
  findMachineList,
  latestCriticalData,
  totalAlarmsByHours,
};
