const Hardware = require('../models/hardware.model');
const moment = require('moment');


  const cycleCount = async (startDate,endDate) => {
  

    const data={
      productionTime:0,
      idealTime:0,
      totalTime:0,
      totalCount:0,
      availability:0,
      performance:0,
      quality:0,
    };
    
  const productionTime = [
    {
      $match: {
        'data.io.machine_status': 1, // Match documents with machine_status: 1
        'data.dtm': {
          $gte: startDate, 
          $lte: endDate, 
        },
      },
    },
    { $count: 'production_time' }, 
  ];

  data.productionTime = (await Hardware.aggregate(productionTime))[0].production_time;
  
  


  const idealTime = [
    {
      $match: {
        'data.io.machine_status': 0, // Match documents with machine_status: 1
        'data.dtm': {
          $gte: startDate, 
          $lte: endDate, 
        },
      },
    },
    { $count: 'ideal_time' }, 
  ];

  data.idealTime = (await Hardware.aggregate(idealTime))[0].ideal_time;
  

  const totalTime = [
    {
      $match: {
        'data.dtm': {
          $gte:startDate , 
          $lte:endDate, 
        },
      },
    },
    { $count: 'total_Time' }, 
  ];

  data.totalTime = (await Hardware.aggregate(totalTime))[0].total_Time;

  const totalCount = [
    {
      $match: {
        'data.io.cycle': 1,
        'data.dtm': {
          $gte: startDate, 
          $lte: endDate, 
        },
      },
    },
    {
      $group: {
        _id: '$data.mac', // Group by the MAC address
        total_count: { $sum: 1 }, // Count the documents for each machine
      },
    }, 
    {
      $project: {
        _id: 0,
        mac: '$_id', // Rename _id to mac
        total_count: 1,
      },
    },
  ];

  data.totalCount = (await Hardware.aggregate(totalCount));
 
  const availability=[
    {
      $match: {
        'data.dtm': {
          $gte: startDate,
          $lte: endDate,
        },
      },
    },
    {
      $group: {
        _id: null,
        total_time: { $sum: 1 }, // Calculate total time as the count of matching documents
        production_time: {
          $sum: {
            $cond: [
              { $eq: ['$data.io.machine_status', 1] }, // Check if machine_status is 1
              1, // Add 1 to the sum if true
              0, // Add 0 to the sum if false
            ],
          },
        },
      },
    },
    {
      $project: {
        _id: 0,
        availability: {
          $cond: [
            { $eq: ['$total_time', 0] }, // Check if total_time is 0 to avoid division by zero
            0, // Set availability to 0 if true
            {$round:[{ $divide: ['$production_time', '$total_time'] },3]}, // Calculate availability
          ],
        },
      },
    },
  ];

  data.availability = (await Hardware.aggregate(availability))[0].availability;



  const performance=[
    {
      $match: {
        'data.dtm': {
          $gte: startDate,
          $lte: endDate,
        },
      },
    },
    {
      $group: {
        _id: null,
       production_time: {
          $sum: {
            $cond: [
              { $eq: ['$data.io.machine_status', 1] }, // Check if machine_status is 1
              1, // Add 1 to the sum if true
              0, // Add 0 to the sum if false
            ],
          },
        },
        totalCount:{
          $sum:{
            $cond:[
              {
                $eq:['$data.io.cycle',1]
              },
              1,
              0,
            ],
          },
        },
      },
    },
    {
      $project: {
        _id: 0,
        perfomance: {
          $cond: [
            { $eq: ['$production_time', 0] }, // Check if total_time is 0 to avoid division by zero
            0, // Set availability to 0 if true
            {$round:[{ $divide: [{$multiply:[20,'$totalCount']}, '$production_time'] },3]}, // Calculate availability
          ],
        },
      },
    },
  ];

  data.performance = (await Hardware.aggregate(performance))[0].perfomance;

  const quality=[
    {
      $match: {
        'data.dtm': {
          $gte: startDate,
          $lte: endDate,
        },
      },
    },
    {
      $group: {
        _id: null,
        
        totalCount:{
          $sum:{
            $cond:[
              {
                $eq:['$data.io.cycle',1]
              },
              1,
              0,
            ],
          },
        },
      },
    },
    {
      $project: {
        _id: 0,
        quality: {
          $cond: [
            { $eq: ['$production_time', 0] }, // Check if total_time is 0 to avoid division by zero
            0, // Set availability to 0 if true
            {$round :[{ $divide: [{$subtract:['$totalCount',0]}, '$totalCount'] },3]}, 
          ],
        },
      },
    },
  ];

  data.quality = (await Hardware.aggregate(quality))[0].quality;

  return data;

  
  
};

const oeeOfSelctedMachine = async (startDate,endDate,mac) => {
  

  const data={
    productionTime:0,
    idealTime:0,
    totalCount:0,
    availability:0,
    performance:0,
    quality:0,
  };
  
const productionTime = [
  {
    $match: {
      'data.io.machine_status': 1, // Match documents with machine_status: 1
      'data.mac': mac,
      'data.dtm': {
        $gte: startDate, 
        $lte: endDate, 
      },
    },
  },
  { $count: 'production_time' }, 
];

data.productionTime = (await Hardware.aggregate(productionTime))[0].production_time;




const idealTime = [
  {
    $match: {
      'data.io.machine_status': 0, // Match documents with machine_status: 1
      'data.mac': mac,
      'data.dtm': {
        $gte: startDate, 
        $lte: endDate, 
      },
    },
  },
  { $count: 'ideal_time' }, 
];

data.idealTime = (await Hardware.aggregate(idealTime))[0].ideal_time;


const totalCount = [
  {
    $match: {
      'data.io.cycle': 1,
      'data.mac': mac,
      'data.dtm': {
        $gte: startDate, 
        $lte: endDate, 
      },
    },
  },
  { $count: 'total_count' }, 
];

data.totalCount = (await Hardware.aggregate(totalCount))[0].total_count;

const availability=[
  {
    $match: {
      'data.mac': mac,
      'data.dtm': {
        $gte: startDate,
        $lte: endDate,
      },
    },
  },
  {
    $group: {
      _id: null,
      total_time: { $sum: 1 }, // Calculate total time as the count of matching documents
      production_time: {
        $sum: {
          $cond: [
            { $eq: ['$data.io.machine_status', 1] }, // Check if machine_status is 1
            1, // Add 1 to the sum if true
            0, // Add 0 to the sum if false
          ],
        },
      },
    },
  },
  {
    $project: {
      _id: 0,
      availability: {
        $cond: [
          { $eq: ['$total_time', 0] }, // Check if total_time is 0 to avoid division by zero
          0, // Set availability to 0 if true
          {$round:[{ $divide: ['$production_time', '$total_time'] },3]}, // Calculate availability
        ],
      },
    },
  },
];

data.availability = (await Hardware.aggregate(availability))[0].availability;



const performance=[
  {
    $match: {
      'data.mac': mac,
      'data.dtm': {
        $gte: startDate,
        $lte: endDate,
      },
    },
  },
  {
    $group: {
      _id: null,
     production_time: {
        $sum: {
          $cond: [
            { $eq: ['$data.io.machine_status', 1] }, // Check if machine_status is 1
            1, // Add 1 to the sum if true
            0, // Add 0 to the sum if false
          ],
        },
      },
      totalCount:{
        $sum:{
          $cond:[
            {
              $eq:['$data.io.cycle',1]
            },
            1,
            0,
          ],
        },
      },
    },
  },
  {
    $project: {
      _id: 0,
      perfomance: {
        $cond: [
          { $eq: ['$production_time', 0] }, // Check if total_time is 0 to avoid division by zero
          0, // Set availability to 0 if true
          {$round:[{ $divide: [{$multiply:[20,'$totalCount']}, '$production_time'] },3]}, // Calculate availability
        ],
      },
    },
  },
];

data.performance = (await Hardware.aggregate(performance))[0].perfomance;

const quality=[
  {
    $match: {
      'data.mac': mac,
      'data.dtm': {
        $gte: startDate,
        $lte: endDate,
      },
    },
  },
  {
    $group: {
      _id: null,
      
      totalCount:{
        $sum:{
          $cond:[
            {
              $eq:['$data.io.cycle',1]
            },
            1,
            0,
          ],
        },
      },
    },
  },
  {
    $project: {
      _id: 0,
      quality: {
        $cond: [
          { $eq: ['$production_time', 0] }, // Check if total_time is 0 to avoid division by zero
          0, // Set availability to 0 if true
          {$round :[{ $divide: [{$subtract:['$totalCount',0]}, '$totalCount'] },3]}, 
        ],
      },
    },
  },
];

data.quality = (await Hardware.aggregate(quality))[0].quality;

return data;



};








module.exports = {
  cycleCount,
  oeeOfSelctedMachine,
};