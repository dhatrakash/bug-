const Shift = require('../models/shift.model');

const createShift = async (shiftData) => {
  try {
    return await Shift.create(shiftData);
  } catch (error) {
    throw new Error(`Failed to create shift: ${error.message}`);
  }
};

const findShiftById = async (id) => {
  try {
    const shift = await Shift.findOne({ shiftId: id });
    return shift;
  } catch (error) {
    throw new Error(`Failed to find shift: ${error.message}`);
  }
};
const findShifts = async () => {
  try {
    const shifts = await Shift.find();
    return shifts;
  } catch (error) {
    throw new Error(`Failed to find shifts: ${error.message}`);
  }
};

const updateShift = async (shiftId, updatedshiftData) => {
  try {
    const updatedShift = await Shift.findOneAndUpdate({ shiftId }, updatedshiftData, { new: true });
    return updatedShift;
  } catch (error) {
    throw new Error(`Failed to update Shift: ${error.message}`);
  }
};
const deleteShift = async (shiftId) => {
  try {
    const deletedShift = await Shift.findOneAndDelete({ shiftId });
    return deletedShift;
  } catch (error) {
    throw new Error(`Failed to delete shift: ${error.message}`);
  }
};

module.exports = {
  createShift,
  findShifts,
  findShiftById,
  updateShift,
  deleteShift,
};
