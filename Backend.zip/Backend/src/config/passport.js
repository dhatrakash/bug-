const { Strategy: JwtStrategy, ExtractJwt } = require('passport-jwt');
const config = require('./config');
const { tokenTypes } = require('./tokens');
const { User } = require('../models');
const { SuperAdmin } = require('../models');

const jwtOptions = {
  secretOrKey: config.jwt.secret,
  jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
};

const jwtVerify = async (payload, done) => {
  try {
    if (payload.type !== tokenTypes.ACCESS) {
      throw new Error('Invalid token type');
    }
    const user = await User.findById(payload.sub);
    if (!user) {
      return done(null, false);
    }
    done(null, user);
  } catch (error) {
    done(error, false);
  }
};

const jwtVerifyForSuperadmin = async (payload, done) => {
  try {
    // Ensure that the token type is ACCESS (or customize as needed)
    if (payload.type !== tokenTypes.ACCESS) {
      throw new Error('Invalid token type');
    }

    // Find a Superadmin based on the payload's subject (sub) field
    const superadmin = await SuperAdmin.findById(payload.sub);

    // If a Superadmin is found, return it
    if (superadmin) {
      done(null, superadmin);
    } else {
      // If not found, indicate that authentication failed
      done(null, false);
    }
  } catch (error) {
    done(error, false);
  }
};


const jwtVerifyUserAndSuperAdmin = async (payload, done) => {
  try {
    if (payload.type !== tokenTypes.ACCESS) {
      throw new Error('Invalid token type');
    }

    let user = await User.findById(payload.sub);

    if (!user) {
      user = await SuperAdmin.findById(payload.sub);
    }

    // console.log('Payload Sub:', payload.sub);
    // console.log('User:', user);

    if (!user) {
      return done(null, false);
    }
   
    done(null, user);
  } catch (error) {
    done(error, false);
  }
};

const jwtStrategy = new JwtStrategy(jwtOptions, jwtVerify);
const jwtStrategyForSuperadmin = new JwtStrategy(jwtOptions, jwtVerifyForSuperadmin);
const jwtStrategyForUserAndSuperAdmin = new JwtStrategy(jwtOptions, jwtVerifyUserAndSuperAdmin);

module.exports = {
  jwtStrategy,
  jwtStrategyForSuperadmin,
  jwtStrategyForUserAndSuperAdmin,
};
