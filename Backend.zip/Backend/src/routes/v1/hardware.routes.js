const express = require('express');
const hardwareController = require('../../controllers/hardware.controller');
const { hardwareValidation } = require('../../validations/index');
const validate = require('../../middlewares/validate');
const OeeAuth = require('../../middlewares/OeeAuth');

const router = express.Router();
// route for finding data from desired time span by post method
router.route('/send').post(validate(hardwareValidation.getDataByTimeFrame), hardwareController.getDataByTimeFrame);
// route for fetching data of part count of all machine.
router.route('/part').post(validate(hardwareValidation.partProduceTable), hardwareController.partProduceTable);
// route for fetching data of OEE,Parts Count,Performance Time,ideal time
router.route('/oeechart').post(validate(hardwareValidation.oeeChart), hardwareController.oeeChart);
// route for fetching data of OEE of all machine.
router.route('/companyoee').post(validate(hardwareValidation.companyOEE), OeeAuth,hardwareController.companyOEE);
// route for fetching data for pdf generation
router.route('/pdf').post(validate(hardwareValidation.pdfGenerator), hardwareController.pdfGenerator);
// route for fetching machine specific data
router.route('/report').post(validate(hardwareValidation.machineReport), hardwareController.machineReport);
// route for fetching data for kavitsu
router.route('/getpipelinedata').post(validate(hardwareValidation.getPipelineData), hardwareController.getPipelineData);
// route for adding hardware data to DB
router.post('/addhardwareData', hardwareController.createHardware);
// route for getting chartdata di1 aka machine_status
router.post('/chartData', hardwareController.getUptime);

router.post('/chartData', hardwareController.getUptime);

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: Hardware
 *   description: Hardware Data Operations
 */

/**
 * @swagger
 * /data/send:
 *   post:
 *     summary: Get Hardware Data by Time Frame
 *     tags: [Hardware]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               mac:
 *                 type: string
 *               hours:
 *                 type: integer
 *     responses:
 *       200:
 *         description: Matching Records from hardware-routes
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 foundData:
 *                   type: array
 *       500:
 *         description: An error occurred while fetching data.
 */

/**
 * @swagger
 * /data/send:
 *   get:
 *     summary: Get Hardware Data by Time Frame (Query Parameters)
 *     tags: [Hardware]
 *     parameters:
 *       - in: query
 *         name: mac
 *         schema:
 *           type: string
 *         required: true
 *         description: The MAC address to filter hardware data.
 *       - in: query
 *         name: hours
 *         schema:
 *           type: integer
 *         required: true
 *         description: The number of hours to look back in time.
 *     responses:
 *       200:
 *         description: Matching Records from hardware-routes
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 foundData:
 *                   type: array
 *       500:
 *         description: An error occurred while fetching data.
 */
