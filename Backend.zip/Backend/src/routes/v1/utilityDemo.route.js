const express = require('express');
const utilityDemoController = require('../../controllers/utilityDemo.controller');
const utilityDemoService = require('../../services/utilityDemo.service');
const router = express.Router();
const DashboardStatus = require('../../models/dashboardStatus.model');

router.post('/addutilityDemo', utilityDemoController.createUtilityDemo);
//send OTP
router.post('/send-otp', utilityDemoController.sendOtp);
//send CRM Update
router.post('/send-crm-update', utilityDemoController.sendCRMUpdate);
//verify OTP
router.post('/verify-otp', utilityDemoController.verifyOtp);
//add dashboard status
router.post('/addDashboardStatus', utilityDemoController.addDashboardStatus);
//get dashboard status
router.post('/dashboard-status', utilityDemoController.getDashboardStatus);

// router.post('/addDashboardStatus', async (req, res) => {
//   const { email } = req.body;

//   try {
//     // Find or create a dashboard status document
//     const currentTime = new Date();
//     const accessExpireTime = new Date(currentTime);
//     accessExpireTime.setDate(currentTime.getDate() + 1); // 1 day from the current time

//     // Find the existing document with the given email and update it, or create a new one
//     const statusDoc = await DashboardStatus.findOneAndUpdate(
//       { email },
//       {
//         email,
//         status: 1, // Initially set the status to 1
//         accessStartTime: currentTime,
//         accessExpireTime,
//       },
//       { upsert: true, new: true },
//     );

//     if (statusDoc) {
//       console.log('Dashboard status document updated or created:', statusDoc);
//       res.json({ message: 'Dashboard status updated successfully' });
//     } else {
//       console.log('Error updating dashboard status');
//       res.status(500).json({ error: 'Internal server error' });
//     }
//   } catch (error) {
//     console.error('Error updating dashboard status:', error);
//     res.status(500).json({ error: 'Internal server error' });
//   }
// });
// router.post('/dashboard-status', async (req, res) => {
//   const { email } = req.body;

//   try {
//     const statusDoc = await DashboardStatus.findOne({ email });

//     if (statusDoc) {
//       const currentTime = new Date();

//       console.log('Current Time:', currentTime);
//       console.log('Access Expire Time:', statusDoc.accessExpireTime);

//       // Check if the current time is greater than or equal to accessExpireTime
//       if (currentTime >= statusDoc.accessExpireTime) {
//         console.log('Status document found:', statusDoc);

//         // Update the status to 0 (contact us page)
//         await statusDoc.updateOne({ status: 0, lastUpdated: currentTime });
//         console.log('Dashboard status updated to 0');

//         return res.json({ message: 'Dashboard status updated successfully', status: 0 });
//       } else {
//         console.log('Status document found but not updated');
//         return res.status(200).json({ message: 'Dashboard status not updated', status: statusDoc.status });
//       }
//     } else {
//       console.log('Status document not found');
//       return res.status(200).json({ message: 'Dashboard status not found' });
//     }
//   } catch (error) {
//     console.error('Error getting dashboard status:', error);
//     return res.status(500).json({ error: 'Internal server error' });
//   }
// });

module.exports = router;
