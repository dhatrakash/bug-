const express = require('express');
const lineController = require('../../controllers/line.controller');

const router = express.Router();

router.post('/addline', lineController.createLine);
router.get('/findAllLines', lineController.findLines);
router.get('/findLineById/:lineId', lineController.findLineById);
router.put('/updateLine/:id', lineController.updateLine);
router.delete('/deleteLine/:lineId', lineController.deleteLine);

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: Lines
 *   description: API endpoints for managing lines
 */

/**
 * @swagger
 * /lines/addline:
 *   post:
 *     summary: Create a new line.
 *     tags: [Lines]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Line'
 *     responses:
 *       '201':
 *         description: Line created successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Line'
 *       '400':
 *         description: Bad request. Invalid input.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /lines/findAllLines:
 *   get:
 *     summary: Retrieve all lines.
 *     tags: [Lines]
 *     responses:
 *       '200':
 *         description: Successfully retrieved lines.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Line'
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /lines/findLineById/{lineId}:
 *   get:
 *     summary: Retrieve a line by ID.
 *     tags: [Lines]
 *     parameters:
 *       - in: path
 *         name: lineId
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the line to retrieve.
 *     responses:
 *       '200':
 *         description: Successfully retrieved the line.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Line'
 *       '404':
 *         description: Line not found.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /lines/updateLine/{id}:
 *   put:
 *     summary: Update a line by ID.
 *     tags: [Lines]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the line to update.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Line'
 *     responses:
 *       '200':
 *         description: Line updated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Line'
 *       '400':
 *         description: Bad request. Invalid input.
 *       '404':
 *         description: Line not found.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /lines/deleteLine/{lineId}:
 *   delete:
 *     summary: Delete a line by ID.
 *     tags: [Lines]
 *     parameters:
 *       - in: path
 *         name: lineId
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the line to delete.
 *     responses:
 *       '204':
 *         description: Line deleted successfully.
 *       '404':
 *         description: Line not found.
 *       '500':
 *         description: Internal server error.
 */
