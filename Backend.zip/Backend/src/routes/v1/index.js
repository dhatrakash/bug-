const express = require('express');
const authRoute = require('./auth.route');
const userRoute = require('./user.route');
const docsRoute = require('./docs.route');
const config = require('../../config/config');
const hardwareRoute = require('./hardware.routes');
const controllerRoute = require('./controller.route');
const superAdminRoute = require('./superAdmin.route');
const superAdminAuthRoute = require('./superAdminAuth.route');
const RoleRoute = require('./role.route');
const machineRoute = require('./machine.route');
const gatewayRoute = require('./gateway.routes');
const sensorRoute = require('./sensor.routes');
const fanucRoute = require('./fanuc.control.routes');
const gatewaySensorAssociationRoute = require('./gateway.sensor.association.routes');
const gatewayInputRoute = require('./gatewayInputs.routes');
const facilityRoute = require('./facility.route');
const cellRoute = require('./cell.route');
const layoutRoute = require('./layout.route');
const lineRoute = require('./line.route');
const machineMappings = require('./machineAssociation.route');
const hardwareDynamic = require('./hardwareDynamic.route');
const utilityDemoRoute = require('./utilityDemo.route');
const DowntimeReasonRoute = require('./downtimeReason.route');
const partcodeRoute = require('./partcode.route');
const shiftRoute = require('./shift.route');
const router = express.Router();

const defaultRoutes = [
  {
    path: '/auth',
    route: authRoute,
  },
  {
    path: '/users',
    route: userRoute,
  },
  {
    path: '/data',
    route: hardwareRoute,
  },
  {
    path: '/controllerdata',
    route: controllerRoute,
  },
  {
    path: '/superAdmins',
    route: superAdminRoute,
  },
  {
    path: '/superAdminAuth',
    route: superAdminAuthRoute,
  },
  {
    path: '/role',
    route: RoleRoute,
  },
  {
    path: '/machines',
    route: machineRoute,
  },
  {
    path: '/facilities',
    route: facilityRoute,
  },
  {
    path: '/cells',
    route: cellRoute,
  },
  {
    path: '/layouts',
    route: layoutRoute,
  },
  {
    path: '/lines',
    route: lineRoute,
  },
  {
    path: '/gateway',
    route: gatewayRoute,
  },
  {
    path: '/sensors',
    route: sensorRoute,
  },
  {
    path: '/fanuc',
    route: fanucRoute,
  },
  {
    path: '/associationGatewaySensor',
    route: gatewaySensorAssociationRoute,
  },
  {
    path: '/gatewayInputs',
    route: gatewayInputRoute,
  },
  {
    path: '/machineMappings',
    route: machineMappings,
  },
  {
    path: '/hardwaredynamic',
    route: hardwareDynamic,
  },
  {
    path: '/utilityDemo',
    route: utilityDemoRoute,
  },
  {
    path: '/downtimeReason',
    route: DowntimeReasonRoute,
  },
  {
    path: '/partCode',
    route: partcodeRoute,
  },
  {
    path: '/shifts',
    route: shiftRoute,
  },
];

const devRoutes = [
  // routes available only in development mode
  {
    path: '/docs',
    route: docsRoute,
  },
];

defaultRoutes.forEach((route) => {
  router.use(route.path, route.route);
});

/* istanbul ignore next */
if (config.env === 'development') {
  devRoutes.forEach((route) => {
    router.use(route.path, route.route);
  });
}

module.exports = router;
