const express = require('express');
const shiftController = require('../../controllers/shift.controller');

const router = express.Router();
router.post('/', shiftController.createShift);
router.get('/', shiftController.findShifts);
router.get('/:shiftId', shiftController.findShiftById);
router.put('/:shiftId', shiftController.updateShift);
router.delete('/:shiftId', shiftController.deleteShift);

module.exports = router;
