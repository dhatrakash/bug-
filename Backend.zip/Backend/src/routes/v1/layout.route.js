const express = require('express');
const layoutController = require('../../controllers/layout.controller');

const router = express.Router();

router.post('/addlayout', layoutController.createLayout);
router.get('/findAllLayouts', layoutController.findLayouts);
router.get('/findLayoutById/:layoutId', layoutController.findLayoutById);
router.put('/updateLayout/:id', layoutController.updateLayout);
router.delete('/deleteLayout/:layoutId', layoutController.deleteLayout);

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: Layouts
 *   description: API endpoints for managing layouts for machine locations
 */

/**
 * @swagger
 * /layouts/addlayout:
 *   post:
 *     summary: Create a new layout.
 *     tags: [Layouts]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Layout'
 *     responses:
 *       '201':
 *         description: Layout created successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Layout'
 *       '400':
 *         description: Bad request. Invalid input.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /layouts/findAllLayouts:
 *   get:
 *     summary: Retrieve all layouts.
 *     tags: [Layouts]
 *     responses:
 *       '200':
 *         description: Successfully retrieved layouts.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Layout'
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /layouts/findLayoutById/{layoutId}:
 *   get:
 *     summary: Retrieve a layout by ID.
 *     tags: [Layouts]
 *     parameters:
 *       - in: path
 *         name: layoutId
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the layout to retrieve.
 *     responses:
 *       '200':
 *         description: Successfully retrieved the layout.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Layout'
 *       '404':
 *         description: Layout not found.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /layouts/updateLayout/{id}:
 *   put:
 *     summary: Update a layout by ID.
 *     tags: [Layouts]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the layout to update.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Layout'
 *     responses:
 *       '200':
 *         description: Layout updated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Layout'
 *       '400':
 *         description: Bad request. Invalid input.
 *       '404':
 *         description: Layout not found.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /layouts/deleteLayout/{layoutId}:
 *   delete:
 *     summary: Delete a layout by ID.
 *     tags: [Layouts]
 *     parameters:
 *       - in: path
 *         name: layoutId
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the layout to delete.
 *     responses:
 *       '204':
 *         description: Layout deleted successfully.
 *       '404':
 *         description: Layout not found.
 *       '500':
 *         description: Internal server error.
 */
