const express = require('express');
const validate = require('../../middlewares/validate');
const {  DowntimeReasonValidation} = require('../../validations/index');
const { DowntimeReasonController } = require('../../controllers/index');

const router = express.Router();

router
  .route('/addDowntimeReason')
  .post(validate(DowntimeReasonValidation.createReason), DowntimeReasonController.createReason);

router
  .route('/getReasondataByReasonid')
  .post(validate(DowntimeReasonValidation.getReasondataByReasonid), DowntimeReasonController.getReasondataByReasonid);

router
  .route('/deleteDowntimeReason')
  .post(validate(DowntimeReasonValidation.deleteReasonsData), DowntimeReasonController.deleteReasonsData);

router
  .route('/updateReasonData')
  .post(validate(DowntimeReasonValidation.updateReasonData), DowntimeReasonController.updateReasonData);

module.exports = router;

/**
 * @swagger
 * /downtimeReason/addDowntimeReason:
 *   post:
 *     summary: Create a Downtime Reason
 *     tags: [Downtime Reasons]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - reason_id
 *               - reason
 *             properties:
 *               reason_id:
 *                 type: number
 *               reason:
 *                 type: string
 *                 description: Must be unique
 *             example:
 *               reason_id: 17
 *               reason: Dummy Reason
 *     responses:
 *       201:
 *         description: Downtime Reason created successfully
 *         content:
 *           application/json:
 *             example:
 *               state: "Unplanned"
 *               color: "#9D2006"
 *               reason_id: 17
 *               reason: "Dummy Reason"
 *               id: "6530c1f074cd710bb4836ee4"
 *             schema:
 *               type: object
 *               properties:
 *                 state:
 *                   type: string
 *                 color:
 *                   type: string
 *                 reason_id:
 *                   type: number
 *                 reason:
 *                   type: string
 *       500:
 *         description: An error occurred
 *         content:
 *           application/json:
 *             example:
 *               error: "Downtime Reason already taken"
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                 code:
 *                   type: number
 */

/**
 * @swagger
 * /downtimeReason/getReasondataByReasonid:
 *   post:
 *     summary: Get reason data by reason_id
 *     tags: [Downtime Reasons]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               reason_id:
 *                 type: number
 *             example:
 *               reason_id: 17
 *     responses:
 *       200:
 *         description: Downtime reason data retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DowntimeReason'
 *       500:
 *         description: An error occurred
 *         content:
 *           application/json:
 *             example:
 *               error: "Downtime reason data not found"
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 */

/**
 * @swagger
 * /downtimeReason/deleteDowntimeReason:
 *   post:
 *     summary: Delete reason data by reason_id
 *     tags: [Downtime Reasons]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               reason_id:
 *                 type: number
 *             example:
 *               reason_id: 17
 *     responses:
 *       200:
 *         description: Downtime reason data deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DowntimeReason'
 *       500:
 *         description: An error occurred
 *         content:
 *           application/json:
 *             example:
 *               error: "Downtime reason data not found"
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 */

/**
 * @swagger
 * /downtimeReason/updateReasonData:
 *   post:
 *     summary: Update state, color, or reason based on update_field
 *     tags:
 *       - Downtime Reasons
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               update_field:
 *                 type: string
 *               value:
 *                 type: string
 *               reason_id:
 *                 type: number
 *             example:
 *               reason_id: 17
 *               update_field: "state"
 *               value: "Planned"
 *     responses:
 *       200:
 *         description: Downtime reason data updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DowntimeReason'
 *       400:
 *         description: Bad Request
 *         content:
 *           application/json:
 *             example:
 *               error: "Invalid state value"
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *       500:
 *         description: An error occurred
 *         content:
 *           application/json:
 *             example:
 *               error: "Downtime reason data not found"
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 */
