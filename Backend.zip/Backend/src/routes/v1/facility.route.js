const express = require('express');
const facilityController = require('../../controllers/facility.controller');

const router = express.Router();

router.post('/addfacility', facilityController.createFacility);
router.get('/findAllFacilities', facilityController.findFacilities);
router.get('/findFacilityById/:facilityId', facilityController.findFacilityById);
router.put('/updateFacility/:id', facilityController.updateFacility);
router.delete('/deleteFacility/:facilityId', facilityController.deleteFacility);

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: Facilities
 *   description: API endpoints for managing facilities for machine locations
 */

/**
 * @swagger
 * /facilities/addfacility:
 *   post:
 *     summary: Create a new facility.
 *     tags: [Facilities]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Facility'
 *     responses:
 *       '201':
 *         description: Facility created successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Facility'
 *       '400':
 *         description: Bad request. Invalid input.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /facilities/findAllFacilities:
 *   get:
 *     summary: Retrieve all facilities.
 *     tags: [Facilities]
 *     responses:
 *       '200':
 *         description: Successfully retrieved facilities.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Facility'
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /facilities/findFacilityById/{facilityId}:
 *   get:
 *     summary: Retrieve a facility by ID.
 *     tags: [Facilities]
 *     parameters:
 *       - in: path
 *         name: facilityId
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the facility to retrieve.
 *     responses:
 *       '200':
 *         description: Successfully retrieved the facility.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Facility'
 *       '404':
 *         description: Facility not found.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /facilities/updateFacility/{id}:
 *   put:
 *     summary: Update a facility by ID.
 *     tags: [Facilities]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the facility to update.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Facility'
 *     responses:
 *       '200':
 *         description: Facility updated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Facility'
 *       '400':
 *         description: Bad request. Invalid input.
 *       '404':
 *         description: Facility not found.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /facilities/deleteFacility/{facilityId}:
 *   delete:
 *     summary: Delete a facility by ID.
 *     tags: [Facilities]
 *     parameters:
 *       - in: path
 *         name: facilityId
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the facility to delete.
 *     responses:
 *       '204':
 *         description: Facility deleted successfully.
 *       '404':
 *         description: Facility not found.
 *       '500':
 *         description: Internal server error.
 */
