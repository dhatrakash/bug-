const express = require('express');
const HardwareController = require('../../controllers/hardwareDynamic.controller');

const router = express.Router();
router.post('/machineDataBySensorNodeName', HardwareController.machineDataByMappingId);
router.post('/productiveTime', HardwareController.findUptimeDataByMachineId);
router.post('/productiveTimeByHour', HardwareController.machineProductionStatusByRecentHour);
router.post('/dataBySensorUse', HardwareController.machineDataAsperSensorUse);
router.post('/machineData', HardwareController.machineDataByTimeFrame);
router.post('/partcount', HardwareController.partCountByTimeFrame);
router.post('/oeeByTimeInterval', HardwareController.macchineOeeCalculationByInterval);
module.exports = router;

/**
 * @swagger
 * tags:
 *   name: Hardware Dynamic routes
 *   description: Used for dynamic get data with machineId
 */

/**
 * @swagger
 * /hardwaredynamic/machineDataBySensorNodeName:
 *   post:
 *     summary: Retrieve uptime data by machine ID and last hours
 *     description: Retrieve uptime data for a specific machine for last number of hours.
 *     tags: [Hardware Dynamic routes]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               machineId:
 *                 type: string
 *               mappingId:
 *                 type: string
 *               hours:
 *                 type: number
 *             example:
 *               machineId: '651ebb449398a00cc3c5e660'
 *               mappingId: '651ebb449398a00cc3c5e660'
 *               hours: 1
 *     responses:
 *       200:
 *         description: Successful response with data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 */

/**
 * @swagger
 * /hardwaredynamic/productiveTime:
 *   post:
 *     summary: Retrieve uptime data by machine ID
 *     description: Retrieve uptime data for a specific machine within a given time frame.
 *     tags: [Hardware Dynamic routes]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               machineId:
 *                 type: string
 *               startDate:
 *                 type: string
 *                 format: date
 *               endDate:
 *                 type: string
 *                 format: date
 *             example:
 *               machineId: '651ebb449398a00cc3c5e660'
 *               startDate: '2023-10-13T18:30:35Z'
 *               endDate: '2023-10-13T19:30:35Z'
 *     responses:
 *       200:
 *         description: Successful response with uptime data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       400:
 *         description: Invalid request data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       404:
 *         description: No data found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 */

/**
 * @swagger
 * /hardwaredynamic/productiveTimeByHour:
 *   post:
 *     summary: Retrieve uptime data by machine ID and last hours
 *     description: Retrieve uptime data for a specific machine for last number of hours.
 *     tags: [Hardware Dynamic routes]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               machineId:
 *                 type: string
 *               hours:
 *                 type: number
 *             example:
 *               machineId: '651ebb449398a00cc3c5e660'
 *               hours: 1
 *     responses:
 *       200:
 *         description: Successful response with uptime data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       400:
 *         description: Invalid request data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       404:
 *         description: No data found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 */

/**
 * @swagger
 * /hardwaredynamic/dataBySensorUse:
 *   post:
 *     summary: Retrieve data by machine ID based on sensorUse
 *     description: Retrieve uptime data for a specific machine within a given time frame with sensorUse
 *     tags: [Hardware Dynamic routes]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               machineId:
 *                 type: string
 *               startDate:
 *                 type: string
 *                 format: date
 *               endDate:
 *                 type: string
 *                 format: date
 *               sensorUse:
 *                 type: string
 *             example:
 *               machineId: '651ebb449398a00cc3c5e660'
 *               startDate: '2023-10-13T18:30:35Z'
 *               endDate: '2023-10-13T19:30:35Z'
 *               sensorUse: 'PRODUCTIVE'
 *     responses:
 *       200:
 *         description: Successful response with uptime data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       400:
 *         description: Invalid request data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       404:
 *         description: No data found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 */

/**
 * @swagger
 * /hardwaredynamic/machineData:
 *   post:
 *     summary: Retrieve machine data by machine ID
 *     description: Retrieve machine data for a specific machine within a given time frame.
 *     tags: [Hardware Dynamic routes]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               machineId:
 *                 type: string
 *               startDate:
 *                 type: string
 *                 format: date
 *               endDate:
 *                 type: string
 *                 format: date
 *             example:
 *               machineId: '651ebb449398a00cc3c5e660'
 *               startDate: '2023-10-13T18:30:35Z'
 *               endDate: '2023-10-13T19:30:35Z'
 *     responses:
 *       200:
 *         description: Successful response with uptime data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       400:
 *         description: Invalid request data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       404:
 *         description: No data found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 */

/**
 * @swagger
 * /hardwaredynamic/partcount:
 *   post:
 *     summary: Retrieve machine partcount by machine ID
 *     description: Retrieve machine total partcount for a specific machine within a given time frame.
 *     tags: [Hardware Dynamic routes]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               machineId:
 *                 type: string
 *               startDate:
 *                 type: string
 *                 format: date
 *               endDate:
 *                 type: string
 *                 format: date
 *             example:
 *               machineId: '651ebb449398a00cc3c5e660'
 *               startDate: '2023-10-13T18:30:35Z'
 *               endDate: '2023-10-13T19:30:35Z'
 *     responses:
 *       200:
 *         description: Successful response with uptime data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       400:
 *         description: Invalid request data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       404:
 *         description: No data found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 */

/**
 * @swagger
 * /hardwaredynamic/oeeByTimeInterval:
 *   post:
 *     summary: Retrieve machine oee  by machine ID
 *     description: Retrieve machine oee for a specific machine within a given time frame and interval.
 *     tags: [Hardware Dynamic routes]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               machineId:
 *                 type: string
 *               startDate:
 *                 type: string
 *                 format: date
 *               endDate:
 *                 type: string
 *                 format: date
 *               interval:
 *                 type: number
 *             example:
 *               machineId: '651ebb449398a00cc3c5e660'
 *               startDate: '2023-10-13T18:30:35Z'
 *               endDate: '2023-10-13T19:30:35Z'
 *               interval: 1
 *     responses:
 *       200:
 *         description: Successful response with uptime data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       400:
 *         description: Invalid request data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       404:
 *         description: No data found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 */
