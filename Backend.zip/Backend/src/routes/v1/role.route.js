const express = require('express');
const validate = require('../../middlewares/validate');
const RoleController = require('../../controllers/role.controller');
const RoleValidation = require('../../validations/role.validations')
const authSuperAdmin = require('../../middlewares/SuperadminAuth');
const router = express.Router();

router.post('/createRole', authSuperAdmin,validate(RoleValidation.createRole), RoleController.createRole);
router.post('/addFunct',authSuperAdmin, validate(RoleValidation.addFunctToRole), RoleController.addFunctionalityToRole);
router.post('/deleteFunct', authSuperAdmin,validate(RoleValidation.deleteFunctToRole), RoleController.deleteFunctionalityToRole);
router.post('/deleteRole',authSuperAdmin, validate(RoleValidation.deleteRoleById), RoleController.deleteRole);
router.post('/getRoleByName', authSuperAdmin,validate(RoleValidation.getRoleByName), RoleController.getRoleByName);
router.post('/getRoleById',authSuperAdmin,validate(RoleValidation.getRoleByID), RoleController.getRole);
router.get('/getAll', authSuperAdmin,RoleController.getAll);
module.exports = router;