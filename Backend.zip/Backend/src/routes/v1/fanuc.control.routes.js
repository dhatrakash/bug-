const express = require('express');
const fanucController = require('../../controllers/fanuc.control.controller');
const cycleDataController = require('../../controllers/cycleData.controller');

const router = express.Router();

router.get('/singleMachineData/:machine/:hours', fanucController.findAllDataByMachineName);
router.get('/data/:machine/:hours/:observationName', fanucController.findDataByName);
router.get('/feed_uptime/:machine/:hours', fanucController.findUptimeFeedByHour); // combined data feed run
router.get('/partName/:machine/:hours', fanucController.findPartNameByHours);
router.get('/machineList', fanucController.findAllMachines);
router.get('/alarms_messages', fanucController.latestMachineAlarmsMessages);
router.post('/totalAlarms', fanucController.totalAlarmsByHours);
router.post('/cycleData', cycleDataController.cycleDataAnalysis);

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: Fanuc
 *   description: Fanuc Routes
 */
/**
 * @swagger
 * /fanuc/cycleData:
 *   post:
 *     summary: Find Cycle Data for machine
 *     tags:
 *       - Fanuc
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               machineName:
 *                 type: string
 *               startDate:
 *                 type: string
 *               endDate:
 *                 type: string
 *             example:
 *               machineName: mahabal
 *               startDate: 2023-12-02T08:00:00Z
 *               endDate: 2023-12-02T16:00:00Z
 *     responses:
 *       '200':
 *         description: Cycle data for machine with start and end times with machineName
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       '500':
 *         description: Unable to fetch data
 */

/**
 * @swagger
 * /fanuc/totalAlarms:
 *   post:
 *     summary: Find Alarms Data for machine by hours for last 24hrs
 *     tags:
 *       - Fanuc
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               machineName:
 *                 type: string
 *             example:
 *               machineName: mahabal
 *     responses:
 *       '200':
 *         description: Alarms data for machine with start and end times with machineName
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       '500':
 *         description: Unable to fetch data
 */

/**
 * @swagger
 * /fanuc/alarms_messages:
 *  get:
 *    summary: Get all machines alarms and messages
 *    tags:
 *      - Fanuc
 *    responses:
 *       '200':
 *         description: Latest Open alarms and messages
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       '500':
 *         description: Unable to fetch data
 */

/**
 * @swagger
 * /fanuc/feed_uptime/{machine}/{hours}:
 *  get:
 *    summary: Get uptime feed by fanuc machine name
 *    tags:
 *      - Fanuc
 *    parameters:
 *       - name: machine
 *         in: path
 *         required: true
 *         description: name of fanuc machine
 *       - name: hours
 *         in: path
 *         required: true
 *         description: how many recent hours?
 *    responses:
 *       '201':
 *         description: uptime data in array
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *       '404':
 *         description: No machine found
 *       '500':
 *         description: Unable to fetch uptime
 */

/**
 * @swagger
 * /fanuc/partName/{machine}/{hours}:
 *  get:
 *    summary: Get part Name by fanuc machine name
 *    tags:
 *      - Fanuc
 *    parameters:
 *       - name: machine
 *         in: path
 *         required: true
 *         description: name of fanuc machine
 *       - name: hours
 *         in: path
 *         required: true
 *         description: how many recent hours?
 *    responses:
 *       '201':
 *         description: feed data in array
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *       '404':
 *         description: No machine found
 *       '500':
 *         description: Unable to fetch uptime
 */

/**
 * @swagger
 * /fanuc/data/{machine}/{hours}/{observationName}:
 *  get:
 *    summary: Get data by fanuc machine name, last hours, observationName
 *    tags:
 *      - Fanuc
 *    parameters:
 *       - name: machine
 *         in: path
 *         required: true
 *         description: name of fanuc machine
 *       - name: hours
 *         in: path
 *         required: true
 *         description: how many recent hours?
 *       - name: observationName
 *         in: path
 *         required: true
 *         description: Observation Name
 *    responses:
 *       '201':
 *         description: fanuc data in array
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *       '404':
 *         description: No machine found
 *       '500':
 *         description: Unable to fetch uptime
 */

/**
 * @swagger
 * /fanuc/singleMachineData/{machine}/{hours}:
 *  get:
 *    summary: Get data by fanuc machine name, last hours
 *    tags:
 *      - Fanuc
 *    parameters:
 *       - name: machine
 *         in: path
 *         required: true
 *         description: name of fanuc machine
 *       - name: hours
 *         in: path
 *         required: true
 *         description: how many recent hours?
 *    responses:
 *       '201':
 *         description: fanuc data in array
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *       '404':
 *         description: No machine found
 *       '500':
 *         description: Unable to fetch uptime
 */
