const express = require('express');
const authForSuperadmin = require('../../middlewares/SuperadminAuth');
const validate = require('../../middlewares/validate');
const superAdminValidations = require('../../validations/superAdmin.validation');
const superAdminController = require('../../controllers/superAdmin.controller');
const { userValidation } = require('../../validations/index');
const { userController } = require('../../controllers/index');
const router = express.Router();

router.route('/viewAddUserForm').get(authForSuperadmin, superAdminController.viewAddUserForm);

router.route('/viewCreateMachineForm').get(authForSuperadmin, userController.viewCreateMachineForm);

router.route('/register').post(authForSuperadmin, validate(userValidation.createUser), userController.register);

router.route('/update').post(authForSuperadmin, superAdminController.updatePermissions);

router.route('/viewAllMachines').get(authForSuperadmin, superAdminController.viewAllMachines);

router.route('/viewAddSensor').get(authForSuperadmin, superAdminController.viewAddSensor);

router.route('/getAllUsers').get(authForSuperadmin, superAdminController.getAllUsers);

router
  .route('/:superAdminId')
  .get(authForSuperadmin, validate(superAdminValidations.getSuperAdmin), superAdminController.getSuperAdmin)
  .patch(authForSuperadmin, validate(superAdminValidations.updateSuperAdmin), superAdminController.updateSuperAdmin)
  .delete(authForSuperadmin, validate(superAdminValidations.deleteSuperAdmin), superAdminController.deleteSuperAdmin);

module.exports = router;

// Swagger Documentation
/**
 * @swagger
 * tags:
 *   name: SuperAdmins
 *   description: API for managing super admin users
 */

/**
 * @swagger
 * /superAdmins/viewAddUserForm:
 *   get:
 *     summary: Get the view for adding a user
 *     description: |
 *       Only Superadmins, admins, and ceo/cxo can create other users.
 *     tags: [SuperAdmins]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       "200":
 *         description: View for adding a user
 *       "401":
 *         description: Unauthorized
 *       "403":
 *         description: Forbidden
 */

/**
 * @swagger
 * /superadmins/register:
 *   post:
 *     summary: Register a new user account
 *     description: Only Superadmins, admins, and ceo/cxo can create other users.
 *     tags: [SuperAdmins]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       description: User data to register
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *                 format: email
 *                 description: Must be unique
 *               password:
 *                 type: string
 *                 format: password
 *                 minLength: 8
 *                 description: At least one letter and one number
 *               role:
 *                 type: string
 *                 enum: ['admin', 'ceo/cxo', 'manager', 'supervisor', 'operator', 'spectator', 'user']
 *                 description: Role of the user
 *             example:
 *               name: fake name
 *               email: fake@example.com
 *               password: password1
 *               role: supervisor
 *     responses:
 *       "201":
 *         description: Created
 *         content:
 *           application/json:
 *             schema:
 *                $ref: '#/components/schemas/User'
 *       "400":
 *         description: Bad request
 *       "401":
 *         description: Unauthorized
 *       "403":
 *         description: Forbidden
 */

/**
 * @swagger
 * /superadmins/{superAdminId}:
 *   get:
 *     summary: Get a super admin user by ID
 *     tags: [SuperAdmins]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: superAdminId
 *         description: ID of the super admin user to retrieve
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       "200":
 *         description: Super admin user retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *                $ref: '#/components/schemas/SuperAdmin'
 *       "401":
 *         description: Unauthorized
 *       "403":
 *         description: Forbidden
 *       "404":
 *         description: Not Found
 *
 *   patch:
 *     summary: Update a super admin user by ID
 *     tags: [SuperAdmins]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: superAdminId
 *         description: ID of the super admin user to update
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       description: Updated super admin data
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *                 format: email
 *                 description: must be unique
 *               password:
 *                 type: string
 *                 format: password
 *                 minLength: 8
 *                 description: At least one letter and one number
 *             example:
 *               name: Updated Name
 *               email: updated@example.com
 *               password: NewPassword123
 *     responses:
 *       "200":
 *         description: Super admin user updated successfully
 *         content:
 *           application/json:
 *             schema:
 *                $ref: '#/components/schemas/SuperAdmin'
 *       "400":
 *         description: Bad request
 *       "401":
 *         description: Unauthorized
 *       "403":
 *         description: Forbidden
 *       "404":
 *         description: Not Found
 *
 *   delete:
 *     summary: Delete a super admin user by ID
 *     tags: [SuperAdmins]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: superAdminId
 *         description: ID of the super admin user to delete
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       "204":
 *         description: Super admin user deleted successfully
 *       "401":
 *         description: Unauthorized
 *       "403":
 *         description: Forbidden
 *       "404":
 *         description: Not Found
 */
