const express = require('express');
const controllerController = require('../../controllers/fanucController.controller');

const router = express.Router();

// route for fetching data of OEE of all machine.
router.route('/allmachine').post(controllerController.allMachineOEEData);
// route for fetching data of part count of all machine.
router.route('/partcount').post(controllerController.partProduceTable);
// route for fetching data of OEE of selected machine.
router.route('/machineOEE').post(controllerController.selectedMachineOEEData);
// route for fetching data of selected machine for create PDF.
router.route('/pdf').post(controllerController.createPdf);
// route for fetching data of selected machine for create PDF.
router.route('/createPdf').post(controllerController.dynamicPdf);
// route for fetching data of all machine for create PDF.
router.route('/companyreport').post(controllerController.companyReport);

module.exports = router;


/**
 * @swagger
 * /controllerdata/allmachine:
 *   post:
 *     summary: Fetch OEE data of all machines
 *     tags: [Controller]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               startDate:
 *                 type: string
 *                 format: date-time
 *               endDate:
 *                 type: string
 *                 format: date-time
 *               interval:
 *                 type: number
 * 
 *     responses:
 *       200:
 *         description: Matching Records from hardware-routes
 *         content:
 *           application/json:
 *             example:
 *               message: "These are matching Records from hardware-routes"
 *               machineData: []
 *       500:
 *         description: Error
 *         content:
 *           application/json:
 *             example:
 *               error: "Internal Server Error"
 * 
 * /controllerdata/partcount:
 *   post:
 *     summary: Fetch part count data for a date
 *     tags: [Controller]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               date:
 *                 type: string
 *                 format: date-time
 *               interval:
 *                 type: number
 *     responses:
 *       200:
 *         description: Matching Records
 *         content:
 *           application/json:
 *             example:
 *               message: "Matching Records"
 *               data: []
 *       500:
 *         description: Error
 *         content:
 *           application/json:
 *             example:
 *               error: "Internal Server Error"
 * 
 * /controllerdata/machineOEE:
 *   post:
 *     summary: Fetch OEE data for a specific machine
 *     tags: [Controller]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               startDate:
 *                 type: string
 *                 format: date-time
 *               endDate:
 *                 type: string
 *                 format: date-time
 *               interval:
 *                 type: number
 *               machineName:
 *                 type: string
 *     responses:
 *       200:
 *         description: Matching Records from hardware-routes
 *         content:
 *           application/json:
 *             example:
 *               message: "These are matching Records from hardware-routes"
 *               machineData: []
 *       500:
 *         description: Error
 *         content:
 *           application/json: 
 *             example:
 *               error: "Internal Server Error"
 * 
 */