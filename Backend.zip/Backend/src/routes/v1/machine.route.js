const express = require('express');
const machineController = require('../../controllers/machine.controller');

const router = express.Router();

// Create or update  an IO record for a gateway
router.post('/:machineId/io', machineController.createIORecord);
// Get all IO records for a gateway
router.get('/:machineId/io', machineController.getAllIORecords);
// Delete an existing IO record by ID
router.delete('/:machineId/io/:diId', machineController.deleteIORecord);

router.get('/findAllMachines', machineController.findMachines);
router.post('/addmachine', machineController.createMachine);
router.put('/defineGateway', machineController.updateGateway);
router.get('/findMachineById/:machineId', machineController.findMachineById);
router.put('/updateMachine/:machineId', machineController.updateMachine);
router.delete('/deleteMachine/:machineId', machineController.deleteMachine);
module.exports = router;

/**
 * @swagger
 * tags:
 *   name: Machines
 *   description: Machine management
 */

/**
 * @swagger
 * /machines/addmachine:
 *   post:
 *     summary: Create a new machine.
 *     tags:
 *       - Machines
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               machineName:
 *                 type: string
 *               machine_type:
 *                 type: string
 *               machineLocation:
 *                 type: object
 *                 properties:
 *                    facility:
 *                      type: string
 *                    cell:
 *                      type: string
 *                    layout:
 *                      type: string
 *                    line:
 *                      type: string
 *               machineMake:
 *                 type: string
 *               mfgEmail:
 *                 type: string
 *               machineMakeYear:
 *                 type: integer
 *               machineWarranty:
 *                 type: integer
 *               maintenancePerson:
 *                 type: string
 *               machinePhoto:
 *                 type: string
 *                 format: binary
 *               controllerPhoto:
 *                 type: string
 *                 format: binary
 *           required:
 *             - machineName
 *             - machine_type
 *     responses:
 *       '201':
 *         description: Machine created successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Machine'
 *       '400':
 *         description: Bad request. Invalid input.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /machines/findAllMachines:
 *   get:
 *     summary: Retrieve a list of all machines.
 *     tags: [Machines]
 *     responses:
 *       '200':
 *         description: A list of machines.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /machines/defineGateway:
 *   put:
 *     summary: Update association between existing gateway and machine
 *     tags: [Machines]
 *     description: Update association between existing gateway and machine
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               machineId:
 *                 type: string
 *               gatewayId:
 *                 type: string
 *             example:
 *               machineId: 650ab1180d743c5361e78d9f
 *               gatewayId: 650ab1180d743c5361e78d9f
 *     responses:
 *       200:
 *         description: Machine updated successfully.
 *       400:
 *         description: Invalid request body.
 *       404:
 *         description: Machine not found.
 *       500:
 *         description: Internal server error.
 */

/**
 * @swagger
 * /machines/findMachineById/{machineId}:
 *   get:
 *     summary: Retrieve a machine by ID.
 *     description: Use this endpoint to retrieve a machine by its unique ID.
 *     tags: [Machines]
 *     parameters:
 *       - in: path
 *         name: machineId
 *     responses:
 *       '200':
 *         description: A list of machines.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /machines/deleteMachine/{machineId}:
 *   delete:
 *     summary: Delete a machine by ID.
 *     tags: [Machines]
 *     description: Use this endpoint to delete a machine by its unique ID.
 *     parameters:
 *       - in: path
 *         name: machineId
 *         required: true
 *         description: ID of the machine to delete.
 *     responses:
 *       200:
 *         description: Machine deleted successfully.
 *       404:
 *         description: Machine not found.
 *         content:
 *           application/json:
 *             example:
 *               code: 404
 *               message: Machine not found
 *       500:
 *         description: Internal server error.
 */

/**
 * @swagger
 * /machines/updateMachine/{machineId}:
 *   put:
 *     summary: use of postman recommended for this method as swagger creates empty fields which are not filled making empty objects unless all of the properties are updated
 *     tags: [Machines]
 *     description: Use this endpoint to update an existing machine's information.
 *     parameters:
 *       - in: path
 *         name: machineId
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               machineName:
 *                 type: string
 *               machine_type:
 *                 type: string
 *               machineLocation:
 *                 type: object
 *                 properties:
 *                    facility:
 *                      type: string
 *                    cell:
 *                      type: string
 *                    layout:
 *                      type: string
 *                    line:
 *                      type: string
 *               machineMake:
 *                 type: string
 *               mfgEmail:
 *                 type: string
 *               machineMakeYear:
 *                 type: integer
 *               machineWarranty:
 *                 type: integer
 *               maintenancePerson:
 *                 type: string
 *               machinePhoto:
 *                 type: string
 *                 format: binary
 *               controllerPhoto:
 *                 type: string
 *                 format: binary
 *     responses:
 *       '201':
 *         description: Machine created successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Machine'
 *       400:
 *         description: Invalid request body.
 *       404:
 *         description: Machine not found.
 *       500:
 *         description: Internal server error.
 */

// /**
//  * @swagger
//  * /machines/updateMapping/{machineId}:
//  *   put:
//  *     summary: Update a mapping of ideal and productive
//  *     tags: [Machines]
//  *     description: Use this endpoint to update an existing machine's mapping.
//  *     parameters:
//  *       - in: path
//  *         name: machineId
//  *     requestBody:
//  *       required: true
//  *       content:
//  *         application/json:
//  *           schema:
//  *             $ref: '#/components/schemas/statusMapping'
//  *     responses:
//  *       200:
//  *         description: Machine updated successfully.
//  *       400:
//  *         description: Invalid request body.
//  *       404:
//  *         description: Machine not found.
//  *       500:
//  *         description: Internal server error.
//  */
// router.put('/updateMapping/:machineId', machineController.updateMapping);
