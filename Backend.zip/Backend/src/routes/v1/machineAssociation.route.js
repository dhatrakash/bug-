const express = require('express');

const router = express.Router();
const {
  createMappingController,
  updateMappingController,
  softDeleteWholeMappingController,
  softDeleteMappingController,
  findActiveMappingsController,
  findInActiveMappingsController,
  findMappingByMachineMappingIdController,
  deleteMappingController,
} = require('../../controllers/machineAssociations.controller');

// Create a new mapping
router.post('/mappings', createMappingController);

// Update a mapping by ID
router.put('/mappings/:machineMappingId/:uniqueRef', updateMappingController);

// Soft delete a whole mapping by ID
router.put('/mappings/:machineMappingId', softDeleteWholeMappingController);

// Soft delete a specific mapping by ID
router.patch('/mappings/:machineMappingId/:mappingId', softDeleteMappingController);

// Get active mappings for a machine by ID
router.get('/mappings/active/:machineId', findActiveMappingsController);

// Get inactive mappings for a machine by ID
router.get('/mappings/inactive/:machineId', findInActiveMappingsController);

// Get a mapping by machineMappingId
router.get('/mappings/:machineMappingId', findMappingByMachineMappingIdController);

// Delete a mapping by machineMappingId
router.delete('/mappings/:machineMappingId', deleteMappingController);

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: MachineMappings
 *   description: Machine Mapping management
 */

/**
 * @swagger
 * /machineMappings/mappings:
 *   post:
 *     summary: Create a new MachineMapping
 *     description: You can create completely new mapping as well as add new mapping to existing mappings does support multiple insert at time or single
 *     tags:
 *       - MachineMappings
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/MachineMapping'
 *     responses:
 *       '201':
 *         description: MachineMapping created successfully
 *       '400':
 *         description: Bad request. Invalid data.
 *       '500':
 *         description: Internal server error.
 */
/**
 * @swagger
 * /machineMappings/mappings/{machineMappingId}/{uniqueRef}:
 *   put:
 *     summary: Update a mapping by ID
 *     description: Edit the existing mapping with uniqueRef to specific mapping nested in machineMapping document
 *     tags:
 *       - MachineMappings
 *     parameters:
 *       - in: path
 *         name: machineMappingId
 *         required: true
 *         description: The ID of the machine mapping to update.
 *       - in: path
 *         name: uniqueRef
 *         required: true
 *         description: The uniqueRef of the mapping to update.
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       description: The data to update the mapping.
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *                   mappingId:
 *                     type: string
 *                     description: The ID of the mapping to update.
 *                   sensorNodeType:
 *                     type: string
 *                     description: Use IO or SLAVE
 *             required:
 *               - sensorNodeType
 *               - mappingId
 *     responses:
 *       '200':
 *         description: Mapping updated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/MachineGatewayAssociation'
 *       '400':
 *         description: Bad request. The request body is invalid.
 *       '404':
 *         description: Mapping not found. The provided `machineMappingId` doesn't exist.
 *       '500':
 *         description: Internal server error. Failed to update the mapping.
 */

/**
 * @swagger
 * /machineMappings/mappings/{machineMappingId}:
 *   put:
 *     summary: Soft delete a whole mapping by ID
 *     description: Completely delete MachineMapping all together but it will stay in the archive part of db
 *     tags:
 *       - MachineMappings
 *     parameters:
 *       - in: path
 *         name: machineMappingId
 *         required: true
 *         description: The ID of the machine mapping to soft delete.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Mapping soft deleted successfully.
 *       '404':
 *         description: Mapping not found. The provided `machineMappingId` doesn't exist.
 *       '500':
 *         description: Internal server error. Failed to soft delete the mapping.
 */

/**
 * @swagger
 * /machineMappings/mappings/{machineMappingId}/{mappingId}:
 *   patch:
 *     summary: Soft delete a specific mapping by ID
 *     description: Completely delete single mapping inside machineMapping document but it will stay in the archive part of db
 *     tags:
 *       - MachineMappings
 *     parameters:
 *       - in: path
 *         name: machineMappingId
 *         required: true
 *         description: The ID of the machine mapping containing the specific mapping.
 *         schema:
 *           type: string
 *       - in: path
 *         name: mappingId
 *         required: true
 *         description: The ID of the specific mapping to soft delete.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Mapping soft deleted successfully.
 *       '404':
 *         description: Mapping not found. The provided `machineMappingId` or `mappingId` doesn't exist.
 *       '500':
 *         description: Internal server error. Failed to soft delete the mapping.
 */

/**
 * @swagger
 * /machineMappings/mappings/active/{machineId}:
 *   get:
 *     summary: Get active mappings for a machine by ID
 *     description: When you need active mappings those are connected to machine and active
 *     tags:
 *       - MachineMappings
 *     parameters:
 *       - in: path
 *         name: machineId
 *         required: true
 *         description: The ID of the machine to retrieve active mappings for.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Active mappings retrieved successfully.
 *       '404':
 *         description: No active mappings found for the provided `machineId`.
 *       '500':
 *         description: Internal server error. Failed to retrieve active mappings.
 */

/**
 * @swagger
 * /machineMappings/mappings/inactive/{machineId}:
 *   get:
 *     summary: Get inactive mappings for a machine by ID
 *     description: When you need inactive (archive) mappings those are connected to machine and active
 *     tags:
 *       - MachineMappings
 *     parameters:
 *       - in: path
 *         name: machineId
 *         required: true
 *         description: The ID of the machine to retrieve inactive mappings for.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Inactive mappings retrieved successfully.
 *       '404':
 *         description: No inactive mappings found for the provided `machineId`.
 *       '500':
 *         description: Internal server error. Failed to retrieve inactive mappings.
 */

/**
 * @swagger
 * /machineMappings/mappings/{machineMappingId}:
 *   get:
 *     summary: Get a mapping by machineMappingId
 *     tags:
 *       - MachineMappings
 *     description: find specific document of machineMapping with it's id
 *     parameters:
 *       - in: path
 *         name: machineMappingId
 *         required: true
 *         description: The ID of the machine mapping to retrieve.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Mapping retrieved successfully.
 *       '404':
 *         description: Mapping not found. The provided `machineMappingId` doesn't exist.
 *       '500':
 *         description: Internal server error. Failed to retrieve the mapping.
 */

/**
 * @swagger
 * /machineMappings/mappings/{machineMappingId}:
 *   delete:
 *     summary: Delete a mapping by machineMappingId
 *     tags:
 *       - MachineMappings
 *     description: No archive directly delete whole mapping without any trace in the db
 *     parameters:
 *       - in: path
 *         name: machineMappingId
 *         required: true
 *         description: The ID of the machine mapping to delete.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Mapping deleted successfully.
 *       '404':
 *         description: Mapping not found. The provided `machineMappingId` doesn't exist.
 *       '500':
 *         description: Internal server error. Failed to delete the mapping.
 */
