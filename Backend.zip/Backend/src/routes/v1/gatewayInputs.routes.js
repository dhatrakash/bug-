const express = require('express');
const gatewayInputController = require('../../controllers/gatewayInputs1.controller');

const router = express.Router();

/**
 * @swagger
 * tags:
 *  name: GatewayInputs
 *  description: Gateway Inputs mapping for gateways
 */

/**
 * @swagger
 * /gatewayInputs:
 *   post:
 *     summary: Create a new Gateway Input.
 *     tags: [GatewayInputs]
 *     requestBody:
 *       description: Gateway Input data to be created.
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/GatewayInput'
 *     responses:
 *       201:
 *         description: Successfully created a new Gateway Input.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewayInput'
 *       400:
 *         description: Bad request. Invalid input.
 *       500:
 *         description: Internal server error.

 */

// Create Gateway Input
router.post('/', gatewayInputController.createGatewayInputController);

/**
 * @swagger
 * /gatewayInputs:
 *   get:
 *     summary: Get Gateway Inputs by Mapping ID.
 *     tags: [GatewayInputs]
 *     responses:
 *       200:
 *         description: Successfully retrieved Gateway Inputs.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewayInput'
 *       500:
 *         description: Internal server error.

 */
router.get('/', gatewayInputController.getGatewayInputsAll);

/**
 * @swagger
 * /gatewayInputs/{mappingId}:
 *   get:
 *     summary: Get Gateway Inputs by Mapping ID.
 *     tags: [GatewayInputs]
 *     parameters:
 *       - name: mappingId
 *         in: path
 *         required: true
 *         description: ID of the mapping.
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successfully retrieved Gateway Inputs.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewayInput'
 *       500:
 *         description: Internal server error.

 */
router.get('/:mappingId', gatewayInputController.getGatewayInputsByMappingIdController);

/**
 * @swagger
 * /gatewayInputs/{mappingId}:
 *   delete:
 *     summary: Delete Gateway Inputs by Mapping ID.
 *     tags: [GatewayInputs]
 *     parameters:
 *       - name: mappingId
 *         in: path
 *         required: true
 *         description: ID of the mapping.
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successfully Deleted Gateway Inputs.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewayInput'
 *       500:
 *         description: Internal server error.

 */
router.delete('/:mappingId', gatewayInputController.deleteGatewayInputByMappingId);
/**
 * @swagger
 * /gatewayInputs/gateway/{gatewayId}:
 *   get:
 *     summary: Get Gateway Inputs by Gateway ID.
 *     tags: [GatewayInputs]
 *     parameters:
 *       - name: gatewayId
 *         in: path
 *         required: true
 *         description: ID of the gateway.
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successfully retrieved Gateway Inputs.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewayInput'
 *       500:
 *         description: Internal server error.

 */
router.get('/gateway/:gatewayId', gatewayInputController.getGatewayInputsByGatewayIdController);

/**
 * @swagger
 * /gatewayInputs/gateway/{gatewayId}/di/{diId}:
 *   get:
 *     summary: Get Gateway Inputs by Gateway ID and DI ID.
 *     tags: [GatewayInputs]
 *     parameters:
 *       - name: gatewayId
 *         in: path
 *         required: true
 *         description: ID of the gateway.
 *         schema:
 *           type: string
 *       - name: diId
 *         in: path
 *         required: true
 *         description: ID of the DI (Digital Input).
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successfully retrieved Gateway Inputs.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewayInput'
 *       500:
 *         description: Internal server error.

 */
router.get('/gateway/:gatewayId/di/:diId', gatewayInputController.getGatewayInputsByGatewayIdDiIdController);

/**
 * @swagger
 * /gatewayInputs/{mappingId}:
 *   put:
 *     summary: Update Gateway Inputs by Mapping ID.
 *     tags: [GatewayInputs]
 *     parameters:
 *       - name: mappingId
 *         in: path
 *         required: true
 *         description: ID of the mapping.
 *         schema:
 *           type: string
 *     requestBody:
 *       description: Updated Gateway Input data.
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/GatewayInput'
 *     responses:
 *       200:
 *         description: Successfully updated Gateway Inputs.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewayInput'
 *       500:
 *         description: Internal server error.

 */
router.put('/:mappingId', gatewayInputController.updateGatewayInputsByIdController);

/**
 * @swagger
 * /gatewayInputs/{mappingId}:
 *   patch:
 *     summary: Soft Delete Gateway Inputs by Mapping ID.
 *     tags: [GatewayInputs]
 *     parameters:
 *       - name: mappingId
 *         in: path
 *         required: true
 *         description: ID of the mapping.
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successfully soft-deleted Gateway Inputs.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewayInput'
 *       500:
 *         description: Internal server error.

 */
router.patch('/:mappingId', gatewayInputController.softDeleteGatewayInputsByMappingIdController);

/**
 * @swagger
 * /gatewayInputs/gateway/{gatewayId}:
 *   patch:
 *     summary: Soft Delete Gateway Inputs by Gateway ID.
 *     tags: [GatewayInputs]
 *     parameters:
 *       - name: gatewayId
 *         in: path
 *         required: true
 *         description: ID of the gateway.
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successfully soft-deleted Gateway Inputs.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewayInput'
 *       500:
 *         description: Internal server error.

 */
router.patch('/gateway/:gatewayId', gatewayInputController.softDeleteGatewayInputsByGatewayIdController);

/**
 * @swagger
 * /gatewayInputs/gateway/{gatewayId}/di/{diId}:
 *   patch:
 *     summary: Soft Delete Gateway Inputs by Gateway ID and DI ID.
 *     tags: [GatewayInputs]
 *     parameters:
 *       - name: gatewayId
 *         in: path
 *         required: true
 *         description: ID of the gateway.
 *         schema:
 *           type: string
 *       - name: diId
 *         in: path
 *         required: true
 *         description: ID of the DI (Digital Input).
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successfully soft-deleted Gateway Inputs.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewayInput'
 *       500:
 *         description: Internal server error.

 */
router.patch('/gateway/:gatewayId/di/:diId', gatewayInputController.softDeleteGatewayInputsByGatewayIdDiIdController);

module.exports = router;
