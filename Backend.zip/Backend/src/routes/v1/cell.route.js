const express = require('express');
const cellController = require('../../controllers/cell.controller');

const router = express.Router();

router.post('/addcell', cellController.createCell);
router.get('/findAllCells', cellController.findCells);
router.get('/findCellById/:cellId', cellController.findCellById);
router.put('/updateCell/:id', cellController.updateCell);
router.delete('/deleteCell/:cellId', cellController.deleteCell);

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: Cells
 *   description: API endpoints for managing cells for machine locations
 */

/**
 * @swagger
 * /cells/addcell:
 *   post:
 *     summary: Create a new cell.
 *     tags: [Cells]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Cell'
 *     responses:
 *       '201':
 *         description: Cell created successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Cell'
 *       '400':
 *         description: Bad request. Invalid input.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /cells/findAllCells:
 *   get:
 *     summary: Retrieve all cells.
 *     tags: [Cells]
 *     responses:
 *       '200':
 *         description: Successfully retrieved cells.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Cell'
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /cells/findCellById/{cellId}:
 *   get:
 *     summary: Retrieve a cell by ID.
 *     tags: [Cells]
 *     parameters:
 *       - in: path
 *         name: cellId
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the cell to retrieve.
 *     responses:
 *       '200':
 *         description: Successfully retrieved the cell.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Cell'
 *       '404':
 *         description: Cell not found.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /cells/updateCell/{id}:
 *   put:
 *     summary: Update a cell by ID.
 *     tags: [Cells]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the cell to update.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Cell'
 *     responses:
 *       '200':
 *         description: Cell updated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Cell'
 *       '400':
 *         description: Bad request. Invalid input.
 *       '404':
 *         description: Cell not found.
 *       '500':
 *         description: Internal server error.
 */

/**
 * @swagger
 * /cells/deleteCell/{cellId}:
 *   delete:
 *     summary: Delete a cell by ID.
 *     tags: [Cells]
 *     parameters:
 *       - in: path
 *         name: cellId
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the cell to delete.
 *     responses:
 *       '204':
 *         description: Cell deleted successfully.
 *       '404':
 *         description: Cell not found.
 *       '500':
 *         description: Internal server error.
 */
