const express = require('express');
const { partcodeController } = require('../../controllers/index');
const { partcodeValidation } = require('../../validations/index');
const validate = require('../../middlewares/validate');

const router = express.Router();

router.route('/createPartCode').post(validate(partcodeValidation.createPartCode), partcodeController.createPartCode);

router.route('/getPartCodeData').post(validate(partcodeValidation.getPartCode), partcodeController.getPartCodeData);

module.exports = router;
