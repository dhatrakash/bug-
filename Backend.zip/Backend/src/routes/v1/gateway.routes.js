const express = require('express');
const gatewayController = require('../../controllers/gateway.controller');

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Gateways
 *   description: Gateway management
 */

/**
 * @swagger
 * /gateway:
 *   post:
 *     summary: Create a new gateway
 *     tags:
 *       - Gateways
 *     requestBody:
 *       description: Gateway data to create
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Gateway'
 *     responses:
 *       '201':
 *         description: Gateway created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Gateway'
 *       '500':
 *         description: Unable to create gateway
 */
router.post('/', gatewayController.createGateway);

/**
 * @swagger
 * /gateway:
 *   get:
 *     summary: Get all gateways
 *     tags:
 *       - Gateways
 *     responses:
 *       '201':
 *         description: List of gateways
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Gateway'
 *       '404':
 *         description: No gateways found
 *       '500':
 *         description: Unable to fetch gateways
 */
router.get('/', gatewayController.getAllGateways);

/**
 * @swagger
 * /gateway/{gatewayId}:
 *   get:
 *     summary: Get a gateway by ID
 *     tags:
 *       - Gateways
 *     parameters:
 *       - name: gatewayId
 *         in: path
 *         required: true
 *         description: ID of the gateway to retrieve
 *         schema:
 *           type: string
 *     responses:
 *       '201':
 *         description: Gateway found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Gateway'
 *       '404':
 *         description: Gateway not found
 *       '500':
 *         description: Unable to fetch gateway by ID
 */
router.get('/:gatewayId', gatewayController.getGatewayById);

/**
 * @swagger
 * /gateway/{gatewayId}:
 *   put:
 *     summary: Update a gateway by ID
 *     tags:
 *       - Gateways
 *     parameters:
 *       - name: gatewayId
 *         in: path
 *         required: true
 *         description: ID of the gateway to update
 *         schema:
 *           type: string
 *     requestBody:
 *       description: Updated gateway data
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Gateway'
 *     responses:
 *       '201':
 *         description: Gateway updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Gateway'
 *       '404':
 *         description: Gateway not found
 *       '500':
 *         description: Unable to update gateway
 */
router.put('/:gatewayId', gatewayController.updateGateway);

/**
 * @swagger
 * /gateway/{gatewayId}:
 *   delete:
 *     summary: Delete a gateway by ID
 *     tags:
 *       - Gateways
 *     parameters:
 *       - name: gatewayId
 *         in: path
 *         required: true
 *         description: ID of the gateway to delete
 *         schema:
 *           type: string
 *     responses:
 *       '201':
 *         description: Gateway deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewayResponse'
 *       '404':
 *         description: Gateway not found
 *       '500':
 *         description: Unable to delete gateway
 */
router.delete('/:gatewayId', gatewayController.deleteGateway);

// /**
//  * @swagger
//  * /gateway/{gatewayId}/io:
//  *   get:
//  *     summary: Find all io records for a gateway
//  *     tags:
//  *       - Gateways_io
//  *     parameters:
//  *       - name: gatewayId
//  *         in: path
//  *         required: true
//  *         description: ID of the gateway to find all io records
//  *         schema:
//  *           type: string
//  *     responses:
//  *       '201':
//  *         description: List of slaves
//  *         content:
//  *           application/json:
//  *             schema:
//  *               type: array
//  *               items:
//  *                 $ref: '#/components/schemas/SensorData'
//  *       '404':
//  *         description: No slaves found
//  *       '500':
//  *         description: Unable to find the slaves
//  */

// router.get('/:gatewayId/io', gatewayController.getAllIORecords);

// /**
//  * @swagger
//  * /gateway/{gatewayId}/io/{diId}:
//  *   delete:
//  *     summary: Delete io from gateway
//  *     tags:
//  *       - Gateways_io
//  *     parameters:
//  *       - name: gatewayId
//  *         in: path
//  *         required: true
//  *         description: ID of the gateway
//  *       - name: diId
//  *         in: path
//  *         required: true
//  *         description: ID of io record
//  *     responses:
//  *       '204':
//  *         description: IO record deleted successfully
//  *       '500':
//  *         description: Unable to delete IO record
//  */
// router.delete('/:gatewayId/io/:diId', gatewayController.deleteIORecord);

// /**
//  * @swagger
//  * /gateway/{gatewayId}/io/{diId}:
//  *   post:
//  *     summary: Add or update an I/O record for a gateway
//  *     tags:
//  *       - Gateways_io
//  *     parameters:
//  *       - name: gatewayId
//  *         in: path
//  *         required: true
//  *         schema:
//  *           type: string
//  *       - name: diId
//  *         in: path
//  *         required: true
//  *         description: ID of the gateway to add/update a slave
//  *         schema:
//  *           type: string
//  *     requestBody:
//  *       description: Add or update inputs DI data
//  *       required: true
//  *       content:
//  *         application/json:
//  *           schema:
//  *             type: object
//  *             properties:
//  *               sensorId:
//  *                 type: string
//  *               tag:
//  *                 type: string
//  *     responses:
//  *       '201':
//  *         description: Slave added/updated successfully
//  *         content:
//  *           application/json:
//  *             schema:
//  *               $ref: '#/components/schemas/Gateway'
//  *       '500':
//  *         description: Unable to modify slave
//  */
// router.post('/:gatewayId/io/:diId', gatewayController.updateIORecord);

module.exports = router;
