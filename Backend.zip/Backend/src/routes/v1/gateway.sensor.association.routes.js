const express = require('express');
const GatewaySensorAssociationController = require('../../controllers/gatewaySensorAssociation.controller');

const router = express.Router();

router.get('/', GatewaySensorAssociationController.retriveAllMapping);
router.get('/:mappingId', GatewaySensorAssociationController.findByMappingId);
router.get('/find/:gatewayId', GatewaySensorAssociationController.findByMappingGatewayId);
router.get('/:gatewayId/slave/:slaveId', GatewaySensorAssociationController.findByMappingSlaveid);
router.get('/:gatewayId/slave/:slaveId/tag/:tag', GatewaySensorAssociationController.findByMappingTag);

router.post('/', GatewaySensorAssociationController.create);
router.post('/createMultiple', GatewaySensorAssociationController.createMultiple);

router.put('/:mappingId', GatewaySensorAssociationController.updateAssociation);

router.delete('/:mappingId', GatewaySensorAssociationController.deleteAssociationsById);

router.patch('/softdel/:gatewayId/slave/:slaveId', GatewaySensorAssociationController.softDeleteBySlaveId);
router.patch('/softdel/:mappingId', GatewaySensorAssociationController.softDeleteByMappingId);
router.patch('/softdel/:gatewayId/slave/:slaveId/tag/:tag', GatewaySensorAssociationController.softDeleteByTag);
router.patch('/softdel/sensor/:sensorId', GatewaySensorAssociationController.softDeleteBySensorId);

module.exports = router;

/**
 * @swagger
 * tags:
 *  name: GatewayModbus
 *  description: all mapping between entites related to gateway, sensor, slaves.
 */

/**
 * @swagger
 * /associationGatewaySensor:
 *  get:
 *    summary: Retrive all the mappings of gateway slaves and sensors.
 *    tags:
 *      - GatewayModbus
 *    responses:
 *      '201':
 *        description: List of mappings
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *      '404':
 *        description: No mappings found
 *      '500':
 *        description: unable to find mappings.
 */

/**
 * @swagger
 * /associationGatewaySensor/{mappingId}:
 *   get:
 *     summary: Get a GatewaySensorAssociation by mappingID
 *     tags:
 *       - GatewayModbus
 *     parameters:
 *       - in: path
 *         name: mappingId
 *         description: The ID of the GatewaySensorAssociation to retrieve
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: A single GatewaySensorAssociation object
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewaySensorAssociation'
 *       '404':
 *         description: GatewaySensorAssociation not found
 *       '500':
 *         description: Unable to get GatewaySensorAssociation
 */

/**
 * @swagger
 * /associationGatewaySensor/find/{gatewayId}:
 *   get:
 *     summary: Get all GatewaySensorAssociation by gatewayId
 *     tags:
 *       - GatewayModbus
 *     parameters:
 *       - in: path
 *         name: gatewayId
 *         description: The ID of the GatewaySensorAssociation to retrieve
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: A single GatewaySensorAssociation object
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewaySensorAssociation'
 *       '404':
 *         description: GatewaySensorAssociation not found
 *       '500':
 *         description: Unable to get GatewaySensorAssociation
 */

/**
 * @swagger
 * /associationGatewaySensor/{gatewayId}/slave/{slaveId}:
 *   get:
 *     summary: Get a GatewaySensorAssociation by gatewayId, slaveId
 *     tags:
 *       - GatewayModbus
 *     parameters:
 *       - in: path
 *         name: gatewayId
 *         description: The gatewayID of the GatewaySensorAssociation to retrieve
 *         required: true
 *       - in: path
 *         name: slaveId
 *         description: The slaveId of the GatewaySensorAssociation to retrieve
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: A multiple GatewaySensorAssociation object
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewaySensorAssociation'
 *       '404':
 *         description: GatewaySensorAssociation not found
 *       '500':
 *         description: Unable to get GatewaySensorAssociation
 */

/**
 * @swagger
 * /associationGatewaySensor/{gatewayId}/slave/{slaveId}/tag/{tag}:
 *   get:
 *     summary: Get a GatewaySensorAssociation by gatewayId, slaveId, tag
 *     tags:
 *       - GatewayModbus
 *     parameters:
 *       - in: path
 *         name: gatewayId
 *         description: The gatewayID of the GatewaySensorAssociation to retrieve
 *         required: true
 *       - in: path
 *         name: slaveId
 *         description: The slaveId of the GatewaySensorAssociation to retrieve
 *         required: true
 *       - in: path
 *         name: tag
 *         description: The tag of the GatewaySensorAssociation to retrieve
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: A single GatewaySensorAssociation object
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/GatewaySensorAssociation'
 *       '404':
 *         description: GatewaySensorAssociation not found
 *       '500':
 *         description: Unable to get GatewaySensorAssociation
 */

/**
 * @swagger
 * /associationGatewaySensor/createMultiple:
 *  post:
 *    summary: Create multiple mappings with the same gatewayId and slaveId
 *    tags:
 *      - GatewayModbus
 *    requestBody:
 *      description: Mapping data to create
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            properties:
 *              gatewayId:
 *                type: string
 *                description: The ID of the gateway.
 *              slaveId:
 *                type: string
 *                description: The ID of the slave.
 *              associationData:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    sensorId:
 *                      type: string
 *                      description: The ID of the sensor.
 *                    tag:
 *                      type: string
 *                      description: The tag for the association.
 *                    sensorNodeName:
 *                      type: string
 *                      description: Name of this sensor node.
 *                description: An array of association data objects.
 *              example:
 *                gatewayId: 650ab1180d743c5361e78d9f
 *                slaveId: 650ab1180d743c5361e78d9f
 *                associationData:
 *                  - sensorId: 650ab1180d743c5361e78d9f
 *                    tag: tag1
 *                    sensorNodeName: sensor1
 *                  - sensorId: 650ab1180d743c5361e78d9f
 *                    tag: tag2
 *                    sensorNodeName: sensor2
 *    responses:
 *      '201':
 *        description: Mapping created successfully
 *        content:
 *          application/json:
 *            schema:
 *              $ref: '#/components/schemas/GatewaySensorAssociation'
 *      '400':
 *        description: Bad request, invalid input data
 *        content:
 *          application/json:
 *            example:
 *              error: Invalid input data
 *      '500':
 *        description: Unable to create mapping
 *        content:
 *          application/json:
 *            example:
 *              error: Failed to create mapping
 */

/**
 * @swagger
 * /associationGatewaySensor:
 *  post:
 *    summary: Create a new mapping
 *    tags:
 *      - GatewayModbus
 *    requestBody:
 *      description: Mapping data to create
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *              $ref: '#/components/schemas/GatewaySensorAssociation'
 *    responses:
 *      '201':
 *        description: Mapping created successfully
 *        content:
 *          application/json:
 *            schema:
 *              $ref: '#/components/schemas/GatewaySensorAssociation'
 *      '400':
 *        description: Bad request, invalid input data
 *        content:
 *          application/json:
 *            example:
 *              error: Invalid input data
 *      '500':
 *        description: Unable to create mapping
 *        content:
 *          application/json:
 *            example:
 *              error: Failed to create mapping
 */

/**
 * @swagger
 * /associationGatewaySensor/{mappingId}:
 *  put:
 *    summary: Update a GatewaySensorAssociation by ID
 *    tags:
 *      - GatewayModbus
 *    parameters:
 *      - in: path
 *        name: mappingId
 *        description: ID of the GatewaySensorAssociation to update
 *        required: true
 *        schema:
 *          type: string
 *    requestBody:
 *        description: Mapping data to create
 *        required: true
 *        content:
 *          application/json:
 *           schema:
 *            $ref: '#/components/schemas/GatewaySensorAssociation'
 *    responses:
 *      '200':
 *        description: GatewaySensorAssociation updated successfully
 *        content:
 *          application/json:
 *            schema:
 *              $ref: '#/components/schemas/GatewaySensorAssociation'
 *      '400':
 *        description: Bad request, invalid input data
 *        content:
 *          application/json:
 *            example:
 *              error: Invalid input data
 *      '404':
 *        description: GatewaySensorAssociation not found
 *        content:
 *          application/json:
 *            example:
 *              error: GatewaySensorAssociation not found
 *      '500':
 *        description: Unable to update GatewaySensorAssociation
 *        content:
 *          application/json:
 *            example:
 *              error: Unable to update GatewaySensorAssociation
 */

/**
 * @swagger
 * /associationGatewaySensor/{mappingId}:
 *   delete:
 *     summary:  delete a GatewaySensorAssociation by ID
 *     tags:
 *       - GatewayModbus
 *     parameters:
 *       - in: path
 *         name: mappingId
 *         description: The ID of the GatewaySensorAssociation to  delete
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: GatewaySensorAssociation  deleted successfully
 *       '404':
 *         description: GatewaySensorAssociation not found
 *       '500':
 *         description: Unable to  delete GatewaySensorAssociation
 */

/**
 * @swagger
 * /associationGatewaySensor/softdel/{mappingId}:
 *   patch:
 *     summary: Soft delete a GatewaySensorAssociation by ID
 *     tags:
 *       - GatewayModbus
 *     parameters:
 *       - in: path
 *         name: mappingId
 *         description: The ID of the GatewaySensorAssociation to soft delete
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: GatewaySensorAssociation soft deleted successfully
 *       '404':
 *         description: GatewaySensorAssociation not found
 *       '500':
 *         description: Unable to soft delete GatewaySensorAssociation
 */

/**
 * @swagger
 * /associationGatewaySensor/softdel/{gatewayId}/slave/{slaveId}/tag/{tag}:
 *   patch:
 *     summary: Soft delete a GatewaySensorAssociation by ID
 *     tags:
 *       - GatewayModbus
 *     parameters:
 *       - in: path
 *         name: tag
 *       - in: path
 *         name: slaveId
 *       - in: path
 *         name: gatewayId
 *         description: The ID of the GatewaySensorAssociation to soft delete
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: GatewaySensorAssociation soft deleted successfully
 *       '404':
 *         description: GatewaySensorAssociation not found
 *       '500':
 *         description: Unable to soft delete GatewaySensorAssociation
 */

/**
 * @swagger
 * /associationGatewaySensor/softdel/{gatewayId}/slave/{slaveId}:
 *   patch:
 *     summary: Soft delete a GatewaySensorAssociation by slaveID and gatewayId
 *     tags:
 *       - GatewayModbus
 *     parameters:
 *       - in: path
 *         name: gatewayId
 *       - in: path
 *         name: slaveId
 *         description: The ID of the GatewaySensorAssociation to soft delete
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: GatewaySensorAssociation soft deleted successfully
 *       '404':
 *         description: GatewaySensorAssociation not found
 *       '500':
 *         description: Unable to soft delete GatewaySensorAssociation
 */

/**
 * @swagger
 * /associationGatewaySensor/softdel/sensor/{sensorId}:
 *   patch:
 *     summary: Soft delete a GatewaySensorAssociation by sensorId
 *     tags:
 *       - GatewayModbus
 *     parameters:
 *       - in: path
 *         name: sensorId
 *         description: The ID of the GatewaySensorAssociation to soft delete
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: GatewaySensorAssociation soft deleted successfully
 *       '404':
 *         description: GatewaySensorAssociation not found
 *       '500':
 *         description: Unable to soft delete GatewaySensorAssociation
 */
