# server side
  npm init -y 
  npm i express ejs dotenv morgan mongoose http-errors
  npm i --save-dev nodemon

  