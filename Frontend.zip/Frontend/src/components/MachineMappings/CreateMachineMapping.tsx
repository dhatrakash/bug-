import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
  RadioGroup,
  FormControlLabel,
  Radio,
  FormLabel,
} from "@mui/material";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";
import { fetchGateways } from "../../redux/gatewaySlice";
import { toast } from "react-toastify";
import {
  Gateway,
  GatewaySensorAssociation,
  Machine,
  MachineMapping,
  Mapping,
} from "../../redux/types";
import { fetchAllMappings as gatewaySensorMappings } from "../../redux/gatewaySensorAsscSlice";
import { fetchAllMappings as gatewayInputMappings } from "../../redux/gatewayInputAsscSlice";
import { createMachineMapping } from "../../redux/machineMappingSlice";

interface CreateMachineMappingProps {
  open: boolean;
  onClose: () => void;
  machineData?: Machine | null;
}

const initialGatewayData: Gateway = {
  macId: "",
  name: "",
  ip: "",
  port: 0,
  gatewayId: "",
  isActive: false,
};
// eslint-disable-next-line
const initialGatewaySensorAssociationData: GatewaySensorAssociation = {
  mappingId: "",
  sensorNodeName: "",
  gatewayId: "",
  sensorId: "",
  slaveId: "",
  tag: "",
};
const initialMachineMappingData: MachineMapping = {
  machineId: "",
  mappings: [],
};

const initialMappingData: Mapping = {
  mappingId: "",
  sensorNodeType: "io",
};
initialMachineMappingData.mappings.push(initialMappingData);

const CreateMachineMapping: React.FC<CreateMachineMappingProps> = ({
  open,
  onClose,
  machineData,
}) => {
  const dispatch = useMachinewiseDispatch();

  const { gateways } = useMachinewiseSelector((state) => state.gateway);
  const [gatewayData, setGatewayData] = useState<Gateway>(initialGatewayData);
  const { gatewaySensorAssociations } = useMachinewiseSelector(
    (state) => state.gatewaySensorAssociation
  );
  const { gatewayInputsAssociations } = useMachinewiseSelector(
    (state) => state.gatewayInputsAssociation
  );
  const [formData, setFormData] = useState<MachineMapping>(
    initialMachineMappingData
  );

  const [filteredSensorNodeNames, setFilteredSensorNodeNames] = useState<
    string[]
  >([]);
  // eslint-disable-next-line
  const [modbusMappings, setModbusMappings] = useState<string[]>([]);
  // eslint-disable-next-line
  const [ioMappings, setIoMappings] = useState<string[]>([]);

  const [selectedRadio, setSelectedRadio] = useState<"io" | "modbus">("io");
  const [selectedSensorNodeNames, setSelectedSensorNodeNames] = useState<
    string[]
  >([]);

  useEffect(() => {
    dispatch(fetchGateways());

    dispatch(gatewaySensorMappings()).then((result: any) => {
      // console.log("fetchGatewaySensorMappings result:", result);

      if (Array.isArray(result.payload)) {
        dispatch({
          type: "gatewaySensorAssociation/setGatewaySensorAssociations",
          payload: result.payload,
        });
        setModbusMappings(
          result.payload.map(
            (gsa: GatewaySensorAssociation) => gsa.sensorNodeName
          )
        );
      }
    });

    dispatch(gatewayInputMappings()).then((result: any) => {
      // console.log("fetchGatewayInputMappings result:", result);

      if (Array.isArray(result.payload)) {
        setIoMappings(
          result.payload.map(
            (gsa: GatewaySensorAssociation) => gsa.sensorNodeName
          )
        );
      }
    });

    // Set the initial machineId here based on machineData
    setFormData((prevFormData) => ({
      ...prevFormData,
      machineId: machineData?.machineId || "",
    }));
  }, [dispatch, machineData]);

  // useEffect(() => {
  //   let filteredSensorNodeNames: string[] = [];
  //   if (machineData?.gatewayId) {
  //     if (selectedRadio === "io" && gatewayInputsAssociations) {
  //       filteredSensorNodeNames = gatewayInputsAssociations
  //         .filter((mapping) => mapping.gatewayId === machineData.gatewayId)
  //         .map((mapping) => mapping.sensorNodeName);
  //       console.log("Filtered IO Sensor Node Names:", filteredSensorNodeNames);
  //     } else if (selectedRadio === "modbus" && gatewaySensorAssociations) {
  //       filteredSensorNodeNames = gatewaySensorAssociations
  //         .filter((mapping) => mapping.gatewayId === machineData.gatewayId)
  //         .map((mapping) => mapping.sensorNodeName);
  //       console.log(
  //         "Filtered Modbus Sensor Node Names:",
  //         filteredSensorNodeNames
  //       );
  //     }
  //   } else {
  //     console.log("No gateway ID available.");
  //   }
  //   setFilteredSensorNodeNames(filteredSensorNodeNames);
  // }, [
  //   machineData?.gatewayId,
  //   selectedRadio,
  //   gatewayInputsAssociations,
  //   gatewaySensorAssociations,
  // ]);
  /* eslint-disable react-hooks/exhaustive-deps */
  useEffect(() => {
    if (machineData?.gatewayId) {
      console.log("Selected Gateway ID:", machineData.gatewayId);
      console.log("Selected Radio:", selectedRadio);
      const selectedGateway = gateways?.find(
        (gateway) => gateway.gatewayId === machineData.gatewayId
      );
      if (selectedGateway) {
        setGatewayData(selectedGateway);
      }
      let filteredSensorNodeNames: string[] = [];

      if (selectedRadio === "io" && gatewayInputsAssociations) {
        filteredSensorNodeNames = gatewayInputsAssociations
          .filter((mapping) => {
            console.log("Filtering Mapping:", mapping);
            console.log("Mapping Gateway ID:", mapping.gatewayId);
            console.log(
              "Condition:",
              mapping.gatewayId === machineData.gatewayId
            );
            return mapping.gatewayId === machineData.gatewayId;
          })
          .map((mapping) => {
            console.log("Mapping Sensor Node Name:", mapping.sensorNodeName);
            return mapping.sensorNodeName;
          });
        console.log("Filtered IO Sensor Node Names:", filteredSensorNodeNames);
      } else if (selectedRadio === "modbus" && gatewaySensorAssociations) {
        filteredSensorNodeNames = gatewaySensorAssociations
          .filter((mapping) => {
            console.log("Filtering Mapping:", mapping);
            console.log("Mapping Gateway ID:", mapping.gatewayId);
            console.log(
              "Condition:",
              mapping.gatewayId === machineData.gatewayId
            );
            return mapping.gatewayId === machineData.gatewayId;
          })
          .map((mapping) => {
            console.log("Mapping Sensor Node Name:", mapping.sensorNodeName);
            return mapping.sensorNodeName;
          });
        console.log(
          "Filtered Modbus Sensor Node Names:",
          filteredSensorNodeNames
        );
      }
      setFilteredSensorNodeNames(filteredSensorNodeNames);
    }
  }, [
    machineData?.gatewayId,
    selectedRadio,
    gatewayInputsAssociations,
    gatewaySensorAssociations,
  ]);

  const handleSubmit = async () => {
    // Check if there are selected sensor node names
    if (selectedSensorNodeNames.length === 0) {
      console.error("No sensor node names selected.");
      return;
    }

    // Iterate over selected sensor node names
    for (const selectedSensorNodeName of selectedSensorNodeNames) {
      // Initialize mappingId as null
      let mappingId: string | null = null;

      if (selectedRadio === "io") {
        const ioMapping = gatewayInputsAssociations?.find(
          (ioMapping) => ioMapping.sensorNodeName === selectedSensorNodeName
        );

        if (ioMapping) {
          mappingId = ioMapping.mappingId as string;
        }
      } else if (selectedRadio === "modbus") {
        const modbusMapping = gatewaySensorAssociations?.find(
          (modbusMapping) =>
            modbusMapping.sensorNodeName === selectedSensorNodeName
        );

        if (modbusMapping) {
          mappingId = modbusMapping.mappingId as string;
        }
      }

      // Check if mappingId is still null or undefined, handle this case accordingly
      if (mappingId === null || mappingId === undefined) {
        console.error(
          "Mapping ID not found for sensor node name:",
          selectedSensorNodeName
        );
        continue; // Move to the next iteration if mappingId is not found
      }

      // Create a new machine mapping object based on your schema
      const newMachineMapping = {
        machineId: formData.machineId,
        mappings: [
          {
            mappingId: mappingId,
            sensorNodeType: selectedRadio,
          },
        ],
      };

      try {
        // Dispatch an action to create or update the machine mapping
        const response = await dispatch(
          createMachineMapping(newMachineMapping)
        );
        console.log("Response:", response);
        toast.success(
          `Mapping for ${selectedSensorNodeName} updated successfully.`
        );
      } catch (error) {
        toast.error(
          `Failed to update mapping for ${selectedSensorNodeName}. Please try again.`
        );
        console.error("Error:", error);
      }
    }
    setFormData(initialMachineMappingData);
    setSelectedSensorNodeNames([]);
    onClose(); // Close the dialog after processing all selected sensor node names
  };

  return (
    <Dialog open={open} maxWidth="sm">
      <DialogTitle
        style={{ color: "#1976d2", textAlign: "center", fontWeight: "bold" }}
      >
        Assign Gateway-Sensor Mappings to {machineData?.machineName}
      </DialogTitle>
      <DialogContent>
        <form style={{ padding: "20px" }} onSubmit={handleSubmit}>
          <Grid container spacing={1}>
            <Grid item xs={6}>
              <TextField
                label="Machine Name"
                size="small"
                name="machineName"
                value={machineData?.machineName}
                fullWidth
                margin="normal"
                disabled
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Machine Id"
                name="machineId"
                size="small"
                value={machineData?.machineId}
                fullWidth
                margin="normal"
                disabled
              />
            </Grid>
            {machineData?.gatewayId && gatewayData.macId ? (
              <>
                <Grid item xs={6}>
                  <TextField
                    label="Gateway Id"
                    size="small"
                    name="gatewayName"
                    value={machineData?.gatewayId}
                    fullWidth
                    margin="normal"
                    disabled
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    label="Gateway MAC ID"
                    size="small"
                    name="gatewayMacId"
                    value={gatewayData.macId}
                    fullWidth
                    margin="normal"
                    disabled
                  />
                </Grid>
              </>
            ) : (
              <Grid item xs={12}>
                <Typography
                  variant="body1"
                  color="textSecondary"
                  textAlign={"center"}
                >
                  {machineData?.gatewayId
                    ? "No MAC ID available for this gateway."
                    : "No gateway is assigned to this machine."}
                </Typography>
              </Grid>
            )}
            <Grid item xs={6}>
              <FormLabel component="legend">Sensor Type</FormLabel>
              <RadioGroup
                row
                aria-label="sensorNodeType"
                name="sensorNodeType"
                value={selectedRadio}
                onChange={(e) => {
                  setSelectedRadio(e.target.value as "io" | "modbus");
                }}
              >
                <FormControlLabel
                  value="io"
                  control={<Radio size="small" />}
                  label="IO"
                />
                <FormControlLabel
                  value="modbus"
                  control={<Radio size="small" />}
                  label="Modbus"
                />
              </RadioGroup>
            </Grid>
            <Grid item xs={6}>
              <FormControl fullWidth size="small" margin="normal">
                <InputLabel>Select Sensor Node Names</InputLabel>
                <Select
                  label="Select Sensor Node Names"
                  multiple // Enable multiple selections
                  value={selectedSensorNodeNames}
                  onChange={(e) => {
                    setSelectedSensorNodeNames(e.target.value as string[]);
                  }}
                >
                  {filteredSensorNodeNames.map((sensorNodeName) => (
                    <MenuItem key={sensorNodeName} value={sensorNodeName}>
                      {sensorNodeName}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            {/* {filteredSensorNodeNames.length > 0 ? (
              <Grid item xs={6}>
                <FormControl fullWidth size="small" margin="normal">
                  <InputLabel>Select Sensor NodeName</InputLabel>
                  <Select
                    // value={formData.sensorNodeName}
                    label="Select Sensor Nodename"
                    // onChange={(e) =>
                    //   handleNodeNameChange(e.target.value as string)
                    // }
                  >
                    {filteredSensorNodeNames.map((nodeName) => (
                      <MenuItem key={nodeName} value={nodeName}>
                        {nodeName}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            ) : (
              <Grid item xs={12}>
                <Typography
                  variant="body1"
                  color="textSecondary"
                  textAlign="center"
                >
                  {machineData?.gatewayId
                    ? "No sensor node names available for this gateway."
                    : "Please ! Assign a Gateway to your Machine"}
                </Typography>
              </Grid>
            )} */}
          </Grid>
        </form>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="primary">
          Cancel
        </Button>
        <Button onClick={handleSubmit} color="primary">
          Assign Sensors
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CreateMachineMapping;
