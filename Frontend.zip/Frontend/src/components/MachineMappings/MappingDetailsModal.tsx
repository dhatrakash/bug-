import React, { useState, useEffect } from "react";
import { useMachinewiseDispatch } from "../../redux/hooks";
import { fetchMachineById } from "../../redux/machineSlice";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Divider,
  Card,
  CardContent,
  IconButton,
  CardActions,
  CardHeader,
  Tooltip,
} from "@mui/material";
import { Archive as ArchiveIcon } from "@mui/icons-material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import NavigateBeforeIcon from "@mui/icons-material/NavigateBefore";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import {
  archiveMapping,
  fetchActiveMappingsByMachineId,
  // eslint-disable-next-line
  findMappingByMachineMappingId,
} from "../../redux/machineMappingSlice";
import { fetchGatewayById } from "../../redux/gatewaySlice";
import { fetchSensorById } from "../../redux/sensorSlice";
import { ToastContent, toast } from "react-toastify";
import ArchiveMachineMapping from "./ArchiveMachineMapping";

interface MappingDetailsProps {
  open: boolean;
  machineId: string | undefined;
  machineMappingId: string | undefined;

  onClose: () => void;
}

const MappingDetails: React.FC<MappingDetailsProps> = ({
  open,
  machineId,
  machineMappingId,
  onClose,
}) => {
  const dispatch = useMachinewiseDispatch();
  const [machineDetails, setMachineDetails] = useState<any>(null);
  const [machineMappingDetails, setMachineMappingDetails] = useState<any>(null);
  const [gatewayDetails, setGatewayDetails] = useState<any>(null);
  const [ioMappings, setIOMappings] = useState<any[]>([]);
  const [modbusMappings, setModbusMappings] = useState<any[]>([]);
  const [currentIOMappingIndex, setCurrentIOMappingIndex] = useState(0);
  const [currentModbusMappingIndex, setCurrentModbusMappingIndex] = useState(0);
  const [sensorDetails, setSensorDetails] = useState<any[]>([]);
  const [selectedMapping, setSelectedMapping] = useState<any>(null);
  const [archiveModalOpen, setArchiveModalOpen] = useState(false);

  useEffect(() => {
    if (machineId) {
      dispatch(fetchMachineById(machineId))
        .then((response: any) => {
          setMachineDetails(response.payload);
        })
        .catch((error: any) => {
          console.error("Error fetching machine details:", error);
        });
    }
  }, [dispatch, machineId]);
  /* eslint-disable react-hooks/exhaustive-deps */
  useEffect(() => {
    if (machineId) {
      dispatch(fetchActiveMappingsByMachineId(machineId))
        .then((response: any) => {
          setMachineMappingDetails(response.payload);

          if (
            response.payload.mappings &&
            response.payload.mappings.length > 0
          ) {
            const gatewayId = response.payload.mappings[0].mappingId.gatewayId;

            if (gatewayId) {
              dispatch(fetchGatewayById(gatewayId))
                .then((gatewayResponse: any) => {
                  setGatewayDetails(gatewayResponse.payload);
                })
                .catch((gatewayError: any) => {
                  console.error(
                    "Error fetching gateway details:",
                    gatewayError
                  );
                });
            }
          }
        })
        .catch((error: any) => {
          console.error("Error fetching machine mapping details:", error);
        });
    }
  }, [dispatch, machineMappingId]);

  useEffect(() => {
    if (machineMappingDetails && machineMappingDetails.isActive) {
      console.log("All machine Mapping details", machineMappingDetails);
      const ioMappings = machineMappingDetails.mappings.filter(
        (mapping: any) => mapping.sensorNodeType === "io"
      );
      setIOMappings(ioMappings);

      const modbusMappings = machineMappingDetails.mappings.filter(
        (mapping: any) => mapping.sensorNodeType === "modbus"
      );
      console.log("thanks for modbus", modbusMappings);
      setModbusMappings(modbusMappings);

      // Fetch sensor details for ioMappings
      ioMappings.forEach(async (ioMapping: any) => {
        const sensorId = ioMapping.mappingId?.sensorId;
        if (sensorId) {
          try {
            const sensorDetailsResponse = await dispatch(
              fetchSensorById(sensorId)
            );

            if (sensorDetailsResponse.payload) {
              // Store sensor details with the sensor ID as the key
              setSensorDetails((prevSensorDetails) => ({
                ...prevSensorDetails,
                [sensorId]: sensorDetailsResponse.payload,
              }));
            } else {
              console.error("No sensor details found for sensorId:", sensorId);
            }
          } catch (error) {
            console.error("Error fetching sensor details:", error);
          }
        }
      });

      // Fetch sensor details for modbusMappings
      modbusMappings.forEach(async (modbusMapping: any) => {
        const sensorId = modbusMapping.mappingId?.sensorId;
        if (sensorId) {
          try {
            const sensorDetailsResponse = await dispatch(
              fetchSensorById(sensorId)
            );

            if (sensorDetailsResponse.payload) {
              // Store sensor details with the sensor ID as the key
              setSensorDetails((prevSensorDetails) => ({
                ...prevSensorDetails,
                [sensorId]: sensorDetailsResponse.payload,
              }));
            } else {
              console.error("No sensor details found for sensorId:", sensorId);
            }
          } catch (error) {
            console.error("Error fetching sensor details:", error);
          }
        }
      });
    }
  }, [dispatch, machineMappingDetails]);

  const handlePrevIOMapping = () => {
    if (currentIOMappingIndex > 0) {
      setCurrentIOMappingIndex(currentIOMappingIndex - 1);
    }
  };

  const handleNextIOMapping = () => {
    if (currentIOMappingIndex < ioMappings.length - 1) {
      setCurrentIOMappingIndex(currentIOMappingIndex + 1);
    }
  };

  const handlePrevModbusMapping = () => {
    if (currentModbusMappingIndex > 0) {
      setCurrentModbusMappingIndex(currentModbusMappingIndex - 1);
    }
  };

  const handleNextModbusMapping = () => {
    if (currentModbusMappingIndex < modbusMappings.length - 1) {
      setCurrentModbusMappingIndex(currentModbusMappingIndex + 1);
    }
  };
  const handleArchiveMapping = (mappingId: string) => {
    setSelectedMapping(mappingId);
    setArchiveModalOpen(true);
    console.log(`Archiving mapping with ID: ${mappingId}`);
  };
  const handleCloseArchiveModal = () => {
    setSelectedMapping(null);
    setArchiveModalOpen(false);
  };
  const handleArchiveAssociation = async () => {
    console.log("Dispatching archive action...");
    if (machineMappingId) {
      try {
        const resultAction: any = await dispatch(
          archiveMapping({
            machineMappingId,
            mappingId: selectedMapping,
          })
        );

        // Check if the action is fulfilled (success)
        if (archiveMapping.fulfilled.match(resultAction)) {
          const response = resultAction.payload;
          console.log("Archive action dispatched successfully!", response);

          if (response) {
            console.log("Machine MappingId archived!!!", response);
            toast.success("Machine Mapping archived!!!");
          } else {
            console.error("Invalid response from the server");
            toast.error(
              "Error while archiving. Invalid response from the server."
            );
          }
        } else if (archiveMapping.rejected.match(resultAction)) {
          // Check if the action is rejected (failure)
          const errorMessage = resultAction.payload; // Access the error message from the rejected action
          console.error(`Error while archiving: ${errorMessage}`);
          toast.error(errorMessage as ToastContent<unknown>);
        }
      } catch (error: any) {
        const errorMessage = error.message || "Error while archiving.";
        console.error(`Error while archiving: ${errorMessage}`);
        toast.error(errorMessage as ToastContent<unknown>);
      }
    } else {
      console.error("machineMappingId is missing. Unable to archive.");
    }

    // Close the delete confirmation modal
    handleCloseArchiveModal();
  };

  console.log("machineMappingDetails", machineMappingDetails);
  console.log("sensor details", sensorDetails);
  return (
    <Dialog open={open}>
      <DialogTitle
        style={{ color: "#1976d2", textAlign: "center", fontWeight: "bold" }}
      >
        Additional Details
      </DialogTitle>
      <DialogContent>
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            Details for Machine ID: {machineId}
          </AccordionSummary>
          <AccordionDetails>
            {machineDetails ? (
              <>
                <Divider
                  style={{
                    color: "#1976d2",
                    paddingTop: "10px",
                    paddingBottom: "10px",
                  }}
                >
                  <Typography
                    variant="h4"
                    fontSize="20px"
                    style={{ color: "#1976d2" }}
                  >
                    Machine Details
                  </Typography>
                </Divider>
                <Typography>Machine ID: {machineId}</Typography>
                {machineDetails.machineName && (
                  <Typography>
                    Machine Name: {machineDetails.machineName}
                  </Typography>
                )}
                {machineDetails.machine_type && (
                  <Typography>
                    Machine Type: {machineDetails.machine_type}
                  </Typography>
                )}
              </>
            ) : (
              <Typography>Loading Machine Details...</Typography>
            )}
          </AccordionDetails>
        </Accordion>
        <Accordion>
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            style={{ justifyContent: "center" }}
          >
            Details for Machine Mapping ID: {machineMappingId}
          </AccordionSummary>
          <AccordionDetails>
            {machineMappingDetails ? (
              <>
                <Divider
                  style={{
                    color: "#1976d2",
                    paddingTop: "10px",
                    paddingBottom: "10px",
                  }}
                >
                  <Typography
                    variant="h4"
                    fontSize="20px"
                    style={{ color: "#1976d2" }}
                  >
                    Machine Mapping Details
                  </Typography>
                </Divider>
                <Typography>Machine Mapping ID: {machineMappingId}</Typography>
                {gatewayDetails && (
                  <>
                    <Divider
                      style={{
                        color: "#1976d2",
                        paddingTop: "10px",
                        paddingBottom: "10px",
                      }}
                    >
                      <Typography
                        variant="h4"
                        fontSize="20px"
                        style={{ color: "#1976d2" }}
                      >
                        Gateway Details
                      </Typography>
                    </Divider>
                    <Typography>Gateway ID: {gatewayDetails._id}</Typography>
                    <Typography>
                      Gateway MAC ID: {gatewayDetails.macId}
                    </Typography>
                    <Typography>Gateway Name: {gatewayDetails.name}</Typography>
                    <Typography>Gateway Port: {gatewayDetails.port}</Typography>
                    <Typography>Gateway IP: {gatewayDetails.ip}</Typography>
                  </>
                )}

                {(ioMappings.length > 0 || modbusMappings.length > 0) && (
                  <>
                    <Divider
                      style={{
                        color: "#1976d2",
                        paddingTop: "10px",
                        paddingBottom: "10px",
                      }}
                    >
                      <Typography
                        variant="h4"
                        fontSize="20px"
                        style={{ color: "#1976d2" }}
                      >
                        Mappings based on Sensor Node Type
                      </Typography>
                    </Divider>
                    <div style={{ display: "flex", justifyContent: "center" }}>
                      <IconButton
                        onClick={handlePrevIOMapping}
                        disabled={currentIOMappingIndex === 0}
                      >
                        <NavigateBeforeIcon />
                      </IconButton>

                      {ioMappings.length > 0 ? (
                        ioMappings.map((mapping: any, index: number) => (
                          <div
                            key={index}
                            style={{
                              display:
                                index === currentIOMappingIndex
                                  ? "block"
                                  : "none",
                              width: "100%",
                            }}
                          >
                            <Card
                              style={{
                                margin: "4px",
                                // backgroundColor: "beige",
                              }}
                              variant="outlined"
                            >
                              <CardHeader
                                title="IO Mapping Details"
                                titleTypographyProps={{
                                  style: { fontSize: "16px" },
                                }}
                                // subheader="IO Mapping Details"
                                style={{
                                  textAlign: "center",
                                  backgroundColor: "#e1f5fe",
                                }}
                              />
                              <CardContent
                                style={{
                                  backgroundColor: "#f8fdff",
                                }}
                              >
                                <Typography>
                                  Mapping ID: {mapping.mappingId?._id}
                                </Typography>
                                <Typography>
                                  Sensor Node Type: {mapping.sensorNodeType}
                                </Typography>
                                <Typography>
                                  DI ID: {mapping.mappingId?.slaveId}
                                </Typography>
                                <Typography>
                                  Sensor Node Name:{" "}
                                  {mapping.mappingId?.sensorNodeName}
                                </Typography>
                                <Typography>
                                  Tag: {mapping.mappingId?.tag}
                                </Typography>
                                <Typography>
                                  SensorId: {mapping.mappingId?.sensorId}
                                </Typography>{" "}
                                {sensorDetails[mapping.mappingId?.sensorId] && (
                                  <>
                                    <Divider />
                                    <Typography variant="h6">
                                      Sensor Details
                                    </Typography>
                                    <Typography>
                                      Sensor Name:{" "}
                                      {
                                        sensorDetails[
                                          mapping.mappingId?.sensorId
                                        ].sensorName
                                      }
                                    </Typography>{" "}
                                    <Typography>
                                      Sensor Type:{" "}
                                      {
                                        sensorDetails[
                                          mapping.mappingId?.sensorId
                                        ].sensorType
                                      }
                                    </Typography>
                                  </>
                                )}{" "}
                              </CardContent>{" "}
                              <CardActions
                                style={{
                                  display: "flex",
                                  justifyContent: "center",
                                  backgroundColor: "#e1f5fe",
                                }}
                              >
                                <Tooltip title="Soft Delete">
                                  <IconButton
                                    onClick={() =>
                                      handleArchiveMapping(
                                        mapping.mappingId?.mappingId
                                      )
                                    }
                                  >
                                    <ArchiveIcon sx={{ color: "#445cff" }} />
                                  </IconButton>
                                </Tooltip>
                              </CardActions>
                            </Card>{" "}
                          </div>
                        ))
                      ) : (
                        <Typography
                          variant="body2"
                          style={{ paddingTop: "10px" }}
                        >
                          No IO mappings available
                        </Typography>
                      )}
                      <IconButton
                        onClick={handleNextIOMapping}
                        disabled={
                          currentIOMappingIndex === ioMappings.length - 1
                        }
                      >
                        <NavigateNextIcon />
                      </IconButton>
                    </div>
                    <div style={{ display: "flex", justifyContent: "center" }}>
                      <IconButton
                        onClick={handlePrevModbusMapping}
                        disabled={currentModbusMappingIndex === 0}
                      >
                        <NavigateBeforeIcon />
                      </IconButton>

                      {modbusMappings.length > 0 ? (
                        modbusMappings.map((mapping: any, index: number) => (
                          <div
                            key={index}
                            style={{
                              display:
                                index === currentModbusMappingIndex
                                  ? "block"
                                  : "none",
                              width: "100%",
                            }}
                          >
                            <Card style={{ margin: "4px" }}>
                              {" "}
                              <CardHeader
                                title="Modbus Mapping Details"
                                titleTypographyProps={{
                                  style: { fontSize: "16px" },
                                }}
                                // subheader="IO Mapping Details"
                                style={{
                                  textAlign: "center",
                                  backgroundColor: "#eefffc",
                                }}
                              />
                              <CardContent
                                style={{
                                  backgroundColor: "#fcffff",
                                }}
                              >
                                <Typography>
                                  Mapping ID: {mapping.mappingId?.mappingId}
                                </Typography>
                                <Typography>
                                  Sensor Node Type: {mapping.sensorNodeType}
                                </Typography>
                                <Typography>
                                  Slave ID: {mapping.mappingId?.slaveId}
                                </Typography>
                                <Typography>
                                  Sensor Node Name:{" "}
                                  {mapping.mappingId?.sensorNodeName}
                                </Typography>
                                <Typography>
                                  Tag: {mapping.mappingId?.tag}
                                </Typography>
                                <Typography>
                                  SensorId: {mapping.mappingId?.sensorId}
                                </Typography>
                                {sensorDetails[mapping.mappingId?.sensorId] && (
                                  <div>
                                    <Divider />
                                    <Typography variant="h6">
                                      Sensor Details
                                    </Typography>
                                    <Typography>
                                      Sensor Name:{" "}
                                      {
                                        sensorDetails[
                                          mapping.mappingId?.sensorId
                                        ].sensorName
                                      }
                                    </Typography>{" "}
                                    <Typography>
                                      Sensor Type:{" "}
                                      {
                                        sensorDetails[
                                          mapping.mappingId?.sensorId
                                        ].sensorType
                                      }
                                    </Typography>
                                  </div>
                                )}
                              </CardContent>{" "}
                              <CardActions
                                style={{
                                  display: "flex",
                                  justifyContent: "center",
                                  backgroundColor: "#eefffc",
                                }}
                              >
                                <Tooltip title="Soft Delete">
                                  <IconButton
                                    onClick={() =>
                                      handleArchiveMapping(
                                        mapping.mappingId?.mappingId
                                      )
                                    }
                                  >
                                    <ArchiveIcon sx={{ color: "#445cff" }} />
                                  </IconButton>
                                </Tooltip>
                              </CardActions>
                            </Card>
                          </div>
                        ))
                      ) : (
                        <Typography
                          variant="body2"
                          style={{ paddingTop: "10px" }}
                        >
                          No Modbus mappings available
                        </Typography>
                      )}
                      <IconButton
                        onClick={handleNextModbusMapping}
                        disabled={
                          currentModbusMappingIndex ===
                          modbusMappings.length - 1
                        }
                      >
                        <NavigateNextIcon />
                      </IconButton>
                    </div>
                  </>
                )}
              </>
            ) : (
              <Typography>Loading Association Details...</Typography>
            )}
          </AccordionDetails>
        </Accordion>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="primary">
          Close
        </Button>
      </DialogActions>
      <ArchiveMachineMapping
        open={archiveModalOpen}
        onClose={handleCloseArchiveModal}
        onArchive={handleArchiveAssociation}
      />
    </Dialog>
  );
};

export default MappingDetails;
