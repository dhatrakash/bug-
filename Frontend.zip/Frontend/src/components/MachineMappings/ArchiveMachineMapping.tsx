import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
} from "@mui/material";

interface ArchiveMachineMappingProps {
  open: boolean;
  onClose: () => void;
  onArchive: () => void;
}

const ArchiveMachineMapping: React.FC<ArchiveMachineMappingProps> = ({
  open,
  onClose,
  onArchive,
}) => {
  return (
    <Dialog open={open} fullWidth maxWidth="sm">
      <DialogTitle>Confirm Archive</DialogTitle>
      <DialogContent>
        <DialogContentText>
          Your Association will be Archived!!!! Are yo Sure?
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="primary">
          Cancel
        </Button>
        <Button onClick={onArchive} color="primary">
          Archive
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ArchiveMachineMapping;
