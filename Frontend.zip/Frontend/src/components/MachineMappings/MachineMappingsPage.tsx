import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";
// import DetailsModal from "./SlaveDetailsModal"; // Import the modal component
import { Machine, MachineMapping } from "../../redux/types";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Paper,
  Typography,
  IconButton,
  Tooltip,
} from "@mui/material";
import {
  Delete as DeleteIcon,
  Archive as ArchiveIcon,
  Visibility as ViewIcon,
} from "@mui/icons-material";
// import { IOIcon, ModbusIcon } from "./CustomIcons"; // Import your custom icons

import {
  archiveMachineMapping,
  deleteMachineMapping,
  fetchActiveMappingsByMachineId,
} from "../../redux/machineMappingSlice";
import { toast } from "react-toastify";
import DeleteMachineMapping from "./DeleteMachineMapping";
import ArchiveMachineMapping from "./ArchiveMachineMapping";
import ModbusMappingDetails from "./MappingDetailsModal";
const MachineMappingsPage: React.FC = () => {
  const { machineId } = useParams<{ machineId: string }>();
  const dispatch = useMachinewiseDispatch();
  const [selectedAssociation, setSelectedAssociation] = useState<any>(null);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [selectedAssociationForDelete, setSelectedAssociationForDelete] =
    useState<MachineMapping | null>(null);

  const [archiveModalOpen, setArchiveModalOpen] = useState(false);
  const [modbusDetailsModalOpen, setModbusDetailsModalOpen] = useState(false); // State for the modal
  const [selectedModbusDetails, setSelectedModbusDetails] = useState<{
    machineId: string;
    machineMappingId: string;
    modbusMappingIds: string[];
  } | null>(null);
  // eslint-disable-next-line
  const [showIOMappings, setShowIOMappings] = useState(true);
  // eslint-disable-next-line
  const [showModbusMappings, setShowModbusMappings] = useState(true);

  useEffect(() => {
    if (machineId) {
      dispatch(fetchActiveMappingsByMachineId(machineId))
        .then((response: any) => {
          console.log("Fetch response:", response);
        })
        .catch((error: any) => {
          console.error("Fetch error:", error);
        });
    }
  }, [dispatch, machineId]);

  const selectedMachine: Machine | null | undefined = useMachinewiseSelector(
    (state) =>
      state.machine.machines.find(
        (machine: Machine) => machine.machineId === machineId
      )
  );
  const machineMappings: MachineMapping[] | null = useMachinewiseSelector(
    (state) => state.machineMapping.machineMappings
  );

  // Create a separate variable to store the data received from dispatch
  const fetchedAssociations = machineMappings || [];

  console.log("machineMappings", fetchedAssociations);

  if (!selectedMachine) {
    return <Typography variant="h5">Machine not found</Typography>;
  }

  const handleDeleteClick = (association: MachineMapping) => {
    setSelectedAssociationForDelete(association);
    setDeleteModalOpen(true);
  };

  const handleCloseDeleteModal = () => {
    setSelectedAssociationForDelete(null);
    setDeleteModalOpen(false);
  };
  const handleDeleteAssociation = async () => {
    if (
      !selectedAssociationForDelete ||
      !selectedAssociationForDelete.machineMappingId
    ) {
      // Handle the case where selectedAssociationForDelete or mappingId is missing
      return;
    }

    try {
      // Dispatch the delete action with machineId and sensorNodeName
      await dispatch(
        deleteMachineMapping({
          machineMappingId: selectedAssociationForDelete.machineMappingId,
        })
      );
      // navigate(`/machineGatewayAssociation/${machineId}`);
      toast.success("Machine Mapping deleted successfully");
    } catch (error) {
      // Handle any errors
      console.error("Error deleting Machine Mapping:", error);
      toast.error("Error deleting Machine Mapping. Please try again.");
    }

    // Close the delete confirmation modal
    handleCloseDeleteModal();
  };
  const handleArchiveClick = (association: MachineMapping) => {
    setSelectedAssociation(association);
    setArchiveModalOpen(true);
  };
  const handleCloseArchiveModal = () => {
    setSelectedAssociation(null);
    setArchiveModalOpen(false);
  };
  const handleArchiveAssociation = async () => {
    if (!selectedAssociation || !selectedAssociation.machineMappingId) {
      return;
    }

    try {
      // Dispatch the archive action
      await dispatch(
        archiveMachineMapping({
          machineMappingId: selectedAssociation.machineMappingId,
        })
      );
      //  navigate(`/machineGatewayAssociation/${machineId}`);
      toast.success("Machine MappingId archived!!!");
    } catch (error) {
      // Handle any errors
      console.error("Error while archive:", error);
      toast.error("Error while archive.");
    }

    // Close the delete confirmation modal
    handleCloseArchiveModal();
  };
  // Function to handle opening the accordion and modal
  // const handleAccordionClick = (machineId: string, mappingId: string) => {
  //   setSelectedDetails({ machineId, mappingId });
  //   setExpandedAccordion(machineId); // Expand the specific accordion
  //   setDetailsModalOpen(true); // Open the modal
  // };

  // const handleOpenDetailsModal = (machineId: string, mappingId: string) => {
  //   setSelectedDetails({ machineId, mappingId });
  //   setDetailsModalOpen(true); // Open the modal
  // };

  // // Function to close the modal
  // const handleCloseDetailsModal = () => {
  //   setSelectedDetails(null);
  //   setDetailsModalOpen(false);
  // };
  const handleModbusDetailsClick = (
    machineId: string,
    machineMappingId: string,
    modbusMappingIds: string[]
  ) => {
    // Check if machineMappingId is defined before opening the modal
    if (machineMappingId) {
      setSelectedModbusDetails({
        machineId,
        machineMappingId: machineMappingId as string,
        modbusMappingIds: modbusMappingIds.map((id) => id as string),
      });
      setModbusDetailsModalOpen(true);
    }
  };
  // const handleOpenModbusDetailsModal = (
  //   machineId: string,
  //   machineMappingId: string
  //   modbusMappingIds:string[]
  // ) => {
  //   setSelectedModbusDetails({ machineId, machineMappingId, modbusMappingIds });
  //   setModbusDetailsModalOpen(true);
  // };
  return (
    <div className="gateway-sensor-details">
      <h2 style={{ color: "#1976d2", textAlign: "center", fontWeight: "500" }}>
        Machine Mappings
      </h2>
      <Paper className="details-paper">
        <Typography variant="h5" paddingBottom={"20px"}>
          Machine Name: {selectedMachine.machineName}
        </Typography>{" "}
        {/* <div
          style={{
            display: "flex",
            justifyContent: "center",
            marginBottom: "20px",
          }}
        >
          <Chip
            label="IO Mappings"
            onClick={() => setShowIOMappings(!showIOMappings)}
            color={showIOMappings ? "primary" : "default"}
            style={{ marginRight: "10px" }}
          />
          <Chip
            label="Modbus Mappings"
            onClick={() => setShowModbusMappings(!showModbusMappings)}
            color={showModbusMappings ? "primary" : "default"}
          />
        </div> */}
        {/* <div className="filter-fields">ADD FILTERS</div> */}
        {/* {console.log("Should render table:", fetchedAssociations)} */}
        {/* Render the table if data is available */}
        {fetchedAssociations.length > 0 ? (
          <Table className="details-table">
            <TableHead>
              <TableRow>
                <TableCell>Machine ID</TableCell>
                <TableCell>Machine Mapping ID</TableCell>
                {showIOMappings && <TableCell>IO Mapping IDs</TableCell>}
                {showModbusMappings && (
                  <TableCell>Modbus Mapping IDs</TableCell>
                )}

                {/* <TableCell>Sensor Node Name</TableCell> */}
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {machineMappings &&
                machineMappings.flat().map((association) => (
                  <TableRow key={association._id}>
                    <TableCell>{association.machineId}</TableCell>
                    <TableCell>{association.machineMappingId}</TableCell>
                    {showIOMappings && (
                      <TableCell>
                        {association.mappings
                          .filter((mapping) => mapping.sensorNodeType === "io")
                          .map((mapping, index) => (
                            <span
                              key={
                                mapping.mappingId &&
                                typeof mapping.mappingId === "object"
                                  ? (mapping.mappingId as { mappingId: string })
                                      .mappingId
                                  : mapping.mappingId
                              }
                            >
                              {index > 0 && ", "}
                              {mapping.mappingId &&
                              typeof mapping.mappingId === "object"
                                ? (mapping.mappingId as { mappingId: string })
                                    .mappingId
                                : mapping.mappingId}
                            </span>
                          ))}
                      </TableCell>
                    )}
                    {showModbusMappings && (
                      <TableCell>
                        {association.mappings
                          .filter(
                            (mapping) => mapping.sensorNodeType === "modbus"
                          )
                          .map((mapping, index) => (
                            <span
                              key={
                                mapping.mappingId &&
                                typeof mapping.mappingId === "object"
                                  ? (mapping.mappingId as { mappingId: string })
                                      .mappingId
                                  : mapping.mappingId
                              }
                            >
                              {index > 0 && ", "}
                              {mapping.mappingId &&
                              typeof mapping.mappingId === "object"
                                ? (mapping.mappingId as { mappingId: string })
                                    .mappingId
                                : mapping.mappingId}
                            </span>
                          ))}
                      </TableCell>
                    )}

                    <TableCell>
                      <Tooltip title="See Details">
                        <IconButton
                          onClick={() => {
                            if (association.machineMappingId) {
                              // Check if it's defined
                              handleModbusDetailsClick(
                                association.machineId,
                                association.machineMappingId,
                                association.mappings.map(
                                  (mapping) => mapping.mappingId
                                )
                              );
                            }
                          }}
                        >
                          <ViewIcon />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Archive Machine Mapping" arrow>
                        <IconButton
                          // color="primary"
                          onClick={() => handleArchiveClick(association)}
                        >
                          <ArchiveIcon style={{ color: "#20b2aa" }} />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete Machine Mapping permanently">
                        <IconButton
                          color="error"
                          onClick={() => handleDeleteClick(association)}
                        >
                          <DeleteIcon />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}{" "}
            </TableBody>
          </Table>
        ) : (
          <Typography variant="h6">No associations found.</Typography>
        )}
      </Paper>{" "}
      <DeleteMachineMapping
        open={deleteModalOpen}
        onClose={handleCloseDeleteModal}
        onDelete={handleDeleteAssociation}
      />
      <ArchiveMachineMapping
        open={archiveModalOpen}
        onClose={handleCloseArchiveModal}
        onArchive={handleArchiveAssociation}
      />{" "}
      {modbusDetailsModalOpen && (
        <ModbusMappingDetails
          open={modbusDetailsModalOpen}
          machineId={selectedModbusDetails?.machineId}
          machineMappingId={selectedModbusDetails?.machineMappingId}
          onClose={() => setModbusDetailsModalOpen(false)}
        />
      )}
    </div>
  );
};

export default MachineMappingsPage;
