import React, { useState, useEffect } from "react";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";
import { updateGateway } from "../../redux/gatewaySlice";
import { RootState } from "../../redux/store";
import { Gateway } from "../../redux/types";
import { toast } from "react-toastify";
import {
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  CircularProgress,
  Switch,
  IconButton,
} from "@mui/material";
import { makeStyles } from "@mui/styles"; // Import makeStyles and Theme
import CloseIcon from "@mui/icons-material/Close";
interface EditGatewayProps {
  showModal: boolean;
  closeModal: () => void;
  gatewayData: Gateway;
}
const useStyles = makeStyles(() => ({
  title: {
    paddingBottom: "10px",
    color: "#1976D2",
  },

  closeButton: {
    position: "relative",
    // top: "8px",
    // right: "8px",
  },
  titleContainer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    paddingBottom: "10px",
    color: "#1976D2",
  },
  requiredAsterisk: {
    color: "red",
  },
  inputField: {
    fontSize: "14px",
    padding: "8px",
    height: "44px",
  },

  // label: {
  //   fontSize: "14px",
  //   color: "blue",

  // },
}));
const EditGateway: React.FC<EditGatewayProps> = ({
  showModal,
  closeModal,
  gatewayData,
}) => {
  const gatewayDispatch = useMachinewiseDispatch();
  const { loading, error } = useMachinewiseSelector(
    (state: RootState) => state.gateway
  );
  const [isActive, setIsActive] = useState<boolean>(gatewayData.isActive);

  // Use a local state to track the edited gateway data
  const [editedGatewayData, setEditedGatewayData] =
    useState<Gateway>(gatewayData);
  const classes = useStyles();

  // Update the local state if gatewayData changes
  useEffect(() => {
    setEditedGatewayData(gatewayData);
    setIsActive(gatewayData.isActive);
  }, [gatewayData]);

  // Handle input changes
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setEditedGatewayData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  const handleIsActiveChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setIsActive(event.target.checked);
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const updatedGatewayData = { ...editedGatewayData };
    updatedGatewayData.isActive = isActive;
    // Make sure there's an ID before dispatching the update
    try {
      // Dispatch the updateGateway action
      const gatewayAction = await gatewayDispatch(
        updateGateway(updatedGatewayData)
      );
      if (updateGateway.fulfilled.match(gatewayAction)) {
        closeModal();
        toast.success("Gateway updated successfully!");
      } else {
        toast.error("Failed to update gateway!");
      }
    } catch (error) {
      console.error("An error occurred while updating the gateway:", error);
      toast.error("An error occurred");
    }
  };
  const handleCloseModal = () => {
    closeModal();
  };
  return (
    <Dialog
      open={showModal}
      maxWidth="sm"
      PaperProps={{
        style: {
          boxShadow: showModal ? "0px 4px 6px rgba(25, 118, 210, 0.1)" : "none",
        },
      }}
    >
      {" "}
      <DialogTitle>
        <div className={classes.titleContainer}>
          <span>Edit Gateway</span>
          <IconButton
            aria-label="close"
            className={classes.closeButton}
            onClick={handleCloseModal}
          >
            <CloseIcon />
          </IconButton>
        </div>
      </DialogTitle>{" "}
      <DialogContent>
        {loading ? (
          <div style={{ textAlign: "center" }}>
            <CircularProgress />
          </div>
        ) : error ? (
          <DialogContentText color="error">{error}</DialogContentText>
        ) : (
          <form style={{ padding: "20px" }} onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label={
                    <span>
                      MAC ID<span className={classes.requiredAsterisk}>*</span>
                    </span>
                  }
                  name="macId"
                  value={editedGatewayData.macId}
                  onChange={handleInputChange}
                  InputProps={{
                    disableUnderline: true,
                    className: classes.inputField,
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label={
                    <span>
                      Name<span className={classes.requiredAsterisk}>*</span>
                    </span>
                  }
                  name="name"
                  value={editedGatewayData.name}
                  onChange={handleInputChange}
                  InputProps={{
                    className: classes.inputField,
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label={
                    <span>
                      IP<span className={classes.requiredAsterisk}>*</span>
                    </span>
                  }
                  name="ip"
                  value={editedGatewayData.ip}
                  onChange={handleInputChange}
                  InputProps={{
                    className: classes.inputField,
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label={
                    <span>
                      Port<span className={classes.requiredAsterisk}>*</span>
                    </span>
                  }
                  name="port"
                  type="number"
                  value={editedGatewayData.port}
                  onChange={handleInputChange}
                  InputProps={{
                    className: classes.inputField,
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <label>
                  Is Active
                  <Switch
                    name="isActive"
                    checked={isActive}
                    onChange={handleIsActiveChange}
                  />
                </label>
              </Grid>
            </Grid>
            <DialogActions>
              <Button
                variant="contained"
                color="primary"
                type="submit"
                disabled={loading}
              >
                Save Changes
              </Button>
            </DialogActions>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default EditGateway;
