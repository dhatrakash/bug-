import React, { useEffect } from "react";
import { useDispatch } from "react-redux";
import { fetchGateways } from "../../redux/gatewaySlice";
import AllGateway from "./AllGateway";
import "../../assets/css/Gateway.css";
const Gateways: React.FC = () => {
  const dispatch = useDispatch();

  // Fetch machines when the component mounts
  useEffect(() => {
    dispatch(fetchGateways() as any);
  }, [dispatch]);
  return (
    <>
      <div className="gateway-container">
        <h5>
          <span>Gateway's List</span>
        </h5>
        <AllGateway />
      </div>
    </>
  );
};

export default Gateways;
