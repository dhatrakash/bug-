import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
} from "@mui/material";
import { Gateway } from "../../redux/types";
import { makeStyles } from "@mui/styles";
import { createTheme } from "@mui/material/styles";

const useStyles = makeStyles((theme: any) => ({
  centerModal: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  card: {
    maxWidth: "400px",
    borderRadius: "10px",
  },
  activeCard: {
    border: `2px solid green`,
    boxShadow: "0px 0px 10px rgba(0, 128, 0, 0.5)",
    backgroundColor: "#f0fff0", // Light green background color
  },
  inactiveCard: {
    border: `2px solid red`,
    boxShadow: "0px 0px 10px rgba(255, 0, 0, 0.9)", // Add a shadow effect
    backgroundColor: "#fff0f0", // Light red background color
  },
  title: {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.common.white,
    borderTopLeftRadius: "10px",
    borderTopRightRadius: "10px",
  },
  content: {
    padding: theme.spacing(2),
  },
  closeButton: {
    color: theme.palette.primary.main,
  },
}));

interface ViewGatewayModalProps {
  open: boolean;
  handleClose: () => void;
  gateway: Gateway | null;
}

const theme = createTheme();

const ViewGatewayModal: React.FC<ViewGatewayModalProps> = ({
  open,
  handleClose,
  gateway,
}) => {
  const classes = useStyles(theme);

  return (
    <Dialog open={open} onClose={handleClose} className={classes.centerModal}>
      <div
        className={`${classes.card} ${
          gateway?.isActive ? classes.activeCard : classes.inactiveCard
        }`}
      >
        <DialogTitle className={classes.title}>
          View Gateway Details
        </DialogTitle>
        <DialogContent className={classes.content}>
          {gateway ? (
            <>
              <Typography variant="h6">Gateway Name: {gateway.name}</Typography>
              <Typography variant="h6">
                Gateway MAC ID: {gateway.macId}
              </Typography>
              <Typography variant="h6"> Gateway IP: {gateway.ip}</Typography>

              <Typography variant="h6">
                Is Active: {gateway.isActive ? "Yes" : "No"}
              </Typography>
            </>
          ) : (
            <Typography variant="h6">Gateway not found</Typography>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} className={classes.closeButton}>
            Close
          </Button>
        </DialogActions>
      </div>
    </Dialog>
  );
};

export default ViewGatewayModal;
