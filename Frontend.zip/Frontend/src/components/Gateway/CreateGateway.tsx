import React, { useState } from "react";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";
import { Gateway } from "../../redux/types";
import { createGateway, fetchGateways } from "../../redux/gatewaySlice";
import { RootState } from "../../redux/store";
import {
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  CircularProgress,
} from "@mui/material";
import { makeStyles } from "@mui/styles"; // Import makeStyles and Theme
import { toast } from "react-toastify";
interface CreateGatewayProps {
  showModal: boolean;
  closeModal: () => void;
}
const initialGatewayData: Gateway = {
  macId: "",
  name: "",
  ip: "",
  port: 0,
  isActive: true,
  issuedDate: new Date(),
  updatedDate: undefined,
};
const initialErrors: Partial<Gateway> = {
  macId: "",
  name: "",
  ip: "",
  port: 0,
};
const useStyles = makeStyles(() => ({
  title: {
    paddingBottom: "10px",
    color: "#1976D2",
  },
  requiredAsterisk: {
    color: "red",
  },
  inputField: {
    fontSize: "14px",
    padding: "8px",
    height: "44px",
  },
}));
const CreateGateway: React.FC<CreateGatewayProps> = (props) => {
  const { showModal, closeModal } = props;
  const { loading, error } = useMachinewiseSelector(
    (state: RootState) => state.facility
  );
  const [gatewayData, setGatewayData] = useState<Gateway>(initialGatewayData);
  const [errors, setErrors] = useState<Partial<Gateway>>(initialErrors);
  const gatewayDispatch = useMachinewiseDispatch();
  const classes = useStyles();

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setGatewayData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };
  const validateFields = () => {
    const errors: Partial<Gateway> = {};

    if (gatewayData.macId.trim() === "") {
      errors.macId = "MAC ID is required";
    }

    if (gatewayData.name.trim() === "") {
      errors.name = "Name is required";
    }

    if (gatewayData.ip.trim() === "") {
      errors.ip = "IP is required";
    }

    return errors;
  };
  const handleSubmit = async () => {
    // Validate the fields
    const errors = validateFields();
    // Convert the port to a number
    const portAsNumber = Number(gatewayData.port);

    // Check if it's a valid number and greater than 0
    if (isNaN(portAsNumber) || portAsNumber <= 0) {
      // Handle the error
      alert("Port must be a valid positive number");
      return;
    }
    // Check if there are any errors
    if (Object.keys(errors).length > 0) {
      setErrors(errors);
      return;
    }
    try {
      // Create the gateway
      const gatewayAction = await gatewayDispatch(createGateway(gatewayData));
      // Check if the gateway was created successfully
      if (createGateway.fulfilled.match(gatewayAction)) {
        toast.success("Gateway Created Successfully");
        // Refresh the gateways
        gatewayDispatch(fetchGateways);
        // Close the modal
        closeModal();
      } else {
        toast.error("Gateway Creation Failed");
      }
    } catch (error: any) {
      console.error(`An error occured:${error.message}`);
      toast.error("An error Occured");
    }
  };
  return (
    <Dialog open={showModal} maxWidth="sm">
      <DialogTitle className={classes.title}>Create Gateway</DialogTitle>
      <DialogContent>
        {loading ? (
          <div style={{ textAlign: "center" }}>
            <CircularProgress />
          </div>
        ) : error ? (
          <DialogContentText color="error">{error}</DialogContentText>
        ) : (
          <form style={{ padding: "20px" }}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label={
                    <span>
                      MAC ID<span className={classes.requiredAsterisk}>*</span>
                    </span>
                  }
                  name="macId"
                  value={gatewayData.macId}
                  onChange={handleChange}
                  InputProps={{
                    className: classes.inputField,
                    disableUnderline: true,
                  }}
                  error={!!errors.macId}
                  helperText={errors.macId}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label={
                    <span>
                      Name<span className={classes.requiredAsterisk}>*</span>
                    </span>
                  }
                  name="name"
                  value={gatewayData.name}
                  onChange={handleChange}
                  InputProps={{
                    className: classes.inputField,
                  }}
                  error={!!errors.name}
                  helperText={errors.name}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label={
                    <span>
                      IP<span className={classes.requiredAsterisk}>*</span>
                    </span>
                  }
                  name="ip"
                  value={gatewayData.ip}
                  onChange={handleChange}
                  InputProps={{
                    className: classes.inputField,
                  }}
                  error={!!errors.ip}
                  helperText={errors.ip}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label={
                    <span>
                      Port<span className={classes.requiredAsterisk}>*</span>
                    </span>
                  }
                  name="port"
                  type="number"
                  value={gatewayData.port}
                  onChange={handleChange}
                  InputProps={{
                    className: classes.inputField,
                  }}
                />
              </Grid>
            </Grid>
          </form>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={closeModal} variant="outlined">
          Cancel
        </Button>
        <Button
          variant="contained"
          color="primary"
          onClick={handleSubmit}
          disabled={loading}
        >
          Create
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CreateGateway;
