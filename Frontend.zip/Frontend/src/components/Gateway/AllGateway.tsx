import React, { useState, useEffect } from "react";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";
import { RootState } from "../../redux/store";
import { fetchGateways, deleteGateway } from "../../redux/gatewaySlice";
import EditGateway from "./EditGateway";
import { Gateway } from "../../redux/types";
import DeleteConfirmationModal from "./DeleteConfirmationModal";
import { makeStyles } from "@mui/styles";
import { toast } from "react-toastify";
import {
  IconButton,
  Card,
  CardContent,
  CardActions,
  Typography,
  Box,
  Grid,
  Tooltip,
  Chip,
} from "@mui/material";
import {
  Visibility as ViewIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  AddCircleOutlineSharp as AddIcon,
} from "@mui/icons-material";

import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";

import AddSensor from "../GatewaySensorAssoc/AddSensorAssoc";
// import EditSlave from "../GatewaySensorAssoc/EditSlave";
import ViewGatewayModal from "./ViewGatewayModal";

import "../../assets/css/Gateway.css";
import CreateGateway from "./CreateGateway";
import { Link } from "react-router-dom";
// const useStyles = makeStyles((theme) => ({
//   table: {
//     minWidth: 650,
//   },
// }));

const useStyles = makeStyles((theme: any) => ({
  card: {
    marginBottom: theme.spacing(2),
  },
  cardContent: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  cardActions: {
    justifyContent: "space-between",
  },
}));
const AllGateway: React.FC = () => {
  //for gateways
  const [editingGateway, setEditingGateway] = useState<Gateway | null>(null);
  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
  const [gatewayToDelete, setGatewayToDelete] = useState<Gateway | null>(null);
  // for Slaves
  const [isAddSlaveModalOpen, setAddSlaveModalOpen] = useState(false);
  const [currentGateway, setCurrentGateway] = useState<Gateway | null>(null);
  // State variable to control the View Gateway modal visibility
  const [isViewModalOpen, setViewModalOpen] = useState(false);
  const [selectedGateway, setSelectedGateway] = useState<Gateway | null>(null);
  const [selectedFilter, setSelectedFilter] = useState("all");
  const [filteredGateways, setFilteredGateways] = useState<Gateway[] | null>(
    null
  );

  //state variables to control the Create/Add Gateway modal visibility
  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  const { gateways } = useMachinewiseSelector(
    (state: RootState) => state.gateway
  );
  const gatewayDispatch = useMachinewiseDispatch();
  const classes = useStyles();
  useEffect(() => {
    // Dispatch the fetchGateways action to fetch data
    gatewayDispatch(fetchGateways());
  }, [gatewayDispatch]);

  useEffect(() => {
    if (gateways) {
      if (selectedFilter === "all") {
        setFilteredGateways(gateways);
      } else if (selectedFilter === "active") {
        setFilteredGateways(
          gateways.filter((gateway: Gateway) => gateway.isActive)
        );
      } else if (selectedFilter === "inactive") {
        setFilteredGateways(
          gateways.filter((gateway: Gateway) => !gateway.isActive)
        );
      }
    }
  }, [gateways, selectedFilter]);

  // Function to open the View Gateway modal
  // eslint-disable-next-line
  const openViewModal = (gateway: Gateway) => {
    setSelectedGateway(gateway);
    setViewModalOpen(true);
  };

  // Function to close the View Gateway modal
  const closeViewModal = () => {
    setSelectedGateway(null);
    setViewModalOpen(false);
  };
  // Function to open the Edit Gateway modal
  const openEditModal = (gateway: Gateway) => {
    setEditingGateway(gateway);
  };

  // Function to close the Edit Gateway modal
  const closeEditModal = () => {
    setEditingGateway(null);
  };
  //function to open the Delete Gateway modal
  const openDeleteModal = (gateway: Gateway) => {
    setGatewayToDelete(gateway);
    setDeleteModalOpen(true);
  };

  // Function to close the Delete Confirmation modal
  const closeDeleteModal = () => {
    setDeleteModalOpen(false);
    setGatewayToDelete(null);
  };

  // Function to Handle Delete Gateway
  const handleConfirmDelete = async () => {
    if (gatewayToDelete && gatewayToDelete.gatewayId) {
      try {
        const gatewayAction = await gatewayDispatch(
          deleteGateway(gatewayToDelete.gatewayId)
        );
        if (deleteGateway.fulfilled.match(gatewayAction)) {
          setDeleteModalOpen(false);
          gatewayDispatch(fetchGateways());
          toast.success("Gateway deleted successfully!");
        } else {
          toast.error("Failed to delete gateway!");
        }
      } catch (error: any) {
        console.error(`An error occured:${error.message}`);
        toast.error("An error occurred while deleting the gateway");
      }
    }
  };
  // Function to open the Add Slave modal
  const openAddSlaveModal = (gateway: Gateway) => {
    setCurrentGateway(gateway);
    setAddSlaveModalOpen(true);
  };
  // Function to close the Add Slave modal
  const closeAddSlaveModal = () => {
    setAddSlaveModalOpen(false);
  };
  // Function to handle adding a slave

  const handleFilterClick = (filter: string) => {
    setSelectedFilter(filter);
  };
  return (
    <>
      {/* "Add Gateway" button at the top-right corner */}

      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Box display="flex" justifyContent="flex-end" alignItems="center">
            <IconButton
              color="primary"
              onClick={openModal}
              aria-label="Add Gateway"
              style={{
                padding: "10px 20px",
                borderRadius: "15px",
                transition: "background-color 0.7s ease",
              }}
            >
              <AddCircleOutlineIcon fontSize="small" />
              <span
                style={{
                  marginLeft: "8px",
                  marginTop: "-2px",
                  fontSize: "medium",
                  fontWeight: "bold",
                }}
              >
                Add Gateway
              </span>
            </IconButton>
          </Box>
        </Grid>
        <Grid item xs={12}>
          <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            marginBottom="16px"
          >
            {/* Filter Chips */}
            <Chip
              label="All"
              onClick={() => handleFilterClick("all")}
              color={selectedFilter === "all" ? "primary" : undefined}
              style={{ marginRight: "8px", cursor: "pointer" }}
            />
            <Chip
              label="Active"
              onClick={() => handleFilterClick("active")}
              color={selectedFilter === "active" ? "success" : undefined}
              style={{ marginRight: "8px", cursor: "pointer" }}
            />
            <Chip
              label="Inactive"
              onClick={() => handleFilterClick("inactive")}
              color={selectedFilter === "inactive" ? "error" : undefined}
              style={{ cursor: "pointer" }}
            />
          </Box>
        </Grid>
        {filteredGateways?.map((gateway, index) => (
          <Grid item key={gateway._id} xs={12} sm={6} md={4}>
            <Card
              style={{ borderRadius: "18px" }}
              className={`custom-card ${classes.card} ${
                gateway.isActive ? "active" : "inactive"
              }`}
            >
              <CardContent>
                <Typography variant="h6" align="center">
                  {gateway.name}
                </Typography>
                <Typography
                  variant="subtitle1"
                  color="textSecondary"
                  align="center"
                >
                  {gateway.macId}
                </Typography>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  align="center"
                >
                  IP: {gateway.ip}
                </Typography>
                <Typography
                  variant="body2"
                  color="textSecondary"
                  align="center"
                >
                  Port: {gateway.port}
                </Typography>{" "}
                {/* <Typography
                  variant="body2"
                  color="textSecondary"
                  align="center"
                >
                  GatewayId: {gateway.gatewayId}
                </Typography> */}
              </CardContent>
              <CardActions className={classes.cardActions}>
                <Typography variant="body2" align="center">
                  Gateway Actions:
                </Typography>
                <Tooltip title="Edit Gateway">
                  <IconButton
                    color="primary"
                    onClick={() => openEditModal(gateway)}
                  >
                    <EditIcon />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Delete Gateway">
                  <IconButton
                    color="error"
                    onClick={() => openDeleteModal(gateway)}
                  >
                    <DeleteIcon />
                  </IconButton>
                </Tooltip>
              </CardActions>
              <CardActions className={classes.cardActions}>
                <Typography variant="body2" align="center">
                  Sensor Actions:
                </Typography>
                <Tooltip title="Add Sensor Assoc.">
                  <IconButton
                    style={{ color: "green" }}
                    onClick={() => openAddSlaveModal(gateway)}
                  >
                    <AddIcon />
                  </IconButton>
                </Tooltip>
                <Tooltip title="View Sensors slaves">
                  <Link to={`/gatewaySensorAssociation/${gateway.gatewayId}`}>
                    <IconButton style={{ color: "#495057" }}>
                      <ViewIcon />
                    </IconButton>
                  </Link>
                </Tooltip>
                <Tooltip title="View Sensors inputs">
                  <Link to={`/gatewayInputsAssociation/${gateway.gatewayId}`}>
                    <IconButton style={{ color: "#495057" }}>
                      <ViewIcon />
                    </IconButton>
                  </Link>
                </Tooltip>
              </CardActions>
            </Card>
          </Grid>
        ))}
        <CreateGateway showModal={showModal} closeModal={closeModal} />
        {editingGateway && (
          <EditGateway
            showModal={true}
            closeModal={closeEditModal}
            gatewayData={editingGateway}
          />
        )}
        <DeleteConfirmationModal
          open={isDeleteModalOpen}
          handleClose={closeDeleteModal}
          handleConfirm={handleConfirmDelete}
        />
        <ViewGatewayModal
          open={isViewModalOpen}
          handleClose={closeViewModal}
          gateway={selectedGateway}
        />
        <AddSensor
          open={isAddSlaveModalOpen}
          handleClose={closeAddSlaveModal}
          //handleAddSlave={handleAddSlave}
          gatewayData={currentGateway}
        />
      </Grid>
    </>
  );
};
export default AllGateway;
