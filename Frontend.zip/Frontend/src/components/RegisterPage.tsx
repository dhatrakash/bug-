import React, {  useState } from 'react';
import '../assets/css/RegisterPage.css'
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const RegisterPage: React.FC = () => {
  const [credentials, setCredentials] = useState<{ [key: string]: string }>({});
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };
  const nav = useNavigate();
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>)=>{
    try{
      e.preventDefault();
      console.log(credentials)
     if(credentials.pswd !== credentials.cpswd)
      {
        toast.error("Passwords do not match ! ",{
          position: "top-right"})
        return;
      }
      if(credentials.pswd.length < 8 || credentials.pswd.length < 8)
      {
        toast.error("Password must be at least 8 characters !",{
          position: "top-right"})
        return;
      }
      if (!credentials.pswd.match(/\d/) || !credentials.pswd.match(/[a-zA-Z]/)) {
        toast.error("Password must contain at least one number and one letter !",{
          position: "top-right"})
        return;
      }
      const response = await fetch('http://localhost:3000/v1/auth/register', {
        method: 'POST',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify({name:credentials.fname,email:credentials.email,password:credentials.pswd})             
    });
    const data = await response.json();
    if(response.status === 201)
    {
      toast.success("You have successfully registered !",{
        position: "top-right"})
        console.log(data)
        nav('/login')
    }else{
      toast.error(data.message,{
        position: "top-right"})
    }
    }catch(err)
    {
      console.log(err);
      toast.error("Internal Server Error ! ",{
        position: "top-right"})
    }
  }

  const resetFormData = () => {
    setCredentials({ fname: "", email: "", pswd: "", cpswd: "" });
  };
  return (
    <div className="register-container">
      <div className="register-box">
        <h2>Register</h2>
        <form onSubmit={handleSubmit}>
          <input className='form-control' type="text" placeholder="Enter Your Full Name" id='fname' name='fname' onChange={handleChange} value={credentials.fname} required={true}/>
          <input className='form-control' type="email" placeholder="Enter Your Email Id" id='email' name='email' onChange={handleChange} value={credentials.email} required={true}/>
          <input className='form-control' type="password" placeholder="Enter Your Password" id='pswd' name='pswd' onChange={handleChange} value={credentials.pswd} required={true}/>
          <input className='form-control' type="password" placeholder="Please Confirm Your Password" id='cpswd' name='cpswd' onChange={handleChange} value={credentials.cpswd} required={true}/>
          <div style={{display:'flex',gap:'20px',alignSelf:'center'}}>
          <button type="submit" className='btn btn-success'>Register</button>
          <button type="reset" className='btn btn-secondary' onClick={resetFormData}>Clear</button>
          </div>
         
        </form>
        <p style={{textAlign:'center',marginTop:'20px'}}>
          Already have an account? <Link to="/login" style={{textDecoration:'none'}}>Login here</Link>
        </p>
      </div>
    </div>
  );
};

export default RegisterPage;    
