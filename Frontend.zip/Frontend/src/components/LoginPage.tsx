import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom'; // Import useNavigate
import '../assets/css/LoginPage.css';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useDispatch, useSelector } from 'react-redux';
import { RootState, Functionality } from '../redux/types';
import { setViewMach,
         setMachAsssignToSuper,
         setCreateNewMach,
         setCreateNewUsers,
         setAssignRepo,
         setAssignPermi,
         setWhatsAppAPI,
         setMachAsssignToUser,
         setShiftCreat,
         setLocaCreat,
         setMastrPartList,
         setViewLimRepo,
         setMachAsssignToOper,
         setReportProb,
         setViewHtmlOnLarScr,
         setCustPermi,
         updateFunctionalities, } from '../redux/functionalitySlice';

interface LoginPageProps {
  setIsLoggedIn: React.Dispatch<React.SetStateAction<boolean>>;
}

const LoginPage: React.FC<LoginPageProps> = ({ setIsLoggedIn }) => {
  const [credentials, setCredentials] = useState<{ email: string; password: string }>({
    email: '',
    password: '',
  });
 
  const dispatch = useDispatch();
  
  const getRoleByName = () => {
    const roleName = sessionStorage.getItem("role");
    const requestBody = { 
      roleName: `${roleName}`,
    };

       if(roleName?.length){
        fetch('http://localhost:3000/v1/users/getRoleByName', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            // 'Authorization' : `Bearer ${sessionStorage.getItem("access-token")}`
          },
          body: JSON.stringify(requestBody),
        })
          .then(response => response.json())
          .then(data => {
             console.warn("API Response Data: ", data.functionalities);
             const updatedFunctionalities = data.functionalities['0'];
             dispatch(updateFunctionalities(updatedFunctionalities));
             sessionStorage.setItem('functionalities', JSON.stringify(updatedFunctionalities));
            //  dispatch(setViewMach(data.functionalities[0]?.viewMach));
            //  dispatch(setMachAsssignToSuper(data.functionalities[0]?.machAsssignToSuper));
            //  dispatch(setCreateNewMach(data.functionalities[0]?.createNewMach));
            //  dispatch(setCreateNewUsers(data.functionalities[0]?.createNewUsers));
            //  dispatch(setAssignRepo(data.functionalities[0]?.assignRepo));
            //  dispatch(setAssignPermi(data.functionalities[0]?.assignPermi));
            //  dispatch(setWhatsAppAPI(data.functionalities[0]?.whatsAppAPI));
            //  dispatch(setMachAsssignToUser(data.functionalities[0]?.machAsssignToUser));
            //  dispatch(setShiftCreat(data.functionalities[0]?.shiftCreat));
            //  dispatch(setLocaCreat(data.functionalities[0]?.locaCreat));
            //  dispatch(setMastrPartList(data.functionalities[0]?.mastrPartList));
            //  dispatch(setViewLimRepo(data.functionalities[0]?.viewLimRepo));
            //  dispatch(setMachAsssignToOper(data.functionalities[0]?.machAsssignToOper));
            //  dispatch(setReportProb(data.functionalities[0]?.reportProb));
            //  dispatch(setViewHtmlOnLarScr(data.functionalities[0]?.viewHtmlOnLarScr));
            //  dispatch(setCustPermi(data.functionalities[0]?.custPermi)); 
             
          })
          .catch(error => {
            console.error('Error fetching data:', error);
          });
       }
  };
  const navigate = useNavigate(); // Use useNavigate for navigation

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    try {
      e.preventDefault();
      const response = await fetch('http://localhost:3000/v1/auth/login', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
        },
        body: JSON.stringify({
          email: credentials.email,
          password: credentials.password,
        }),
      });
      const data = await response.json();
      if (response.status === 200) {
        sessionStorage.setItem('sessionStartTime', String(new Date().getTime()));
        console.log(data);
        sessionStorage.setItem('role', data.user.role);
        sessionStorage.setItem('access-token',data.tokens.access.token)
        sessionStorage.setItem('access-token-expires',data.tokens.access.expires)
        sessionStorage.setItem('refresh-token',data.tokens.refresh.token)
        sessionStorage.setItem('refresh-token-expires',data.tokens.refresh.expires)
        sessionStorage.setItem('isLoggedIn', 'true');
        sessionStorage.setItem('name', data.user.name);
        getRoleByName();
        setIsLoggedIn(true);
        toast.success('Welcome ' + data.user.name, { position: 'top-right',});
        navigate('/'); // Use navigate for redirection
      } else {
        toast.error(data.message, {position: 'top-right', });
      }
    } catch (err) {
      console.log(err);
      toast.error('Internal Server Error ! ', {
        position: 'top-right',
      });
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h3>Login</h3>
        <form onSubmit={handleSubmit}>
          <input
            type="email"
            className="form-control"
            placeholder="Enter Your Email here."
            name="email"
            onChange={handleChange}
            required={true}
          />
          <input
            type="password"
            className="form-control"
            placeholder="Enter Your Password here."
            name="password"
            onChange={handleChange}
            required={true}
          />
          <div style={{ display: 'flex', gap: '20px', alignSelf: 'center' }}>
            <button type="submit" className="btn btn-primary">
              Login
            </button>
            <button type="reset" className="btn btn-secondary">
              Clear
            </button>
          </div>
        </form>
        <p style={{ textAlign: 'center', marginTop: '20px' }}>
          Don't have an account? <Link to="/register" style={{ textDecoration: 'none' }}>
            Register here
          </Link>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;





 /*  // Extract the functionalities from the response
            const functionalities: { [key: string]: boolean }[] = data.functionalities;
    
            // Store the functionalities in session storage as key-value pairs
            functionalities.forEach((func: { [key: string]: boolean }) => {
              for (const key in func) {
                sessionStorage.setItem(key, func[key].toString());
              }
            }); */
