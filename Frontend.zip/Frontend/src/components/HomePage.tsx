import React from 'react';
import machineWiselogo from '../assets/images/Machine Wise Logo.jpeg';

const HomePage: React.FC = () => {
  return (
  
      <div style={{padding:'40px'}}>
        <img src={machineWiselogo} alt="logo" style={{height:'450px',margin: 'auto'}} />
        <h3 style={{color:'crimson'}}>Welcome to Machine Wise Application</h3>
      </div>
   
  );
};

export default HomePage;
