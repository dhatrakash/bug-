import React, { FC, useEffect, useState } from "react";
import socket from "../../../socket.io";
import {
  CartesianGrid,
  Label,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../../../@/components/ui/card";

interface OeeData {
  hour: string;
  machineON: number;
  productionTime: number;
  idleTime: number;
  production: number;
  OEE: number | null;
  reportTime: number;
  autoMode0: number;
  autoMode1: number;
  autoMode6: number;
}

interface CompareOeeProps {
  selectedMachine: string | undefined;
}

const CompareOee: FC<CompareOeeProps> = ({ selectedMachine }) => {
  const [data, setData] = useState<OeeData[]>([]);

  const [today, setToday] = useState<OeeData[]>([]);
  const [yesterday, setYesterday] = useState<OeeData[]>([]);

  const [error, setError] = useState(null);

  useEffect(() => {
    socket.emit("compareOeeData", {
      interval: "1",
      machineName: selectedMachine,
    });

    socket.on("compareOeeData", (result) => {
      console.log("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
      console.log("result: " + result);
      setData(result);
      const Line1 = data.slice(0, 24);
      const Line2 = data.slice(24, 48);

      console.log("Line1 @@@@@@@@@@@@@@@@@@@@@@@@@@@");
      console.log(Line1);
      console.log(Line2);
    });

    socket.on("partProduceError", (errorMessage) => {
      setError(errorMessage);
    });
  }, [selectedMachine]);
  const dataForLine1 = data.slice(0, 24);
  const dataForLine2 = data.slice(24, 48);
  return (
    <div>
      {/* <h2>Compare OEE Data {selectedMachine}</h2>
      <table>
        <thead>
          <tr>
            <th>Hour</th>
            <th>Machine ON</th>
            <th>Production Time</th>
            <th>Idle Time</th>
            <th>Production</th>
            <th>OEE</th>
            <th>Report Time</th>
            <th>Auto Mode 0</th>
            <th>Auto Mode 1</th>
            <th>Auto Mode 6</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr key={item.hour}>
              <td>{item.hour}</td>
              <td>{item.machineON}</td>
              <td>{item.productionTime}</td>
              <td>{item.idleTime}</td>
              <td>{item.production}</td>
              <td>{item.OEE !== null ? item.OEE.toFixed(2) : "N/A"}</td>
              <td>{item.reportTime}</td>
              <td>{item.autoMode0}</td>
              <td>{item.autoMode1}</td>
              <td>{item.autoMode6}</td>
            </tr>
          ))}
        </tbody>
      </table> */}
      <div style={{ width: "439px" }}>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              OEE Today v Yesterday
            </CardTitle>

            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
            </svg>
          </CardHeader>
          <CardContent>
            <div>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart
                  data={data}
                  margin={{
                    top: 5,

                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis
                    dataKey="hour"
                    tickFormatter={(tick) => tick.split("T")[1].slice(0, 5)}
                  />
                  <YAxis>
                    <Label
                      value="OEE %"
                      angle={-90}
                      position="insideLeft"
                      style={{
                        textAnchor: "middle",
                        fontWeight: "bold",
                        fill: "#000",
                      }}
                    />
                  </YAxis>
                  <Tooltip
                    formatter={(value, name, props) => {
                      const formattedValue =
                        typeof value === "number" ? value.toFixed(2) : value;
                      return [`${formattedValue}%`, name];
                    }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="OEE"
                    stroke="#00ff00"
                    name="YESTERDAY"
                    data={dataForLine1}
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="OEE"
                    stroke="#ff0000"
                    activeDot={{ r: 8 }}
                    name="TODAY"
                    data={dataForLine2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>{" "}
    </div>
  );
};

export default CompareOee;
