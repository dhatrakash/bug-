import axios from "axios";
import { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../../../@/components/ui/card";
import {
  CartesianGrid,
  Label,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

interface AlarmCountProps {
  selectedMachine: string | undefined;
}

interface AlarmData {
  startTime: string;
  endTime: string;
  alarmCount: number;
}

interface AlarmCountApiResponse {
  status: string;
  code: number;
  message: string;
  data: AlarmData[];
}

const AlarmCount: React.FC<AlarmCountProps> = ({ selectedMachine }) => {
  const [data, setData] = useState<AlarmData[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const alarmResponse = await axios.post<AlarmCountApiResponse>(
          "http://localhost:3000/v1/fanuc/totalAlarms",
          {
            machineName: selectedMachine,
          }
        );
        setData(alarmResponse.data.data);
      } catch (e) {
        console.log("Error in fetching totalAlarms API ", e);
      }
    };
    fetchData();

    const interval = setInterval(() => {
      fetchData();
    }, 3600000); // 1 hour in milliseconds

    return () => clearInterval(interval);
  }, [selectedMachine]);

  return (
    <div>
      <div style={{ width: "439px" }}>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alarm Count</CardTitle>

            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
            </svg>
          </CardHeader>
          <CardContent>
            <div>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart
                  data={data}
                  margin={{
                    top: 5,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis
                    dataKey="startTime"
                    tickFormatter={(tick) => tick.split(" ")[1].slice(0, 5)}
                  />
                  <YAxis>
                    <Label
                      value="No's"
                      angle={-90}
                      position="insideLeft"
                      style={{
                        textAnchor: "middle",
                        fontWeight: "bold",
                        fill: "#000",
                      }}
                    />
                  </YAxis>
                  <Tooltip />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="alarmCount"
                    stroke="#00ff00"
                    name="Alarn Count"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>{" "}
    </div>
  );
};

export default AlarmCount;
