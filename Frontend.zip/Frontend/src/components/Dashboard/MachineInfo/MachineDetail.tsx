import UtilizationTrend from "./UtilizationTrend";
import PartCountTrend from "./PartCountTrend";
import IdleTimeTrend from "./IdleTimeTrend";
import { Link, useParams } from "react-router-dom";
import { faArrowLeft, faCog } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useEffect, useRef, useState } from "react";
import {
  setAvgSingleMachineOee,
  setMachineInfo,
} from "../../../redux/Dashboard/reducers";
import { useDispatch, useSelector } from "react-redux";
import Spinner from "react-bootstrap/Spinner";
import MachineSettings from "./MachineSettings";
import axios from "axios";
import { RootState } from "../../../redux/Dashboard/types";
import { format } from "date-fns-tz";
import React from "react";
import socket from "../../../socket.io";
import { Button } from "../../../@/components/ui/button";
import CompareOee from "./CompareOee";
import AlarmCount from "./AlarmCount";

const MachineDetails: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const dispatch = useDispatch();
  const [totalProductionTime, setTotalProductionTime] = useState("00:00:00");
  const [totalIdleTime, setTotalIdleTime] = useState("00:00:00");
  const [oeeOfMachine, setOeeOfMachine] = useState<number>(0);

  const [totalPartCount, setTotalPartCount] = useState(0);
  const [showSettings, setShowSettings] = useState(false);

  const utilizationTrend = useRef<any>(null);
  const { selectedMachine } = useParams();
  const from = useSelector((state: RootState) => state.app.startDate);
  const to = useSelector((state: RootState) => state.app.endDate);
  const userInput = useSelector((state: RootState) => state.app.userInput);

  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");

  useEffect(() => {
    if (from) {
      setStartDate(format(from, "yyyy-MM-dd'T'HH:mm:ss'Z'"));
    }
    if (to) {
      setEndDate(format(to, "yyyy-MM-dd'T'HH:mm:ss'Z'"));
    }
  }, [from, to]);

  const cardContainerStyle = {
    display: "grid",
    gridTemplateColumns: "repeat(4, 1fr)", // Create 4 equally spaced columns
    gap: "10px", // Adjust the gap as needed
    margin: "10px 0px 10px 10px ",
  };
  // Helper function to convert seconds to "hh:mm:ss" format
  function secondsToHHMMSS(seconds: number) {
    seconds = Math.round(seconds);
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  }
  // Function to toggle settings page visibility
  const toggleSettings = () => {
    setShowSettings(!showSettings);
  };

  //socket
  useEffect(() => {
    const emitSocketEvent = () => {
      const requestData = {
        startDate: startDate,
        endDate: endDate,
        interval: userInput,
        machineName: selectedMachine,
      };
      console.log("###################################");
      console.log(startDate);
      console.log(endDate);
      console.log(userInput);
      console.log(selectedMachine);

      console.log("Socket emit");
      socket.emit("machineSpecificData", requestData);
    };

    // Emit socket event initially
    emitSocketEvent();
  }, [selectedMachine]);

  // useEffect(() => {
  //   socket.on("machineSpecificData", (results) => {
  //     if (
  //       results &&
  //       results.machineData &&
  //       Array.isArray(results.machineData)
  //     ) {
  //       console.log("Received machine specific data socket:", results);

  //       const productionTimeSum = results.machineData.reduce(
  //         (total: any, entry: { productionTime: any }) =>
  //           total + entry.productionTime,
  //         0
  //       );
  //       console.log("productionTimeSum :", productionTimeSum);
  //       const idleTimeSum = results.machineData.reduce(
  //         (total: any, entry: { idleTime: any }) => total + entry.idleTime,
  //         0
  //       );
  //       console.log("idleTimeSum :", idleTimeSum);
  //       const partCountSum = results.machineData.reduce(
  //         (total: any, entry: { production: any }) => total + entry.production,
  //         0
  //       );
  //       setTotalProductionTime(secondsToHHMMSS(productionTimeSum));
  //       setTotalIdleTime(secondsToHHMMSS(idleTimeSum));
  //       setTotalPartCount(partCountSum);

  //       dispatch(setMachineInfo(results.machineData));

  //       setIsLoading(false);
  //     }

  //     // dispatch(setBaseInfo(results));
  //   });
  // }, [socket]);

  useEffect(() => {
    const handleMachineSpecificData = async (results: any[]) => {
      console.log("Received machine specific data socket:", results);

      if (results) {
        console.log("Received machine specific data socket:", results);

        const productionTimeSum = results.reduce(
          (total: any, entry: { productionTime: any }) =>
            total + entry.productionTime,
          0
        );
        const idleTimeSum = results.reduce(
          (total: any, entry: { idleTime: any }) => total + entry.idleTime,
          0
        );
        const partCountSum = results.reduce(
          (total: any, entry: { production: any }) => total + entry.production,
          0
        );

        const oeeSum = results.reduce(
          (total: any, entry: { OEE: any }) => total + entry.OEE,
          0
        );

        const averageOEE = oeeSum / results.length;
        setOeeOfMachine(averageOEE);
        dispatch(setAvgSingleMachineOee(averageOEE.toFixed(2)));

        setTotalProductionTime(secondsToHHMMSS(productionTimeSum));
        setTotalIdleTime(secondsToHHMMSS(idleTimeSum));
        setTotalPartCount(partCountSum);
        dispatch(setMachineInfo(results));

        setIsLoading(false);
      }
      // dispatch(setBaseInfo(results));
    };

    const initSocket = async (): Promise<void> => {
      return new Promise<void>((resolve) => {
        socket.on("machineSpecificData", (results) => {
          handleMachineSpecificData(results);
          resolve(); // Resolve the promise when the data is handled.
        });
      });
    };

    const setupSocket = async () => {
      await initSocket();
    };

    setupSocket();
  }, [dispatch, selectedMachine]);

  return (
    <>
      {isLoading ? (
        <div
          className="d-flex justify-content-center align-items-center"
          style={{ height: "100vh" }}
        >
          <Spinner animation="border" role="status">
            {/* <span className="sr-only">Loading...</span> */}
          </Spinner>
        </div>
      ) : (
        <>
          <div>
            <div
              className="card shadow"
              style={{
                marginLeft: "10px",
                marginRight: "10px",
                marginTop: "10px",
                // height: "90px",
              }}
            >
              <div className="card-body">
                <div className="row">
                  <div className="col-12 col-md-4">
                    <p>Machine Name: {selectedMachine}</p>
                  </div>
                  <div className="col-12 col-md-4">
                    <p>Production Time:{totalProductionTime}</p>
                  </div>
                  <div className="col-12 col-md-4">
                    <p>Idle Time: {totalIdleTime}</p>
                  </div>
                  <div className="col-12 col-md-4">
                    <p>Operator Name: John </p>
                  </div>
                  <div className="col-12 col-md-4">
                    <p>Part Count: {totalPartCount}</p>
                  </div>
                  <div className="col-12 col-md-4">
                    <div
                      className={`btn btn-${
                        showSettings ? "secondary" : "btn btn-light"
                      }`}
                      onClick={toggleSettings}
                    >
                      {showSettings ? (
                        // Show "Back" button when showSettings is true
                        <>
                          <FontAwesomeIcon
                            icon={faArrowLeft}
                            className="ml-2"
                          />{" "}
                          Back
                        </>
                      ) : (
                        // Show settings icon when showSettings is false
                        <>
                          <FontAwesomeIcon icon={faCog} className="ml-2" />{" "}
                          Setting
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div style={cardContainerStyle}>
            {showSettings ? (
              <MachineSettings />
            ) : (
              <div className="trends-container">
                <div ref={utilizationTrend} className="trend-item">
                  <UtilizationTrend />
                </div>
                <div className="trend-item">
                  <PartCountTrend />
                </div>
                <div className="trend-item">
                  <IdleTimeTrend />
                </div>
                <div className="trend-item">{/* <EnergyTrend /> */}</div>
              </div>
            )}
          </div>

          <div
            style={{
              display: "flex",
              marginBottom: "140px",
              marginLeft: "10px",
            }}
          >
            {/* <SingleMachinePdf
              Name={selectedMachine}
              utilizationTrendRef={utilizationTrend}
            /> */}
            {/* <Header />
            <RangeSelect /> */}

            <CompareOee selectedMachine={selectedMachine} />
            <AlarmCount selectedMachine={selectedMachine} />
            {/* <Link to={`/machine-report/${selectedMachine}`}>
              <Button variant={"outline"}>Download Report</Button>
            </Link> */}
            <Link to={`/daily-machine-report/${selectedMachine}`}>
              <Button variant={"outline"}> Daily Report</Button>
            </Link>
            <Link to={`/weekly-machine-report/${selectedMachine}`}>
              <Button variant={"outline"}> Weekly Report</Button>
            </Link>
            <Link to={`/monthly-machine-report/${selectedMachine}`}>
              <Button variant={"outline"}> Monthly Report</Button>
            </Link>
          </div>
        </>
      )}
    </>
  );
};

export default MachineDetails;
