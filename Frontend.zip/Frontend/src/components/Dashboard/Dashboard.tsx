import Header from "./Nav/Header";
import RightNav from "./Nav/RightNav";
import CombinedChartsAllMachines from "./Charts/CombinedChartAllMachines";

export default function Dashboard() {
  return (
    <div className="grid grid-cols-3 gap-4">
      <div
        className="col-span-2 p-4"
        style={{ height: "100vh", overflowY: "auto" }}
      >
        {/* Content for the 75% div with scrollable behavior */}
        <Header />
        <CombinedChartsAllMachines  />
      </div>
      <div className="col-span-1 p-4" style={{ height: "100vh" }}>
        {/* Content for the 25% div, static */}
        <RightNav />
      </div>
    </div>
  );
}
