import React, { useEffect, useState, useCallback } from "react";
import { useDispatch, useSelector } from "react-redux";
import { ComposedChart, Bar, XAxis, Tooltip, Rectangle } from "recharts";
import { fetchFeedData } from "../../../redux/GanttReduces/feedSlice";
import { RootState, AppDispatch } from "../../../redux/store";
import moment from "moment";
import "../../../assets/css/FeedChart.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faGreaterThan } from "@fortawesome/free-solid-svg-icons";
interface FeedChartProps {
  selectedHours: number;
  selectedMachine: string;
  chartWidth: number;
  timeTicks: number[];
  activeTooltipIndex: number | null;
  onMouseOver: (index: number) => void;
  onMouseOut: () => void;
}
interface FeedData {
  time: number;
  feed: number | null;
}
const generateTickValues = (
  start: number,
  end: number,
  chartWidth: number
): number[] => {
  const durationInMinutes = moment(end).diff(moment(start), "minutes");
  const pixelsPerTick = 45; // Adjust this value based on your preference
  const numberOfTicks = chartWidth / pixelsPerTick;
  const intervalInMinutes = Math.ceil(durationInMinutes / numberOfTicks);

  const ticks: number[] = [];
  let current = moment(start);

  while (current.valueOf() <= end) {
    ticks.push(current.valueOf());
    current.add(intervalInMinutes, "minutes");
  }

  return ticks;
};

const CustomLegend = () => {
  return (
    <div className="custom-legend">
      <div className="legend-item">
        <div
          className="color-box"
          style={{ backgroundColor: "rgba(255, 255, 0)" }}
        ></div>
        <span>{"< 100 (Feed Value)"}</span>
      </div>
      <div className="legend-item">
        <div
          className="color-box"
          style={{ backgroundColor: "rgba(0, 128, 0)" }}
        ></div>
        <span>{"= 100 (Feed Value)"}</span>
      </div>
      <div className="legend-item">
        <div
          className="color-box"
          style={{ backgroundColor: "rgba(255, 0, 0)" }}
        ></div>
        <span>{"> 100 (Feed Value)"}</span>
      </div>
    </div>
  );
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const speed = payload[0].value;
    const time = formatToHoursMinutes(label);

    return (
      <div className="custom-tooltip">
        <p className="speed-value">{`Speed: ${speed}`}</p>
        <p className="time-value">{`Time: ${time}`}</p>
      </div>
    );
  }
  return null;
};

const formatToHoursMinutes = (timestamp: number) => {
  const date = new Date(timestamp);
  const hours = date.getHours().toString().padStart(2, "0");
  const minutes = date.getMinutes().toString().padStart(2, "0");
  return `${hours}:${minutes}`;
};
const getColor = (feed: number | null) => {
  if (feed === null) {
    return "grey"; // Color for null (no data)
  } else if (feed < 100) {
    return "rgba(255, 255, 0)"; // Yellow for feed values below 100
  } else if (feed === 100) {
    return "rgba(0, 128, 0)"; // Green for feed value exactly 100
  } else {
    return "rgba(255, 0, 0)"; // Red for feed values above 100
  }
};

const FeedChart: React.FC<FeedChartProps> = ({
  selectedHours,
  selectedMachine,
  chartWidth,
  activeTooltipIndex, // Make sure this prop is passed down from the parent
  onMouseOver, // Make sure this prop is passed down from the parent
  onMouseOut,
}) => {
  const dispatch: AppDispatch = useDispatch();
  const feedData = useSelector(
    (state: RootState) => state.feed.data[selectedMachine] || []
  );

  const [chartData, setChartData] = useState<any[]>([]);

  const minBarWidth = 8;
  const calculatedBarWidth = chartWidth / (chartData.length || 1);
  const barWidth = Math.max(minBarWidth, calculatedBarWidth);

  const fetchData = useCallback(() => {
    dispatch(fetchFeedData({ hours: selectedHours, machine: selectedMachine }));
  }, [dispatch, selectedHours, selectedMachine]);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 60 * 1000); // Adjust interval as needed

    return () => clearInterval(interval);
  }, [fetchData]);

  const fillGaps = (data: FeedData[], interval: number = 1000): FeedData[] => {
    if (data.length === 0) {
      return data;
    }

    const filledData: FeedData[] = [];
    let previousData = data[0];

    filledData.push(previousData);

    for (let i = 1; i < data.length; i++) {
      const currentData = data[i];
      let gapTime = previousData.time + interval;

      // Fill the gap with null values until the next data point is reached
      while (gapTime < currentData.time) {
        filledData.push({
          time: gapTime,
          feed: null, // Marking this as a gap
        });
        gapTime += interval;
      }

      filledData.push(currentData);
      previousData = currentData;
    }

    return filledData;
  };

  useEffect(() => {
    if (feedData.length > 0) {
      const newDataWithGapsFilled = fillGaps(feedData, 60 * 1000); // Assuming a 1-minute interval
      setChartData(newDataWithGapsFilled);
    }
  }, [feedData]);

  // useEffect(() => {
  //   if (feedData.length > 0) {
  //     const newDataWithGapsFilled = fillGaps(feedData, 60 * 1000); // Assuming a 1-minute interval
  //     setChartData(newDataWithGapsFilled);
  //   }
  // }, [feedData]);
  // useEffect(() => {
  //   setChartData(feedData);
  // }, [feedData]);

  const [timeTicks, setTimeTicks] = useState<number[]>([]);
  useEffect(() => {
    const currentTime = moment().valueOf();
    const startTime = moment().subtract(selectedHours, "hours").valueOf();

    const filteredData = feedData.filter(
      (item) => item.time >= startTime && item.time <= currentTime
    );

    const newTimeTicks = generateTickValues(
      startTime,
      currentTime,
      selectedHours
    );
    setTimeTicks(newTimeTicks); // Assuming setTimeTicks is a useState setter for timeTicks
  }, [feedData, selectedHours]);

  const calculateBarWidth = () => {
    const numberOfBars = chartData.length;
    const maxBarWidth = 0.5; // Adjust as needed
    return Math.max(chartWidth / numberOfBars - 1, maxBarWidth);
  };
  // const barWidth = calculateBarWidth();

  const CustomBarShape = (props: any) => {
    const { x, width, value, index } = props;

    // Determine the color based on the value
    let color;
    if (value === null) {
      color = "grey"; // Replace 'defaultColor' with your desired color for gaps
    } else {
      color = getColor(value); // Your existing logic for non-gap values
    }

    const isFirstBar = index === 0;
    const isLastBar = index === chartData.length - 1;
    let radius = [0, 0, 0, 0]; // Default: no radius

    if (chartData.length === 1) {
      radius = [10, 10, 10, 10]; // Apply radius to all corners if only one bar
    } else {
      if (isFirstBar) {
        radius = [10, 0, 0, 10]; // Left side rounded for the first bar
      } else if (isLastBar) {
        radius = [0, 10, 10, 0]; // Right side rounded for the last bar
      }
    }
    const adjustedX = x - 3;
    const adjustedWidth = width;
    const fixedHeight = 30;
    const adjustedY = 30 - fixedHeight;

    return (
      <Rectangle
        {...props}
        onMouseOver={() => onMouseOver(props.index)}
        onMouseOut={onMouseOut}
        x={adjustedX}
        y={adjustedY}
        width={adjustedWidth + 120}
        height={fixedHeight}
        fill={color}
        // radius={radius}
      />
    );
  };

  // Assuming chartData is sorted by time
  const start = chartData.length > 0 ? chartData[0].time : moment().valueOf();
  const end =
    chartData.length > 0
      ? chartData[chartData.length - 1].time
      : moment().add(1, "hour").valueOf();
  const tickValues = generateTickValues(start, end, chartWidth);

  return (
    <div className="feed-chart-container">
      <h6>Feed-Data</h6>

      {chartData.length === 0 ? (
        <div className="no-data-message">
          Data is not available for this time period.
        </div>
      ) : (
        <>
          <ComposedChart
            width={chartWidth + 9}
            height={60}
            data={chartData}
            margin={{ top: 1, right: 30, bottom: 0, left: 30 }}
            barSize={20}
            barGap={0}
            barCategoryGap={0}
            onMouseMove={(e) => {
              if (e.isTooltipActive && e.activeTooltipIndex !== undefined) {
                onMouseOver(e.activeTooltipIndex);
              }
            }}
            onMouseLeave={onMouseOut}
          >
            <XAxis
              dataKey="time"
              type="number"
              domain={["dataMin", "dataMax"]}
              tickFormatter={(unixTime) => moment(unixTime).format("HH:mm")}
              ticks={tickValues}
              tick={{ fontSize: "9px" }}
            />

            <Tooltip
              content={<CustomTooltip />}
              active={activeTooltipIndex !== null}
              payload={
                activeTooltipIndex !== null &&
                activeTooltipIndex >= 0 &&
                activeTooltipIndex < chartData.length &&
                chartData[activeTooltipIndex].feed !== null
                  ? [
                      {
                        name: "Feed Speed",
                        value: chartData[activeTooltipIndex].feed as number, // You need to ensure this index is within the data array bounds
                      },
                    ]
                  : []
              }
              labelFormatter={(label) => formatToHoursMinutes(label)}
            />

            <Bar
              dataKey="feed"
              name="Feed Speed"
              barSize={barWidth}
              shape={(props) => <CustomBarShape {...props} />}
            />
          </ComposedChart>
          <CustomLegend />
        </>
      )}
    </div>
  );
};

export default FeedChart;


// import React, { useEffect, useState, useCallback } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { ComposedChart, Bar, XAxis, Tooltip, Rectangle } from "recharts";
// import { fetchFeedData } from "../../../redux/GanttReduces/feedSlice";
// import { RootState, AppDispatch } from "../../../redux/store";
// import moment from "moment";
// import "../../../assets/css/FeedChart.css";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faGreaterThan } from "@fortawesome/free-solid-svg-icons";
// interface FeedChartProps {
//   selectedHours: number;
//   selectedMachine: string;
//   chartWidth: number;
//   timeTicks: number[];
//   activeTooltipIndex: number | null;
//   onMouseOver: (index: number) => void;
//   onMouseOut: () => void;
// }
// interface FeedData {
//   time: number;
//   feed: number | null;
//   sweep: boolean; // Add this line
// }

// const generateTickValues = (
//   start: number,
//   end: number,
//   chartWidth: number
// ): number[] => {
//   const durationInMinutes = moment(end).diff(moment(start), "minutes");
//   const pixelsPerTick = 45; // Adjust this value based on your preference
//   const numberOfTicks = chartWidth / pixelsPerTick;
//   const intervalInMinutes = Math.ceil(durationInMinutes / numberOfTicks);

//   const ticks: number[] = [];
//   let current = moment(start);

//   while (current.valueOf() <= end) {
//     ticks.push(current.valueOf());
//     current.add(intervalInMinutes, "minutes");
//   }

//   return ticks;
// };

// const CustomLegend = () => {
//   return (
//     <div className="custom-legend">
//       <div className="legend-item">
//         <div
//           className="color-box"
//           style={{ backgroundColor: "rgba(255, 255, 0)" }}
//         ></div>
//         <span>{"< 100 (Feed Value)"}</span>
//       </div>
//       <div className="legend-item">
//         <div
//           className="color-box"
//           style={{ backgroundColor: "rgba(0, 128, 0)" }}
//         ></div>
//         <span>{"= 100 (Feed Value)"}</span>
//       </div>
//       <div className="legend-item">
//         <div
//           className="color-box"
//           style={{ backgroundColor: "rgba(255, 0, 0)" }}
//         ></div>
//         <span>{"> 100 (Feed Value)"}</span>
//       </div>
//       <div className="legend-item">
//         <div
//           className="color-box"
//           style={{ backgroundColor: "rgba(128, 128, 128)" }} // Grey color
//         ></div>
//         <span>{"Machine Disconnected"}</span>
//       </div>
//     </div>
//   );
// };


// const CustomTooltip = ({ active, payload, label }: any) => {
//   if (active && payload && payload.length) {
//     const speed = payload[0].value;
//     const time = formatToHoursMinutes(label);

//     return (
//       <div className="custom-tooltip">
//         <p className="speed-value">{`Speed: ${speed}`}</p>
//         <p className="time-value">{`Time: ${time}`}</p>
//       </div>
//     );
//   }
//   return null;
// };

// const formatToHoursMinutes = (timestamp: number) => {
//   const date = new Date(timestamp);
//   const hours = date.getHours().toString().padStart(2, "0");
//   const minutes = date.getMinutes().toString().padStart(2, "0");
//   return `${hours}:${minutes}`;
// };
// const getColor = (feed: number | null, sweep: boolean) => {
//   if (!sweep) {
//     return "grey"; // Grey color when sweep is false
//   } else if (feed === null) {
//     return "grey"; // Grey color for null values (assuming you still want this)
//   } else if (feed < 100) {
//     return "rgba(255, 255, 0)"; // Yellow for feed values below 100
//   } else if (feed === 100) {
//     return "rgba(0, 128, 0)"; // Green for feed value exactly 100
//   } else {
//     return "rgba(255, 0, 0)"; // Red for feed values above 100
//   }
// };

// const FeedChart: React.FC<FeedChartProps> = ({
//   selectedHours,
//   selectedMachine,
//   chartWidth,
//   activeTooltipIndex, // Make sure this prop is passed down from the parent
//   onMouseOver, // Make sure this prop is passed down from the parent
//   onMouseOut,
// }) => {
//   const dispatch: AppDispatch = useDispatch();
//   const feedData = useSelector(
//     (state: RootState) => state.feed.data[selectedMachine] || []
//   );

//   const [chartData, setChartData] = useState<any[]>([]);

//   const minBarWidth = 8;
//   const calculatedBarWidth = chartWidth / (chartData.length || 1);
//   const barWidth = Math.max(minBarWidth, calculatedBarWidth);

//   const fetchData = useCallback(() => {
//     dispatch(fetchFeedData({ hours: selectedHours, machine: selectedMachine }));
//   }, [dispatch, selectedHours, selectedMachine]);

//   useEffect(() => {
//     fetchData();
//     const interval = setInterval(fetchData, 60 * 1000); // Adjust interval as needed

//     return () => clearInterval(interval);
//   }, [fetchData]);

//   const fillGaps = (data: FeedData[], interval: number = 1000): FeedData[] => {
//     if (data.length === 0) return data;
  
//     const filledData: FeedData[] = [];
//     let previousData = data[0];
  
//     filledData.push(previousData);
  
//     for (let i = 1; i < data.length; i++) {
//       const currentData = data[i];
//       let gapTime = previousData.time + interval;
  
//       // Fill the gap with previous state data until the next data point is reached
//       while (gapTime < currentData.time) {
//         filledData.push({
//           time: gapTime,
//           feed: previousData.feed, // Carrying forward the previous 'feed' value
//           sweep: previousData.sweep, // Carrying forward the previous 'sweep' value
//         });
//         gapTime += interval;
//       }
  
//       filledData.push(currentData);
//       previousData = currentData;
//     }
  
//     return filledData;
//   };
  
//   useEffect(() => {
//     if (feedData.length > 0) {
//       const newDataWithGapsFilled = fillGaps(feedData, 60 * 1000); // Assuming a 1-minute interval
//       setChartData(newDataWithGapsFilled);
//     }
//   }, [feedData]);

//   // useEffect(() => {
//   //   if (feedData.length > 0) {
//   //     const newDataWithGapsFilled = fillGaps(feedData, 60 * 1000); // Assuming a 1-minute interval
//   //     setChartData(newDataWithGapsFilled);
//   //   }
//   // }, [feedData]);
//   // useEffect(() => {
//   //   setChartData(feedData);
//   // }, [feedData]);

//   const [timeTicks, setTimeTicks] = useState<number[]>([]);
//   useEffect(() => {
//     const currentTime = moment().valueOf();
//     const startTime = moment().subtract(selectedHours, "hours").valueOf();

//     const filteredData = feedData.filter(
//       (item) => item.time >= startTime && item.time <= currentTime
//     );

//     const newTimeTicks = generateTickValues(
//       startTime,
//       currentTime,
//       selectedHours
//     );
//     setTimeTicks(newTimeTicks); // Assuming setTimeTicks is a useState setter for timeTicks
//   }, [feedData, selectedHours]);

//   const calculateBarWidth = () => {
//     const numberOfBars = chartData.length;
//     const maxBarWidth = 0.5; // Adjust as needed
//     return Math.max(chartWidth / numberOfBars - 1, maxBarWidth);
//   };
//   // const barWidth = calculateBarWidth();

//   const CustomBarShape = (props: any) => {
//     const { x, width, value, index, payload } = props;

//     const color = getColor(payload.feed, payload.sweep);

//     const isFirstBar = index === 0;
//     const isLastBar = index === chartData.length - 1;
//     let radius = [0, 0, 0, 0]; // Default: no radius

//     if (chartData.length === 1) {
//       radius = [10, 10, 10, 10]; // Apply radius to all corners if only one bar
//     } else {
//       if (isFirstBar) {
//         radius = [10, 0, 0, 10]; // Left side rounded for the first bar
//       } else if (isLastBar) {
//         radius = [0, 10, 10, 0]; // Right side rounded for the last bar
//       }
//     }
//     const adjustedX = x - 3;
//     const adjustedWidth = width;
//     const fixedHeight = 30;
//     const adjustedY = 30 - fixedHeight;

//     return (
//       <Rectangle
//         {...props}
//         onMouseOver={() => onMouseOver(props.index)}
//         onMouseOut={onMouseOut}
//         x={adjustedX}
//         y={adjustedY}
//         width={adjustedWidth + 90}
//         height={fixedHeight}
//         fill={color}
//         // radius={radius}
//       />
//     );
//   };

//   // Assuming chartData is sorted by time
//   const start = chartData.length > 0 ? chartData[0].time : moment().valueOf();
//   const end =
//     chartData.length > 0
//       ? chartData[chartData.length - 1].time
//       : moment().add(1, "hour").valueOf();
//   const tickValues = generateTickValues(start, end, chartWidth);

//   return (
//     <div className="feed-chart-container">
//       <h6>Feed-Data</h6>

//       {chartData.length === 0 ? (
//         <div className="no-data-message">
//           Data is not available for this time period.
//         </div>
//       ) : (
//         <>
//           <ComposedChart
//             width={chartWidth + 9}
//             height={60}
//             data={chartData}
//             margin={{ top: 1, right: 30, bottom: 0, left: 30 }}
//             barSize={20}
//             barGap={0}
//             barCategoryGap={0}
//             onMouseMove={(e) => {
//               if (e.isTooltipActive && e.activeTooltipIndex !== undefined) {
//                 onMouseOver(e.activeTooltipIndex);
//               }
//             }}
//             onMouseLeave={onMouseOut}
//           >
//             <XAxis
//               dataKey="time"
//               type="number"
//               domain={["dataMin", "dataMax"]}
//               tickFormatter={(unixTime) => moment(unixTime).format("HH:mm")}
//               ticks={tickValues}
//               tick={{ fontSize: "9px" }}
//             />

//             <Tooltip
//               content={<CustomTooltip />}
//               active={activeTooltipIndex !== null}
//               payload={
//                 activeTooltipIndex !== null &&
//                 activeTooltipIndex >= 0 &&
//                 activeTooltipIndex < chartData.length &&
//                 chartData[activeTooltipIndex].feed !== null
//                   ? [
//                       {
//                         name: "Feed Speed",
//                         value: chartData[activeTooltipIndex].feed as number, // You need to ensure this index is within the data array bounds
//                       },
//                     ]
//                   : []
//               }
//               labelFormatter={(label) => formatToHoursMinutes(label)}
//             />

//             <Bar
//               dataKey="feed"
//               name="Feed Speed"
//               barSize={barWidth}
//               shape={(props:any) => <CustomBarShape {...props} />}
//             />
//           </ComposedChart>
//           <CustomLegend />
//         </>
//       )}
//     </div>
//   );
// };

// export default FeedChart;