import React, { useEffect, useState, useMemo, useCallback, useRef, } from "react";
import { useDispatch, useSelector } from 'react-redux';

import {
  ComposedChart,
  Bar,
  XAxis,
  Rectangle,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import moment from "moment";
import { fetchPartTimelineData } from "../../../redux/GanttReduces/partTimelineSlice";
import { RootState, AppDispatch } from "../../../redux/store";
import "../../../assets/css/PartTimelineChart.css";

interface PartTimelineChartProps {
  selectedHours: number;
  selectedMachine: string;
  chartWidth: number;
  timeTicks: number[];
  activeTooltipIndex: number | null;
  onMouseOver: (index: number) => void;
  onMouseOut: () => void;
  hoveredTime: number | null;
}

interface ColorMap {
  [name: string]: string;
}

const generateTickValues = (
  start: number,
  end: number,
  chartWidth: number
): number[] => {
  const durationInMinutes = moment(end).diff(moment(start), "minutes");
  const pixelsPerTick = 45;
  const numberOfTicks = chartWidth / pixelsPerTick;
  const intervalInMinutes = Math.ceil(durationInMinutes / numberOfTicks);

  const ticks: number[] = [];
  let current = moment(start);

  while (current.valueOf() <= end) {
    ticks.push(current.valueOf());
    current.add(intervalInMinutes, "minutes");
  }

  return ticks;
};

const PartTimelineChart: React.FC<PartTimelineChartProps> = React.memo(
  ({
    selectedHours,
    selectedMachine,
    chartWidth,
    hoveredTime,
    activeTooltipIndex,
    onMouseOver,
    onMouseOut,
  }) => {
    const dispatch: AppDispatch = useDispatch();
    const rawPartData = useSelector(
      (state: RootState) => state.partTimeline.data[selectedMachine] || []
    );
    const [mergedData, setMergedData] = useState<any[]>([]);
    const colorMapRef = useRef<ColorMap>({});

    const endDate = useMemo(() => new Date(), []);
    const startDate = useMemo(
      () => moment(endDate).subtract(selectedHours, "hours").toDate(),
      [selectedHours, endDate]
    );

    const getColorMap = useCallback(
      (data: any[]) => {
        const colors = [
          "#0088FE",
          "#00C49F",
          "#FFBB28",
          "#FF8042",
          "#8884d8",
          "#A55D35",
          "#D0B7B1",
          "#A58FAA",
          "#DDA0DD",
          "#5F9EA0",
        ];
        let colorIndex = 0;

        data.forEach((item) => {
          const partName = item.partName;
          if (!colorMapRef.current[partName]) {
            colorMapRef.current[partName] = colors[colorIndex % colors.length];
            colorIndex++;
          }
        });
      },
      [colorMapRef]
    );

    const fetchData = useCallback(() => {
      dispatch(
        fetchPartTimelineData({
          hours: selectedHours,
          machine: selectedMachine,
          observationName: "production",
        })
      );
    }, [dispatch, selectedHours, selectedMachine]);

    useEffect(() => {
      fetchData();
      const interval = setInterval(fetchData, 60 * 1000); // Fetch data every 1 seconds
      return () => clearInterval(interval);
    }, [fetchData]);

    useEffect(() => {
      if (rawPartData && rawPartData.length > 0) {
        getColorMap(rawPartData);

        const convertedData = rawPartData.map((item:any) => ({
          ...item,
          time: moment(item.time, "YYYY-MM-DD HH:mm:ss").valueOf(),
        }));

        setMergedData((prevData) => [...prevData, ...convertedData]);
      } else {
        setMergedData([]);
      }
    }, [rawPartData, selectedHours, startDate, endDate, getColorMap]);

    const formatToHoursMinutes = (timestamp: string) => {
      const date = new Date(timestamp);
      const hours = date.getHours().toString().padStart(2, "0");
      const minutes = date.getMinutes().toString().padStart(2, "0");
      return `${hours}:${minutes}`;
    };

    const CustomTooltip: React.FC<any> = ({ active, payload }) => {
      if (active && payload && payload.length) {
        const dataItem = payload[0].payload;
        const partName = dataItem.partName || "UNAVAILABLE";
        const comment = partName;
        const fullDate = new Date(dataItem.time);
        const formattedDate = fullDate.toLocaleDateString();
        const formattedTime = formatToHoursMinutes(dataItem.time);
        return (
          <div className="custom-tooltip">
            <p className="label">{`Part-Name: ${comment}`}</p>
            <p className="label">{`Date: ${formattedDate}`}</p>
            <p className="label">{`Time: ${formattedTime}`}</p>
          </div>
        );
      }
      return null;
    };

    const calculateBarWidth = () => {
      const maxBarWidth = 180;
      const minBarWidth = 900;
      const numBars = mergedData.length;
      const chartContainerWidth = chartWidth - 100;

      let barWidth = chartContainerWidth / numBars;
      barWidth = Math.max(Math.min(barWidth, maxBarWidth), minBarWidth);

      return barWidth;
    };

    const barWidth = calculateBarWidth();

    const CustomBarShape: React.FC<any> = (props) => {
      const { fill, x, width, index, totalBars } = props;
      const comment = props.payload.partName;
      const fillColor = colorMapRef.current[props.payload.partName] || "#d38181";
      const isFirstBar = index === 0;
      const isLastBar = index === totalBars - 1;

      let radius = [0, 0, 0, 0];
      if (totalBars === 1) {
        radius = [10, 10, 10, 10];
      } else if (isFirstBar) {
        radius = [10, 0, 0, 10];
      } else if (isLastBar) {
        radius = [0, 10, 10, 0];
      }
      const adjustedWidth = barWidth;
      const adjustedX = x;

      return (
        <Rectangle
          {...props}
          x={adjustedX - 5}
          y={5}
          width={adjustedWidth + 3}
          height={30}
          fill={fillColor}
        />
      );
    };

    const CustomLegend = () => (
      <div className="custom-legend">
        {Object.entries(colorMapRef.current).map(([comment, color]) => (
          <div key={comment} className="legend-item">
            <span
              className="legend-color-box"
              style={{
                background: color,
                display: "inline-block",
                width: "7px",
                height: "9px",
                marginRight: "5px",
              }}
            ></span>
            <span className="legend-text" style={{ fontSize: "9px" }}>
              {comment}
            </span>
          </div>
        ))}
      </div>
    );

    const tickInterval = 2;

    const start =
      mergedData.length > 0 ? mergedData[0].time : moment().valueOf();
    const end =
      mergedData.length > 0
        ? mergedData[mergedData.length - 1].time
        : moment().add(1, "hour").valueOf();
    const tickValues = useMemo(() => generateTickValues(start, end, chartWidth), [start, end, chartWidth]);

    return (
      <div className="part-timeline-chart-container">
        <h6>Part-Name Data</h6>
        {mergedData.length === 0 ? (
          <div className="no-data-message">
            Data is not available for this time period.
          </div>
        ) : (
          <>
            <div style={{ width: chartWidth + 6, height: "100%" }}>
              <ResponsiveContainer width="100%" height={62}>
                <ComposedChart
                  barGap={0}
                  barCategoryGap={0}
                  data={mergedData}
                  margin={{ top: 1, right: 30, bottom: 0, left: 30 }}
                >
                  <XAxis
                    dataKey="time"
                    type="number"
                    domain={["dataMin", "dataMax"]}
                    tickFormatter={formatToHoursMinutes}
                    ticks={tickValues}
                    tick={{ fontSize: "9px" }}
                  />

                  <Tooltip
                    content={<CustomTooltip />}
                    active={activeTooltipIndex !== null ? true : undefined}
                    cursor={{ fill: "transparent" }}
                  />

                  <Bar
                    dataKey="partName"
                    shape={(props) => (
                      <CustomBarShape
                        {...props}
                        fill={
                          colorMapRef.current[props.payload.partName] ||
                          "#d38181"
                        }
                        totalBars={mergedData.length}
                        onMouseOver={() => onMouseOver(props.index)}
                        onMouseOut={onMouseOut}
                      />
                    )}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </>
        )}
        <CustomLegend />
      </div>
    );
  }
);

export default PartTimelineChart;



// import React, { useEffect, useState, useMemo, useCallback, useRef } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import {
//   ComposedChart,
//   Bar,
//   XAxis,
//   Rectangle,
//   Tooltip,
//   ResponsiveContainer,
// } from "recharts";
// import moment from "moment"; // Import moment
// import { fetchPartTimelineData } from "../../../redux/GanttReduces/partTimelineSlice";
// import { RootState, AppDispatch } from "../../../redux/store";
// import "../../../assets/css/PartTimelineChart.css";

// interface PartTimelineChartProps {
//   selectedHours: number;
//   selectedMachine: string;
//   chartWidth: number;
//   timeTicks: number[]; // Update the type to string
//   activeTooltipIndex: number | null;
//   onMouseOver: (index: number) => void;
//   onMouseOut: () => void;
//   hoveredTime: number | null; // Update the type to string
// }

// interface ColorMap {
//   [name: string]: string;
// }

// const generateTickValues = (
//   start: number,
//   end: number,
//   chartWidth: number
// ): number[] => {
//   const durationInMinutes = moment(end).diff(moment(start), "minutes");
//   const pixelsPerTick = 45; // Adjust this value based on your preference
//   const numberOfTicks = chartWidth / pixelsPerTick;
//   const intervalInMinutes = Math.ceil(durationInMinutes / numberOfTicks);

//   const ticks: number[] = [];
//   let current = moment(start);

//   while (current.valueOf() <= end) {
//     ticks.push(current.valueOf());
//     current.add(intervalInMinutes, "minutes");
//   }

//   return ticks;
// };


// const PartTimelineChart: React.FC<PartTimelineChartProps> = ({
//   selectedHours,
//   selectedMachine,
//   chartWidth,
//   hoveredTime,
//   activeTooltipIndex,
//   onMouseOver,
//   onMouseOut,
// }) => {

//   const DISCONNECTED_COLOR = "#d38181"; // This color represents a disconnected machine
//   const DISCONNECTED_LEGEND_ITEM = {
//     comment: "Machine Disconnected", // Description for the disconnected state
//     color: DISCONNECTED_COLOR,       // Color representing a disconnected machine
//   };
  

//   const dispatch: AppDispatch = useDispatch();
//   const rawPartData = useSelector(
//     (state: RootState) => state.partTimeline.data[selectedMachine] || []
//   );
//   const [mergedData, setMergedData] = useState<any[]>([]);
//   const colorMapRef = useRef<ColorMap>({});
//   const endDate = useMemo(() => new Date(), []);
//   const startDate = useMemo(
//     () => moment(endDate).subtract(selectedHours, "hours").toDate(),
//     [selectedHours, endDate]
//   );


//   const getColorMap = useCallback((data: any[]) => {
//     const colors = [
//       "#0088FE",
//       "#00C49F",
//       "#FFBB28",
//       "#FF8042",
//       "#8884d8",
//       "#A55D35",
//       "#D0B7B1",
//       "#A58FAA",
//       "#DDA0DD",
//       "#5F9EA0",
//     ];
//     let colorIndex = 0;

//     data.forEach((item) => {
//       const partName = item.partName;
//       if (!colorMapRef.current[partName]) {
//         colorMapRef.current[partName] = colors[colorIndex % colors.length];
//         colorIndex++;
//       }
//     });
//   }, []);

//   const fetchData = useCallback(() => {
//     dispatch(
//       fetchPartTimelineData({
//         hours: selectedHours,
//         machine: selectedMachine,
//         observationName: "production",
//       })
//     );
//   }, [dispatch, selectedHours, selectedMachine]);

//   useEffect(() => {
//     fetchData();
//     const interval = setInterval(fetchData, 60 * 1000); // Fetch data every 1 seconds
//     return () => clearInterval(interval);
//   }, [fetchData]);

//   useEffect(() => {
//     if (rawPartData && rawPartData.length > 0) {
//       getColorMap(rawPartData);
  
//       const convertedData = rawPartData.map((item) => ({
//         ...item,
//         time: moment(item.time, "YYYY-MM-DD HH:mm:ss").valueOf(), // Convert to numeric timestamp
//       }));
  
//       setMergedData(convertedData);
//     } else {
//       setMergedData([]);
//     }
//   }, [rawPartData, selectedHours, startDate, endDate, getColorMap]);

//   const formatToHoursMinutes = (timestamp: string) => {
//     const date = new Date(timestamp);
//     const hours = date.getHours().toString().padStart(2, "0");
//     const minutes = date.getMinutes().toString().padStart(2, "0");
//     return `${hours}:${minutes}`;
//   };

//   const CustomTooltip: React.FC<any> = ({ active, payload }) => {
//     if (active && payload && payload.length) {
//       const dataItem = payload[0].payload;
//       const partName = dataItem.partName || "UNAVAILABLE";
//       const disconnectedMsg = dataItem.sweep === false ? " (Machine Disconnected)" : "";
//       const formattedDate = moment(dataItem.time).format('YYYY-MM-DD');
//       const formattedTime = formatToHoursMinutes(dataItem.time);
  
//       return (
//         <div className="custom-tooltip">
//           <p className="label">{`Part-Name: ${partName}${disconnectedMsg}`}</p>
//           <p className="label">{`Date: ${formattedDate}`}</p>
//           <p className="label">{`Time: ${formattedTime}`}</p>
//         </div>
//       );
//     }
//     return null;
//   };
  

//   const calculateBarWidth = () => {
//     const maxBarWidth = 180;
//     const minBarWidth = 900;
//     const numBars = mergedData.length;
//     const chartContainerWidth = chartWidth -100;

//     let barWidth = chartContainerWidth / numBars;
//     barWidth = Math.max(Math.min(barWidth, maxBarWidth), minBarWidth);

//     return barWidth;
//   };

//   const barWidth = calculateBarWidth();

//   const CustomBarShape: React.FC<any> = (props) => {
//     const { fill, x, width, index, totalBars } = props;
//     const comment = props.payload.partName;
//     const fillColor = props.payload.sweep === false ? DISCONNECTED_COLOR : colorMapRef.current[props.payload.partName] || "#8884d8";
//     const isFirstBar = index === 0;
//     const isLastBar = index === totalBars - 1;

//     let radius = [0, 0, 0, 0];
//     if (totalBars === 1) {
//       radius = [10, 10, 10, 10];
//     } else if (isFirstBar) {
//       radius = [10, 0, 0, 10];
//     } else if (isLastBar) {
//       radius = [0, 10, 10, 0];
//     }
//     const adjustedWidth = barWidth;
//     const adjustedX = x;

//     return (
//       <Rectangle
//         {...props}
//         x={adjustedX-5}
//         y={5}
//         width={adjustedWidth+3}
//         height={30}
//      fill={fillColor}
//       />
//     );
//   };

//   const CustomLegend = () => (
//     <div className="custom-legend">
//       {/* Add the "Machine Disconnected" legend item first */}
//       <div className="legend-item">
//         <span
//           className="legend-color-box"
//           style={{
//             background: DISCONNECTED_LEGEND_ITEM.color,
//             display: "inline-block",
//             width: "7px",
//             height: "9px",
//             marginRight: "5px",
//           }}
//         ></span>
//         <span className="legend-text" style={{ fontSize: "9px" }}>
//           {DISCONNECTED_LEGEND_ITEM.comment}
//         </span>
//       </div>
  
//       {/* Then add the dynamically generated legend items */}
//       {Object.entries(colorMapRef.current).map(([comment, color]) => (
//         <div key={comment} className="legend-item">
//           <span
//             className="legend-color-box"
//             style={{
//               background: color,
//               display: "inline-block",
//               width: "7px",
//               height: "9px",
//               marginRight: "5px",
//             }}
//           ></span>
//           <span className="legend-text" style={{ fontSize: "9px" }}>
//             {comment}
//           </span>
//         </div>
//       ))}
//     </div>
//   );
  

//   const tickInterval = 2;
 

//   const start = mergedData.length > 0 ? mergedData[0].time : moment().valueOf();
// const end = mergedData.length > 0 ? mergedData[mergedData.length - 1].time : moment().add(1, "hour").valueOf();
// const tickValues = generateTickValues(start, end, chartWidth);


//   return (
//     <div className="part-timeline-chart-container">
//     <h6>Part-Name Data</h6>
//     {mergedData.length === 0 ? (
//       <div className="no-data-message">
//         Data is not available for this time period.
//       </div>
//     ) : (
//       <>
//         <div style={{ width: chartWidth + 6, height: "100%" }}>
//           <ResponsiveContainer width="100%" height={62}>
//             <ComposedChart
//               barGap={0}
//               barCategoryGap={0}
//               data={mergedData}
//               margin={{ top: 1, right: 30, bottom: 0, left: 30 }}
//             >
//               <XAxis
//                 dataKey="time" // Update dataKey to "time"
//                 type="number"
//                 domain={["dataMin", "dataMax"]}
//                 tickFormatter={formatToHoursMinutes}
//                 ticks={tickValues}
//                 tick={{ fontSize: "9px" }}
//               />

//               <Tooltip
//                 content={<CustomTooltip />}
//                 active={activeTooltipIndex !== null ? true : undefined}
//                 cursor={{ fill: "transparent" }}
//               />

//               <Bar
//                 dataKey="partName"
//                 shape={(props:any) => (
//                   <CustomBarShape
//                     {...props}
//                     fill={
//                       colorMapRef.current[props.payload.partName] || "#d38181"
//                     }
//                     totalBars={mergedData.length}
//                     onMouseOver={() => onMouseOver(props.index)}
//                     onMouseOut={onMouseOut}
//                   />
//                 )}
//               />
//             </ComposedChart>
//           </ResponsiveContainer>
//         </div>
//       </>
//     )}
//     <CustomLegend />
//   </div>
//   );
// };

// export default PartTimelineChart;