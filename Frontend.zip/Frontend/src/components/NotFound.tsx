import React from "react";
import "../assets/css/NotFound.css";
import { Modal, Button, Form, Row, Col } from "react-bootstrap";

interface NotFoundProps {
  showModal: boolean;
  closeModal: () => void;
}

const NotFound: React.FC<NotFoundProps> = ({ showModal, closeModal }) => {
  return (
    <Modal show={showModal} onHide={closeModal} size="lg" centered>
      <Modal.Header closeButton>
        <Modal.Title
          style={{ textAlign: "center", width: "100%" }}
          className="notFound-title"
        >
          Not Authorized
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="modal-container">
        <div className="not-found">
          <h1>Unauthorized Access</h1>
          <p>Sorry, you are not authorized to view this page.</p>
          <p>Please log in or contact an administrator for access.</p>
          {/* <img src="/unauthorized-image.png" alt="Unauthorized" /> */}
        </div>
      </Modal.Body>
    </Modal>
  );
};

export default NotFound;
