import React from 'react';
import { AppBar, Toolbar, Typography, Button, IconButton } from '@mui/material';
import { Home, Dashboard, Accessibility, Menu, Login, Logout } from '@mui/icons-material';
import { Link, useNavigate } from 'react-router-dom';
import logoImage from '../assets/images/logo1.png';
import '../assets/css/Navbar.css';

interface NavbarProps {
  toggleSidebar: () => void;
  isLoggedIn: boolean; // Add isLoggedIn prop to determine if the user is logged in
  handleLogout: () => void; // Add handleLogout prop to handle the logout action
}

const Navbar: React.FC<NavbarProps> = ({ toggleSidebar, isLoggedIn, handleLogout }) => {
  const navigate = useNavigate(); 
  const handleLogoutAndRedirect = () => {
    handleLogout(); // Perform logout logic (clear tokens, reset user data, etc.)
    navigate('/login'); // Redirect to the login page
  };
  
  return (
    <AppBar position="static">
      <Toolbar className="Toolbar">
        <div className="left-content">
          <IconButton
            color="inherit"
            aria-label="Open Sidebar"
            edge="start"
            onClick={toggleSidebar}
          >
            <Menu />
          </IconButton>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            <img src={logoImage} alt="Logo" className="logo" />
          </Typography>
        </div>
        <div className="right-content">
          <Button
            color="inherit"
            startIcon={<Home />}
            component={Link}
            to="/home"
            className="button-style"
          >
            Home
          </Button>
          {/* <Button
            color="inherit"
            startIcon={<Dashboard />}
            component={Link}
            to="/dashboard"
            className="button-style"  
          >
            Dashboard
          </Button> */}
          {/* <Button
            color="inherit"
            startIcon={<Accessibility />}
            component={Link}
            to="/permission"
            className="button-style"
          >
            Permission
          </Button> */}
          {sessionStorage.getItem('isLoggedIn') ? (
            <Button
              color="inherit"
              startIcon={<Login />}
              onClick={handleLogoutAndRedirect} 
              className="logout-button"
              
            >
              Logout
            </Button> 
          ) : (
            <Button
              color="inherit"
              startIcon={<Logout />}
              component={Link}
              to="/login"
              className="login-button"
              
            >
              Login
            </Button>
          )}
        </div>
      </Toolbar>

    </AppBar>
  );
};

export default Navbar;


// another way of styling for button

// {isLoggedIn ? (
//   <Button
//     color="inherit"
//     startIcon={<Login />}
//     onClick={handleLogoutAndRedirect}
//     className="logout-button" // Use className here
//   >
//     Logout
//   </Button>
// ) : (
//   <Button
//     color="inherit"
//     startIcon={<Logout />}
//     component={Link}
//     to="/login"
//     className="login-button" // Use className here
//   >
//     Login
//   </Button>
// )}



// import React from 'react';
// import { AppBar, Toolbar, Typography, Button, IconButton } from '@mui/material';
// import { Home, Info, Work, ContactMail, Dashboard, Login, Menu, Accessibility } from '@mui/icons-material';
// import { Link } from 'react-router-dom';
// import logoImage from '../assets/images/logo1.png';
// import '../assets/css/logo.css';


// interface NavbarProps {
//   toggleSidebar: () => void; // Make sure to define the prop
// }

// const Navbar: React.FC<NavbarProps>  = ({ toggleSidebar })  => {
//   return (
//     <AppBar position="static">
//       <Toolbar>
//         <IconButton color="inherit" aria-label="Open Sidebar" edge="start" onClick={toggleSidebar}>
//           <Menu />
//         </IconButton>
//         <Typography variant="h6" component="div" sx={{ flexGrow: 1 } }>
//           <img src={logoImage} alt="Logo" className='logo' />
//         </Typography>
     
//         <Button
//           color="inherit"
//           startIcon={<Home />}
//           component={Link}
//           to="/home"
//         >
//           Home
//         </Button>
//         <Button color="inherit" startIcon={<Dashboard />} href="#services">
//           DashBoard
//         </Button>
//         <Button color="inherit" startIcon={<Accessibility />} component={Link} to="/permission">
//           Permission
//         </Button>
//         {/* <Button color="inherit" startIcon={<Info />} href="#about">
//           About
//         </Button> */}
//         <Button
//           color="inherit"
//           startIcon={<Login />}
//           component={Link}
//           to="/login"
//         >
//           Login
//         </Button>
       
//       </Toolbar>
      
//     </AppBar>
    
//   );
// };

// export default Navbar;
