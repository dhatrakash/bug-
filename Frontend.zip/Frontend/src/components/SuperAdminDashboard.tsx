import React from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const SuperAdminDashboard: React.FC = () => {
    const nav = useNavigate();
    const handleLogOut = async (e: React.MouseEvent<HTMLButtonElement>) => {
        try
        {
        const response = await fetch('http://localhost:3000/v1/superAdminAuth/logoutSuperAdmin', {
          method: 'POST',
          headers: {
              'content-type': 'application/json'
          },
          body: JSON.stringify({refreshToken:localStorage.getItem('refresh-token')})            
      });
      if(response.status === 204)
      {
        localStorage.clear();
        toast.success("You have been signed out.",{
            position: "top-right"})
        nav('/home');    
      }else{
        const data = await response.json();
        toast.error(data.message,{
            position: "top-right"})
    }
        }catch(err)
        {
            console.log(err);
            toast.error("Internal Server Error ! ",{
            position: "top-right"})

        }
    }

    return (
        localStorage.getItem('access-token') && localStorage.getItem('refresh-token') ?
        <div>
            <h1>This is superadmin dashboard</h1>
            <h1>You have access tokens</h1>
            <center>
                <button className='btn btn-danger' onClick={handleLogOut}>Log Out</button>
            </center>
        </div> :
        <div><h1>You don't have access tokens</h1></div>
    )
}

export default SuperAdminDashboard;
