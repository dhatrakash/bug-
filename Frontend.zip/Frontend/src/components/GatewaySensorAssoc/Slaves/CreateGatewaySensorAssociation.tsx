import React, { useState, useEffect, useCallback } from "react";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Grid,
  Typography,
  Tooltip,
  TextField,
  FormControl,
  Autocomplete,
  Divider,
  Button,
  DialogActions,
  Link,
} from "@mui/material";
import {
  ExpandMore as ExpandMoreIcon,
  Info as InfoIcon,
  Sensors as AddSensorIcon,
} from "@mui/icons-material";
import { toast } from "react-toastify";
import {
  Sensor,
  Gateway,
  GatewaySensorAssociation,
} from "../../../redux/types";
import {
  createGatewaySensorAssociation,
  findByMappingGatewayId,
} from "../../../redux/gatewaySensorAsscSlice";
import { fetchSensorById } from "../../../redux/sensorSlice";
import CreateSensor from "../../Sensor/CreateSensor";
import EditAssociation from "./EditAssociation";
import "../../../assets/css/CreateGatewaySensorAssociation.css";
interface CreateGatewaySensorAssociationProps {
  sensorData: Sensor[] | null;
  gatewayData: Gateway | null;
}

const initialInputsData: GatewaySensorAssociation = {
  sensorNodeName: "",
  slaveId: "",
  tag: "",
  sensorId: "",
  mappingId: "",
  gatewayId: "",
};
const CreateGatewaySensorAssociation: React.FC<CreateGatewaySensorAssociationProps> =
  React.memo(({ gatewayData, sensorData }) => {
    const dispatch = useMachinewiseDispatch();
    const [showSensorModal, setShowSensorModal] = useState(false);
    const [inputData, setInputData] = useState<GatewaySensorAssociation[]>([
      initialInputsData,
    ]);
    const [expanded, setExpanded] = useState(false);
    const [selectedAssociation, setSelectedAssociation] = useState<any>(null);
    const [editModalOpen, setEditModalOpen] = useState(false);
    // eslint-disable-next-line
    const [loadingSensors, setLoadingSensors] = useState<boolean>(true);
    const [sensorNames, setSensorNames] = useState<Record<string, string>>({});
    const gatewaySensorAssociations: GatewaySensorAssociation[] | null =
      useMachinewiseSelector(
        (state) => state.gatewaySensorAssociation.gatewaySensorAssociations
      );
    console.log("available sensors", sensorData);
    console.log("gatewaySensorAssociations:", gatewaySensorAssociations);

    const dispatchAction = useCallback(
      (gatewayId: string | undefined) => {
        if (gatewayId) {
          dispatch(findByMappingGatewayId(gatewayId));
        }
      },
      [dispatch]
    );

    useEffect(() => {
      const gatewayId = gatewayData?.gatewayId;
      dispatchAction(gatewayId);

      // Update sensorNames based on sensorData
      if (sensorData) {
        const newSensorNames: Record<string, string> = {};
        sensorData.forEach((sensor) => {
          if (sensor && sensor.sensorId) {
            newSensorNames[sensor.sensorId] = sensor.sensorName || "";
          }
        });
        setSensorNames(newSensorNames);
      }
    }, [dispatchAction, gatewayData?.gatewayId, dispatch, sensorData]);

    const handleCreateGatewaySlaveAssoc = async (index: number) => {
      const selectedGatewayId = gatewayData?.gatewayId || "";
      const { slaveId, tag, sensorNodeName, sensorId } = inputData[index];

      if (!slaveId || !tag || !sensorNodeName || !sensorId) {
        toast.error("Please fill in all required fields");
        return;
      }
      const selectedSensor = sensorData?.find(
        (sensor) => sensor.sensorId === sensorId
      );
      if (!selectedSensor) {
        toast.error("Invalid sensor selected");
        return;
      }

      const inputDataObject = {
        gatewayId: selectedGatewayId,
        slaveId,
        tag,
        sensorNodeName,
        sensorId: selectedSensor.sensorId,
      };

      try {
        // Add data to the backend
        const createaction = await dispatch(
          createGatewaySensorAssociation(inputDataObject)
        );
        if (createGatewaySensorAssociation.fulfilled.match(createaction)) {
          setInputData((prevData) => {
            const updatedData = [...prevData];
            updatedData[index] = initialInputsData; // Replace with empty fields
            return updatedData;
          });

          toast.success("Slave association created successfully!");
        } else {
          toast.error("Error creating Slave association. Please try again.");
        }
        // Update the row in the form with empty fields
      } catch (error) {
        console.error("An Error Occured", error);
        toast.error("An Error Occured..!");
      }
    };

    const handleInputsOnChange = (
      e: React.ChangeEvent<HTMLInputElement>,
      index: number
    ) => {
      const { name, value } = e.target;
      setInputData((prevData) => {
        const updatedData = [...prevData];
        updatedData[index] = {
          ...updatedData[index],
          [name]: value,
        };
        return updatedData;
      });
    };

    const handleSelectChange = (
      e: React.ChangeEvent<{}>,
      value: { value: string; label: string } | null,
      index: number
    ) => {
      setInputData((prevData) => {
        const updatedData = [...prevData];
        updatedData[index] = {
          ...updatedData[index],
          sensorId: value?.value || "",
        };
        return updatedData;
      });
    };
    const handleEditClick = (association: any) => {
      setSelectedAssociation(association);
      setEditModalOpen(true);
    };
    const handleChange = () => {
      setExpanded(!expanded);
    };
    const fetchSensorName = useCallback(
      async (
        sensorId: string | Sensor
      ): Promise<{ payload: { sensorName: string } }> => {
        try {
          if (typeof sensorId === "string") {
            const action = await dispatch(fetchSensorById(sensorId));

            if (fetchSensorById.fulfilled.match(action)) {
              const fetchedsensor = action.payload;
              const sensorName = fetchedsensor?.sensorName || "";
              return Promise.resolve({ payload: { sensorName } });
            }
          }

          return Promise.resolve({ payload: { sensorName: "" } });
        } catch (error) {
          console.error("Error fetching sensor name:", error);
          toast.error("Error fetching sensor name. Please try again.");
          return Promise.reject(error);
        }
      },
      [dispatch]
    );
    // eslint-disable-next-line
    const fetchAndStoreSensorNames = useCallback(async () => {
      if (sensorData) {
        const data: Record<string, string> = {};

        for (const sensorItem of sensorData) {
          try {
            if (typeof sensorItem.sensorId === "string") {
              const response = await fetchSensorName(sensorItem.sensorId);

              if (response.payload?.sensorName) {
                data[sensorItem.sensorId] = response.payload.sensorName;
              } else {
                data[sensorItem.sensorId] = "";
              }
            }
          } catch (error) {
            console.error("Error fetching sensor name:", error);
            toast.error("Error fetching sensor name. Please try again.");
          }
        }

        setSensorNames(data);
        setLoadingSensors(false);
      }
    }, [sensorData, fetchSensorName]);

    return (
      <>
        <form style={{ padding: "20px" }}>
          <Grid container spacing={1}>
            <Grid item xs={12} sm={12}>
              <TextField
                label="Gateway MAC ID"
                name="macId"
                value={gatewayData?.macId}
                fullWidth
                margin="normal"
                disabled
              />
            </Grid>
            <Grid item xs={12}>
              <Accordion
                className="accordion"
                expanded={expanded}
                onChange={handleChange}
              >
                <AccordionSummary
                  className="accordionSummary"
                  expandIcon={<ExpandMoreIcon />}
                >
                  <Typography style={{ fontSize: "16px" }}>
                    Available Gateway Sensor Associations (Modbus)
                  </Typography>
                </AccordionSummary>
                <AccordionDetails className="accordionDetails">
                  {gatewaySensorAssociations?.length === 0 ? (
                    <div className="noAssociationsMessage">
                      <Typography variant="subtitle1" color="textSecondary">
                        No Associations available
                      </Typography>
                      <InfoIcon color="disabled" fontSize="large" />
                    </div>
                  ) : (
                    <div>
                      {gatewaySensorAssociations?.map((association) => (
                        <>
                          {" "}
                          <Grid
                            key={association.mappingId}
                            container
                            spacing={2}
                          >
                            <Grid item xs={12} sm={2}>
                              <TextField
                                label="Slave ID"
                                value={association.slaveId}
                                fullWidth
                                margin="normal"
                                disabled
                                size="small"
                              />
                            </Grid>
                            <Grid item xs={12} sm={2.5}>
                              <TextField
                                label="Tag"
                                value={association.tag}
                                fullWidth
                                margin="normal"
                                disabled
                                size="small"
                              />
                            </Grid>
                            <Grid item xs={12} sm={2.5}>
                              <TextField
                                label="Sensor Node Name"
                                value={association.sensorNodeName}
                                fullWidth
                                margin="normal"
                                disabled
                                size="small"
                              />
                            </Grid>
                            <Grid item xs={12} sm={3}>
                              <>
                                <TextField
                                  label="Sensor Name"
                                  value={
                                    typeof association.sensorId === "string"
                                      ? sensorNames[
                                          association.sensorId as string
                                        ]
                                      : (association.sensorId as Sensor)
                                          ?.sensorName
                                  }
                                  fullWidth
                                  margin="normal"
                                  disabled
                                  size="small"
                                />
                                {console.log(
                                  "Type of association.sensorId:",
                                  typeof association.sensorId
                                )}
                              </>
                            </Grid>

                            <Grid item className="addSensorButton">
                              <Tooltip title="Update Association">
                                <Button
                                  onClick={() => handleEditClick(association)}
                                >
                                  Edit
                                </Button>
                              </Tooltip>{" "}
                            </Grid>
                          </Grid>{" "}
                          <Divider
                            style={{
                              color: "#1976d2",
                              paddingTop: "10px",
                              paddingBottom: "10px",
                            }}
                          >
                            <Typography
                              variant="h4"
                              fontSize="20px"
                              style={{ color: "#1976d2" }}
                            >
                              ---
                            </Typography>
                          </Divider>
                        </>
                      ))}{" "}
                    </div>
                  )}
                </AccordionDetails>
              </Accordion>
            </Grid>
          </Grid>
          {inputData.map((row, index) => (
            <Grid key={index} container spacing={1}>
              <Grid item xs={12} sm={2}>
                <TextField
                  label="Slave ID"
                  name="slaveId"
                  value={row.slaveId}
                  fullWidth
                  margin="normal"
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    handleInputsOnChange(e, index)
                  }
                />
              </Grid>
              <Grid item xs={12} sm={2.5}>
                <TextField
                  label="Tag"
                  name="tag"
                  value={row.tag}
                  fullWidth
                  margin="normal"
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    handleInputsOnChange(e, index)
                  }
                />
              </Grid>
              <Grid item xs={12} sm={2.5}>
                <TextField
                  label="Sensor Node Name"
                  name="sensorNodeName"
                  value={row.sensorNodeName}
                  fullWidth
                  margin="normal"
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    handleInputsOnChange(e, index)
                  }
                />
              </Grid>
              <Grid item xs={12} sm={3}>
                <FormControl fullWidth margin="normal">
                  <Autocomplete
                    value={
                      typeof row.sensorId === "string"
                        ? {
                            value: row.sensorId,
                            label: sensorNames[row.sensorId] || "",
                          }
                        : null
                    }
                    options={
                      sensorData?.map((sensor) => ({
                        value: sensor.sensorId || "", // Ensure value is non-nullable
                        label: sensor.sensorName,
                      })) || []
                    }
                    getOptionLabel={(option) => option.label || ""}
                    renderInput={(params) => (
                      <TextField {...params} label="Select Sensor" />
                    )}
                    onChange={(e, value) => handleSelectChange(e, value, index)}
                    isOptionEqualToValue={(option, value) =>
                      option.value === value?.value
                    }
                  />
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={1.5} className="addSensorButton">
                <Tooltip title="Submit & Add Sensor Slave">
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => handleCreateGatewaySlaveAssoc(index)}
                  >
                    Submit
                  </Button>
                </Tooltip>
              </Grid>{" "}
            </Grid>
          ))}
        </form>{" "}
        <DialogActions>
          <Typography variant="body2" color="textSecondary">
            No sensors available in list.{" "}
            <Link
              onClick={() => setShowSensorModal(true)}
              style={{ cursor: "pointer" }}
            >
              Create a New Sensor <AddSensorIcon style={{ fontSize: "1rem" }} />
            </Link>{" "}
            to associate with this gateway.
          </Typography>
        </DialogActions>
        <EditAssociation
          isOpen={editModalOpen}
          handleClose={() => setEditModalOpen(false)}
          associationData={selectedAssociation}
          gatewayId={gatewayData?.gatewayId}
        />{" "}
        <CreateSensor
          showModal={showSensorModal}
          closeModal={() => setShowSensorModal(false)}
        />
      </>
    );
  });

export default CreateGatewaySensorAssociation;
