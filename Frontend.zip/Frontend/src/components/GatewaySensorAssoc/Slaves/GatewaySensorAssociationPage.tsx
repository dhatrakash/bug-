import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  archiveGatewaySensorAssociation,
  deleteGatewaySensorAssociation,
  findByMappingGatewayId,
} from "../../../redux/gatewaySensorAsscSlice";
import {
  Gateway,
  GatewaySensorAssociation,
  Sensor,
} from "../../../redux/types";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Paper,
  CircularProgress,
  Typography,
  IconButton,
  Tooltip,
  TextField,
} from "@mui/material";
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  Archive as ArchiveIcon,
} from "@mui/icons-material";

import { fetchGatewayById } from "../../../redux/gatewaySlice";
import { fetchSensorById } from "../../../redux/sensorSlice";
import { toast } from "react-toastify";
import EditAssociation from "./EditAssociation";
import Pagination from "@mui/material/Pagination";
import "../../../assets/css/GatewaySensorAssociationDetails.css";
import DeleteAssociation from "../DeleteAssociation";
import ArchiveAssociation from "../ArchiveAssociation";

const GatewaySensorAssociationDetails: React.FC = () => {
  const [page, setPage] = useState(1);
  const itemsPerPage = 2; // Adjust the number of items per page as needed
  const [filterSlaveId, setFilterSlaveId] = useState<string | null>(null);
  const [filterTag, setFilterTag] = useState<string | null>(null);
  const [filterSensorNode, setFilterSensorNode] = useState<string | null>(null);
  const [filterSensorName, setFilterSensorName] = useState<string | null>(null);

  const { gatewayId } = useParams<{ gatewayId: string }>();
  const dispatch = useMachinewiseDispatch();
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [selectedAssociation, setSelectedAssociation] = useState<any>(null);
  //  state for delete confirmation modal
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [selectedAssociationForDelete, setSelectedAssociationForDelete] =
    useState<GatewaySensorAssociation | null>(null);

  const [archiveModalOpen, setArchiveModalOpen] = useState(false);
  // Map the gatewaySensorAssociations data based on the current page

  useEffect(() => {
    // Check if gatewayId is defined before fetching data
    if (gatewayId) {
      dispatch(findByMappingGatewayId(gatewayId));
      dispatch(fetchGatewayById(gatewayId));
    }
  }, [dispatch, gatewayId]);

  const gatewaySensorAssociations: GatewaySensorAssociation[] | null =
    useMachinewiseSelector(
      (state) => state.gatewaySensorAssociation.gatewaySensorAssociations
    );

  const selectedGateway: Gateway | null = useMachinewiseSelector(
    (state) => state.gateway.gateways && state.gateway.gateways[0]
  );

  const [loadingSensors, setLoadingSensors] = useState<boolean>(true);
  const [sensorNames, setSensorNames] = useState<Record<string, string>>({});
  /* eslint-disable react-hooks/exhaustive-deps */
  useEffect(() => {
    if (gatewaySensorAssociations) {
      const fetchData = async () => {
        // eslint-disable-next-line
        const data: Record<string, string> = {};
        for (const association of gatewaySensorAssociations) {
          if (association.sensorId) {
            await fetchSensorName(association.sensorId);
          }
        }
        setLoadingSensors(false);
      };

      fetchData();
    }
  }, [dispatch, gatewaySensorAssociations]);

  const fetchSensorName = async (sensorId: string | Sensor) => {
    try {
      if (typeof sensorId === "string") {
        const response = await dispatch(fetchSensorById(sensorId));

        if (response.payload?.sensorName) {
          setSensorNames((prevSensorNames) => ({
            ...prevSensorNames,
            [sensorId]: response.payload.sensorName,
          }));
        } else {
          setSensorNames((prevSensorNames) => ({
            ...prevSensorNames,
            [sensorId]: "",
          }));
        }
      }
    } catch (error) {
      console.error("Error fetching sensor name:", error);
      toast.error("Error fetching sensor name. Please try again.");
    }
  };

  if (!selectedGateway) {
    return <Typography variant="h5">Gateway not found</Typography>;
  }
  if (!gatewaySensorAssociations || !selectedGateway || loadingSensors) {
    return <CircularProgress />;
  }
  const handleEditClick = (association: any) => {
    setSelectedAssociation(association);
    setEditModalOpen(true);
  };
  const handleDeleteClick = (association: GatewaySensorAssociation) => {
    setSelectedAssociationForDelete(association);
    setDeleteModalOpen(true);
  };

  const handleCloseDeleteModal = () => {
    setSelectedAssociationForDelete(null);
    setDeleteModalOpen(false);
  };

  const handleDeleteAssociation = async () => {
    if (
      !selectedAssociationForDelete ||
      !selectedAssociationForDelete.mappingId
    ) {
      // Handle the case where selectedAssociationForDelete or mappingId is missing
      return;
    }

    try {
      // Dispatch the delete action
      const deleteAction = await dispatch(
        deleteGatewaySensorAssociation(selectedAssociationForDelete.mappingId)
      );
      if (deleteGatewaySensorAssociation.fulfilled.match(deleteAction)) {
        // navigate(`/gatewaySensorAssociation/${gatewayId}`);
        toast.success("Association deleted successfully");
      } else {
        toast.error("Failed to delete..!");
      }
    } catch (error) {
      // Handle any errors
      console.error("An error occured", error);
      toast.error("An error occured");
    }

    // Close the delete confirmation modal
    handleCloseDeleteModal();
  };

  const handleArchiveClick = (association: GatewaySensorAssociation) => {
    setSelectedAssociation(association);
    setArchiveModalOpen(true);
  };
  const handleCloseArchiveModal = () => {
    setSelectedAssociation(null);
    setArchiveModalOpen(false);
  };
  const handleArchiveAssociation = async () => {
    if (!selectedAssociation || !selectedAssociation.mappingId) {
      return;
    }

    try {
      // Dispatch the archive action
      const archiveAction = await dispatch(
        archiveGatewaySensorAssociation(selectedAssociation.mappingId)
      );
      if (archiveGatewaySensorAssociation.fulfilled.match(archiveAction)) {
        toast.success("Association archived!!!");
      } else {
        toast.error("Failed to Archive");
      }
      // navigate(`/gatewaySensorAssociation/${gatewayId}`);
    } catch (error) {
      // Handle any errors
      console.error("An error occured", error);
      toast.error("An error occured");
    }

    // Close the delete confirmation modal
    handleCloseArchiveModal();
  };

  return (
    <div className="gateway-sensor-details">
      {" "}
      <h2 style={{ color: "#1976d2", textAlign: "center", fontWeight: "500" }}>
        Gateway Sensor Associations (Modbus)
      </h2>
      <Paper className="details-paper">
        <Typography variant="h5" paddingBottom={"20px"}>
          Gateway MAC ID: {selectedGateway.macId}
        </Typography>{" "}
        <div className="filter-fields">
          <TextField
            size="small"
            // id="outlined-size-small"
            label="Filter Slave ID"
            value={filterSlaveId || ""}
            onChange={(e) => setFilterSlaveId(e.target.value)}
          />
          <TextField
            size="small"
            label="Filter Tag"
            value={filterTag || ""}
            onChange={(e) => setFilterTag(e.target.value)}
          />
          <TextField
            size="small"
            label="Filter Sensor Node Name"
            value={filterSensorNode || ""}
            onChange={(e) => setFilterSensorNode(e.target.value)}
          />
          <TextField
            size="small"
            label="Filter Sensor Name"
            value={filterSensorName || ""}
            onChange={(e) => setFilterSensorName(e.target.value)}
          />
        </div>
        <Table className="details-table">
          <TableHead>
            <TableRow>
              {" "}
              <TableCell>Slave ID</TableCell>
              <TableCell>Tag</TableCell>
              <TableCell>Sensor Node Name</TableCell>
              <TableCell>Sensor Name</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {gatewaySensorAssociations
              .filter((association) => {
                const lowerCaseFilterDIId = filterSlaveId?.toLowerCase();
                const lowerCaseFilterTag = filterTag?.toLowerCase();
                const lowerCaseFilterSensorNode =
                  filterSensorNode?.toLowerCase();
                const lowerCaseFilterSensorName =
                  filterSensorName?.toLowerCase();

                return (
                  (!lowerCaseFilterDIId ||
                    association.slaveId
                      .toLowerCase()
                      .includes(lowerCaseFilterDIId)) &&
                  (!lowerCaseFilterTag ||
                    association.tag
                      .toLowerCase()
                      .includes(lowerCaseFilterTag)) &&
                  (!lowerCaseFilterSensorNode ||
                    association.sensorNodeName
                      .toLowerCase()
                      .includes(lowerCaseFilterSensorNode)) &&
                  (!lowerCaseFilterSensorName ||
                    (typeof association.sensorId === "string"
                      ? sensorNames[association.sensorId]?.toLowerCase() || ""
                      : (
                          association.sensorId as Sensor | undefined
                        )?.sensorName?.toLowerCase() || ""
                    ).includes(lowerCaseFilterSensorName))
                );
              })
              .map((association) => (
                <TableRow key={association.mappingId}>
                  <TableCell>{association.slaveId}</TableCell>
                  <TableCell>{association.tag}</TableCell>
                  <TableCell>{association.sensorNodeName}</TableCell>
                  <TableCell>
                    {/* {sensorNames[association.sensorId as string] || "N/A"} */}
                    {typeof association.sensorId === "string"
                      ? sensorNames[association.sensorId] || ""
                      : (association.sensorId as Sensor | undefined)
                          ?.sensorName || ""}
                  </TableCell>
                  <TableCell>
                    <Tooltip title="Update Sensor">
                      <IconButton
                        color="primary"
                        onClick={() => handleEditClick(association)}
                      >
                        <EditIcon />
                      </IconButton>
                    </Tooltip>{" "}
                    <Tooltip title="Archive" arrow>
                      <IconButton
                        color="primary"
                        onClick={() => handleArchiveClick(association)}
                      >
                        <ArchiveIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete  Association permanently">
                      <IconButton
                        color="error"
                        onClick={() => handleDeleteClick(association)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
        <Pagination
          count={Math.ceil(gatewaySensorAssociations.length / itemsPerPage)}
          page={page}
          onChange={(_, value) => setPage(value)}
          color="primary"
        />
      </Paper>
      <EditAssociation
        isOpen={editModalOpen}
        handleClose={() => setEditModalOpen(false)}
        associationData={selectedAssociation}
        gatewayId={gatewayId}
      />
      <DeleteAssociation
        open={deleteModalOpen}
        onClose={handleCloseDeleteModal}
        onDelete={handleDeleteAssociation}
      />
      <ArchiveAssociation
        open={archiveModalOpen}
        onClose={handleCloseArchiveModal}
        onArchive={handleArchiveAssociation}
      />
    </div>
  );
};

export default GatewaySensorAssociationDetails;
