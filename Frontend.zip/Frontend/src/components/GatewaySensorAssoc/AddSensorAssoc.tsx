import React, { useCallback, useEffect, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Tabs,
  Tab,
  CircularProgress,
} from "@mui/material";
import { Gateway } from "../../redux/types";
import { fetchSensors } from "../../redux/sensorSlice";
import { RootState } from "../../redux/store";

import CloseIcon from "@mui/icons-material/Close";
import { makeStyles } from "@mui/styles";
import CreateGatewaySensorAssociation from "./Slaves/CreateGatewaySensorAssociation";
import CreateGatewayInputsAssociation from "./Inputs/CreateGatewayInputsAssociation";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";

interface AddSensorProps {
  open: boolean;
  handleClose: () => void;
  gatewayData?: Gateway | null;
  // handleAddSlave: (slaveData: Slaves) => void;
}

const useStyles = makeStyles(() => ({
  addSensorButton: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    paddingBottom: "10px",
    color: "#1976D2",
  },

  closeButton: {
    position: "relative",
    // top: "8px",
    // right: "8px",
  },
  titleContainer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    paddingBottom: "10px",
    color: "#1976D2",
  },
  loadingContainer: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "100px",
  },
}));
const AddSensor: React.FC<AddSensorProps> = ({
  open,
  handleClose,
  gatewayData,
}) => {
  const [activeTab, setActiveTab] = useState("slaves");
  const { sensors } = useMachinewiseSelector(
    (state: RootState) => state.sensor
  );
  const sensorDispatch = useMachinewiseDispatch();
  const classes = useStyles();
  const [loadingSensors, setLoadingSensors] = useState(false);

  // useEffect(() => {
  //   if (open && sensors?.length === 0) {
  //     // Fetch sensors only when the modal is opened and sensors are not loaded
  //     setLoadingSensors(true); // Set loading state to true
  //     sensorDispatch (fetchSensors()).then(() => {
  //       // After fetching, set loading state to false
  //       setLoadingSensors(false);
  //     });
  //   }
  // }, [sensorDispatch , open, sensors]);

  // useEffect(() => {
  //   sensorDispatch (fetchSensors());
  // }, [sensorDispatch ]);
  useEffect(() => {
    if (open && sensors?.length === 0 && !loadingSensors) {
      setLoadingSensors(true);
      sensorDispatch(fetchSensors()).then(() => {
        setLoadingSensors(false);
      });
    }
  }, [sensorDispatch, open, sensors, loadingSensors]);

  // const handleTabChange = (event: React.SyntheticEvent, newValue: string) => {
  //   setActiveTab(newValue);
  //   if (!loadingSensors) {
  //     // Fetch sensors again when tab is changed if they are not loading
  //     sensorDispatch (fetchSensors());
  //   }
  // };
  const handleTabChange = useCallback(
    (event: React.SyntheticEvent, newValue: string) => {
      setActiveTab(newValue);
      if (!loadingSensors && sensors?.length === 0) {
        sensorDispatch(fetchSensors());
      }
    },
    [loadingSensors, sensorDispatch, sensors]
  );
  return (
    <Dialog open={open} maxWidth="md">
      <DialogTitle>
        <div className={classes.titleContainer}>
          <span>Add Gateway Sensor Associations</span>
          <IconButton
            aria-label="close"
            className={classes.closeButton}
            onClick={handleClose}
          >
            <CloseIcon />
          </IconButton>
        </div>

        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          variant="fullWidth"
          textColor="primary"
          indicatorColor="primary"
        >
          <Tab value="slaves" label="Modbus (Slaves)" />
          <Tab value="input" label="IO (Inputs)" />
        </Tabs>
      </DialogTitle>
      <DialogContent>
        {loadingSensors ? (
          <div className={classes.loadingContainer}>
            <CircularProgress />
          </div>
        ) : (
          <>
            {activeTab === "slaves" ? (
              <CreateGatewaySensorAssociation
                gatewayData={gatewayData ?? null}
                sensorData={sensors}
              />
            ) : (
              <CreateGatewayInputsAssociation
                gatewayData={gatewayData ?? null}
                sensorData={sensors}
              />
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default AddSensor;
