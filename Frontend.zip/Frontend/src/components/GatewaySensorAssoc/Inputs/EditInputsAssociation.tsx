import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  SelectChangeEvent,
} from "@mui/material";

import { GatewayInputsAssociation, Sensor } from "../../../redux/types";
import { updateGatewayInputsAssociation } from "../../../redux/gatewayInputAsscSlice";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";
interface EditInputsAssociationProps {
  isOpen: boolean;
  handleClose: () => void;
  associationData: GatewayInputsAssociation | null;
  gatewayId?: string | "";
}

const EditInputsAssociation: React.FC<EditInputsAssociationProps> = ({
  isOpen,
  handleClose,
  associationData,
  gatewayId,
}) => {
  const dispatch = useMachinewiseDispatch();
  const sensors = useMachinewiseSelector((state) => state.sensor.sensors);
  const [formData, setFormData] = useState<GatewayInputsAssociation | null>(
    associationData
  );
  const [selectedSensor, setSelectedSensor] = useState<string>("");

  useEffect(() => {
    if (associationData && associationData.sensorId) {
      //console.log("associationData.sensorId:", associationData.sensorId);

      setFormData(associationData);

      const selectedSensorId =
        typeof associationData.sensorId === "string"
          ? associationData.sensorId
          : (associationData.sensorId as Sensor).sensorId || "NA";

      //console.log("Selected Sensor ID:", selectedSensorId);

      setSelectedSensor(selectedSensorId);
    }
  }, [associationData]);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({
      ...prevData!,
      [name]: value,
    }));
  };

  const handleSensorChange = (event: SelectChangeEvent) => {
    const selectedSensorId = event.target.value as string;
    setSelectedSensor(selectedSensorId);

    // Find the selected sensor based on the ID
    const selectedSensor = sensors!.find(
      (sensor) => sensor.sensorId === selectedSensorId
    );

    // Update the formData with the selected sensor
    setFormData((prevData) => ({
      ...prevData!,
      sensorId: selectedSensor ? selectedSensor.sensorId : "NA",
    }));
  };

  const handleUpdate = async () => {
    if (formData) {
      try {
        // Dispatch the asynchronous action and wait for it to complete
        const updatedAssociation = await dispatch(
          updateGatewayInputsAssociation(formData)
        );

        // Handle the result
        if (
          updateGatewayInputsAssociation.fulfilled.match(updatedAssociation)
        ) {
          toast.success("Association updated successfully!");
        } else {
          toast.error("Failed to update association!");
        }
      } catch (error) {
        console.error("An Error occured", error);
        toast.error("An Error occured..!");
      }

      handleClose();
    }
  };
  return (
    <Dialog open={isOpen} maxWidth="sm">
      <DialogTitle>Edit Gateway Sensor Association</DialogTitle>
      <DialogContent style={{ paddingTop: "25px" }}>
        <Grid container spacing={2}>
          <Grid item xs={6}>
            {" "}
            <TextField
              size="small"
              label="Slave ID"
              name="slaveId"
              value={formData?.slaveId}
              fullWidth
              onChange={handleChange}
              disabled
            />
          </Grid>

          <Grid item xs={6}>
            {" "}
            <TextField
              label="Tag"
              size="small"
              name="tag"
              value={formData?.tag || ""}
              fullWidth
              onChange={handleChange}
            />
          </Grid>

          <Grid item xs={6}>
            <TextField
              label="Sensor Node Name"
              size="small"
              name="sensorNodeName"
              value={formData?.sensorNodeName || ""}
              fullWidth
              onChange={handleChange}
            />
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel>Select Sensor</InputLabel>
              <Select
                fullWidth
                label="Select Sensor"
                size="small"
                value={selectedSensor}
                onChange={handleSensorChange}
              >
                {sensors?.map((sensor) => (
                  <MenuItem key={sensor._id} value={sensor._id}>
                    {sensor.sensorName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button onClick={handleUpdate} color="primary">
          Update
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default EditInputsAssociation;
