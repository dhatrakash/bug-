import React, {  useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../assets/css/SuperAdminLoginPage.css'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useDispatch } from 'react-redux';
import { updateFunctionalities } from '../redux/functionalitySlice';

interface superAdminLoginPageProps {
  setIsLoggedIn: React.Dispatch<React.SetStateAction<boolean>>;
}

const SuperAdminLoginPage: React.FC<superAdminLoginPageProps> = ({ setIsLoggedIn }) => {
    const [credentials, setCredentials] = useState<{ [key: string]: string }>({});
    const nav = useNavigate();
    const dispatch = useDispatch();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };
  
  const getRoleByName = () => {
    const roleName = sessionStorage.getItem("role");
    const requestBody = { 
      roleName: `${roleName}`,
    };

       if(roleName?.length){
        fetch('http://localhost:3000/v1/users/getRoleByName', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            // 'Authorization' : `Bearer ${sessionStorage.getItem("access-token")}`
          },
          body: JSON.stringify(requestBody),
        })
          .then(response => response.json())
          .then(data => {
           
            const updatedFunctionalities = data.functionalities['0'];
            dispatch(updateFunctionalities(updatedFunctionalities));
            sessionStorage.setItem('functionalities', JSON.stringify(updatedFunctionalities));

            /*  // ** mantaining state through session storage 
            // Extract the functionalities from the response
            const functionalities: { [key: string]: boolean }[] = data.functionalities;
    
            // Store the functionalities in session storage as key-value pairs
            functionalities.forEach((func: { [key: string]: boolean }) => {
              for (const key in func) {
                sessionStorage.setItem(key, func[key].toString());
              }
            });
            */
          })
          .catch(error => {
            console.error('Error fetching data:', error);
          });
       }
  };
  
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    try {
       e.preventDefault();
       if(credentials.email === "" || credentials.password === ""){
        toast.error("Please fill all the fields",{
          position: "top-right"});
          return;
       }
      const response = await fetch('http://localhost:3000/v1/superAdminAuth/loginSuperAdmin', {
          method: 'POST',
          headers: {
              'content-type': 'application/json'
          },
          body: JSON.stringify({email:credentials.email,password:credentials.password})             
      });
      const data = await response.json();
      if(response.status === 200)
      {
        toast.success('Welcome '+data.superAdmin.name,{ position: "top-right"})
        sessionStorage.setItem('access-token',data.tokens.access.token)
        sessionStorage.setItem('access-token-expires',data.tokens.access.expires)
        sessionStorage.setItem('refresh-token',data.tokens.refresh.token)
        sessionStorage.setItem('refresh-token-expires',data.tokens.refresh.expires)
        sessionStorage.setItem('role', data.superAdmin.role)
        sessionStorage.setItem('isLoggedIn', 'true');
        sessionStorage.setItem('name', data.superAdmin.name);
        getRoleByName();
        setIsLoggedIn(true);
        nav('/')
           
      }else {
        toast.error(data.message,{ position: "top-right"})
        setIsLoggedIn(false);
      }
    } catch (err) {
      console.log(err);
      toast.error("Internal Server Error ! ",{ position: "top-right"})
    }    
  };
  const resetFormData = () => {
    setCredentials({ email: "", password: ""});
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h3>Super Admin Login</h3>
        <form onSubmit={handleSubmit}>
          <input type="email" className='form-control' placeholder="Enter Your Email here." name="email" value={credentials.email} onChange={handleChange} required={true} />
          <input type="password" className='form-control' placeholder="Enter Your Password here." name="password" value={credentials.password} onChange={handleChange} required={true} />         
          <div style={{display:'flex',gap:'20px',alignSelf:'center'}}>
          <button type="submit" className='btn btn-primary'>Login</button>
          <button type="button" className='btn btn-secondary' onClick={resetFormData}>Clear</button>
          </div>          
        </form>
        </div>
    </div>
  );
}

export default SuperAdminLoginPage;