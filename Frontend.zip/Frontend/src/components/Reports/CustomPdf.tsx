import React, { useState } from 'react';
import { Document, Page, Text, View, PDFDownloadLink, StyleSheet } from '@react-pdf/renderer';
import Header from '../Dashboard/Nav/Header';
import Footer from '../Footer';

const styles = StyleSheet.create({
  page: {
    flexDirection: 'row',
    backgroundColor: '#E4E4E4',
  },
  section: {
    margin: 10,
    padding: 10,
    flexGrow: 1,
  },
  text: {
    fontSize: 12,
    marginBottom: 5,
  },
});

const MyDocument = () => (
  <Document>
    <Page size="A4" style={styles.page}>
      <View style={styles.section}>
        <Text style={styles.text}>Hello, this is a PDF document.</Text>
        <Footer/>
      </View>
   
    </Page>
  </Document>
);

function CustomPdf() {
  return (
    <div>
      <PDFDownloadLink document={<MyDocument />} fileName="custom-pdf.pdf">
        {({ blob, url, loading, error }) =>
          loading ? 'Loading document...' : 'Download now!'
        }
      </PDFDownloadLink>
    </div>
  );
}

export default CustomPdf;
