import React, { useState } from 'react';
import { toast } from 'react-toastify';

function FileUploadForm() {
  const [file, setFile] = useState<File | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    setFile(selectedFile ?? null); // Use null if selectedFile is undefined
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (file) {
      const formData = new FormData();
      formData.append('pdfFile', file);

      try {
        const response = await fetch('http://localhost:4000/send-pdf', {
          method: 'POST',
          body: formData,
        });

        if (response.status === 200) {
            toast.success('PDF file sent successfully. ' , {  position: 'top-right', }); 
            console.log('PDF file sent successfully');
        } else {
            toast.error('Failed to send PDF file. ' , {  position: 'top-right', }); 
        }
      } catch (error) {
        console.error('Error sending PDF file:', error);
      }
    }
  };

  return (
    <div>
      <h1>Upload a PDF file</h1>
      <form onSubmit={handleSubmit}>
        <input type="file" accept=".pdf" onChange={handleFileChange} />
        <button className='btn btn-success' type="submit">Send PDF</button>
      </form>
    </div>
  );
}

export default FileUploadForm;
