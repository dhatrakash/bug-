import React, { useEffect, useState } from "react";
// import { deleteShift } from "./shiftsSlice";
import "../../assets/css/Infrastructure.css";

import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  CircularProgress,
  Paper,
  Box,
  IconButton,
  Tooltip,
} from "@mui/material";
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  AddCircleOutlineSharp as AddIcon,
} from "@mui/icons-material";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";
import { Shift } from "../../redux/types";
import { toast } from "react-toastify";
import ShiftFormModal from "./ShiftFormModal";
import { deleteShift, fetchShifts } from "../../redux/shiftsSlice";
import DeleteConfirmationModal from "./DeleteConfirmationModal";

const ShiftsList: React.FC = () => {
  const { shifts, loading, error } = useMachinewiseSelector(
    (state) => state.shifts
  );
  const dispatch = useMachinewiseDispatch();
  const [showModal, setShowModal] = useState(false);

  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);
  const [editShift, setEditShift] = useState<Shift | null>(null);

  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
  const [shiftToDelete, setShiftToDelete] = useState<Shift | null>(null);

  useEffect(() => {
    dispatch(fetchShifts());
  }, [dispatch]);

  const openEditModal = (shift: Shift) => {
    console.log("Opening edit modal with shift:", shift);
    setEditShift(shift);
    setShowModal(true);
  };

  // const closeEditModal = () => {
  //   console.log("Closing edit modal");
  //   setEditShift(null);
  //   setShowModal(false);
  // };
  const openDeleteModal = (shift: Shift) => {
    setShiftToDelete(shift);
    setDeleteModalOpen(true);
  };

  // Function to close the Delete Confirmation modal
  const closeDeleteModal = () => {
    setDeleteModalOpen(false);
    setShiftToDelete(null);
  };

  const handleConfirmDelete = async () => {
    if (shiftToDelete && shiftToDelete._id) {
      try {
        const shiftAction = await dispatch(deleteShift(shiftToDelete._id));
        if (deleteShift.fulfilled.match(shiftAction)) {
          setDeleteModalOpen(false);
          dispatch(fetchShifts());
          toast.success("Shift deleted successfully");
        } else {
          toast.error("Failed to delete Shift");
        }
      } catch (err) {
        console.error("An error occurred while deleting the shift");
        toast.error("Error deleting the shift...Server Error!");
      }
    }
  };

  return (
    <>
      <div className="infrastructure-container">
        <h5>
          <span>Shift's List</span>
        </h5>
        <div className="infrastructure-details">
          <Paper className="infrastructure-paper">
            {" "}
            <Box display="flex" justifyContent="flex-end" alignItems="center">
              <IconButton
                color="primary"
                aria-label="Add Shift"
                onClick={openModal}
                style={{
                  padding: "10px 20px",
                  borderRadius: "15px",
                  transition: "background-color 0.7s ease",
                }}
              >
                <AddIcon fontSize="small" />
                <span
                  style={{
                    marginLeft: "8px",
                    marginTop: "-2px",
                    fontSize: "medium",
                    fontWeight: "bold",
                  }}
                >
                  Add Shift
                </span>
              </IconButton>
            </Box>
            <Table className="infrastructure-table" sx={{ minWidth: "auto" }}>
              <TableHead>
                <TableRow key="heading">
                  <TableCell>Shift Id</TableCell>
                  <TableCell>Shift Name</TableCell>
                  <TableCell>Shift Start Time</TableCell>
                  <TableCell>Shift End Time</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {loading ? (
                  <TableRow key="loading">
                    <TableCell colSpan={4} align="center">
                      <CircularProgress />
                    </TableCell>
                  </TableRow>
                ) : error ? (
                  <TableRow key="error">
                    <TableCell colSpan={4} align="center">
                      Error: {"Something went wrong while loading"}
                    </TableCell>
                  </TableRow>
                ) : (
                  shifts?.map((shift) => (
                    <TableRow key={shift.shiftId}>
                      <TableCell>{shift.shiftId}</TableCell>
                      <TableCell>{shift.shiftName}</TableCell>

                      <TableCell>{shift.startTime}</TableCell>
                      <TableCell>{shift.endTime}</TableCell>
                      <TableCell>
                        <Tooltip title="Update Shift">
                          <IconButton
                            color="primary"
                            onClick={() => openEditModal(shift)}
                          >
                            <EditIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete Shift">
                          <IconButton
                            color="error"
                            onClick={() => openDeleteModal(shift)} // Open the Delete Confirmation modal
                          >
                            <DeleteIcon />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
            {/* <ShiftForm
              showModal={showModal}
              closeModal={closeModal}
              shiftData={editShift}
            /> */}
            <ShiftFormModal
              showModal={showModal}
              closeModal={closeModal}
              shiftData={editShift}
            />
            <DeleteConfirmationModal
              open={isDeleteModalOpen}
              handleClose={closeDeleteModal}
              handleConfirm={handleConfirmDelete}
            />
          </Paper>
        </div>
      </div>
    </>
  );
};

export default ShiftsList;
