import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
} from "@mui/material";
import ShiftForm from "./ShiftForm";
import { Shift } from "../../redux/types";

interface ShiftFormModalProps {
  showModal: boolean;
  closeModal: () => void;
  shiftData: Shift | null;
}

const ShiftFormModal: React.FC<ShiftFormModalProps> = ({
  showModal,
  closeModal,
  shiftData,
}) => {
  return (
    <Dialog open={showModal} onClose={closeModal} maxWidth="lg">
      <DialogTitle
        className="machine-form-title"
        style={{ textAlign: "center" }}
      >
        {shiftData ? "Edit Shift" : "Add Shift"}
      </DialogTitle>
      <DialogContent className="modal-container">
        <ShiftForm shiftData={shiftData} closeModal={closeModal} />
      </DialogContent>
      <DialogActions>
        <Button onClick={closeModal} color="secondary">
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ShiftFormModal;
