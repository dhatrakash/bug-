// ShiftForm.tsx
import React, { useState, useEffect } from "react";
import { Button, TextField } from "@mui/material";
import { useMachinewiseDispatch } from "../../redux/hooks";
import { createShift, fetchShifts, updateShift } from "../../redux/shiftsSlice";
import { Shift } from "../../redux/types";
import { toast } from "react-toastify";

interface ShiftFormProps {
  shiftData: Shift | null;
  closeModal: () => void;
}

const ShiftForm: React.FC<ShiftFormProps> = ({ shiftData, closeModal }) => {
  const dispatch = useMachinewiseDispatch();

  // Set defaults for date and time fields
  const today = new Date().toISOString().split("T")[0];
  const initialTime = "00:00";

  const [formData, setFormData] = useState({
    shiftName: shiftData?.shiftName || "",

    startTime: shiftData?.startTime || initialTime,
    endTime: shiftData?.endTime || initialTime,
  });

  useEffect(() => {
    if (shiftData) {
      setFormData({
        shiftName: shiftData.shiftName,

        startTime: shiftData.startTime,
        endTime: shiftData.endTime,
      });
    }
  }, [shiftData]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    const newShift: Shift = {
      shiftName: formData.shiftName,
      // date: new Date(formData.date),
      startTime: formData.startTime,
      endTime: formData.endTime,
    };

    try {
      let createAction;

      if (shiftData) {
        newShift.shiftId = shiftData.shiftId;
        const updateAction = await dispatch(updateShift(newShift));

        if (updateShift.fulfilled.match(updateAction)) {
          toast.success("Shift Updated Successfully");
        } else {
          toast.error("Failed to update Shift");
        }
      } else {
        createAction = await dispatch(createShift(newShift));

        if (createShift.fulfilled.match(createAction)) {
          toast.success("Shift created Successfully");
          closeModal();
        } else {
          toast.error("Failed to create Shift");
        }
      }

      // Wait for createShift or updateShift action to be fulfilled
      await createAction;

      // After the action is fulfilled, fetch the shifts
      dispatch(fetchShifts());
    } catch (error) {
      console.error("An error occurred while handling the shift:", error);
      toast.error("Error handling the shift");
    } finally {
      closeModal();
    }
  };

  return (
    <form>
      <TextField
        fullWidth
        margin="normal"
        label="Shift Name"
        name="shiftName"
        value={formData.shiftName}
        onChange={handleInputChange}
      />

      <TextField
        fullWidth
        margin="normal"
        label="Start Time"
        name="startTime"
        type="time"
        value={formData.startTime}
        onChange={handleInputChange}
      />
      <TextField
        fullWidth
        margin="normal"
        label="End Time"
        name="endTime"
        type="time"
        value={formData.endTime}
        onChange={handleInputChange}
      />
      <Button variant="contained" color="primary" onClick={handleSubmit}>
        {shiftData?.shiftId ? "Update Shift" : "Add Shift"}
      </Button>
    </form>
  );
};

export default ShiftForm;
