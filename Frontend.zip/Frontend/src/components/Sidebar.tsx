import React, { useEffect, useState } from 'react';
import { Collapse, Drawer, Icon, IconButton, List, ListItem, ListItemIcon, ListItemText, Paper } from '@mui/material';
import {  Accessibility, ArrowDropDownCircle, ChevronRight,  ExitToApp, ExpandLess, ExpandMore,  GrainTwoTone, Home,  Login,  PersonAdd,  Sensors,  SettingsApplications } from '@mui/icons-material';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import '../assets/css/Sidebar.css';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../redux/store';

interface SidebarProps {
  open: boolean;
  onClose: () => void;
  isLoggedIn: boolean; // Add isLoggedIn prop
  handleLogout: () => void; // Add handleLogout prop
}

const Sidebar: React.FC<SidebarProps> = ({ open, onClose, handleLogout, isLoggedIn}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const sidebarClass = open ? 'sidebar-container open' : 'sidebar-container';
   // Use the correct path to access the functionalities in the Redux store
  const functionalities = useSelector((state: RootState) => state.functionalities);
   

    // Function to handle logout and route to login page
    const handleLogoutAndRedirect = () => {
      handleLogout(); // Perform logout logic (clear tokens, reset user data, etc.)
      navigate('/login'); // Redirect to the login page
    };

    console.warn("in side bar compo  " +functionalities.viewMach);
    const [companyInfraOpen, setCompanyInfraOpen] = useState(false);

    const toggleCompanyMenu = () => {
      setCompanyInfraOpen(!companyInfraOpen);
    };

  return (
    <Drawer open={open} onClose={onClose}>
      <Paper className={sidebarClass}>
      <List>
          <ListItem
            button
            component={Link}
            to="/home"
            className={`sidebar-item ${location.pathname === '/home' ? 'selected' : ''}`}
          >
            <ListItemIcon>
              <Home />
            </ListItemIcon>
            <ListItemText primary="Home" className="sidebar-text" />
          </ListItem>
          
          {isLoggedIn && sessionStorage.getItem('role') === 'superAdmin' &&
            <ListItem
            button
            component={Link}
            to="/permission"
            className={`sidebar-item ${location.pathname === '/permission' ? 'selected' : ''}`}
            >
            <ListItemIcon>
              <Accessibility />
            </ListItemIcon>
            <ListItemText primary="Permission" className="sidebar-text" />
          </ListItem>
          }
          
         { functionalities.createNewUsers && 
          <ListItem
            button
            component={Link}
            to="/createUser"
            className={`sidebar-item ${location.pathname === '/createUser' ? 'selected' : ''}`}
          >
            <ListItemIcon>
              <PersonAdd />
            </ListItemIcon>
            <ListItemText primary="Register" className="sidebar-text" />
          </ListItem>
         }
          {functionalities.viewMach &&
              <ListItem
              button
              component={Link}
              to="/machines"
              className={`sidebar-item ${location.pathname === '/machines' ? 'selected' : ''}`}
            >
              <ListItemIcon>
                <SettingsApplications />
              </ListItemIcon>
              <ListItemText primary="Machines" className="sidebar-text" />
            </ListItem>
          }
         
          <ListItem
            button
            component={Link}
            to="/gateway"
            className={`sidebar-item ${location.pathname === '/gateway' ? 'selected' : ''}`}
          >
            <ListItemIcon>
              <GrainTwoTone />
            </ListItemIcon>
            <ListItemText primary="Gateway" className="sidebar-text" />
          </ListItem>

          <ListItem
            button
            component={Link}
            to="/sensor"
            className={`sidebar-item ${location.pathname === '/sensor' ? 'selected' : ''}`}
          >
            <ListItemIcon>
              <Sensors />
            </ListItemIcon>
            <ListItemText primary="Sensor" className="sidebar-text" />
          </ListItem>
          
          <ListItem
            button
            onClick={toggleCompanyMenu}
          >
            <ListItemIcon>
              <ArrowDropDownCircle />
            </ListItemIcon>
            <ListItemText primary="Company Infra" className="sidebar-text" />
            {companyInfraOpen ? <ExpandLess /> : <ExpandMore />}
          </ListItem>
           
          <Collapse in={companyInfraOpen} timeout="auto" unmountOnExit>
            <List component="div" disablePadding>
              <ListItem
                button
                component={Link}
                to="/facility"
                className={`nested-sidebar-item ${
                  location.pathname === '/facility' ? 'selected' : ''
                }`}
              >
                <ListItemIcon>
                  <ChevronRight />
                </ListItemIcon>
                <ListItemText primary="Facility" className="nested-sidebar-text" />
              </ListItem>

              <ListItem
                button
                component={Link}
                to="/layout"
                className={`nested-sidebar-item ${
                  location.pathname === '/layout' ? 'selected' : ''
                }`}
              >
                <ListItemIcon>
                  <ChevronRight />
                </ListItemIcon>
                <ListItemText primary="Layout" className="nested-sidebar-text" />
              </ListItem>

              <ListItem
                button
                component={Link}
                to="/line"
                className={`nested-sidebar-item ${
                  location.pathname === '/line' ? 'selected' : ''
                }`}
              >
                <ListItemIcon>
                  <ChevronRight />
                </ListItemIcon>
                <ListItemText primary="Line" className="nested-sidebar-text" />
              </ListItem>

              <ListItem
                button
                component={Link}
                to="/cell"
                className={`nested-sidebar-item ${
                  location.pathname === '/cell' ? 'selected' : ''
                }`}
              >
                <ListItemIcon>
                  <ChevronRight />
                </ListItemIcon>
                <ListItemText primary="Cell" className="nested-sidebar-text" />
              </ListItem>
            </List>
          </Collapse>

          {isLoggedIn ? (
            <ListItem button onClick={handleLogoutAndRedirect}>
              <ListItemIcon>
                <ExitToApp />
              </ListItemIcon>
              <ListItemText primary="Logout" className="sidebar-text" />
            </ListItem>
          ) : (
            <ListItem
            button
            component={Link}
            to="/login"
            className={`sidebar-item ${location.pathname === '/login' ? 'selected' : ''}`}
            >
            <ListItemIcon>
              <Login />
            </ListItemIcon>
            <ListItemText primary="Login" className="sidebar-text" />
          </ListItem>
          )
          
          }
        </List>
      </Paper>
    </Drawer>
  );
};

export default Sidebar;





