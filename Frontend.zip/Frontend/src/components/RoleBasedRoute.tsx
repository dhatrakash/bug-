import React from 'react';
import { Navigate } from 'react-router-dom';

interface RoleBasedRouteProps {
  isAuthenticated: boolean;
  requiredRoles?: string[]; // Use an array of required roles
  redirectTo: string;
  children: React.ReactNode;
}

const RoleBasedRoute: React.FC<RoleBasedRouteProps> = ({
  isAuthenticated,
  requiredRoles,
  redirectTo,
  children,
}) => {
  if (requiredRoles && requiredRoles.length > 0) {
    // Check if the user has at least one of the required roles
    const hasRequiredRole = requiredRoles.some(role => {
      return isAuthenticated && sessionStorage.getItem('role') === role;
    });

    if (!hasRequiredRole) {
      return <Navigate to={redirectTo} />;
    }
  }

  return <>{children}</>;
};

export default RoleBasedRoute;





// import React from 'react';
// import { Navigate } from 'react-router-dom';
// import Dashboard from './Dashboard/Dashboard';

// interface RoleBasedRouteProps {
//   isAuthenticated: boolean;
//   requiredRole?: string;
//   redirectTo: string;
//   children: React.ReactNode;
// }

// const RoleBasedRoute: React.FC<RoleBasedRouteProps> = ({
//   isAuthenticated,
//   requiredRole,
//   redirectTo,
//   children,
// }) => {
//   if (requiredRole && (!isAuthenticated || sessionStorage.getItem('superAdmin-role') !== requiredRole )  ) {
//     return <Navigate to={redirectTo} />;
//   }
  
//   return <>{children}</>;
// };

// export default RoleBasedRoute;










// import React from 'react';
// import { Navigate } from 'react-router-dom';
// import Dashboard from './Dashboard/Dashboard';

// interface RoleBasedRouteProps {
//   isAuthenticated: boolean;
//   requiredRole?: string;
//   redirectTo: string;
//   children: React.ReactNode;
// }

// const RoleBasedRoute: React.FC<RoleBasedRouteProps> = ({
//   isAuthenticated,
//   requiredRole,
//   redirectTo,
//   children,
// }) => {
//   console.log(isAuthenticated)
//   console.log(localStorage.getItem('superAdmin-role'))
//   if (requiredRole && (!isAuthenticated || localStorage.getItem('superAdmin-role') !== requiredRole)) {
//     return <Navigate to={redirectTo} />;
//   }
  
//   return <>{<Dashboard/>}</>;
// };

// export default RoleBasedRoute;
