import React from "react";
import "../assets/css/NotFound1.css";

const NotFound1: React.FC = () => {
  return (
    <div className="not-found-container">
      <div className="not-found">
        <h1>Unauthorized Access</h1>
        <p>Sorry, you are not authorized to view this page.</p>
        <p>Please log in or contact an administrator for access.</p>
        {/* You can add an image here if needed */}
      </div>
    </div>
  );
};

export default NotFound1;
