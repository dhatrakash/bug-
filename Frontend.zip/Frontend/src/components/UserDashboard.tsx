import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const UserDashboard: React.FC = () => {
  const nav = useNavigate();
  const [data, setData] = useState<any | null>(null);
  const handleLogOut = async (e: React.MouseEvent<HTMLButtonElement>) => {
    try {
      const response = await fetch("http://localhost:3000/v1/auth/logout", {
        method: "POST",
        headers: {
          "content-type": "application/json",
        },
        body: JSON.stringify({
          refreshToken: localStorage.getItem("refresh-token"),
        }),
      });
      if (response.status === 204) {
        localStorage.clear();
        toast.success("You have been signed out.", {
          position: "top-right",
        });
        nav("/home");
      } else {
        const data = await response.json();
        toast.error(data.message, {
          position: "top-right",
        });
      }
    } catch (err) {
      console.log(err);
      toast.error("Internal Server Error ! ", {
        position: "top-right",
      });
    }
  };

  const handleMyProfile = async (e: React.MouseEvent<HTMLButtonElement>) => {
    try {
      const response = await fetch(
        "http://localhost:3000/v1/users/" + localStorage.getItem("user-Id"),
        {
          method: "GET",
          headers: {
            "content-type": "application/json",
            authorization: "Bearer " + localStorage.getItem("access-token"),
          },
        }
      );
      const data = await response.json();
      if (response.status === 200) {
        setData(data);
      } else {
        toast.error(data.message, {
          position: "top-right",
        });
      }
    } catch (err) {
      console.log(err);
      toast.error("Internal Server Error ! ", {
        position: "top-right",
      });
    }
  };

  return localStorage.getItem("access-token") &&
    localStorage.getItem("refresh-token") ? (
    <div>
      <h1 style={{ textAlign: "center", marginTop: "20px" }}>
        This is User Dashboard
      </h1>
      <hr />
      <h1>You have access tokens</h1>
      <center>
        <button className="btn btn-warning mx-3" onClick={handleMyProfile}>
          View Profile
        </button>
        <button className="btn btn-danger" onClick={handleLogOut}>
          Log Out
        </button>
      </center>
      {data ? (
        <div style={{ textAlign: "center", marginTop: "40px" }}>
          <p>Account Id : {data.id}</p>
          <p>Account Name : {data.name}</p>
          <p>Account Email : {data.email}</p>
          <p>Account Role : {data.role}</p>
        </div>
      ) : null}
    </div>
  ) : (
    <div>
      <h1>You don't have access tokens</h1>
    </div>
  );
};

export default UserDashboard;
