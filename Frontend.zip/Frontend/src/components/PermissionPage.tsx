import React, { useState, useEffect } from 'react';
import '../assets/css/PermissionPage.css';
import { toast } from 'react-toastify';

type Permissions = {
  [key: string]: {
    [key: string]: boolean;
  };
};

type BackendResponse = {
  [key: string]: {
    [key: string]: boolean;
  }[];
};

const PermissionPage: React.FC = () => {
  const [permissions, setPermissions] = useState<Permissions | null>(null);

  useEffect(() => {
    // Fetch permissions from the API and update the state
    fetch('http://localhost:3000/v1/role/getAll', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization' : `Bearer ${sessionStorage.getItem("access-token")}`
      },
    })
      .then((response) => response.json())
      .then((data: BackendResponse) => {
        // Transform the nested structure into the expected Permissions format
        const transformedPermissions: Permissions = {};

        for (const role of Object.keys(data)) {
          transformedPermissions[role] = {};
          for (const permissionObj of data[role]) {
            for (const permission in permissionObj) {
              transformedPermissions[role][permission] = permissionObj[permission];
            }
          }
        }

        setPermissions(transformedPermissions);
      })
      .catch((error) => {
        console.error('Error fetching permissions:', error);
      });
  }, []);

  const handlePermissionChange = (role: string, permission: string) => {
    if (permissions) {
      setPermissions((prevPermissions) => {
        if (!prevPermissions) {
          return prevPermissions;
        }
        return {
          ...prevPermissions,
          [role]: {
            ...prevPermissions[role],
            [permission]: !prevPermissions[role][permission],
          },
        };
      });
    }
  };

  const handleSubmit = () => {
    // Check if permissions is not null
    if (permissions) {
      // Send a POST request to your backend API with the permissions data
      console.warn(permissions);

      fetch('http://localhost:3000/v1/superAdmins/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization' : `Bearer ${sessionStorage.getItem("access-token")}`
        },
        body: JSON.stringify(permissions),
      })
        .then((response) => response.json())
        .then((data) => {
          console.log('Permissions data sent successfully:', data);
          toast.success(data.message, {
            position: 'top-right',
          });
        })
        .catch((error) => {
          console.error('Error sending permissions data:', error);
          toast.error(error, {
            position: 'top-right',
          });
        });
    }
  };

  if (!permissions) {
    // Render a loading indicator or message while permissions are being fetched
    return <p>Loading...</p>;
  }

  // Get the list of functionality permissions from one of the roles (e.g., 'superadmin')
  const functionalityPermissions = Object.keys(permissions.superadmin); // Change 'superadmin' to one of the roles that contains all functionality permissions

  // Define the order of roles
  const roleOrder: string[] = [
    'superadmin',
    'admin',
    'ceo/cxo',
    'manager',
    'supervisor',
    'operator',
    'spectator',
    'user',
  ];

  return (
    <div className="permission-page">
      <h3>Permissions</h3>
      <table>
        <thead>
          <tr>
            <th>Functionality</th>
            {roleOrder.map((role) => (
              <th key={role}>{role}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {functionalityPermissions.map((permission) => (
            <tr key={permission}>
              <td>{permission}</td>
              {roleOrder.map((role) => (
                <td key={role}>
                  <input
                    type="checkbox"
                    checked={permissions[role][permission]}
                    onChange={() => handlePermissionChange(role, permission)}
                  />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {/* <button type="button" className="btn btn-success">Success</button> */}
      <button onClick={handleSubmit} className='custom-success-button'>Confirm Permission</button>
      
    </div>
  );
};

export default PermissionPage;





















// import React, { useState, useEffect } from 'react';
// import '../assets/css/PermissionPage.css';


// type Permissions = {
//   superadmin: {
//     createNewMach: boolean;
//     createNewUsers: boolean;
//     assignRepo: boolean;
//     assignPermi: boolean;
//     whatsAppAPI: boolean;
//     machAsssignToUser: boolean;
//     shiftCreat: boolean;
//     locaCreat: boolean;
//     mastrPartList: boolean;
//     viewMach: boolean;
//     machAsssignToSuper: boolean;
//     viewLimRepo: boolean;
//     machAsssignToOper: boolean;
//     reportProb: boolean;
//     viewHtmlOnLarScr: boolean;
//     custPermi: boolean;
//   };
//   admin: {
//     createNewMach: boolean;
//     createNewUsers: boolean;
//     assignRepo: boolean;
//     assignPermi: boolean;
//     whatsAppAPI: boolean;
//     machAsssignToUser: boolean;
//     shiftCreat: boolean;
//     locaCreat: boolean;
//     mastrPartList: boolean;
//     viewMach: boolean;
//     machAsssignToSuper: boolean;
//     viewLimRepo: boolean;
//     machAsssignToOper: boolean;
//     reportProb: boolean;
//     viewHtmlOnLarScr: boolean;
//     custPermi: boolean;
//   };
//   'ceo/cxo': {
//     createNewMach: boolean;
//     createNewUsers: boolean;
//     assignRepo: boolean;
//     assignPermi: boolean;
//     whatsAppAPI: boolean;
//     machAsssignToUser: boolean;
//     shiftCreat: boolean;
//     locaCreat: boolean;
//     mastrPartList: boolean;
//     viewMach: boolean;
//     machAsssignToSuper: boolean;
//     viewLimRepo: boolean;
//     machAsssignToOper: boolean;
//     reportProb: boolean;
//     viewHtmlOnLarScr: boolean;
//     custPermi: boolean;
//   };
//   manager: {
//     createNewMach: boolean;
//     createNewUsers: boolean;
//     assignRepo: boolean;
//     assignPermi: boolean;
//     whatsAppAPI: boolean;
//     machAsssignToUser: boolean;
//     shiftCreat: boolean;
//     locaCreat: boolean;
//     mastrPartList: boolean;
//     viewMach: boolean;
//     machAsssignToSuper: boolean;
//     viewLimRepo: boolean;
//     machAsssignToOper: boolean;
//     reportProb: boolean;
//     viewHtmlOnLarScr: boolean;
//     custPermi: boolean;
//   };
//   supervisor: {
//     createNewMach: boolean;
//     createNewUsers: boolean;
//     assignRepo: boolean;
//     assignPermi: boolean;
//     whatsAppAPI: boolean;
//     machAsssignToUser: boolean;
//     shiftCreat: boolean;
//     locaCreat: boolean;
//     mastrPartList: boolean;
//     viewMach: boolean;
//     machAsssignToSuper: boolean;
//     viewLimRepo: boolean;
//     machAsssignToOper: boolean;
//     reportProb: boolean;
//     viewHtmlOnLarScr: boolean;
//     custPermi: boolean;
//   };
//   operator: {
//     createNewMach: boolean;
//     createNewUsers: boolean;
//     assignRepo: boolean;
//     assignPermi: boolean;
//     whatsAppAPI: boolean;
//     machAsssignToUser: boolean;
//     shiftCreat: boolean;
//     locaCreat: boolean;
//     mastrPartList: boolean;
//     viewMach: boolean;
//     machAsssignToSuper: boolean;
//     viewLimRepo: boolean;
//     machAsssignToOper: boolean;
//     reportProb: boolean;
//     viewHtmlOnLarScr: boolean;
//     custPermi: boolean;
//   };
//   spectator: {
//     createNewMach: boolean;
//     createNewUsers: boolean;
//     assignRepo: boolean;
//     assignPermi: boolean;
//     whatsAppAPI: boolean;
//     machAsssignToUser: boolean;
//     shiftCreat: boolean;
//     locaCreat: boolean;
//     mastrPartList: boolean;
//     viewMach: boolean;
//     machAsssignToSuper: boolean;
//     viewLimRepo: boolean;
//     machAsssignToOper: boolean;
//     reportProb: boolean;
//     viewHtmlOnLarScr: boolean;
//     custPermi: boolean;
//   };
//   user: {
//     createNewMach: boolean;
//     createNewUsers: boolean;
//     assignRepo: boolean;
//     assignPermi: boolean;
//     whatsAppAPI: boolean;
//     machAsssignToUser: boolean;
//     shiftCreat: boolean;
//     locaCreat: boolean;
//     mastrPartList: boolean;
//     viewMach: boolean;
//     machAsssignToSuper: boolean;
//     viewLimRepo: boolean;
//     machAsssignToOper: boolean;
//     reportProb: boolean;
//     viewHtmlOnLarScr: boolean;
//     custPermi: boolean;
//   };
// };



// // Define an object to map permission keys to display names
// const permissionDisplayNames: Record<keyof Permissions['superadmin'], string> = {
//   createNewMach: 'Create New Machine',
//   createNewUsers: 'Create New Users',
//   assignRepo: 'Assign Repository',
//   assignPermi: 'Assign Permission',
//   whatsAppAPI: 'WhatsApp API',
//   machAsssignToUser: 'Machine Assigned to User',
//   shiftCreat: 'Shift Create',
//   locaCreat: 'Location Create',
//   mastrPartList: 'Master Part List',
//   viewMach: 'View Machine',
//   machAsssignToSuper: 'Machine Assigned to Super',
//   viewLimRepo: 'View Limited Repository',
//   machAsssignToOper: 'Machine Assigned to Operator',
//   reportProb: 'Report Problem',
//   viewHtmlOnLarScr: 'View HTML on Large Screen',
//   custPermi: 'Custom Permissions',
// };


// const PermissionPage: React.FC = () => {
//   const [permissions, setPermissions] = useState<Permissions | null>(null);

//   useEffect(() => {
//     // Fetch permissions from the API and update the state
//     fetch('http://localhost:3000/v1/role/getAll')
//       .then((response) => response.json())
//       .then((data) => {
//         setPermissions(data);
//       })
//       .catch((error) => {
//         console.error('Error fetching permissions:', error);
//       });
//   }, []);

//   const handlePermissionChange = (
//     role: keyof Permissions,
//     permission: keyof Permissions['superadmin']
//   ) => {
//     if (permissions) {
//       setPermissions((prevPermissions) => {
//         if (!prevPermissions) {
//           return prevPermissions;
//         }
//         return {
//           ...prevPermissions,
//           [role]: {
//             ...prevPermissions[role],
//             [permission]: !prevPermissions[role][permission],
//           },
//         };
//       });
//     }
//   };

//   const handleSubmit = () => {
//     // Check if permissions is not null
//     if (permissions) {
//       // Send a POST request to your backend API with the permissions data
//       console.warn(permissions);
      
//       fetch('http://localhost:3000/v1/permissions/update', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify(permissions),
//       })
//         .then((response) => response.json())
//         .then((data) => {
//           console.log('Permissions data sent successfully:', data);
//           // You can handle success actions here, such as showing a success message.
//         })
//         .catch((error) => {
//           console.error('Error sending permissions data:', error);
//           // You can handle error actions here, such as showing an error message.
//         });
//     }
//   };

//   if (!permissions) {
//     // Render a loading indicator or message while permissions are being fetched
//     return <p>Loading...</p>;
//   }

//   // Get the list of functionality permissions
//   const functionalityPermissions = Object.keys(permissions.superadmin);

//   // Define the order of roles
//   const roleOrder: (keyof Permissions)[] = [
//     'superadmin',
//     'admin',
//     'ceo/cxo',
//     'manager',
//     'supervisor',
//     'operator',
//     'spectator',
//     'user',
//   ];

//   return (
//     <div className="permission-page">
//       <h3 style={{ textAlign: 'center' }}>Permissions</h3>
//       <table className="table permission-table table-bordered table-striped table-hover rounded text-center mt-4">
//         <thead>
//           <tr>
//             <th>Functionality</th>
//             {roleOrder.map((role) => (
//               <th key={role}>{role}</th>
//             ))}
//           </tr>
//         </thead>
//         <tbody>
//           {functionalityPermissions.map((permission) => (
//             <tr key={permission}>
//               <td>{permissionDisplayNames[permission as keyof Permissions['superadmin']]}</td>
//               {roleOrder.map((role) => (
//                 <td key={role}>
//                   <input
//                     type="checkbox"
//                     checked={permissions[role][permission as keyof Permissions['superadmin']]}
//                     onChange={() => handlePermissionChange(role, permission as keyof Permissions['superadmin'])}
//                   />
//                 </td>
//               ))}
//             </tr>
//           ))}
//         </tbody>
//       </table>
//       <button onClick={handleSubmit}>Proceed</button>
//     </div>
//   );
// };

// export default PermissionPage;



// import React, { useState, useEffect } from 'react';
// import '../assets/css/PermissionPage.css';

// type Permissions = {
//   [key: string]: {
//     [key: string]: boolean;
//   };
// };

// type BackendResponse = {
//   [key: string]: string[];
// };

// const PermissionPage: React.FC = () => {
//   const [permissions, setPermissions] = useState<Permissions | null>(null);

//   useEffect(() => {
//     // Fetch permissions from the API and update the state
//     fetch('http://localhost:3000/v1/role/getAll')
//       .then((response) => response.json())
//       .then((data: BackendResponse) => {
//         // Ensure that the keys in initialPermissions match the backend response
//         const initialPermissions: Permissions = {
//           superadmin: {},
//           admin: {},
//           'ceo/cxo': {},
//           manager: {},
//           supervisor: {},
//           operator: {},
//           spectator: {},
//           user: {},
//         };

//         // Initialize the initialPermissions object with the fetched data
//         for (const role of Object.keys(data)) {
//           initialPermissions[role] = {};
//           for (const permission of data[role]) {
//             initialPermissions[role][permission] = true;
//           }
//         }

//         setPermissions(initialPermissions);
//       })
//       .catch((error) => {
//         console.error('Error fetching permissions:', error);
//       });
//   }, []);

//   const handlePermissionChange = (role: string, permission: string) => {
//     if (permissions) {
//       setPermissions((prevPermissions) => {
//         if (!prevPermissions) {
//           return prevPermissions;
//         }
//         return {
//           ...prevPermissions,
//           [role]: {
//             ...prevPermissions[role],
//             [permission]: !prevPermissions[role][permission],
//           },
//         };
//       });
//     }
//   };

//   const handleSubmit = () => {
//     // Check if permissions is not null
//     if (permissions) {
//       // Send a POST request to your backend API with the permissions data
//       console.warn(permissions);

//       fetch('http://localhost:3000/v1/permissions/update', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify(permissions),
//       })
//         .then((response) => response.json())
//         .then((data) => {
//           console.log('Permissions data sent successfully:', data);
//           // You can handle success actions here, such as showing a success message.
//         })
//         .catch((error) => {
//           console.error('Error sending permissions data:', error);
//           // You can handle error actions here, such as showing an error message.
//         });
//     }
//   };

//   if (!permissions) {
//     // Render a loading indicator or message while permissions are being fetched
//     return <p>Loading...</p>;
//   }

//   // Get the list of functionality permissions from one of the roles (e.g., 'superadmin')
//   const functionalityPermissions = Object.keys(permissions.superadmin);

//   // Define the order of roles
//   const roleOrder: string[] = [
//     'superadmin',
//     'admin',
//     'ceo/cxo',
//     'manager',
//     'supervisor',
//     'operator',
//     'spectator',
//     'user',
//   ];

//   return (
//     <div className="permission-page">
//       <h3 style={{ textAlign: 'center' }}>Permissions</h3>
//       <table className="table permission-table table-bordered table-striped table-hover rounded text-center mt-4">
//         <thead>
//           <tr>
//             <th>Functionality</th>
//             {roleOrder.map((role) => (
//               <th key={role}>{role}</th>
//             ))}
//           </tr>
//         </thead>
//         <tbody>
//           {functionalityPermissions.map((permission) => (
//             <tr key={permission}>
//               <td>{permission}</td>
//               {roleOrder.map((role) => (
//                 <td key={role}>
//                   <input
//                     type="checkbox"
//                     checked={permissions[role][permission]}
//                     onChange={() => handlePermissionChange(role, permission)}
//                   />
//                 </td>
//               ))}
//             </tr>
//           ))}
//         </tbody>
//       </table>
//       <button onClick={handleSubmit}>Proceed</button>
//     </div>
//   );
// };

// export default PermissionPage;


// import React, { useState, useEffect } from 'react';
// import '../assets/css/PermissionPage.css';

// type Permissions = {
//   [key: string]: {
//     [key: string]: boolean;
//   };
// };

// type BackendResponse = {
//   [key: string]: string[];
// };

// const PermissionPage: React.FC = () => {
//   const [permissions, setPermissions] = useState<Permissions | null>(null);

//   useEffect(() => {
//     // Fetch permissions from the API and update the state
//     fetch('http://localhost:3000/v1/role/getAll')
//       .then((response) => response.json())
//       .then((data: BackendResponse) => {
//         // Ensure that the keys in initialPermissions match the backend response
//         const initialPermissions: Permissions = {
//           superadmin: {},
//           admin: {},
//           'ceo/cxo': {},
//           manager: {},
//           supervisor: {},
//           operator: {},
//           spectator: {},
//           user: {},
//         };

//         // Initialize the initialPermissions object with the fetched data
//         for (const role of Object.keys(data)) {
//           initialPermissions[role] = {};
//           for (const permission of data[role]) {
//             initialPermissions[role][permission] = true;
//           }
//         }

//         setPermissions(initialPermissions);
//       })
//       .catch((error) => {
//         console.error('Error fetching permissions:', error);
//       });
//   }, []);

//   const handlePermissionChange = (role: string, permission: string) => {
//     if (permissions) {
//       setPermissions((prevPermissions) => {
//         if (!prevPermissions) {
//           return prevPermissions;
//         }
//         return {
//           ...prevPermissions,
//           [role]: {
//             ...prevPermissions[role],
//             [permission]: !prevPermissions[role][permission],
//           },
//         };
//       });
//     }
//   };

//   const handleSubmit = () => {
//     // Check if permissions is not null
//     if (permissions) {
//       // Send a POST request to your backend API with the permissions data
//       console.warn(permissions);

//       fetch('http://localhost:3000/v1/permissions/update', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify(permissions),
//       })
//         .then((response) => response.json())
//         .then((data) => {
//           console.log('Permissions data sent successfully:', data);
//           // You can handle success actions here, such as showing a success message.
//         })
//         .catch((error) => {
//           console.error('Error sending permissions data:', error);
//           // You can handle error actions here, such as showing an error message.
//         });
//     }
//   };

//   if (!permissions) {
//     // Render a loading indicator or message while permissions are being fetched
//     return <p>Loading...</p>;
//   }

//   // Get the list of functionality permissions from one of the roles (e.g., 'superadmin')
//   const functionalityPermissions = Object.keys(permissions.superadmin); // Change 'superadmin' to one of the roles that contains all functionality permissions

//   // Define the order of roles
//   const roleOrder: string[] = [
//     'superadmin',
//     'admin',
//     'ceo/cxo',
//     'manager',
//     'supervisor',
//     'operator',
//     'spectator',
//     'user',
//   ];

//   return (
//     <div className="permission-page">
//       <h3 style={{ textAlign: 'center' }}>Permissions</h3>
//       <table className="table permission-table table-bordered table-striped table-hover rounded text-center mt-4">
//         <thead>
//           <tr>
//             <th>Functionality</th>
//             {roleOrder.map((role) => (
//               <th key={role}>{role}</th>
//             ))}
//           </tr>
//         </thead>
//         <tbody>
//           {functionalityPermissions.map((permission) => (
//             <tr key={permission}>
//               <td>{permission}</td>
//               {roleOrder.map((role) => (
//                 <td key={role}>
//                   <input
//                     type="checkbox"
//                     checked={permissions[role][permission]}
//                     onChange={() => handlePermissionChange(role, permission)}
//                   />
//                 </td>
//               ))}
//             </tr>
//           ))}
//         </tbody>
//       </table>
//       <button onClick={handleSubmit}>Proceed</button>
//     </div>
//   );
// };

// export default PermissionPage;

