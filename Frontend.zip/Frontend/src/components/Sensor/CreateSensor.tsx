import React, { useState } from "react";
import { Sensor } from "../../redux/types";
import { createSensor, fetchSensors } from "../../redux/sensorSlice";
import { RootState } from "../../redux/store";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";

import {
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  CircularProgress,
  TextareaAutosize,
  RadioGroup,
  FormControlLabel,
  Radio,
  Theme,
  FormControl,
  FormLabel,
  MenuItem,
} from "@mui/material";
import { makeStyles } from "@mui/styles"; // Import makeStyles and Theme
import "../../assets/css/Sensor.css";
interface CreateSensorProps {
  showModal: boolean;
  closeModal: () => void;
}
const initialSensorData: Sensor = {
  //sensorId: "", // This will be generated on the server
  sensorName: "",
  sensorType: "",
  valueForOne: null,
  sensorUse: "", //"PRODUCTIVE" | "IDLE" | "PARTCOUNT" | "OTHER";
  isActive: true,
  location: "",
  manufacturer: "",
  model: "",
  serialNumber: "",
  calibrationDate: new Date(),
  accuracy: "",
  measurementRange: "",
  operatingTemperature: "",
  powerSupply: "",
  dataFormat: "",
  sensorStatus: "",
  sensorDescription: "",
  conversion: [],
};

const initialErrors: Partial<Sensor> = {
  sensorName: "",
  sensorType: "",
  location: "",
  manufacturer: "",
  model: "",
  serialNumber: "",
  calibrationDate: new Date(),
  accuracy: "",
  measurementRange: "",
  operatingTemperature: "",
  powerSupply: "",
  dataFormat: "",
  sensorStatus: "",
  sensorDescription: "",
  conversion: [],
};
const useStyles = makeStyles((theme: Theme) => ({
  requiredAsterisk: {
    color: "red",
  },
  inputField: {
    fontSize: "14px",
    padding: "8px",
    height: "44px",
  },
  errorText: {
    color: theme.palette.error.main,
    fontSize: "0.875rem",
    marginTop: theme.spacing(0.5),
  },
}));

const CreateSensor: React.FC<CreateSensorProps> = (props) => {
  const { showModal, closeModal } = props;
  const { loading, error } = useMachinewiseSelector(
    (state: RootState) => state.facility
  );
  const [sensorData, setSensorData] = useState<Sensor>(initialSensorData);
  const [errors, setErrors] = useState<Partial<Sensor>>(initialErrors);
  const sensorDispatch = useMachinewiseDispatch();
  const classes = useStyles();
  const booleanOptions = [0, 1];
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0"); // Add 1 to month because it's zero-based
  const day = String(today.getDate()).padStart(2, "0");

  const defaultDate = `${year}-${month}-${day}`;

  const handleSensorChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;

    // If the sensor type is BOOLEAN, show the "Value for 1" field, otherwise set it to null
    const updatedValueForOne: number | null =
      sensorData.sensorType === "BOOLEAN" ? parseInt(value, 10) : null; //parse the value to a base-10 integer.

    setSensorData((prevData) => ({
      ...prevData,
      [name]: value,
      valueForOne: updatedValueForOne,
    }));
  };
  const validateFields = () => {
    const errors: Partial<Sensor> = {};
    if (sensorData.sensorName.trim() === "") {
      errors.sensorName = "Sensor name cannot be empty!";
    }
    if (sensorData.sensorType.trim() === "") {
      errors.sensorType = "Sensor type cannot be empty!";
    }
    // Validate sensorUse
    if (!sensorData.sensorUse) {
      errors.sensorUse = "Please select a value for Sensor Use!";
    }
    return errors;
  };
  const handleSubmit = async () => {
    const errors = validateFields();
    if (Object.keys(errors).length > 0) {
      setErrors(errors);
      return;
    }
    try {
      const sensorAction = await sensorDispatch(createSensor(sensorData));
      if (createSensor.fulfilled.match(sensorAction)) {
        toast.success("Sensor has been successfully created!");
        sensorDispatch(fetchSensors());
        closeModal();
      } else {
        toast.error("Sensor creation failed!");
      }
    } catch (error: any) {
      console.error(`An error occured:${error.message}`);
      toast.error("An error occurred");
    }
  };
  return (
    <Dialog open={showModal} maxWidth="sm">
      <DialogTitle
        className="sensor-form-title"
        style={{ textAlign: "center" }}
      >
        Create Sensor
      </DialogTitle>
      <DialogContent>
        {loading ? (
          <div style={{ textAlign: "center" }}>
            <CircularProgress />
          </div>
        ) : error ? (
          <DialogContentText color="error">{error}</DialogContentText>
        ) : (
          <form style={{ padding: "20px" }}>
            <Grid container spacing={2}>
              {" "}
              <Grid item xs={9}>
                <FormControl component="fieldset" fullWidth>
                  <FormLabel component="legend">
                    <span>
                      Sensor Type
                      <span className={classes.requiredAsterisk}>*</span>
                    </span>
                  </FormLabel>
                  <RadioGroup
                    aria-label="sensorType"
                    name="sensorType"
                    value={sensorData.sensorType}
                    onChange={handleSensorChange}
                    row
                  >
                    <FormControlLabel
                      value="BOOLEAN"
                      control={<Radio color="primary" size="small" />}
                      label="BOOLEAN"
                      labelPlacement="end"
                    />
                    <FormControlLabel
                      value="INTEGER"
                      control={<Radio color="primary" size="small" />}
                      label="INTEGER"
                      labelPlacement="end"
                    />
                    <FormControlLabel
                      value="OTHER"
                      control={<Radio color="primary" size="small" />}
                      label="OTHER"
                      labelPlacement="end"
                    />
                  </RadioGroup>
                  {errors.sensorType && (
                    <span className={classes.errorText}>
                      {errors.sensorType}
                    </span>
                  )}
                </FormControl>
              </Grid>{" "}
              <Grid item xs={3}>
                {/* Conditionally render the "Value for 1" field for BOOLEAN type */}
                {sensorData.sensorType === "BOOLEAN" && (
                  <TextField
                    fullWidth
                    select
                    label="Value for 1"
                    margin="normal"
                    name="valueForOne"
                    value={sensorData.valueForOne}
                    onChange={handleSensorChange}
                    size="small"
                  >
                    {booleanOptions.map((option) => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label={
                    <span>
                      Sensor Name
                      <span className={classes.requiredAsterisk}>*</span>
                    </span>
                  }
                  name="sensorName"
                  value={sensorData.sensorName}
                  onChange={handleSensorChange}
                  error={!!errors.sensorName}
                  helperText={errors.sensorName}
                  size="small"
                />
              </Grid>{" "}
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  select
                  // label="Sensor Use"
                  label={
                    <span>
                      Sensor Use
                      <span className={classes.requiredAsterisk}>*</span>
                    </span>
                  }
                  name="sensorUse"
                  value={sensorData.sensorUse}
                  onChange={handleSensorChange}
                  size="small"
                  error={!!errors.sensorUse}
                  helperText={errors.sensorUse}
                >
                  <MenuItem value="PRODUCTIVE">Productive</MenuItem>
                  <MenuItem value="IDLE">Idle</MenuItem>
                  <MenuItem value="PARTCOUNT">Part Count</MenuItem>
                  <MenuItem value="OTHER">Other</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Location"
                  name="location"
                  value={sensorData.location}
                  onChange={handleSensorChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Manufacturer"
                  name="manufacturer"
                  value={sensorData.manufacturer}
                  onChange={handleSensorChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Model"
                  name="model"
                  value={sensorData.model}
                  onChange={handleSensorChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Serial Number"
                  name="serialNumber"
                  value={sensorData.serialNumber}
                  onChange={handleSensorChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Accuracy"
                  name="accuracy"
                  value={sensorData.accuracy}
                  onChange={handleSensorChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  type="date"
                  label="Calibration Date"
                  name="calibrationDate"
                  value={sensorData.calibrationDate || defaultDate}
                  onChange={handleSensorChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Measurement Range"
                  name="measurementRange"
                  value={sensorData.measurementRange}
                  onChange={handleSensorChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Operating Temperature"
                  name="operatingTemperature"
                  value={sensorData.operatingTemperature}
                  onChange={handleSensorChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Power Supply"
                  name="powerSupply"
                  value={sensorData.powerSupply}
                  onChange={handleSensorChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Data Format"
                  name="dataFormat"
                  value={sensorData.dataFormat}
                  onChange={handleSensorChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Sensor Status"
                  name="sensorStatus"
                  value={sensorData.sensorStatus}
                  size="small"
                  onChange={handleSensorChange}
                />
              </Grid>
              <Grid item xs={12}>
                <TextareaAutosize
                  minRows={2}
                  style={{ width: "100%" }}
                  placeholder="Sensor Description"
                  name="sensorDescription"
                  value={sensorData.sensorDescription}
                  onChange={handleSensorChange}
                />
              </Grid>
            </Grid>
          </form>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={closeModal} color="primary" variant="outlined">
          Cancel
        </Button>{" "}
        <Button
          variant="contained"
          color="primary"
          onClick={handleSubmit}
          disabled={loading}
        >
          Create
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CreateSensor;
