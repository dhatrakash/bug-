import React from "react";
import AllSensor from "./AllSensor";
import "../../assets/css/Sensor.css";
const Sensors: React.FC = () => {
  return (
    <>
      <div className="sensor-container">
        <h5>
          <span>Sensor's List</span>
        </h5>
        <AllSensor />
      </div>
    </>
  );
};

export default Sensors;
