import React, { useEffect, useState } from "react";
import { Conversion, Sensor } from "../../redux/types";
import { fetchSensors, updateSensor } from "../../redux/sensorSlice";
import { RootState } from "../../redux/store";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";

import {
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  CircularProgress,
  TextareaAutosize,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  MenuItem,
} from "@mui/material";

import { makeStyles } from "@mui/styles";
import ConversionModal from "./ConversionModal";
import { toast } from "react-toastify";
import "../../assets/css/Sensor.css";
interface EditSensorProps {
  showModal: boolean;
  closeModal: () => void;
  sensorData: Sensor;
}
const initialConversionData: Conversion = {
  unit: "",
  scale: 0,
  sourceUnit: "",
  targetUnit: "",
  formula: "",
  precision: 0,
  description: "",
};
const initialErrors: Partial<Sensor> = {
  sensorName: "",
  sensorType: "",
  location: "",
  manufacturer: "",
  model: "",
  serialNumber: "",
  calibrationDate: new Date(),
  accuracy: "",
  measurementRange: "",
  operatingTemperature: "",
  powerSupply: "",
  dataFormat: "",
  sensorStatus: "",
  sensorDescription: "",
  conversion: [],
};
const useStyles = makeStyles(() => ({
  title: {
    paddingBottom: "10px",
    color: "#1976D2",
  },
  requiredAsterisk: {
    color: "red",
  },
  inputField: {
    fontSize: "14px",
    padding: "8px",
    height: "44px",
  },
}));

const EditSensor: React.FC<EditSensorProps> = ({
  showModal,
  closeModal,
  sensorData,
}) => {
  const { loading, error } = useMachinewiseSelector(
    (state: RootState) => state.facility
  );
  const [editedSensorData, setEditedSensorData] = useState<Sensor>(sensorData);
  const [errors, setErrors] = useState<Partial<Sensor>>(initialErrors);

  const [isConversionModalOpen, setConversionModalOpen] = useState(false);

  const sensorDispatch = useMachinewiseDispatch();
  const classes = useStyles();
  const booleanOptions = [0, 1];
  useEffect(() => {
    setEditedSensorData(sensorData);
  }, [sensorData]);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    // const updatedValueForOne: number | null =
    //   editedSensorData.sensorType === "BOOLEAN" ? parseInt(value, 10) : null; //parse the value to a base-10 integer.
    // //console.log("Selected Radio:", selectedRadio);
    const updatedValueForOne: number | null =
      name === "sensorType" && value !== "BOOLEAN" ? null : parseInt(value, 10);

    setEditedSensorData((prevData) => ({
      ...prevData,
      [name]: value,
      // sensorType: selectedRadio,
      valueForOne: updatedValueForOne,
    }));
  };

  const validateFields = () => {
    const errors: Partial<Sensor> = {};
    if (sensorData.sensorName.trim() === "") {
      errors.sensorName = "Sensor name cannot be empty!";
    }
    if (sensorData.sensorType.trim() === "") {
      errors.sensorType = "Sensor type cannot be empty!";
    }
    return errors;
  };
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const errors = validateFields();
    if (Object.keys(errors).length > 0) {
      setErrors(errors);
      return;
    }
    if (editedSensorData.sensorId) {
      try {
        const sensorAction = await sensorDispatch(
          updateSensor(editedSensorData)
        );

        if (updateSensor.fulfilled.match(sensorAction)) {
          closeModal();
          sensorDispatch(fetchSensors);
          // Show success toast message
          toast.success("Sensor updated successfully");
        } else {
          toast.error("Failed to update Sensor");
        }
      } catch (error: any) {
        console.error(`An error occured:${error.message}`);
        toast.error("An error occurred");
      }
    } else {
      console.warn("Sensor Id not found");
    }
  };

  const getLastConversionData = () => {
    const lastConversionData =
      editedSensorData.conversion[editedSensorData.conversion.length - 1];
    return lastConversionData || initialConversionData;
  };
  // ...

  const handleAddOrUpdateConversion = (newConversionData: Conversion) => {
    let updatedConversionData = [...editedSensorData.conversion];
    const existingConversionIndex = updatedConversionData.findIndex(
      (conversion) => conversion.unit === newConversionData.unit
    );

    if (existingConversionIndex !== -1) {
      // Replace the existing conversion if it exists
      updatedConversionData[existingConversionIndex] = newConversionData;
    } else {
      // Add a new conversion at the 0th position
      updatedConversionData.unshift(newConversionData);
    }

    // Ensure only one entry exists in the conversion array at the 0th position
    if (updatedConversionData.length > 1) {
      updatedConversionData = [updatedConversionData[0]];
    }

    const updatedSensor = {
      ...editedSensorData,
      conversion: updatedConversionData,
    };

    setEditedSensorData(updatedSensor);
    setConversionModalOpen(false);
  };

  return (
    <Dialog open={showModal} maxWidth="sm">
      <DialogTitle
        className="sensor-form-title"
        style={{ textAlign: "center" }}
      >
        Update Sensor
      </DialogTitle>
      <DialogContent>
        {loading ? (
          <div style={{ textAlign: "center" }}>
            <CircularProgress />
          </div>
        ) : error ? (
          <DialogContentText color="error">{error}</DialogContentText>
        ) : (
          <form style={{ padding: "20px" }} onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={9}>
                <FormControl component="fieldset" fullWidth>
                  <FormLabel
                    component="legend"
                    // style={{
                    //   color: " #061c73",
                    //   fontSize: "13px",
                    //   fontWeight: "600",
                    //   justifyContent: "center",
                    //   textAlign: "center",
                    // }}
                  >
                    <span>
                      Sensor Type
                      <span className={classes.requiredAsterisk}>*</span>
                    </span>
                  </FormLabel>
                  <RadioGroup
                    aria-label="sensorType"
                    name="sensorType"
                    value={editedSensorData.sensorType}
                    onChange={handleInputChange}
                    row
                  >
                    <FormControlLabel
                      value="BOOLEAN"
                      control={<Radio color="primary" size="small" />}
                      label="BOOLEAN"
                      labelPlacement="end"
                    />
                    <FormControlLabel
                      value="INTEGER"
                      control={<Radio color="primary" size="small" />}
                      label="INTEGER"
                      labelPlacement="end"
                    />
                    <FormControlLabel
                      value="OTHER"
                      control={<Radio color="primary" size="small" />}
                      label="OTHER"
                      labelPlacement="end"
                    />
                  </RadioGroup>
                </FormControl>
              </Grid>{" "}
              <Grid item xs={3}>
                {/* Conditionally render the "Value for 1" field for BOOLEAN type */}
                {editedSensorData.sensorType === "BOOLEAN" && (
                  <TextField
                    fullWidth
                    select
                    label="Value for 1"
                    margin="normal"
                    name="valueForOne"
                    value={editedSensorData.valueForOne}
                    onChange={handleInputChange}
                    size="small"
                  >
                    {booleanOptions.map((option) => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label={
                    <span>
                      Sensor Name
                      <span className={classes.requiredAsterisk}>*</span>
                    </span>
                  }
                  name="sensorName"
                  value={editedSensorData.sensorName}
                  onChange={handleInputChange}
                  InputProps={{
                    disableUnderline: true,
                    className: classes.inputField,
                  }}
                  size="small"
                />
              </Grid>{" "}
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  select
                  label="Sensor Use"
                  name="sensorUse"
                  value={editedSensorData.sensorUse}
                  onChange={handleInputChange}
                  size="small"
                  error={!!errors.sensorUse}
                  helperText={errors.sensorUse}
                >
                  <MenuItem value="PRODUCTIVE">Productive</MenuItem>
                  <MenuItem value="IDLE">Idle</MenuItem>
                  <MenuItem value="PARTCOUNT">Part Count</MenuItem>
                  <MenuItem value="OTHER">Other</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Location"
                  name="location"
                  value={editedSensorData.location}
                  onChange={handleInputChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Manufacturer"
                  name="manufacturer"
                  value={editedSensorData.manufacturer}
                  onChange={handleInputChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Model"
                  name="model"
                  value={editedSensorData.model}
                  onChange={handleInputChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Serial Number"
                  name="serialNumber"
                  value={editedSensorData.serialNumber}
                  onChange={handleInputChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Accuracy"
                  name="accuracy"
                  value={editedSensorData.accuracy}
                  onChange={handleInputChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  type="date"
                  label="Calibration Date"
                  name="calibrationDate"
                  value={
                    editedSensorData.calibrationDate ||
                    new Date().toISOString().slice(0, 10)
                  }
                  onChange={handleInputChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Measurement Range"
                  name="measurementRange"
                  value={editedSensorData.measurementRange}
                  onChange={handleInputChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Operating Temperature"
                  name="operatingTemperature"
                  value={editedSensorData.operatingTemperature}
                  onChange={handleInputChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Power Supply"
                  name="powerSupply"
                  value={editedSensorData.powerSupply}
                  onChange={handleInputChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Data Format"
                  name="dataFormat"
                  value={editedSensorData.dataFormat}
                  onChange={handleInputChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Sensor Status"
                  name="sensorStatus"
                  value={editedSensorData.sensorStatus}
                  onChange={handleInputChange}
                  size="small"
                />
              </Grid>
              <Grid item xs={12}>
                <TextareaAutosize
                  minRows={2}
                  style={{ width: "100%" }}
                  placeholder="Sensor Description"
                  name="sensorDescription"
                  value={editedSensorData.sensorDescription}
                  onChange={handleInputChange}
                />
              </Grid>
            </Grid>
            <DialogActions>
              {" "}
              <Button onClick={closeModal} color="primary" variant="outlined">
                Cancel
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={() => {
                  setConversionModalOpen(true);
                }}
              >
                Add Conversion
              </Button>
              <Button
                variant="contained"
                color="primary"
                type="submit"
                disabled={loading}
              >
                Save Changes
              </Button>
              <ConversionModal
                open={isConversionModalOpen}
                onClose={() => setConversionModalOpen(false)}
                onSave={handleAddOrUpdateConversion} // Use the new function
                initialConversionData={getLastConversionData()}
              />
            </DialogActions>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default EditSensor;
