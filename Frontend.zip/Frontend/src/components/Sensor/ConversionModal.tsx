import React, { useState } from "react";
import {
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  TextareaAutosize,
} from "@mui/material";

import { makeStyles } from "@mui/styles";
import { Conversion } from "../../redux/types";
import { toast } from "react-toastify";

interface ConversionModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (conversionData: Conversion) => void;
  initialConversionData?: Conversion;
}

const useStyles = makeStyles(() => ({
  title: {
    paddingBottom: "10px",
    color: "#1976D2",
  },
  inputField: {
    fontSize: "14px",
    padding: "8px",
    height: "44px",
  },
}));

const ConversionModal: React.FC<ConversionModalProps> = ({
  open,
  onClose,
  onSave,
  initialConversionData,
}) => {
  const [conversionData, setConversionData] = useState<Conversion>(
    initialConversionData || {
      unit: "",
      scale: 0,
      sourceUnit: "",
      targetUnit: "",
      formula: "",
      precision: 0,
      description: "",
    }
  );
  // eslint-disable-next-line
  const classes = useStyles();

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setConversionData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSave = () => {
    onSave(conversionData);
    toast.success("Conversion saved successfully");
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose}>
      {" "}
      <DialogTitle
        className="sensor-form-title"
        style={{ textAlign: "center" }}
      >
        Add Conversion
      </DialogTitle>
      <DialogContent style={{ padding: "20px" }}>
        <Grid container spacing={2}>
          <Grid item xs={6}>
            <TextField
              fullWidth
              label="Unit"
              name="unit"
              value={conversionData.unit}
              onChange={handleInputChange}
              size="small"
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              fullWidth
              label="Scale"
              name="scale"
              value={conversionData.scale}
              onChange={handleInputChange}
              size="small"
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              fullWidth
              label="Source Unit"
              name="sourceUnit"
              value={conversionData.sourceUnit}
              onChange={handleInputChange}
              size="small"
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              fullWidth
              label="Target Unit"
              name="targetUnit"
              value={conversionData.targetUnit}
              onChange={handleInputChange}
              size="small"
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              fullWidth
              label="Formula"
              name="formula"
              value={conversionData.formula}
              onChange={handleInputChange}
              size="small"
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              fullWidth
              label="Precision"
              name="precision"
              value={conversionData.precision}
              onChange={handleInputChange}
              size="small"
            />
          </Grid>

          <Grid item xs={12}>
            <TextareaAutosize
              minRows={2}
              style={{ width: "100%" }}
              placeholder="Sensor Conversion Description"
              name="description"
              value={conversionData.description}
              onChange={handleInputChange}
            />
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="primary" variant="outlined">
          Cancel
        </Button>
        <Button onClick={handleSave} color="primary" variant="contained">
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ConversionModal;
