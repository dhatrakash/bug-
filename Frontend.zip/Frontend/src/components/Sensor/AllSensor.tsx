import React, { useState, useEffect } from "react";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  CircularProgress,
  Paper,
  IconButton,
  styled,
  Box,
  TextField,
  Grid,
  TablePagination,
} from "@mui/material";
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  AddCircleOutlineSharp as AddIcon,
  ArrowUpward as ArrowUpwardIcon,
  ArrowDownward as ArrowDownwardIcon,
  FilterList as FilterListIcon,
  FilterListOff as CloseIcon,
} from "@mui/icons-material";

import { RootState } from "../../redux/store";
import { fetchSensors, deleteSensor } from "../../redux/sensorSlice";
import { Sensor } from "../../redux/types";
import DeleteConfirmationModal from "./DeleteConfirmationModal";
import EditSensor from "./EditSensor";
import { toast } from "react-toastify";
import "../../assets/css/Sensor.css";
import CreateSensor from "./CreateSensor";
import NotFound from "../NotFound";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  head: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  body: {
    fontSize: 14,
  },
}));

const AllSensor: React.FC = () => {
  const [showModal, setShowModal] = useState(false);
  const [addSensor, setAddSensor] = useState(false);
  const [sortConfig, setSortConfig] = useState<Record<string, string>>({});
  const [editingSensor, setEditingSensor] = useState<Sensor | null>(null);
  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
  const [sensorToDelete, setSensorToDelete] = useState<Sensor | null>(null);
  const [sensorNameFilter, setSensorNameFilter] = useState("");
  const [sensorTypeFilter, setSensorTypeFilter] = useState("");
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [page, setPage] = useState(0); // State for the current page
  const [rowsPerPage, setRowsPerPage] = useState(10); // State for rows per page
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  const {
    sensors = [],
    loading,
    error,
  } = useMachinewiseSelector((state: RootState) => state.sensor);

  const functionalities = useMachinewiseSelector(
    (state: RootState) => state.functionalities
  );

  const sensorDispatch = useMachinewiseDispatch();

  useEffect(() => {
    // Dispatch the fetchSensors action to fetch data
    sensorDispatch(fetchSensors());
  }, [sensorDispatch]);

  const handleSortClick = (column: string) => {
    let direction = "asc";
    if (sortConfig[column] === "asc") {
      direction = "desc";
    }
    setSortConfig({ [column]: direction });
  };

  // Function to open the Edit Sensor modal
  const openEditModal = (sensor: Sensor) => {
    setEditingSensor(sensor);
  };

  // Function to close the Edit Sensor modal
  const closeEditModal = () => {
    setEditingSensor(null);
  };

  const openDeleteModal = (sensor: Sensor) => {
    setSensorToDelete(sensor);
    setDeleteModalOpen(true);
  };

  // Function to close the Delete Confirmation modal
  const closeDeleteModal = () => {
    setDeleteModalOpen(false);
    setSensorToDelete(null);
  };

  const handleConfirmDelete = async () => {
    if (sensorToDelete && sensorToDelete.sensorId) {
      try {
        const sensorAction = await sensorDispatch(
          deleteSensor(sensorToDelete.sensorId)
        );
        if (deleteSensor.fulfilled.match(sensorAction)) {
          setDeleteModalOpen(false);
          sensorDispatch(fetchSensors());
          toast.success("Sensor deleted successfully");
        } else {
          toast.error("Failed to delete sensor. Please try again.");
        }
      } catch (error: any) {
        console.error(`An error occured:${error.message}`);
        toast.error("An error occurred while deleting the sensor");
      }
    }
  };

  // Sort the sensors array based on the sortConfig
  const sortedSensors = [...(sensors || [])].sort((a, b) => {
    let comparison = 0;
    for (const column in sortConfig) {
      const sortOrder = sortConfig[column];
      const aValue = (a as any)[column];
      const bValue = (b as any)[column];

      if (aValue < bValue) {
        comparison = sortOrder === "asc" ? -1 : 1;
        break;
      }
      if (aValue > bValue) {
        comparison = sortOrder === "asc" ? 1 : -1;
        break;
      }
    }
    return comparison;
  });
  const handleFilterToggle = () => {
    // Toggle the filter visibility
    setIsFilterOpen(!isFilterOpen);
  };
  const handleChangePage = (
    event: React.MouseEvent<HTMLButtonElement> | null,
    newPage: number
  ) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handlePermission = async () => {
    // Get data from session storage
    const sessionStorageDataString = sessionStorage.getItem("functionalities");
    // Check if sessionStorageDataString is not null or undefined
    if (sessionStorageDataString) {
      const sessionStorageData = JSON.parse(sessionStorageDataString);

      // Check if sessionStorageData is an object
      if (sessionStorageData && typeof sessionStorageData === "object") {
        const dataArray = Object.keys(sessionStorageData);
        const newDataFormat = { data: dataArray };
        if (!showModal) {
          // Send a POST request to your server
          try {
            const response = await fetch(
              "http://localhost:3000/v1/users/permission",
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${sessionStorage.getItem(
                    "access-token"
                  )}`,
                  // Add any other headers as needed
                },
                body: JSON.stringify(newDataFormat),
              }
            );
            // Handle the response
            const responseData = await response.json();
            console.log(responseData);
            if (
              responseData.trueUserRights &&
              responseData.trueUserRights.addSensor !== undefined
            ) {
              setAddSensor(responseData.trueUserRights.addSensor);
            }
            console.warn("addSensor1 " + addSensor);
            openModal();
          } catch (error) {
            console.error("Error:", error);
            console.warn("addSensor2 " + addSensor);
            closeModal();
          }
        } else {
          console.warn("addSensor3 " + addSensor);
          closeModal();
        }
      } else {
        console.error("sessionStorageData is not an object");
      }
    } else {
      console.error("sessionStorageDataString is null or undefined");
    }
  };

  return (
    <div className="sensor-details">
      <Paper className="sensor-paper">
        <Box display="flex" justifyContent="flex-end" alignItems="center">
          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            <IconButton
              color="primary"
              aria-label="Filter Sensors"
              onClick={handleFilterToggle}
              style={{
                padding: "10px 20px",
                borderRadius: "15px",
                transition: "background-color 0.7s ease",
              }}
            >
              {isFilterOpen ? (
                <CloseIcon fontSize="small" />
              ) : (
                <FilterListIcon fontSize="small" />
              )}
              <span
                style={{
                  marginLeft: "8px",
                  marginTop: "-2px",
                  fontSize: "medium",
                  fontWeight: "bold",
                }}
              >
                Filter Sensors
              </span>
            </IconButton>{" "}
            {functionalities.addSensor && (
              <IconButton
                color="primary"
                aria-label="Add Sensor"
                onClick={handlePermission}
                style={{
                  padding: "10px 20px",
                  borderRadius: "15px",
                  transition: "background-color 0.7s ease",
                }}
              >
                <AddIcon fontSize="small" />
                <span
                  style={{
                    marginLeft: "8px",
                    marginTop: "-2px",
                    fontSize: "medium",
                    fontWeight: "bold",
                  }}
                >
                  Add Sensor
                </span>
              </IconButton>
            )}
          </div>
        </Box>

        {isFilterOpen && (
          <Box
            style={{
              padding: "10px 20px",
              borderRadius: "15px",
              transition: "background-color 0.7s ease",
              marginLeft: "auto", // Align the filter button to the right
            }}
          >
            <Grid
              container
              spacing={2}
              alignItems="center"
              style={{ display: "flex", justifyContent: "flex-end" }}
              className="sensor-filter-fields"
            >
              {" "}
              <Grid item xs={12} sm={6} md={4} lg={2}>
                <TextField
                  label="Filter by Sensor Name"
                  value={sensorNameFilter}
                  onChange={(e) => setSensorNameFilter(e.target.value)}
                  variant="outlined"
                  size="small"
                  fullWidth
                  margin="normal"
                />
              </Grid>
              <Grid item xs={12} sm={6} md={4} lg={2}>
                <TextField
                  label="Filter by Sensor Type"
                  value={sensorTypeFilter}
                  onChange={(e) => setSensorTypeFilter(e.target.value)}
                  variant="outlined"
                  size="small"
                  fullWidth
                  margin="normal"
                />
              </Grid>
            </Grid>
          </Box>
        )}
        <Table className="sensor-table">
          <TableHead>
            <TableRow>
              <StyledTableCell>Sr No</StyledTableCell>
              <StyledTableCell onClick={() => handleSortClick("sensorName")}>
                Sensor Name
                {sortConfig["sensorName"] === "asc" && <ArrowUpwardIcon />}
                {sortConfig["sensorName"] === "desc" && <ArrowDownwardIcon />}
              </StyledTableCell>
              <StyledTableCell onClick={() => handleSortClick("sensorType")}>
                Sensor Type
                {sortConfig["sensorType"] === "asc" && <ArrowUpwardIcon />}
                {sortConfig["sensorType"] === "desc" && <ArrowDownwardIcon />}
              </StyledTableCell>
              <StyledTableCell>Actions</StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
              <TableRow key="loading">
                <TableCell colSpan={4} align="center">
                  <CircularProgress />
                </TableCell>
              </TableRow>
            ) : error ? (
              <TableRow key="error">
                <TableCell colSpan={4} align="center">
                  Error: Something went wrong while loading
                </TableCell>
              </TableRow>
            ) : (
              sortedSensors
                .filter((sensor) => {
                  const sensorName = (sensor.sensorName || "").toLowerCase();
                  const sensorType = (sensor.sensorType || "").toLowerCase();

                  return (
                    sensorName.includes(sensorNameFilter.toLowerCase()) &&
                    sensorType.includes(sensorTypeFilter.toLowerCase())
                  );
                })
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((sensor, index) => (
                  <TableRow key={sensor._id}>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell>{sensor.sensorName}</TableCell>
                    <TableCell>{sensor.sensorType}</TableCell>
                    <TableCell>
                      <IconButton
                        color="primary"
                        onClick={() => openEditModal(sensor)}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton
                        color="error"
                        onClick={() => openDeleteModal(sensor)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
            )}
          </TableBody>
        </Table>
        {/* TablePagination component */}
        <TablePagination
          rowsPerPageOptions={[5, 10, 25, 50]} // You can customize the available options
          component="div"
          count={sortedSensors.length} // Total number of rows
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
        {addSensor ? (
          <CreateSensor
            showModal={showModal}
            closeModal={() => setShowModal(false)}
          />
        ) : (
          <NotFound showModal={showModal} closeModal={closeModal} />
        )}
        {editingSensor && (
          <EditSensor
            showModal={true}
            closeModal={closeEditModal}
            sensorData={editingSensor}
          />
        )}
        <DeleteConfirmationModal
          open={isDeleteModalOpen}
          handleClose={closeDeleteModal}
          handleConfirm={handleConfirmDelete}
        />
      </Paper>
    </div>
  );
};

export default AllSensor;
