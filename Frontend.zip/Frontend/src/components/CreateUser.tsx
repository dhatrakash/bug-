import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  TextField,
  Button,
  Grid,
  Paper,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box,
} from "@mui/material";
import '../assets/css/CreateUser.css';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
import NotFound from './NotFound';

interface FormData {
  name: string;
  email: string;
  role: string;
  // compName: string;
  password: string; 
}

const CreateUserPage: React.FC = () => {
  // const [companyNames, setCompanyNames] = useState<string[]>([]);
  const navigate = useNavigate();
  const [responseStatus, setResponseStatus ] = useState<boolean>(false);

  const handleResponseStatus = async () => {

     if(sessionStorage.getItem("role") === "superAdmin"){
      try {
        // Make a POST request to the API
        const response = await fetch('http://localhost:3000/v1/superAdmins/viewAddUserForm', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization' : `Bearer ${sessionStorage.getItem("access-token")}`
          }
        });
        console.warn("response " + response);
        const data = await response.json();
        setResponseStatus(data.msg);
        console.log(data.msg);
      } catch (err) {
        console.log(err);
      }
    }else{
      try {
        // Make a POST request to the API
        const response = await fetch('http://localhost:3000/v1/users/viewAddUserForm', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization' : `Bearer ${sessionStorage.getItem("access-token")}`
          }
        });
        console.warn("response " + response);
        const data = await response.json();
        setResponseStatus(data.msg);
        console.log(data.msg);
      } catch (err) {
        console.log(err);
      }
    }
 
  };

  // useEffect(() => {
  //   fetch('http://localhost:3000/v1/clientComp/getAllClientCompaniesNames')
  //     .then((response) => response.json())
  //     .then((data) => {
  //       const companyNamesFromApi = data.map((item: any) => item.name);
  //       setCompanyNames(companyNamesFromApi);
  //     })
  //     .catch((error) => {
  //       console.error('Error fetching company names:', error);
  //     });
  // }, []);

   useEffect(() => {
    handleResponseStatus();
  }, []);



  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    role: '',
    // compName: 'MachineWise',
    password: '', 
  });

  const [password, setPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [passwordError, setPasswordError] = useState<string>('');
  const [confirmPasswordError, setConfirmPasswordError] = useState<string>('');

  const [errors, setErrors] = useState<{ name?: string; email?: string; role?: string; compName?: string }>({});

  const handleInputChange = (event: React.ChangeEvent<{ name?: string; value: unknown }>) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name as string]: value,
    });

    if (name === 'password') {
      setPassword(value as string);
    } else if (name === 'confirmPassword') {
      setConfirmPassword(value as string);
    }
  };

  const handleRoleChange = (event: React.ChangeEvent<{ name?: string; value: unknown }>) => {
    const role = event.target.value as string;
    setFormData({
      ...formData,
      role,
    });
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const formErrors = validateFormData(formData);
    if (Object.keys(formErrors).length > 0 || !validatePasswords()) {
      setErrors({ ...formErrors });
      return;
    }

    try {
      // Construct the request body using formData
      const requestBody = {
        name: formData.name,
        email: formData.email,
        password: formData.password, // Use the password field from formData
        role: formData.role,
        // compName: formData.compName,
      };

      // Make a POST request to the API
      const response = await fetch('http://localhost:3000/v1/superAdmins/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization' : `Bearer ${sessionStorage.getItem("access-token")}`
        },
        body: JSON.stringify(requestBody),
      });
      console.warn(requestBody);
      const data = await response.json();
      if (response.status === 201) {
        console.warn(data);
        toast.success('User Created successfully', { position: 'top-right' });
        navigate('/');
      } else {
        toast.error('User registration failed !!!', { position: 'top-right' });
      }
    } catch (err) {
      console.log(err);
      toast.error('Internal Server Error !', { position: 'top-right' });
    }
  };


  const validateFormData = (data: FormData) => {
    const errors: { name?: string; email?: string; role?: string; compName?: string } = {};

    if (!data.name) {
      errors.name = 'Name is required';
    }
    if (!data.email) {
      errors.email = 'Email is required';
    } else if (!isValidEmail(data.email)) {
      errors.email = 'Invalid email address';
    }
    if (!data.role) {
      errors.role = 'Role is required';
    }
 

    return errors;
  };

  const isValidEmail = (email: string) => {
    return email.includes('@');
  };

  const validatePasswords = () => {
    if (!password) {
      setPasswordError('Password is required');
      return false;
    } else if (password.length < 6) {
      setPasswordError('Password must be at least 6 characters long');
      return false;
    } else {
      setPasswordError('');
    }

    if (password !== confirmPassword) {
      setConfirmPasswordError('Passwords do not match');
      return false;
    } else {
      setConfirmPasswordError('');
    }

    return true;
  };

  return (
    <div className='createUser-container'
      // style={{ backgroundColor: "#f1f1f1" }}
    >
      {responseStatus && (
  
          <Paper
            elevation={3}
            className="container createUser"
            id="createUserContainer"
          >
            <Box>
            <Typography variant="h5" gutterBottom fontStyle={"normal"}>
              Create User
            </Typography>
            <form onSubmit={handleSubmit}>
              <Grid container spacing={2}>
                <Grid item xs={12} className="form-input">
                  <TextField
                    name="name"
                    label="Name"
                    fullWidth
                    value={formData.name}
                    onChange={handleInputChange}
                    error={!!errors.name}
                    helperText={errors.name}
                  />
                </Grid>
                <Grid item xs={12} className="form-input">
                  <TextField
                    name="email"
                    label="Email"
                    type="email"
                    fullWidth
                    value={formData.email}
                    onChange={handleInputChange}
                    error={!!errors.email}
                    helperText={errors.email}
                  />
                </Grid>
                <Grid item xs={12} className="form-input">
                  <TextField
                    name="password"
                    label="Password"
                    type="password"
                    fullWidth
                    value={password}
                    onChange={handleInputChange}
                    error={!!passwordError}
                    helperText={passwordError}
                  />
                </Grid>
                <Grid item xs={12} className="form-input">
                  <TextField
                    name="confirmPassword"
                    label="Confirm Password"
                    type="password"
                    fullWidth
                    value={confirmPassword}
                    onChange={handleInputChange}
                    error={!!confirmPasswordError}
                    helperText={confirmPasswordError}
                  />
                </Grid>
                <Grid item xs={12} className="form-input">
                  <FormControl fullWidth>
                    <InputLabel htmlFor="role-select">Role</InputLabel>
                    <Select
                      name="role"
                      label="Role"
                      value={formData.role}
                      onChange={(event) =>
                        handleRoleChange(
                          event as React.ChangeEvent<{
                            name?: string;
                            value: unknown;
                          }>
                        )
                      }
                      error={!!errors.role}
                    >
                      <MenuItem value="">Select Role</MenuItem>
                      <MenuItem value="admin">Admin</MenuItem>
                      <MenuItem value="ceo/cxo">CEO/CXO</MenuItem>
                      <MenuItem value="manager">Manager</MenuItem>
                      <MenuItem value="supervisor">Supervisor</MenuItem>
                      <MenuItem value="operator">Operator</MenuItem>
                      <MenuItem value="spectator">Spectator</MenuItem>
                      <MenuItem value="user">User</MenuItem>
                    </Select>
                    {errors.role && <div>{errors.role}</div>}
                  </FormControl>
                </Grid>

                {/* <Grid item xs={12} className="form-input">
              <FormControl fullWidth>
                <InputLabel htmlFor="company-name-select">Company Name</InputLabel>
                <Select
                  name="compName"
                  label="Company Name"
                  value={formData.compName}
                  onChange={(event) =>
                    handleInputChange(event as React.ChangeEvent<{ name?: string; value: unknown }>)
                  }
                  error={!!errors.compName}
                >
                  <MenuItem value="">Select Company Name</MenuItem>
                  {companyNames.map((companyName) => (
                    <MenuItem key={companyName} value={companyName}>
                      {companyName}
                  </MenuItem>
                  ))}
                </Select>
                {errors.compName && <div>{errors.compName}</div>}
              </FormControl>
            </Grid> */}
              </Grid>
              <div className="form-button">
                <Button variant="contained" color="primary" type="submit">
                  Submit
                </Button>
              </div>
            </form>
            </Box>
         
          </Paper>
       
      )}
      {!responseStatus && (
        <div>
          <h3>You are not an authorized user</h3>
        </div>
      )}
    </div>
  );
};

export default CreateUserPage;





