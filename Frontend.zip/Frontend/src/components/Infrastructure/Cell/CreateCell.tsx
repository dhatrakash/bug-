import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
} from "@mui/material";
import { createCell, fetchCells } from "../../../redux/cellSlice";
import { Cell } from "../../../redux/types";
import { toast } from "react-toastify";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";

interface CreateCellProps {
  showModal: boolean;
  closeModal: () => void;
}

const CreateCell: React.FC<CreateCellProps> = ({ showModal, closeModal }) => {
  const loading = useMachinewiseSelector((state) => state.cell.loading);
  const cellDispatch = useMachinewiseDispatch();

  const [cellData, setCellData] = useState<Cell>({
    name: "",
    value: "",
  });

  const handleChange = (field: string, value: string) => {
    setCellData({ ...cellData, [field]: value });
  };

  const handleCreateCell = async () => {
    try {
      const cellAction = await cellDispatch(createCell(cellData));

      if (createCell.fulfilled.match(cellAction)) {
        toast.success("Cell created successfully");
        cellDispatch(fetchCells());
        closeModal();
      } else {
        toast.error("Failed to create cell. Please try again!");
      }
    } catch (error) {
      toast.error("An error occurred");
    }
  };

  return (
    <Dialog open={showModal} maxWidth="lg">
      <DialogTitle
        className="machine-form-title"
        style={{ textAlign: "center" }}
      >
        Create Cell
      </DialogTitle>
      <DialogContent className="modal-container">
        <form>
          <TextField
            fullWidth
            label="Cell Name"
            variant="outlined"
            margin="normal"
            value={cellData.name}
            onChange={(e) => handleChange("name", e.target.value)}
          />
          <TextField
            fullWidth
            label="Cell Value"
            variant="outlined"
            margin="normal"
            value={cellData.value}
            onChange={(e) => handleChange("value", e.target.value)}
          />

          <DialogActions>
            <Button variant="outlined" onClick={closeModal}>
              Close
            </Button>
            <Button
              variant="contained"
              color="primary"
              type="button"
              onClick={handleCreateCell}
              disabled={loading}
            >
              Submit
            </Button>
          </DialogActions>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateCell;
