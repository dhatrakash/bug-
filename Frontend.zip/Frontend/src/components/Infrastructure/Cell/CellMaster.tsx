import React from "react";
import AllCell from "./AllCell";
import "../../../assets/css/Infrastructure.css";
const CellsMaster: React.FC = () => {
  return (
    <>
      <div className="infrastructure-container">
        <h5>
          <span>Cell's List</span>
        </h5>

        <AllCell />
      </div>
    </>
  );
};

export default CellsMaster;
