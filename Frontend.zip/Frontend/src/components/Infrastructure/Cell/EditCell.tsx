import React, { useState, useEffect } from "react";
import {
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import { updateCell } from "../../../redux/cellSlice";
import { Cell } from "../../../redux/types";
import { toast } from "react-toastify";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";

interface EditCellProps {
  showModal: boolean;
  closeModal: () => void;
  cellData: Cell;
}

const EditCell: React.FC<EditCellProps> = ({
  showModal,
  closeModal,
  cellData,
}) => {
  const { loading } = useMachinewiseSelector((state) => state.cell);
  const cellDispatch = useMachinewiseDispatch();
  // Use a local state to track the edited cell data
  const [editedCellData, setEditedCellData] = useState<Cell>(cellData);

  // Update the local state if cellData changes
  useEffect(() => {
    setEditedCellData(cellData);
  }, [cellData]);

  // Handle input changes
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setEditedCellData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // Make sure there's an ID before dispatching the update
    if (editedCellData._id) {
      try {
        const cellAction = await cellDispatch(updateCell(editedCellData));

        if (updateCell.fulfilled.match(cellAction)) {
          toast.success("Cell updated successfully");
          closeModal();
        } else {
          toast.error("Failed to update cell. Please try again!");
        }
      } catch (error) {
        toast.error("An error occurred");
      }
    } else {
      console.error("Cell ID is missing.");
    }
  };

  return (
    <Dialog open={showModal} maxWidth="lg">
      <DialogTitle className="infra-form-title" style={{ textAlign: "center" }}>
        Update Cell
      </DialogTitle>
      <DialogContent className="modal-container">
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Cell Name"
            variant="outlined"
            margin="normal"
            name="name"
            value={editedCellData.name}
            onChange={handleInputChange}
          />

          <TextField
            fullWidth
            label="Cell Value"
            variant="outlined"
            margin="normal"
            name="value"
            value={editedCellData.value}
            onChange={handleInputChange}
          />

          <DialogActions>
            {" "}
            <Button variant="outlined" onClick={closeModal}>
              Close
            </Button>
            <Button
              variant="contained"
              color="primary"
              type="submit"
              disabled={loading}
            >
              Update
            </Button>
          </DialogActions>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EditCell;
