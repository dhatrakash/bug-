import React, { useState, useEffect } from "react";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  CircularProgress,
  Paper,
  Box,
  IconButton,
  Tooltip,
} from "@mui/material";
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  AddCircleOutlineSharp as AddIcon,
} from "@mui/icons-material";
import { toast } from "react-toastify";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";
import { fetchCells, deleteCell } from "../../../redux/cellSlice";
import { Cell } from "../../../redux/types";
import CreateCell from "./CreateCell";
import EditCell from "./EditCell";
import DeleteConfirmationModal from "./DeleteConfirmationModal";
import "../../../assets/css/Infrastructure.css";
const AllCell: React.FC = () => {
  const [showModal, setShowModal] = useState(false);

  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  const [editingCell, setEditingCell] = useState<Cell | null>(null);

  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
  const [cellToDelete, setCellToDelete] = useState<Cell | null>(null);

  const { cells, loading, error } = useMachinewiseSelector(
    (state) => state.cell
  );
  const cellDispatch = useMachinewiseDispatch();

  useEffect(() => {
    // Dispatch the fetchCells action to fetch data
    cellDispatch(fetchCells());
  }, [cellDispatch]);
  // Function to open the Edit Cell modal
  const openEditModal = (cell: Cell) => {
    setEditingCell(cell);
  };

  // Function to close the Edit Cell modal
  const closeEditModal = () => {
    setEditingCell(null);
  };
  const openDeleteModal = (cell: Cell) => {
    setCellToDelete(cell);
    setDeleteModalOpen(true);
  };

  // Function to close the Delete Confirmation modal
  const closeDeleteModal = () => {
    setDeleteModalOpen(false);
    setCellToDelete(null);
  };

  const handleConfirmDelete = async () => {
    if (cellToDelete && cellToDelete._id) {
      try {
        const cellAction = await cellDispatch(deleteCell(cellToDelete._id));
        if (deleteCell.fulfilled.match(cellAction)) {
          setDeleteModalOpen(false);
          cellDispatch(fetchCells());
          toast.success("Cell deleted successfully");
        } else {
          toast.error("Failed to delete Cell");
        }
      } catch (err) {
        console.error("An error occurred while deleting the cell");
        toast.error("Error deleting the cell...Server Error!");
      }
    }
  };

  return (
    <div className="infrastructure-details">
      {" "}
      <Paper className="infrastructure-paper">
        <Box display="flex" justifyContent="flex-end" alignItems="center">
          <IconButton
            color="primary"
            aria-label="Add Cell"
            onClick={openModal}
            style={{
              padding: "10px 20px",
              borderRadius: "15px",
              transition: "background-color 0.7s ease",
            }}
          >
            <AddIcon fontSize="small" />
            <span
              style={{
                marginLeft: "8px",
                marginTop: "-2px",
                fontSize: "medium",
                fontWeight: "bold",
              }}
            >
              Add Cell
            </span>
          </IconButton>
        </Box>
        <Table className="infrastructure-table" sx={{ minWidth: "auto" }}>
          <TableHead>
            <TableRow>
              <TableCell>Sr No</TableCell>
              <TableCell>Cell Name</TableCell>
              <TableCell>Cell Value</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
              <TableRow key="loading">
                <TableCell colSpan={4} align="center">
                  <CircularProgress />
                </TableCell>
              </TableRow>
            ) : error ? (
              <TableRow key="error">
                <TableCell colSpan={4} align="center">
                  Error: {"Something went wrong while loading"}
                </TableCell>
              </TableRow>
            ) : (
              cells?.map((cell) => (
                <TableRow key={cell._id}>
                  <TableCell>{cell._id}</TableCell>
                  <TableCell>{cell.name}</TableCell>
                  <TableCell>{cell.value}</TableCell>
                  <TableCell>
                    {" "}
                    <Tooltip title="Update Cell">
                      <IconButton
                        color="primary"
                        onClick={() => openEditModal(cell)}
                      >
                        <EditIcon />
                      </IconButton>
                    </Tooltip>{" "}
                    <Tooltip title="Delete Cell">
                      <IconButton
                        color="error"
                        onClick={() => openDeleteModal(cell)} // Open the Delete Confirmation modal
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Tooltip>{" "}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
        <CreateCell showModal={showModal} closeModal={closeModal} />

        {editingCell && (
          <EditCell
            showModal={true}
            closeModal={closeEditModal}
            cellData={editingCell}
          />
        )}
        <DeleteConfirmationModal
          open={isDeleteModalOpen}
          handleClose={closeDeleteModal}
          handleConfirm={handleConfirmDelete}
        />
      </Paper>
    </div>
  );
};
export default AllCell;
