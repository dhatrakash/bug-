import React, { useState, useEffect } from "react";
import {
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import { updateLine } from "../../../redux/lineSlice";
import { Line } from "../../../redux/types";
import { toast } from "react-toastify";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";

interface EditLineProps {
  showModal: boolean;
  closeModal: () => void;
  lineData: Line;
}

const EditLine: React.FC<EditLineProps> = ({
  showModal,
  closeModal,
  lineData,
}) => {
  const { loading } = useMachinewiseSelector((state) => state.line);
  const lineDispatch = useMachinewiseDispatch();
  // Use a local state to track the edited line data
  const [editedLineData, setEditedLineData] = useState<Line>(lineData);

  // Update the local state if lineData changes
  useEffect(() => {
    setEditedLineData(lineData);
  }, [lineData]);

  // Handle input changes
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setEditedLineData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // Make sure there's an ID before dispatching the update
    if (editedLineData._id) {
      try {
        const lineAction = await lineDispatch(updateLine(editedLineData));

        if (updateLine.fulfilled.match(lineAction)) {
          toast.success("Line updated successfully"); // if dispatch actions is fulfilled
          closeModal();
        } else {
          toast.error("Failed to update line. Please try again!"); // if dispatch actions is rejected
        }
      } catch (error) {
        toast.error("An error occurred."); // if received null from backend when id is not fetched properly from params
      }
    } else {
      console.error("Line ID is missing.");
    }
  };

  return (
    <Dialog open={showModal} maxWidth="lg">
      <DialogTitle className="infra-form-title" style={{ textAlign: "center" }}>
        Update Line
      </DialogTitle>
      <DialogContent className="modal-container">
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Line Name"
            variant="outlined"
            margin="normal"
            name="name"
            value={editedLineData.name}
            onChange={handleInputChange}
          />

          <TextField
            fullWidth
            label="Line Value"
            variant="outlined"
            margin="normal"
            name="value"
            value={editedLineData.value}
            onChange={handleInputChange}
          />

          <DialogActions>
            {" "}
            <Button variant="outlined" onClick={closeModal}>
              Close
            </Button>
            <Button
              variant="contained"
              color="primary"
              type="submit"
              disabled={loading}
            >
              Update
            </Button>
          </DialogActions>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EditLine;
