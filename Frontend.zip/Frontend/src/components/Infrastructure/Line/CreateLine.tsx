import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
} from "@mui/material";
import { createLine, fetchLines } from "../../../redux/lineSlice";
import { Line } from "../../../redux/types";
import { toast } from "react-toastify";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";

interface CreateLineProps {
  showModal: boolean;
  closeModal: () => void;
}

const CreateLine: React.FC<CreateLineProps> = ({ showModal, closeModal }) => {
  const loading = useMachinewiseSelector((state) => state.line.loading);
  const lineDispatch = useMachinewiseDispatch();

  const [lineData, setLineData] = useState<Line>({
    name: "",
    value: "",
  });

  const handleChange = (field: string, value: string) => {
    setLineData({ ...lineData, [field]: value });
  };

  const handleCreateLine = async () => {
    try {
      const lineAction = await lineDispatch(createLine(lineData));

      if (createLine.fulfilled.match(lineAction)) {
        toast.success("Line created successfully");
        lineDispatch(fetchLines());
        closeModal();
      } else {
        toast.error("Failed to create line. Please try again!");
      }
    } catch (error) {
      toast.error("An error occurred");
    }
  };

  return (
    <Dialog open={showModal} maxWidth="lg">
      <DialogTitle
        className="machine-form-title"
        style={{ textAlign: "center" }}
      >
        Create Line
      </DialogTitle>
      <DialogContent className="modal-container">
        <form>
          <TextField
            fullWidth
            label="Line Name"
            variant="outlined"
            margin="normal"
            value={lineData.name}
            onChange={(e) => handleChange("name", e.target.value)}
          />
          <TextField
            fullWidth
            label="Line Value"
            variant="outlined"
            margin="normal"
            value={lineData.value}
            onChange={(e) => handleChange("value", e.target.value)}
          />

          <DialogActions>
            <Button variant="outlined" onClick={closeModal}>
              Close
            </Button>
            <Button
              variant="contained"
              color="primary"
              type="button"
              onClick={handleCreateLine}
              disabled={loading}
            >
              Submit
            </Button>
          </DialogActions>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateLine;
