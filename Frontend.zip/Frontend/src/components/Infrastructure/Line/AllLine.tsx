import React, { useState, useEffect } from "react";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  CircularProgress,
  Paper,
  Box,
  IconButton,
  Tooltip,
} from "@mui/material";
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  AddCircleOutlineSharp as AddIcon,
} from "@mui/icons-material";
import { toast } from "react-toastify";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";
import { fetchLines, deleteLine } from "../../../redux/lineSlice";
import { Line } from "../../../redux/types";
import CreateLine from "./CreateLine";
import EditLine from "./EditLine";
import DeleteConfirmationModal from "./DeleteConfirmationModal";
import "../../../assets/css/Infrastructure.css";
const AllLine: React.FC = () => {
  const [showModal, setShowModal] = useState(false);

  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  const [editingLine, setEditingLine] = useState<Line | null>(null);

  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
  const [lineToDelete, setLineToDelete] = useState<Line | null>(null);

  const { lines, loading, error } = useMachinewiseSelector(
    (state) => state.line
  );
  const lineDispatch = useMachinewiseDispatch();

  useEffect(() => {
    // Dispatch the fetchLines action to fetch data
    lineDispatch(fetchLines());
  }, [lineDispatch]);
  // Function to open the Edit Line modal
  const openEditModal = (line: Line) => {
    setEditingLine(line);
  };

  // Function to close the Edit Line modal
  const closeEditModal = () => {
    setEditingLine(null);
  };
  const openDeleteModal = (line: Line) => {
    setLineToDelete(line);
    setDeleteModalOpen(true);
  };

  // Function to close the Delete Confirmation modal
  const closeDeleteModal = () => {
    setDeleteModalOpen(false);
    setLineToDelete(null);
  };

  const handleConfirmDelete = async () => {
    if (lineToDelete && lineToDelete._id) {
      try {
        const lineAction = await lineDispatch(deleteLine(lineToDelete._id));
        if (deleteLine.fulfilled.match(lineAction)) {
          setDeleteModalOpen(false);
          lineDispatch(fetchLines());
          toast.success("Line deleted successfully");
        } else {
          toast.error("Failed to delete Line");
        }
      } catch (err) {
        console.error("An error occurred while deleting the line");
        toast.error("Error deleting the line...Server Error!");
      }
    }
  };

  return (
    <div className="infrastructure-details">
      {" "}
      <Paper className="infrastructure-paper">
        <Box display="flex" justifyContent="flex-end" alignItems="center">
          <IconButton
            color="primary"
            aria-label="Add Gateway"
            onClick={openModal}
            style={{
              padding: "10px 20px",
              borderRadius: "15px",
              transition: "background-color 0.7s ease",
            }}
          >
            <AddIcon fontSize="small" />
            <span
              style={{
                marginLeft: "8px",
                marginTop: "-2px",
                fontSize: "medium",
                fontWeight: "bold",
              }}
            >
              Add Line
            </span>
          </IconButton>
        </Box>
        <Table className="infrastructure-table" sx={{ minWidth: "auto" }}>
          <TableHead>
            <TableRow>
              <TableCell>Sr No</TableCell>
              <TableCell>Line Name</TableCell>
              <TableCell>Line Value</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
              <TableRow key="loading">
                <TableCell colSpan={4} align="center">
                  <CircularProgress />
                </TableCell>
              </TableRow>
            ) : error ? (
              <TableRow key="error">
                <TableCell colSpan={4} align="center">
                  Error: {"Something went wrong while loading"}
                </TableCell>
              </TableRow>
            ) : (
              lines?.map((line) => (
                <TableRow key={line._id}>
                  <TableCell>{line._id}</TableCell>
                  <TableCell>{line.name}</TableCell>
                  <TableCell>{line.value}</TableCell>
                  <TableCell>
                    {" "}
                    <Tooltip title="Update Line">
                      <IconButton
                        color="primary"
                        onClick={() => openEditModal(line)}
                      >
                        <EditIcon />
                      </IconButton>
                    </Tooltip>{" "}
                    <Tooltip title="Delete Line">
                      <IconButton
                        color="error"
                        onClick={() => openDeleteModal(line)} // Open the Delete Confirmation modal
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Tooltip>{" "}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
        <CreateLine showModal={showModal} closeModal={closeModal} />

        {editingLine && (
          <EditLine
            showModal={true}
            closeModal={closeEditModal}
            lineData={editingLine}
          />
        )}
        <DeleteConfirmationModal
          open={isDeleteModalOpen}
          handleClose={closeDeleteModal}
          handleConfirm={handleConfirmDelete}
        />
      </Paper>
    </div>
  );
};
export default AllLine;
