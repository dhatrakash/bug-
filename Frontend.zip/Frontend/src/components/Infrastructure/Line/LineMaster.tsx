import React from "react";
import AllLine from "./AllLine";
import "../../../assets/css/Infrastructure.css";

const LinesMaster: React.FC = () => {
  return (
    <>
      <div className="infrastructure-container">
        <h5>
          <span>Line's List</span>
        </h5>

        <AllLine />
      </div>
    </>
  );
};

export default LinesMaster;
