import React from "react";
import AllFacility from "./AllFacility";

import "../../../assets/css/Infrastructure.css";
const FacilitiesMaster: React.FC = () => {
  return (
    <>
      <div className="infrastructure-container">
        <h5>
          <span>Facilities List</span>
        </h5>

        <AllFacility />
      </div>
    </>
  );
};

export default FacilitiesMaster;
