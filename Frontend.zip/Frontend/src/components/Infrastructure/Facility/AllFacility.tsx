import React, { useState, useEffect } from "react";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  CircularProgress,
  Paper,
  Box,
  IconButton,
  Tooltip,
} from "@mui/material";
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  AddCircleOutlineSharp as AddIcon,
} from "@mui/icons-material";
import { toast } from "react-toastify";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";
import { fetchFacilities, deleteFacility } from "../../../redux/facilitySlice";
import { Facility } from "../../../redux/types";
import CreateFacility from "./CreateFacility";
import EditFacility from "./EditFacility";
import DeleteConfirmationModal from "./DeleteConfirmationModal";
import "../../../assets/css/Infrastructure.css";
const AllFacility: React.FC = () => {
  const [showModal, setShowModal] = useState(false);

  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  const [editingFacility, setEditingFacility] = useState<Facility | null>(null);

  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
  const [facilityToDelete, setFacilityToDelete] = useState<Facility | null>(
    null
  );

  const { facilities, loading, error } = useMachinewiseSelector(
    (state) => state.facility
  );
  const facilityDispatch = useMachinewiseDispatch();

  useEffect(() => {
    // Dispatch the fetchFacilities action to fetch data
    facilityDispatch(fetchFacilities());
  }, [facilityDispatch]);
  // Function to open the Edit Facility modal
  const openEditModal = (facility: Facility) => {
    setEditingFacility(facility);
  };

  // Function to close the Edit Facility modal
  const closeEditModal = () => {
    setEditingFacility(null);
  };
  const openDeleteModal = (facility: Facility) => {
    setFacilityToDelete(facility);
    setDeleteModalOpen(true);
  };

  // Function to close the Delete Confirmation modal
  const closeDeleteModal = () => {
    setDeleteModalOpen(false);
    setFacilityToDelete(null);
  };

  const handleConfirmDelete = async () => {
    if (facilityToDelete && facilityToDelete._id) {
      try {
        const facilityAction = await facilityDispatch(
          deleteFacility(facilityToDelete._id)
        );
        if (deleteFacility.fulfilled.match(facilityAction)) {
          setDeleteModalOpen(false);
          facilityDispatch(fetchFacilities());
          toast.success("Facility deleted successfully");
        } else {
          toast.error("Failed to delete Facility");
        }
      } catch (err) {
        console.error("An error occurred while deleting the facility");
        toast.error("Error deleting the facility...Server Error!");
      }
    }
  };

  return (
    <div className="infrastructure-details">
      {" "}
      <Paper className="infrastructure-paper">
        <Box display="flex" justifyContent="flex-end" alignItems="center">
          <IconButton
            color="primary"
            aria-label="Add Gateway"
            onClick={openModal}
            style={{
              padding: "10px 20px",
              borderRadius: "15px",
              transition: "background-color 0.7s ease",
            }}
          >
            <AddIcon fontSize="small" />
            <span
              style={{
                marginLeft: "8px",
                marginTop: "-2px",
                fontSize: "medium",
                fontWeight: "bold",
              }}
            >
              Add Facility
            </span>
          </IconButton>
        </Box>
        <Table className="infrastructure-table" sx={{ minWidth: "auto" }}>
          <TableHead>
            <TableRow>
              <TableCell>Sr No</TableCell>
              <TableCell>Facility Name</TableCell>
              <TableCell>Facility Value</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
              <TableRow key="loading">
                <TableCell colSpan={4} align="center">
                  <CircularProgress />
                </TableCell>
              </TableRow>
            ) : error ? (
              <TableRow key="error">
                <TableCell colSpan={4} align="center">
                  Error: {"Something went wrong while loading"}
                </TableCell>
              </TableRow>
            ) : (
              facilities?.map((facility) => (
                <TableRow key={facility._id}>
                  <TableCell>{facility._id}</TableCell>
                  <TableCell>{facility.name}</TableCell>
                  <TableCell>{facility.value}</TableCell>
                  <TableCell>
                    {" "}
                    <Tooltip title="Update Facility">
                      <IconButton
                        color="primary"
                        onClick={() => openEditModal(facility)}
                      >
                        <EditIcon />
                      </IconButton>
                    </Tooltip>{" "}
                    <Tooltip title="Delete Facility">
                      <IconButton
                        color="error"
                        onClick={() => openDeleteModal(facility)} // Open the Delete Confirmation modal
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Tooltip>{" "}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
        <CreateFacility showModal={showModal} closeModal={closeModal} />
        {/* <CreateInfrastructure
          showModal={showModal}
          closeModal={closeModal}
          entityType="facility"
        /> */}
        {editingFacility && (
          <EditFacility
            showModal={true}
            closeModal={closeEditModal}
            facilityData={editingFacility}
          />
          // <EditInfrastructure
          //   showModal={true}
          //   closeModal={closeEditModal}
          //   entityData={editingFacility}
          //   entityType="facility"
          // />
        )}
        <DeleteConfirmationModal
          open={isDeleteModalOpen}
          handleClose={closeDeleteModal}
          handleConfirm={handleConfirmDelete}
        />
      </Paper>
    </div>
  );
};
export default AllFacility;
