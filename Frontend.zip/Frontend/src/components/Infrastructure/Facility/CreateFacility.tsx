import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
} from "@mui/material";
import { createFacility, fetchFacilities } from "../../../redux/facilitySlice";
import { Facility } from "../../../redux/types";
import { toast } from "react-toastify";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";

interface CreateFacilityProps {
  showModal: boolean;
  closeModal: () => void;
}

const CreateFacility: React.FC<CreateFacilityProps> = ({
  showModal,
  closeModal,
}) => {
  const loading = useMachinewiseSelector((state) => state.facility.loading);
  const facilityDispatch = useMachinewiseDispatch();

  const [facilityData, setFacilityData] = useState<Facility>({
    name: "",
    value: "",
  });

  const handleChange = (field: string, value: string) => {
    setFacilityData({ ...facilityData, [field]: value });
  };

  const handleCreateFacility = async () => {
    try {
      const facilityAction = await facilityDispatch(
        createFacility(facilityData)
      );

      if (createFacility.fulfilled.match(facilityAction)) {
        toast.success("Facility created successfully");
        facilityDispatch(fetchFacilities());
        closeModal();
      } else {
        toast.error("Failed to create facility. Please try again!");
      }
    } catch (error) {
      toast.error("An error occurred");
    }
  };

  return (
    <Dialog open={showModal} maxWidth="lg">
      <DialogTitle
        className="machine-form-title"
        style={{ textAlign: "center" }}
      >
        Create Facility
      </DialogTitle>
      <DialogContent className="modal-container">
        <form>
          <TextField
            fullWidth
            label="Facility Name"
            variant="outlined"
            margin="normal"
            value={facilityData.name}
            onChange={(e) => handleChange("name", e.target.value)}
          />
          <TextField
            fullWidth
            label="Facility Value"
            variant="outlined"
            margin="normal"
            value={facilityData.value}
            onChange={(e) => handleChange("value", e.target.value)}
          />

          <DialogActions>
            <Button variant="outlined" onClick={closeModal}>
              Close
            </Button>
            <Button
              variant="contained"
              color="primary"
              type="button"
              onClick={handleCreateFacility}
              disabled={loading}
            >
              Submit
            </Button>
          </DialogActions>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateFacility;
