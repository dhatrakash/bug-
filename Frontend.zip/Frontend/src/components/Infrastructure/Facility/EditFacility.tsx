import React, { useState, useEffect } from "react";
import {
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import { updateFacility } from "../../../redux/facilitySlice";
import { Facility } from "../../../redux/types";
import { toast } from "react-toastify";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";

interface EditFacilityProps {
  showModal: boolean;
  closeModal: () => void;
  facilityData: Facility;
}

const EditFacility: React.FC<EditFacilityProps> = ({
  showModal,
  closeModal,
  facilityData,
}) => {
  const { loading } = useMachinewiseSelector((state) => state.facility);
  const facilityDispatch = useMachinewiseDispatch();
  // Use a local state to track the edited facility data
  const [editedFacilityData, setEditedFacilityData] =
    useState<Facility>(facilityData);

  // Update the local state if facilityData changes
  useEffect(() => {
    setEditedFacilityData(facilityData);
  }, [facilityData]);

  // Handle input changes
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setEditedFacilityData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // Make sure there's an ID before dispatching the update
    if (editedFacilityData._id) {
      try {
        const facilityAction = await facilityDispatch(
          updateFacility(editedFacilityData)
        );

        if (updateFacility.fulfilled.match(facilityAction)) {
          toast.success("Facility updated successfully");
          closeModal();
        } else {
          toast.error("Failed to update facility. Please try again!");
        }
      } catch (error) {
        toast.error("An error occurred");
      }
    } else {
      console.error("Facility ID is missing.");
    }
  };

  return (
    <Dialog open={showModal} maxWidth="lg">
      <DialogTitle className="infra-form-title" style={{ textAlign: "center" }}>
        Update Facility
      </DialogTitle>
      <DialogContent className="modal-container">
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Facility Name"
            variant="outlined"
            margin="normal"
            name="name"
            value={editedFacilityData.name}
            onChange={handleInputChange}
          />

          <TextField
            fullWidth
            label="Facility Value"
            variant="outlined"
            margin="normal"
            name="value"
            value={editedFacilityData.value}
            onChange={handleInputChange}
          />

          <DialogActions>
            {" "}
            <Button variant="outlined" onClick={closeModal}>
              Close
            </Button>
            <Button
              variant="contained"
              color="primary"
              type="submit"
              disabled={loading}
            >
              Update
            </Button>
          </DialogActions>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EditFacility;
