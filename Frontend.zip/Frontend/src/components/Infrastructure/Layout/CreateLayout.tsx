import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
} from "@mui/material";
import { createLayout, fetchLayouts } from "../../../redux/layoutSlice";
import { Layout } from "../../../redux/types";
import { toast } from "react-toastify";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";

interface CreateLayoutProps {
  showModal: boolean;
  closeModal: () => void;
}

const CreateLayout: React.FC<CreateLayoutProps> = ({
  showModal,
  closeModal,
}) => {
  const loading = useMachinewiseSelector((state) => state.layout.loading);
  const layoutDispatch = useMachinewiseDispatch();

  const [layoutData, setLayoutData] = useState<Layout>({
    name: "",
    value: "",
  });

  const handleChange = (field: string, value: string) => {
    setLayoutData({ ...layoutData, [field]: value });
  };

  const handleCreateLayout = async () => {
    try {
      const layoutAction = await layoutDispatch(createLayout(layoutData));

      if (createLayout.fulfilled.match(layoutAction)) {
        toast.success("Layout created successfully");
        layoutDispatch(fetchLayouts());
        closeModal();
      } else {
        toast.error("Failed to create layout. Please try again!");
      }
    } catch (error) {
      toast.error("An error occurred");
    }
  };

  return (
    <Dialog open={showModal} maxWidth="lg">
      <DialogTitle
        className="machine-form-title"
        style={{ textAlign: "center" }}
      >
        Create Layout
      </DialogTitle>
      <DialogContent className="modal-container">
        <form>
          <TextField
            fullWidth
            label="Layout Name"
            variant="outlined"
            margin="normal"
            value={layoutData.name}
            onChange={(e) => handleChange("name", e.target.value)}
          />
          <TextField
            fullWidth
            label="Layout Value"
            variant="outlined"
            margin="normal"
            value={layoutData.value}
            onChange={(e) => handleChange("value", e.target.value)}
          />

          <DialogActions>
            <Button variant="outlined" onClick={closeModal}>
              Close
            </Button>
            <Button
              variant="contained"
              color="primary"
              type="button"
              onClick={handleCreateLayout}
              disabled={loading}
            >
              Submit
            </Button>
          </DialogActions>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateLayout;
