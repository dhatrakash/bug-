import React, { useState, useEffect } from "react";
import {
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import { updateLayout } from "../../../redux/layoutSlice";
import { Layout } from "../../../redux/types";
import { toast } from "react-toastify";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";

interface EditLayoutProps {
  showModal: boolean;
  closeModal: () => void;
  layoutData: Layout;
}

const EditLayout: React.FC<EditLayoutProps> = ({
  showModal,
  closeModal,
  layoutData,
}) => {
  const { loading } = useMachinewiseSelector((state) => state.layout);
  const layoutDispatch = useMachinewiseDispatch();
  // Use a local state to track the edited layout data
  const [editedLayoutData, setEditedLayoutData] = useState<Layout>(layoutData);

  // Update the local state if layoutData changes
  useEffect(() => {
    setEditedLayoutData(layoutData);
  }, [layoutData]);

  // Handle input changes
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setEditedLayoutData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // Make sure there's an ID before dispatching the update
    if (editedLayoutData._id) {
      try {
        const layoutAction = await layoutDispatch(
          updateLayout(editedLayoutData)
        );

        if (updateLayout.fulfilled.match(layoutAction)) {
          toast.success("Layout updated successfully"); // if dispatch actions is fulfilled
          closeModal();
        } else {
          toast.error("Failed to update layout. Please try again!"); // if dispatch actions is rejected
        }
      } catch (error) {
        toast.error("An error occurred."); // if received null from backend when id is not fetched properly from params
      }
    } else {
      console.error("Layout ID is missing.");
    }
  };

  return (
    <Dialog open={showModal} maxWidth="lg">
      <DialogTitle className="infra-form-title" style={{ textAlign: "center" }}>
        Update Layout
      </DialogTitle>
      <DialogContent className="modal-container">
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Layout Name"
            variant="outlined"
            margin="normal"
            name="name"
            value={editedLayoutData.name}
            onChange={handleInputChange}
          />

          <TextField
            fullWidth
            label="Layout Value"
            variant="outlined"
            margin="normal"
            name="value"
            value={editedLayoutData.value}
            onChange={handleInputChange}
          />

          <DialogActions>
            {" "}
            <Button variant="outlined" onClick={closeModal}>
              Close
            </Button>
            <Button
              variant="contained"
              color="primary"
              type="submit"
              disabled={loading}
            >
              Update
            </Button>
          </DialogActions>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EditLayout;
