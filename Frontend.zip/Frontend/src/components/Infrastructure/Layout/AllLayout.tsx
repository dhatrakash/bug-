import React, { useState, useEffect } from "react";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  CircularProgress,
  Paper,
  Box,
  IconButton,
  Tooltip,
} from "@mui/material";
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  AddCircleOutlineSharp as AddIcon,
} from "@mui/icons-material";
import { toast } from "react-toastify";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../../redux/hooks";
import { fetchLayouts, deleteLayout } from "../../../redux/layoutSlice";
import { Layout } from "../../../redux/types";
import CreateLayout from "./CreateLayout";
import EditLayout from "./EditLayout";
import DeleteConfirmationModal from "./DeleteConfirmationModal";
import "../../../assets/css/Infrastructure.css";
const AllLayout: React.FC = () => {
  const [showModal, setShowModal] = useState(false);

  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  const [editingLayout, setEditingLayout] = useState<Layout | null>(null);

  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
  const [layoutToDelete, setLayoutToDelete] = useState<Layout | null>(null);

  const { layouts, loading, error } = useMachinewiseSelector(
    (state) => state.layout
  );
  const layoutDispatch = useMachinewiseDispatch();

  useEffect(() => {
    // Dispatch the fetchLayouts action to fetch data
    layoutDispatch(fetchLayouts());
  }, [layoutDispatch]);
  // Function to open the Edit Layout modal
  const openEditModal = (layout: Layout) => {
    setEditingLayout(layout);
  };

  // Function to close the Edit Layout modal
  const closeEditModal = () => {
    setEditingLayout(null);
  };
  const openDeleteModal = (layout: Layout) => {
    setLayoutToDelete(layout);
    setDeleteModalOpen(true);
  };

  // Function to close the Delete Confirmation modal
  const closeDeleteModal = () => {
    setDeleteModalOpen(false);
    setLayoutToDelete(null);
  };

  const handleConfirmDelete = async () => {
    if (layoutToDelete && layoutToDelete._id) {
      try {
        const layoutAction = await layoutDispatch(
          deleteLayout(layoutToDelete._id)
        );
        if (deleteLayout.fulfilled.match(layoutAction)) {
          setDeleteModalOpen(false);
          layoutDispatch(fetchLayouts());
          toast.success("Layout deleted successfully");
        } else {
          toast.error("Failed to delete Layout");
        }
      } catch (err) {
        console.error("An error occurred while deleting the layout");
        toast.error("Error deleting the layout...Server Error!");
      }
    }
  };

  return (
    <div className="infrastructure-details">
      {" "}
      <Paper className="infrastructure-paper">
        <Box display="flex" justifyContent="flex-end" alignItems="center">
          <IconButton
            color="primary"
            aria-label="Add Gateway"
            onClick={openModal}
            style={{
              padding: "10px 20px",
              borderRadius: "15px",
              transition: "background-color 0.7s ease",
            }}
          >
            <AddIcon fontSize="small" />
            <span
              style={{
                marginLeft: "8px",
                marginTop: "-2px",
                fontSize: "medium",
                fontWeight: "bold",
              }}
            >
              Add Layout
            </span>
          </IconButton>
        </Box>
        <Table className="infrastructure-table" sx={{ minWidth: "auto" }}>
          <TableHead>
            <TableRow>
              <TableCell>Sr No</TableCell>
              <TableCell>Layout Name</TableCell>
              <TableCell>Layout Value</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
              <TableRow key="loading">
                <TableCell colSpan={4} align="center">
                  <CircularProgress />
                </TableCell>
              </TableRow>
            ) : error ? (
              <TableRow key="error">
                <TableCell colSpan={4} align="center">
                  Error: {"Something went wrong while loading"}
                </TableCell>
              </TableRow>
            ) : (
              layouts?.map((layout) => (
                <TableRow key={layout._id}>
                  <TableCell>{layout._id}</TableCell>
                  <TableCell>{layout.name}</TableCell>
                  <TableCell>{layout.value}</TableCell>
                  <TableCell>
                    {" "}
                    <Tooltip title="Update Layout">
                      <IconButton
                        color="primary"
                        onClick={() => openEditModal(layout)}
                      >
                        <EditIcon />
                      </IconButton>
                    </Tooltip>{" "}
                    <Tooltip title="Delete Layout">
                      <IconButton
                        color="error"
                        onClick={() => openDeleteModal(layout)} // Open the Delete Confirmation modal
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Tooltip>{" "}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
        <CreateLayout showModal={showModal} closeModal={closeModal} />

        {editingLayout && (
          <EditLayout
            showModal={true}
            closeModal={closeEditModal}
            layoutData={editingLayout}
          />
        )}
        <DeleteConfirmationModal
          open={isDeleteModalOpen}
          handleClose={closeDeleteModal}
          handleConfirm={handleConfirmDelete}
        />
      </Paper>
    </div>
  );
};
export default AllLayout;
