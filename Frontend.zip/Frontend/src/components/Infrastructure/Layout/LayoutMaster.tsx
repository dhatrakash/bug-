import React from "react";
import AllLayout from "./AllLayout";

import "../../../assets/css/Infrastructure.css";
const LayoutsMaster: React.FC = () => {
  return (
    <>
      <div className="infrastructure-container">
        <h5>
          <span>Layout's List</span>
        </h5>

        <AllLayout />
      </div>
    </>
  );
};

export default LayoutsMaster;
