import React, { useEffect, useState } from "react";
import { Modal, Button, Form, Row, Col } from "react-bootstrap";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";
import { editMachine, fetchMachines } from "../../redux/machineSlice";
import "../../assets/css/Create_updateMachine.css";
import { Machine } from "../../redux/types";
import { fetchFacilities } from "../../redux/facilitySlice";
import { fetchCells } from "../../redux/cellSlice";
import { fetchLayouts } from "../../redux/layoutSlice";
import { fetchLines } from "../../redux/lineSlice";
import { toast } from "react-toastify";
import CustomFormGroup from "./CustomFormGroup";
import CustomLocationSelectInput from "./CustomSelectInput";

interface EditMachineProps {
  showModal: boolean;
  closeModal: () => void;
  machineId: string;
  machineData: Machine | null;
  onUpdate: () => void;
}
interface MachinePhotoObject {
  base64: {
    data: string;
  };
}
const EditMachine: React.FC<EditMachineProps> = ({
  showModal,
  closeModal,
  machineId,
  machineData,
  onUpdate,
}) => {
  const dispatch = useMachinewiseDispatch();
  const [machines, setMachines] = useState<Machine | null>(machineData || null);
  const [selectedFacility, setSelectedFacility] = useState<string>("");
  const [selectedCell, setSelectedCell] = useState<string>("");
  const [selectedLayout, setSelectedLayout] = useState<string>("");
  const [selectedLine, setSelectedLine] = useState<string>("");

  const facilities = useMachinewiseSelector(
    (state) => state.facility.facilities
  );
  const cells = useMachinewiseSelector((state) => state.cell.cells);
  const layouts = useMachinewiseSelector((state) => state.layout.layouts);
  const lines = useMachinewiseSelector((state) => state.line.lines);
  const [machinePhotoURL, setMachinePhotoURL] = useState<string | undefined>(
    machineData?.machinePhoto?.toString()
  );
  const [controllerPhotoURL, setControllerPhotoURL] = useState<
    string | undefined
  >(machineData?.controllerPhoto?.toString());

  // console.log("machineData:", machineData);
  // console.log("machines:", machines);
  //to fetch and handle photo/images
  const controllerTypeOptions = ["fanuc", "siemens"];

  const handlePhoto = (
    file: File | null | undefined,
    setURL: (url: string | undefined) => void
  ) => {
    if (file && file instanceof Blob) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (reader.result instanceof ArrayBuffer) {
          setURL(URL.createObjectURL(new Blob([reader.result])));
        }
      };
      reader.readAsArrayBuffer(file);
    } else {
      setURL(undefined);
    }
  };

  useEffect(() => {
    const handlePhotoData = (
      photoData: string | File | MachinePhotoObject | null | undefined,
      setPhotoURL: (url: string | undefined) => void
    ) => {
      if (photoData) {
        if (typeof photoData === "string") {
          setPhotoURL(photoData);
        } else if (photoData instanceof File) {
          handlePhoto(photoData, setPhotoURL);
        } else if (typeof photoData === "object" && "base64" in photoData) {
          const base64String = (photoData as any).base64;

          if (typeof base64String === "string") {
            setPhotoURL(`data:image/png;base64,${base64String}`);
          } else {
            setPhotoURL(undefined);
          }
        } else {
          setPhotoURL(undefined);
        }
      } else {
        setPhotoURL(undefined);
      }
    };
    if (machineData) {
      if (machineData.machinePhoto) {
        handlePhoto(machineData.machinePhoto, setMachinePhotoURL);
      } else {
        setMachinePhotoURL(undefined);
      }

      if (machineData.controllerPhoto) {
        handlePhoto(machineData.controllerPhoto, setControllerPhotoURL);
      } else {
        setControllerPhotoURL(undefined);
      }
    } else {
      setMachinePhotoURL(undefined);
      setControllerPhotoURL(undefined);
    }

    if (showModal && machineData) {
      handlePhotoData(machineData.machinePhoto, setMachinePhotoURL);
      handlePhotoData(machineData.controllerPhoto, setControllerPhotoURL);
    }
  }, [showModal, machineData]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const facilitiesPromise = dispatch(fetchFacilities());
        const cellsPromise = dispatch(fetchCells());
        const layoutsPromise = dispatch(fetchLayouts());
        const linesPromise = dispatch(fetchLines());

        // Wait for all promises to resolve
        await Promise.all([
          facilitiesPromise,
          cellsPromise,
          layoutsPromise,
          linesPromise,
        ]);

        console.log("Updating selected location values...");
        if (machineData?.machineLocation) {
          const { facility, cell, layout, line } = machineData.machineLocation;

          setSelectedFacility((facility as string) || "");
          setSelectedCell((cell as string) || "");
          setSelectedLayout((layout as string) || "");
          setSelectedLine((line as string) || "");
        }
      } catch (error) {
        console.error(
          "An error occurred while fetching or updating location data:",
          error
        );
      }
    };

    if (machineData) {
      setMachines(machineData);

      // Fetch data and update selected values
      fetchData();
    } else {
      setMachines(null);
    }
  }, [machineData, dispatch]);

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = e.target;

    if (name === "machine_type") {
      setMachines((prevMachines) => ({
        ...(prevMachines as Machine),
        machine_type: value,
        controllerType:
          value === "hardwire" ? "N/A" : prevMachines?.controllerType,
      }));
    } else if (name === "machineLocation") {
      const locationParts = value.split(", ");
      setSelectedFacility(locationParts[0] || "");
      setSelectedCell(locationParts[1] || "");
      setSelectedLayout(locationParts[2] || "");
      setSelectedLine(locationParts[3] || "");
    } else {
      setMachines((prevMachines) => ({
        ...(prevMachines as Machine),
        [name]: value,
      }));
    }
  };

  // Function to handle machine photo change
  const handleMachinePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setMachines((prevMachine) => {
      if (!prevMachine) {
        return null;
      }

      const newMachine: Machine = {
        ...prevMachine,
        machinePhoto: file || prevMachine.machinePhoto,
      };

      handlePhoto(file, setMachinePhotoURL);

      return newMachine;
    });
  };

  // Function to handle controller photo change
  const handleControllerPhotoChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    setMachines((prevMachine) => {
      if (!prevMachine) {
        return null;
      }

      const newMachine: Machine = {
        ...prevMachine,
        controllerPhoto: file || prevMachine.controllerPhoto,
      };

      handlePhoto(file, setControllerPhotoURL);

      return newMachine;
    });
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (machines) {
      try {
        const formData = new FormData();

        // Use the updated state values directly
        formData.append(
          "machineLocation.facility",
          selectedFacility.toString()
        );
        formData.append("machineLocation.cell", selectedCell.toString());
        formData.append("machineLocation.layout", selectedLayout.toString());
        formData.append("machineLocation.line", selectedLine.toString());
        // Check if a new machinePhoto has been selected
        if (machines.machinePhoto instanceof File) {
          formData.append("machinePhoto", machines.machinePhoto);
        } else if (
          machines.machinePhoto &&
          Array.isArray(machines.machinePhoto)
        ) {
          // If machinePhoto is an array, assume it's the existing photo data
          formData.append("machinePhoto", machines.machinePhoto[0]);
        } else {
          // If no new machinePhoto is selected, use the existing data
          formData.append("machinePhoto", machines.machinePhoto || "");
        }

        // Check if a new controllerPhoto has been selected
        if (machines.controllerPhoto instanceof File) {
          formData.append("controllerPhoto", machines.controllerPhoto);
        } else if (
          machines.controllerPhoto &&
          Array.isArray(machines.controllerPhoto)
        ) {
          // If controllerPhoto is an array, assume it's the existing photo data
          formData.append("controllerPhoto", machines.controllerPhoto[0]);
        } else {
          // If no new controllerPhoto is selected, use the existing data
          formData.append("controllerPhoto", machines.controllerPhoto || "");
        }

        for (const key in machines) {
          if (machines.hasOwnProperty(key)) {
            const value = machines[key as keyof Machine];

            // Skip appending "statusMapping" to formData
            if (key === "statusMapping") {
              continue;
            }

            if (value !== null && value !== undefined) {
              if (key === "machineLocation" && typeof value === "object") {
                // Skip appending location details again
                continue;
              } else if (value instanceof File) {
                // formData.append(key, value);
                continue;
              } else {
                formData.append(key, value.toString());
              }
            }
          }
        }

        const updateAction = await dispatch(
          editMachine({ machineId, formData })
        );
        if (editMachine.fulfilled.match(updateAction)) {
          closeModal();
          onUpdate();
          dispatch(fetchMachines());
          toast.success("Machine details updated successfully!");
        } else {
          toast.error("Failed to update machine");
        }
      } catch (error) {
        console.error("An error occurred:", error);
        toast.error("An error occurred while updating machine details.", {
          autoClose: 5000,
        });
      }
    }
  };

  return (
    <Modal
      show={showModal}
      onHide={closeModal}
      size="lg"
      backdrop="static"
      keyboard={false}
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title
          style={{ textAlign: "center", width: "100%", color: "#3081cd" }}
          className="machine-form-title"
        >
          Update Machine
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="modal-container">
        <Form
          className="machine-form"
          onSubmit={handleSubmit}
          style={{ justifyContent: "center" }}
        >
          <Row>
            <Col sm={12} md={6} lg={6}>
              <Row>
                {" "}
                <Form.Group className="mb-3" controlId="machine_type">
                  <Form.Label>Machine Type</Form.Label>
                  <div className="radio-group">
                    <Form.Check
                      type="radio"
                      label="Hardwire"
                      name="machine_type"
                      value="hardwire"
                      checked={machines?.machine_type === "hardwire"}
                      onChange={handleInputChange}
                      className="radio-option"
                    />
                    <Form.Check
                      type="radio"
                      label="Controller"
                      name="machine_type"
                      value="controller"
                      checked={machines?.machine_type === "controller"}
                      onChange={handleInputChange}
                      className="radio-option"
                    />
                  </div>
                </Form.Group>
              </Row>
              <Row>
                {" "}
                {machines?.machine_type === "controller" && (
                  <Form.Group className="mb-3" controlId="controllerType">
                    <Form.Label>Controller type</Form.Label>

                    <Form.Control
                      as="select"
                      name="controllerType"
                      value={machines?.controllerType || ""}
                      onChange={handleInputChange}
                      required
                    >
                      <option value="">Select Controller Type</option>
                      {controllerTypeOptions?.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </Form.Control>
                  </Form.Group>
                )}
              </Row>
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="machineName"
                type="text"
                placeholder="Enter machine name"
                name="machineName"
                value={machines?.machineName || ""}
                onChange={handleInputChange}
                label="Machine Name"
                required
              />
            </Col>
          </Row>
          {/* Machine Location Area */}
          <Row>
            <Col md={12}>
              <CustomFormGroup
                controlId="machineLocation"
                label="Machine Location"
                type="text"
                placeholder="Select From Facility, Cell, Layout, Line"
                name="machineLocation"
                value={`${
                  facilities?.find((f) => f._id === selectedFacility)?.name ||
                  ""
                }, ${cells?.find((c) => c._id === selectedCell)?.name || ""}, ${
                  layouts?.find((l) => l._id === selectedLayout)?.name || ""
                }, ${lines?.find((l) => l._id === selectedLine)?.name || ""}`}
                onChange={handleInputChange}
              />
            </Col>
            <CustomLocationSelectInput
              controlId="facilitySelect"
              label="Facility"
              value={selectedFacility}
              onChange={setSelectedFacility}
              options={facilities}
            />{" "}
            <CustomLocationSelectInput
              controlId="cellSelect"
              label="Cell"
              value={selectedCell}
              onChange={setSelectedCell}
              options={cells}
            />
            <CustomLocationSelectInput
              controlId="layoutSelect"
              label="Layout"
              value={selectedLayout}
              onChange={setSelectedLayout}
              options={layouts}
            />
            <CustomLocationSelectInput
              controlId="lineSelect"
              label="Line"
              value={selectedLine}
              onChange={setSelectedLine}
              options={lines}
            />
          </Row>
          {/* Machine Location Area */}
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="machineMake"
                type="text"
                placeholder="Enter machine make"
                name="machineMake"
                value={machines?.machineMake}
                onChange={handleInputChange}
                label="Machine Make"
              />
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="machineMakeYear"
                label="Machine Make Year"
                type="number"
                placeholder="Enter machine make year"
                name="machineMakeYear"
                value={machines?.machineMakeYear}
                onChange={handleInputChange}
              />
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="maintenancePerson"
                type="text"
                placeholder="Enter Maintenance Person Name"
                name="maintenancePerson"
                value={machines?.maintenancePerson}
                onChange={handleInputChange}
                label="Maintenance Person"
              />
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="maintainanceContact"
                type="text"
                placeholder="Enter Maintenance Contact Number"
                pattern="[0-9]{10}"
                name="maintenanceContact"
                value={machines?.maintenanceContact}
                onChange={handleInputChange}
                label="Maintenance Contact"
              />
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="mfgEmail"
                type="email"
                placeholder="Enter manufacturer email"
                name="mfgEmail"
                value={machines?.mfgEmail}
                onChange={handleInputChange}
                label="Mfg Email"
                pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}"
              />
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="machineWarranty"
                type="text"
                placeholder="Enter Warranty"
                name="machineWarranty"
                value={machines?.machineWarranty}
                onChange={handleInputChange}
                label="Machine Warranty"
              />
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={12} lg={12}>
              <Form.Group
                className="mb-3"
                controlId="inputMethod"
                style={{ textAlign: "center" }}
              >
                <Form.Label
                  style={{
                    justifyContent: "center",
                    textAlign: "center",
                  }}
                >
                  Input method
                </Form.Label>
                <div className="radio-group">
                  <Form.Check
                    type="radio"
                    label="STABILIZER"
                    name="inputMethod"
                    value="STABILIZER"
                    checked={machines?.inputMethod === "STABILIZER"}
                    onChange={handleInputChange}
                    className="radio-option"
                  />
                  <Form.Check
                    type="radio"
                    label="UPS"
                    name="inputMethod"
                    value="UPS"
                    checked={machines?.inputMethod === "UPS"}
                    onChange={handleInputChange}
                    className="radio-option"
                  />
                  <Form.Check
                    type="radio"
                    label="Other"
                    name="inputMethod"
                    value="Other"
                    checked={machines?.inputMethod === "Other"}
                    onChange={handleInputChange}
                    className="radio-option"
                  />
                </div>
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="powerSupplyRating"
                type="text"
                placeholder="Enter power supply rating"
                name="powerSupplyRating"
                value={machines?.powerSupplyRating}
                onChange={handleInputChange}
                label="Power supply rating"
              />
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="controllerMake"
                type="text"
                placeholder="Enter controller make"
                name="controllerMake"
                value={machines?.controllerMake}
                onChange={handleInputChange}
                label="Controller Make"
              />
            </Col>
          </Row>{" "}
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="controllerMakeYear"
                label="Controller Make Year"
                type="number"
                placeholder="Enter controller make year"
                name="controllerMakeYear"
                value={machines?.controllerMakeYear}
                onChange={handleInputChange}
              />
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="controllerModel"
                type="text"
                placeholder="Enter controller Model"
                name="controllerModel"
                value={machines?.controllerModel}
                onChange={handleInputChange}
                label="Controller Model"
              />
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="subscribeTopic"
                type="text"
                placeholder="Enter Subscribe Topic"
                name="subscribeTopic"
                value={machines?.subscribeTopic}
                onChange={handleInputChange}
                label="Subscribe Topic"
              />
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="publishTopic"
                type="text"
                placeholder="Enter Publish Topic"
                name="publishTopic"
                value={machines?.publishTopic}
                onChange={handleInputChange}
                label="Publish Topic"
              />
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={6} lg={6}>
              {" "}
              <Form.Group className="mb-3" controlId="machinePhoto">
                <Form.Label>Machine photo</Form.Label>
                <Form.Control
                  type="file"
                  name="machinePhoto"
                  accept="image/*"
                  onChange={handleMachinePhotoChange}
                />
              </Form.Group>{" "}
              <div className="machine-card-image">
                {machinePhotoURL ? (
                  <>
                    <img
                      src={machinePhotoURL}
                      alt={machineData?.machineName}
                      style={{
                        width: "100px",
                        height: "100px",
                        borderRadius: "20px",
                      }}
                    />
                  </>
                ) : (
                  <div>No Machine Photo Available</div>
                )}
              </div>
              {/* {machines?.machinePhoto &&
                machines.machinePhoto instanceof File && (
                  <img
                    src={URL.createObjectURL(machines.machinePhoto)}
                    alt="Machine Photo"
                    style={{ maxWidth: "100px", maxHeight: "100px" }}
                  />
                )} */}
            </Col>
            <Col sm={12} md={6} lg={6}>
              <Form.Group className="mb-3" controlId="controllerPhoto">
                <Form.Label>Machine Controller photo</Form.Label>
                <Form.Control
                  type="file"
                  name="controllerPhoto"
                  accept="image/*"
                  onChange={handleControllerPhotoChange}
                />
              </Form.Group>{" "}
              <div className="machine-card-image">
                {controllerPhotoURL ? (
                  <img
                    src={controllerPhotoURL}
                    alt={machineData?.machineName}
                    style={{
                      width: "100px",
                      height: "100px",
                      borderRadius: "20px",
                    }}
                  />
                ) : (
                  <div>No Controller Photo Available</div>
                )}
              </div>
              {/* {machines?.controllerPhoto &&
                machines.controllerPhoto instanceof File && (
                  <img
                    src={URL.createObjectURL(machines?.controllerPhoto)}
                    alt="Machine Controller Photo"
                    style={{ maxWidth: "100px", maxHeight: "100px" }}
                  />
                )} */}
            </Col>
          </Row>{" "}
          <Row>
            <Col sm={12} md={6} lg={6}>
              <Form.Group className="mb-3" controlId="downtimeReason">
                <CustomFormGroup
                  controlId="downtimeReason"
                  type="text"
                  placeholder="Enter Downtime reason"
                  name="downtimeReason"
                  value={machines?.downtimeReason}
                  onChange={handleInputChange}
                  label="Downtime reason"
                />
              </Form.Group>
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="lockRegister"
                type="text"
                placeholder="Enter Lock register"
                name="lockRegister"
                value={machines?.lockRegister}
                onChange={handleInputChange}
                label="Lock register"
              />
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="partCode"
                type="text"
                placeholder="Enter Part Code Number"
                name="partCode"
                value={machines?.partCode}
                onChange={handleInputChange}
                label="Part Code Number"
              />
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="operatorId"
                type="text"
                placeholder="Enter Operator Id"
                name="operatorId"
                value={machines?.operatorId}
                onChange={handleInputChange}
                label="Operator Id"
              />
            </Col>
          </Row>{" "}
          <Row>
            <Col sm={12} md={6} lg={4}>
              <CustomFormGroup
                controlId="lockCommand"
                type="text"
                placeholder="Enter lock Command"
                name="lockCommand"
                value={machines?.lockCommand}
                onChange={handleInputChange}
                label="lock Command"
              />
            </Col>
            <Col sm={12} md={6} lg={4}>
              <CustomFormGroup
                controlId="unlockCommand"
                type="text"
                placeholder="Enter Unlock Command"
                name="unlockCommand"
                value={machines?.unlockCommand}
                onChange={handleInputChange}
                label="Unlock Command"
              />
            </Col>
            <Col sm={12} md={6} lg={4}>
              <CustomFormGroup
                controlId="flushCommand"
                type="text"
                placeholder="Enter Flush Command"
                name="flushCommand"
                value={machines?.flushCommand}
                onChange={handleInputChange}
                label="Flush Command"
              />
            </Col>
          </Row>
          <Button variant="primary" type="submit">
            Update Machine Details
          </Button>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default EditMachine;
