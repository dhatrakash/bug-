import React from "react";
import { Modal, Button } from "react-bootstrap";

interface DeleteMachineProps {
  show: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

const DeleteMachine: React.FC<DeleteMachineProps> = ({
  show,
  onClose,
  onConfirm,
}) => {
  return (
    <Modal show={show} centered>
      <Modal.Header closeButton>
        <Modal.Title>Confirm Deletion</Modal.Title>
      </Modal.Header>
      <Modal.Body>Are you sure you want to delete this Machine?</Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          Cancel
        </Button>
        <Button variant="danger" onClick={onConfirm}>
          Delete
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default DeleteMachine;
