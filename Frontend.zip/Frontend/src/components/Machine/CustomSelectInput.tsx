import React from "react";
import { Col, Form } from "react-bootstrap";
import { Cell, Facility, Layout, Line } from "../../redux/types";

interface SelectInputProps {
  controlId: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: Facility[] | Cell[] | Layout[] | Line | null;
}

const CustomLocationSelectInput: React.FC<SelectInputProps> = ({
  controlId,
  label,
  value,
  onChange,
  options,
}) => (
  <Col sm={12} md={6} lg={3}>
    <Form.Group className="mb-3" controlId={controlId}>
      <Form.Label>{label}</Form.Label>
      <select
        className="form-select"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        <option value="">{`Select ${label}`}</option>
        {Array.isArray(options) &&
          options.map((option) => (
            <option key={option._id} value={option._id}>
              {option.name}
            </option>
          ))}
      </select>
    </Form.Group>
  </Col>
);

export default CustomLocationSelectInput;
