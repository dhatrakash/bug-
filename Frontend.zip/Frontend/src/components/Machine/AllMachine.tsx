import React, { useState, useEffect } from "react";
import { fetchMachines, deleteMachine } from "../../redux/machineSlice";
import { Machine } from "../../redux/types";
import DeleteMachine from "./DeleteMachine";
import EditMachine from "./EditMachine";
import { Gateway } from "../../redux/types";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  CircularProgress,
  Paper,
  Tooltip,
  IconButton,
  Box,
  TextField,
  Grid,
  TablePagination,
} from "@mui/material";
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  AddCircleOutlineSharp as AddIcon,
  AddLink as AssignIcon,
  Visibility as ViewIcon,
  ArrowUpward as ArrowUpwardIcon,
  ArrowDownward as ArrowDownwardIcon,
  FilterList as FilterListIcon,
  FilterListOff as CloseIcon,
} from "@mui/icons-material";
import CreateMachine from "./CreateMachine";
import CreateMachineGatewayAssociation from "../MachineGatewayAssoc/Slaves/CreateMachineGatewayAssociation";
import { Link } from "react-router-dom";
import CreateMachineInputsAssociation from "../MachineGatewayAssoc/Inputs/CreateMachineInputsAssociation";
import AssignGatewayModal from "./AssignGatewayModal";
import NotFound from "../NotFound";
import CreateMachineMapping from "../MachineMappings/CreateMachineMapping";
import MachineDetailsModal from "./MachineDetailsModal";
import "../../assets/css/AllMachine.css";
import { toast } from "react-toastify";

const AllMachine: React.FC = () => {
  const dispatch = useMachinewiseDispatch();
  // const [machineStatus, setMachineStatus] = useState<boolean>(false);
  const { machines, loading, error } = useMachinewiseSelector(
    (state) => state.machine
  );
  const functionalities = useMachinewiseSelector(
    (state) => state.functionalities
  );
  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  //   const handleMachineStatus = async () => {

  //     if(sessionStorage.getItem("role") === "superAdmin"){
  //      try {
  //        // Make a POST request to the API
  //        const response = await fetch('http://localhost:3000/v1/superAdmins/viewAllMachines', {
  //          method: 'GET',
  //          headers: {
  //            'Content-Type': 'application/json',
  //            'Authorization' : `Bearer ${sessionStorage.getItem("access-token")}`
  //          }
  //        });
  //        (response.status !== 200 ) ? ( openModal() ) : (closeModal() );
  //        console.warn("response " + response);
  //        const data = await response.json();
  //        setMachineStatus(data.msg);
  //        console.log(data.msg);
  //      } catch (err) {
  //        console.log(err);
  //      }
  //    }else{
  //      try {
  //        // Make a POST request to the API
  //        const response = await fetch('http://localhost:3000/v1/users/viewAllMachines', {
  //          method: 'GET',
  //          headers: {
  //            'Content-Type': 'application/json',
  //            'Authorization' : `Bearer ${sessionStorage.getItem("access-token")}`
  //          }
  //        });
  //        (response.status !== 200 ) ? ( openModal() ) : (closeModal() );
  //        closeModal();
  //        console.warn("response " + response);
  //        const data = await response.json();
  //        setMachineStatus(data.msg);
  //        console.log(data.msg);
  //        console.warn("machinseStatus "+machineStatus)
  //      } catch (err) {
  //        console.log(err);
  //      }
  //    }

  //  };

  //  useEffect(() => {
  //   handleMachineStatus();
  //  }, []);

  useEffect(() => {
    dispatch(fetchMachines());
  }, [dispatch]);

  const [addMachineStatus, setAddMachineStatus] = useState(false);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [selectedMachine, setSelectedMachine] = useState<Machine | null>(null);
  const [deleteConfirmationModalOpen, setDeleteConfirmationModalOpen] =
    useState(false);
  const [machineToDeleteId, setMachineToDeleteId] = useState<string | null>(
    null
  );
  const [machineDetailsModalOpen, setMachineDetailsModalOpen] = useState(false);
  const [isEditingComplete, setIsEditingComplete] = useState(false);
  const [assignGatewaySlaveModalOpen, setAssignGatewaySlaveModalOpen] =
    useState(false);
  const [assignGatewayInputsModalOpen, setAssignGatewayInputsModalOpen] =
    useState(false);
  const [assignGatewayModalOpen, setAssignGatewayModalOpen] = useState(false);
  const handleEdit = (machine: Machine) => {
    // Open the edit modal and set the selected machine
    setSelectedMachine(machine);
    setEditModalVisible(true);
  };

  const [assignMappingModalOpen, setAssignMappingModalOpen] = useState(false);
  const [machineNameFilter, setMachineNameFilter] = useState("");
  const [machineTypeFilter, setMachineTypeFilter] = useState("");
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [page, setPage] = useState(0); // State for the current page
  const [rowsPerPage, setRowsPerPage] = useState(10); // State for rows per page
  const [sortConfig, setSortConfig] = useState<Record<string, string>>({});

  const handleUpdate = () => {
    setIsEditingComplete(true);
  };

  useEffect(() => {
    dispatch(fetchMachines());
  }, [dispatch, isEditingComplete]); // Trigger a refresh when editing is complete

  const handleDelete = (machineId: string) => {
    // Open the confirmation modal and set the machine ID
    setMachineToDeleteId(machineId);
    setDeleteConfirmationModalOpen(true);
  };

  const confirmDelete = async () => {
    if (machineToDeleteId) {
      try {
        const machineAction = await dispatch(deleteMachine(machineToDeleteId));
        if (deleteMachine.fulfilled.match(machineAction)) {
          setDeleteConfirmationModalOpen(false);
          dispatch(fetchMachines());
          toast.success("Machine deleted successfully");
        } else {
          toast.error("Failed to Delete Machine");
        }
      } catch (error) {
        console.error("An error occurred while deleting the machine:", error);
        toast.error("An error Occured");
      }
    }
  };

  const cancelDelete = () => {
    // Close the confirmation modal without deleting
    setDeleteConfirmationModalOpen(false);
    setMachineToDeleteId(null);
  };
  const handleAssignMapping = (machine: Machine) => {
    setSelectedMachine(machine);
    setAssignMappingModalOpen(true);
  };

  // const handleAssignGatewaySubmit = async (gatewayDetails: Gateway) => {
  //   if (selectedMachine) {
  //     try {
  //       // Call the backend API to assign the gateway to the machine
  //       console.log(
  //         "Assigning gateway to machine:",
  //         selectedMachine,
  //         gatewayDetails
  //       );

  //       // Close the modal and reset selectedMachine
  //       setAssignGatewaySlaveModalOpen(false);
  //       setSelectedMachine(null);
  //     } catch (error) {
  //       console.error("Failed to assign gateway:", error);
  //     }
  //   }
  // };
  const handleAssignGateway = (machine: Machine) => {
    setSelectedMachine(machine);
    setAssignGatewayModalOpen(true);
  };

  const handleAssignGatewaySubmit = async (gatewayDetails: Gateway) => {
    if (selectedMachine) {
      try {
        // Call the backend API to assign the gateway to the machine
        console.log(
          "Assigning gateway to machine:",
          selectedMachine,
          gatewayDetails
        );

        // Close the modal and reset selectedMachine
        setAssignGatewayModalOpen(false);
        setSelectedMachine(null);
      } catch (error) {
        console.error("Failed to assign gateway:", error);
      }
    }
  };

  const handleSortClick = (column: string) => {
    let direction = "asc";
    if (sortConfig[column] === "asc") {
      direction = "desc";
    }
    setSortConfig({ [column]: direction });
  };
  // Sort the Machines array based on the sortConfig
  const sortedMachines = [...(machines || [])].sort((a, b) => {
    let comparison = 0;
    for (const column in sortConfig) {
      const sortOrder = sortConfig[column];
      const aValue = (a as any)[column];
      const bValue = (b as any)[column];

      if (aValue < bValue) {
        comparison = sortOrder === "asc" ? -1 : 1;
        break;
      }
      if (aValue > bValue) {
        comparison = sortOrder === "asc" ? 1 : -1;
        break;
      }
    }
    return comparison;
  });
  const handleFilterToggle = () => {
    // Toggle the filter visibility
    setIsFilterOpen(!isFilterOpen);
  };
  const handleChangePage = (
    event: React.MouseEvent<HTMLButtonElement> | null,
    newPage: number
  ) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  // eslint-disable-next-line
  const handleAddMachine = async () => {
    if (sessionStorage.getItem("role") === "superAdmin") {
      if (!showModal) {
        try {
          // Make a POST request to the API
          const response = await fetch(
            "http://localhost:3000/v1/superAdmins/viewCreateMachineForm",
            {
              method: "GET",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${sessionStorage.getItem(
                  "access-token"
                )}`,
              },
            }
          );
          console.warn("response " + response);
          const data = await response.json();
          console.log("data.msg1 " + data.msg);
          setAddMachineStatus(data.msg);
          console.warn("addmach1 " + addMachineStatus);
          openModal();
        } catch (err) {
          console.log(err);
          closeModal();
        }
      } else {
        closeModal();
      }
    } else {
      if (!showModal) {
        try {
          const response = await fetch(
            "http://localhost:3000/v1/users/viewCreateMachineForm",
            {
              method: "GET",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${sessionStorage.getItem(
                  "access-token"
                )}`,
              },
            }
          );
          console.warn("response " + response);
          const data = await response.json();
          console.log("data.msg2 " + data.msg);
          // setAddMachineStatus(data?.msg);
          response.status === 200
            ? setAddMachineStatus(true)
            : setAddMachineStatus(false);
          console.warn("addmach2 " + addMachineStatus);
          openModal();
        } catch (err) {
          console.log(err);
          closeModal();
        }
      } else {
        closeModal();
      }
    }
  };

  const handlePermission = async () => {
    // Get data from session storage
    const sessionStorageDataString = sessionStorage.getItem("functionalities");
    // Check if sessionStorageDataString is not null or undefined
    if (sessionStorageDataString) {
      const sessionStorageData = JSON.parse(sessionStorageDataString);

      // Check if sessionStorageData is an object
      if (sessionStorageData && typeof sessionStorageData === "object") {
        const dataArray = Object.keys(sessionStorageData);
        const newDataFormat = { data: dataArray };
        if (!showModal) {
          // Send a POST request to your server
          try {
            const response = await fetch(
              "http://localhost:3000/v1/users/permission",
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${sessionStorage.getItem(
                    "access-token"
                  )}`,
                  // Add any other headers as needed
                },
                body: JSON.stringify(newDataFormat),
              }
            );
            // Handle the response
            const responseData = await response.json();
            console.log(responseData);
            response.status === 200
              ? setAddMachineStatus(true)
              : setAddMachineStatus(false);
            console.warn("addMachineStatus1 " + addMachineStatus);
            openModal();
          } catch (error) {
            console.error("Error:", error);
            console.warn("addMachineStatus2 " + addMachineStatus);
            closeModal();
          }
        } else {
          console.warn("addMachineStatus3 " + addMachineStatus);
          closeModal();
        }
      } else {
        console.error("sessionStorageData is not an object");
      }
    } else {
      console.error("sessionStorageDataString is null or undefined");
    }
  };

  const handleViewDetails = (machine: Machine) => {
    setSelectedMachine(machine);
    setMachineDetailsModalOpen(true);
  };

  return (
    <div>
      <div className="allMachines-details">
        <Paper className="allmachines-paper">
          <Box display="flex" justifyContent="flex-end" alignItems="center">
            <div style={{ display: "flex", justifyContent: "flex-end" }}>
              {" "}
              <IconButton
                color="primary"
                aria-label="Filter Machines"
                onClick={handleFilterToggle}
                style={{
                  padding: "10px 20px",
                  borderRadius: "15px",
                  transition: "background-color 0.7s ease",
                }}
              >
                {isFilterOpen ? (
                  <CloseIcon fontSize="small" />
                ) : (
                  <FilterListIcon fontSize="small" />
                )}
                <span
                  style={{
                    marginLeft: "8px",
                    marginTop: "-2px",
                    fontSize: "medium",
                    fontWeight: "bold",
                  }}
                >
                  Filter Machines
                </span>
              </IconButton>{" "}
              {functionalities.createNewMach && (
                <IconButton
                  color="primary"
                  aria-label="Add Machine"
                  onClick={handlePermission}
                  style={{
                    padding: "10px 20px",
                    borderRadius: "15px",
                    transition: "background-color 0.7s ease",
                  }}
                >
                  <AddIcon fontSize="small" />
                  <span
                    style={{
                      marginLeft: "8px",
                      marginTop: "-2px",
                      fontSize: "medium",
                      fontWeight: "bold",
                    }}
                  >
                    Add Machine
                  </span>
                </IconButton>
              )}
            </div>{" "}
          </Box>
          {isFilterOpen && (
            <Box
              style={{
                padding: "10px 20px",
                borderRadius: "15px",
                transition: "background-color 0.7s ease",
                marginLeft: "auto", // Align the filter button to the right
              }}
            >
              <Grid
                container
                spacing={2}
                alignItems="center"
                style={{ display: "flex", justifyContent: "flex-end" }}
                className="allMachine-filter-fields"
              >
                {" "}
                <Grid item xs={12} sm={6} md={4} lg={2}>
                  <TextField
                    label="Filter by Machine Name"
                    value={machineNameFilter}
                    onChange={(e) => setMachineNameFilter(e.target.value)}
                    variant="outlined"
                    size="small"
                    fullWidth
                    margin="normal"
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={4} lg={2}>
                  <TextField
                    label="Filter by Machine Type"
                    value={machineTypeFilter}
                    onChange={(e) => setMachineTypeFilter(e.target.value)}
                    variant="outlined"
                    size="small"
                    fullWidth
                    margin="normal"
                  />
                </Grid>
              </Grid>
            </Box>
          )}
          <Table className="allmachines-table">
            <TableHead>
              <TableRow>
                <TableCell onClick={() => handleSortClick("machineName")}>
                  Machine Name
                  {sortConfig["machineName"] === "asc" && <ArrowUpwardIcon />}
                  {sortConfig["machineName"] === "desc" && (
                    <ArrowDownwardIcon />
                  )}
                </TableCell>
                <TableCell onClick={() => handleSortClick("machineType")}>
                  Machine Type
                  {sortConfig["machineType"] === "asc" && <ArrowUpwardIcon />}
                  {sortConfig["machineType"] === "desc" && (
                    <ArrowDownwardIcon />
                  )}
                </TableCell>
                {/* <TableCell>Machine Make</TableCell> */}
                {/* <TableCell>Machine Location</TableCell> */}
                <TableCell>Machine Actions</TableCell>
                <TableCell>Machine Mappings Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={4} align="center">
                    <CircularProgress />
                  </TableCell>
                </TableRow>
              ) : error ? (
                <TableRow>
                  <TableCell colSpan={4} align="center">
                    Error: {error}
                  </TableCell>
                </TableRow>
              ) : (
                sortedMachines
                  .filter((machine) => {
                    const machineName = (
                      machine.machineName || ""
                    ).toLowerCase();
                    const machineType = (
                      machine.machine_type || ""
                    ).toLowerCase();
                    return (
                      machineName.includes(machineNameFilter.toLowerCase()) &&
                      machineType.includes(machineTypeFilter.toLowerCase())
                    );
                  })
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((machine) => (
                    <TableRow key={machine._id}>
                      <TableCell>
                        {/* Make the machine name clickable */}
                        <span
                          style={{ cursor: "pointer" }}
                          onClick={() => handleViewDetails(machine)}
                        >
                          {machine.machineName}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span
                          style={{ cursor: "pointer" }}
                          onClick={() => handleViewDetails(machine)}
                        >
                          {machine.machine_type}
                        </span>
                      </TableCell>
                      {/* Machine Actions */}
                      <TableCell>
                        {/* <Tooltip title="View Machine Details">
                        <IconButton
                          color="primary"
                          onClick={() => handleViewDetails(machine)}
                        >
                          <ViewIcon />
                        </IconButton>
                      </Tooltip> */}
                        <Tooltip title="Update Machine">
                          <IconButton
                            color="primary"
                            onClick={() => handleEdit(machine)}
                          >
                            <EditIcon />
                          </IconButton>
                        </Tooltip>{" "}
                        <Tooltip title="Delete  Machine permanently">
                          <IconButton
                            color="error"
                            onClick={() =>
                              machine.machineId &&
                              handleDelete(machine.machineId)
                            }
                          >
                            <DeleteIcon />
                          </IconButton>
                        </Tooltip>{" "}
                        <Tooltip title="Assign Gateway ">
                          <IconButton
                            color="primary"
                            onClick={() => handleAssignGateway(machine)}
                          >
                            <AssignIcon />
                          </IconButton>
                        </Tooltip>
                      </TableCell>

                      {/* Machine Mappings Actions  */}
                      <TableCell>
                        <Tooltip title="Create Machine Mapping">
                          <IconButton
                            color="primary"
                            onClick={() => handleAssignMapping(machine)}
                          >
                            <AddIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="View Machine Mapping">
                          <Link to={`/machineMappings/${machine.machineId}`}>
                            <IconButton style={{ color: "#495057" }}>
                              <ViewIcon />
                            </IconButton>
                          </Link>
                        </Tooltip>{" "}
                      </TableCell>
                    </TableRow>
                  ))
              )}
            </TableBody>
          </Table>
          {/* Table Pagination */}
          <TablePagination
            rowsPerPageOptions={[3, 5, 10, 25]}
            component="div"
            count={sortedMachines.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
          {addMachineStatus ? (
            <CreateMachine showModal={showModal} closeModal={closeModal} />
          ) : (
            <NotFound showModal={showModal} closeModal={closeModal} />
          )}
          <MachineDetailsModal
            open={machineDetailsModalOpen}
            onClose={() => setMachineDetailsModalOpen(false)}
            machineData={selectedMachine}
          />
          {/* Edit Machine Modal */}
          <EditMachine
            showModal={editModalVisible}
            closeModal={() => {
              setEditModalVisible(false);
              setSelectedMachine(null);
            }}
            machineId={
              selectedMachine ? (selectedMachine as any).machineId : ""
            }
            machineData={selectedMachine}
            onUpdate={handleUpdate}
          />
          {/* Delete Machine Modal */}
          <DeleteMachine
            show={deleteConfirmationModalOpen}
            onClose={cancelDelete}
            onConfirm={confirmDelete}
          />
          {/* Assign Gateway Modal */}{" "}
          <AssignGatewayModal
            open={assignGatewayModalOpen}
            onClose={() => setAssignGatewayModalOpen(false)}
            handleAssignGateway={handleAssignGatewaySubmit}
            machineData={selectedMachine}
          />
          <CreateMachineGatewayAssociation
            open={assignGatewaySlaveModalOpen}
            onClose={() => setAssignGatewaySlaveModalOpen(false)}
            machineData={selectedMachine}
          />
          <CreateMachineInputsAssociation
            open={assignGatewayInputsModalOpen}
            onClose={() => setAssignGatewayInputsModalOpen(false)}
            machineData={selectedMachine}
          />
          <CreateMachineMapping
            open={assignMappingModalOpen}
            onClose={() => setAssignMappingModalOpen(false)}
            machineData={selectedMachine}
          />
        </Paper>
      </div>
    </div>
  );
};
export default AllMachine;
