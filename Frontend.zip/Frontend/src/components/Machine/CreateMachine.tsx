import React, { useState, useEffect } from "react";
import { Modal, Button, Form, Row, Col, Alert } from "react-bootstrap";
import { Machine } from "../../redux/types";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";
import { RootState } from "../../redux/store";
import { createMachine, fetchMachines } from "../../redux/machineSlice";
import { fetchFacilities } from "../../redux/facilitySlice";
import { fetchCells } from "../../redux/cellSlice";
import { fetchLayouts } from "../../redux/layoutSlice";
import { fetchLines } from "../../redux/lineSlice";
import "../../assets/css/Create_updateMachine.css";
import { toast } from "react-toastify";
import CustomFormGroup from "./CustomFormGroup";

interface CreateMachineProps {
  showModal: boolean;
  closeModal: () => void;
}
const initialValue: Machine = {
  machineName: "",
  machine_type: "",
  machineLocation: {
    facility: "",
    cell: "",
    layout: "",
    line: "",
  },
  controllerType: "",
  machineMake: "",
  machineMakeYear: 0,
  maintenancePerson: "",
  maintenanceContact: "",
  mfgEmail: "",
  machineWarranty: "",
  powerSupplyRating: 0,
  inputMethod: "STABILIZER",
  controllerMake: "",
  controllerModel: "",
  controllerMakeYear: 0,
  machineId: "",
  machinePhoto: null,
  controllerPhoto: null,
  subscribeTopic: "",
  publishTopic: "",
  downtimeReason: "",
  lockRegister: "",
  operatorId: "",
  partCode: "",
  lockCommand: "",
  unlockCommand: "",
  flushCommand: "",
};

const CreateMachine: React.FC<CreateMachineProps> = ({
  showModal,
  closeModal,
}) => {
  const [machines, setMachines] = useState<Machine>(initialValue);
  const facilities = useMachinewiseSelector(
    (state: RootState) => state.facility.facilities
  );
  const cells = useMachinewiseSelector((state: RootState) => state.cell.cells);
  const layouts = useMachinewiseSelector(
    (state: RootState) => state.layout.layouts
  );
  const lines = useMachinewiseSelector((state: RootState) => state.line.lines);

  const dispatch = useMachinewiseDispatch();

  const [selectedFacility, setSelectedFacility] = useState<string>("");
  const [selectedCell, setSelectedCell] = useState<string>("");
  const [selectedLine, setSelectedLine] = useState<string>("");
  const [selectedLayout, setSelectedLayout] = useState<string>("");
  // eslint-disable-next-line
  const [selectedLocation, setSelectedLocation] = useState<string | null>(null);
  const [yearWarning, setYearWarning] = useState("");
  const controllerTypeOptions = ["fanuc", "siemens"];
  useEffect(() => {
    Promise.all([
      dispatch(fetchFacilities()),
      dispatch(fetchCells()),
      dispatch(fetchLines()),
      dispatch(fetchLayouts()),
    ]);
  }, [dispatch]);

  const getMachineData = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setMachines({ ...machines, [name]: value });
    const numericValue = Number(value);
    if (
      (name === "controllerMakeYear" || name === "machineMakeYear") &&
      numericValue < 1800
    ) {
      setYearWarning("Please enter a year greater than 1800");
    } else {
      setYearWarning("");
    }
  };

  const handleFileChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    fieldName: string
  ) => {
    const file = e.target.files?.[0];

    if (file) {
      setMachines((prevMachines) => ({
        ...prevMachines,
        [fieldName]: file,
      }));
    }
  };
  const isValidYear = (year: number) => {
    return year >= 1800 && year <= new Date().getFullYear();
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};

    if (machines.machineName.trim() === "") {
      errors.machineName = "Machine Name is required";
    }

    if (!machines.machine_type) {
      errors.machine_type = "Machine Type is required";
    }

    // if (!machines.inputMethod) {
    //   errors.inputMethod = "Input Method is required";
    // }
    // if (!machines.mfgEmail) {
    //   errors.mfgEmail = "Manufacturer Email is required";
    // }
    if (!isValidYear(machines.machineMakeYear)) {
      errors.machineMakeYear = "Invalid Machine Make Year";
    }

    if (!isValidYear(machines.controllerMakeYear)) {
      errors.controllerMakeYear = "Invalid Controller Make Year";
    }

    return errors;
  };
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const errors = validateForm();

    if (Object.keys(errors).length > 0) {
      for (const key in errors) {
        toast.error(errors[key], { autoClose: 5000 });
      }
      return;
    }

    try {
      const formData = new FormData();

      formData.append("machineName", machines.machineName);
      formData.append("machine_type", machines.machine_type);

      // Check if machine_type is hardwire
      if (machines.machine_type === "hardwire") {
        formData.append("controllerType", "N/A"); // or "" depending on backend expectations
      } else {
        // Append controllerType if not hardwire and not null
        formData.append("controllerType", machines.controllerType || "");
      }
      formData.append("machineMake", machines.machineMake);
      formData.append("machineMakeYear", String(machines.machineMakeYear));
      formData.append("maintenancePerson", machines.maintenancePerson);
      formData.append("maintenanceContact", machines.maintenanceContact);
      formData.append("mfgEmail", machines.mfgEmail);
      formData.append("machineWarranty", machines.machineWarranty);
      formData.append("powerSupplyRating", String(machines.powerSupplyRating));
      formData.append("inputMethod", machines.inputMethod);
      formData.append("controllerMake", machines.controllerMake);
      formData.append("controllerModel", machines.controllerModel);
      formData.append("subscribeTopic", machines.subscribeTopic ?? "");
      formData.append("publishTopic", machines.publishTopic ?? "");
      formData.append("downtimeReason", machines.downtimeReason ?? "");
      formData.append("lockRegister", machines.lockRegister ?? "");
      formData.append("operatorId", machines.operatorId ?? "");
      formData.append("partCode", machines.partCode ?? "");
      formData.append("lockCommand", machines.lockCommand ?? "");
      formData.append("unlockCommand", machines.unlockCommand ?? "");
      formData.append("flushCommand", machines.flushCommand ?? "");
      // formData.append("");

      formData.append(
        "controllerMakeYear",
        String(machines.controllerMakeYear)
      );
      formData.append("machineLocation[facility]", selectedFacility);
      formData.append("machineLocation[cell]", selectedCell);
      formData.append("machineLocation[layout]", selectedLayout);
      formData.append("machineLocation[line]", selectedLine);
      console.log("hffyfytf", formData);
      if (machines.machinePhoto) {
        formData.append("machinePhoto", machines.machinePhoto);
      }

      if (machines.controllerPhoto) {
        formData.append("controllerPhoto", machines.controllerPhoto);
      }
      console.log("formData sending:", formData);
      const createAction = await dispatch(createMachine(formData));
      if (createMachine.fulfilled.match(createAction)) {
        closeModal();
        dispatch(fetchMachines());
        // setMachines(initialValue);
        toast.success("Machine added successfully!");
      } else {
        toast.error("Failed to add machine");
      }
    } catch (error) {
      console.error("An error occurred:", error);
      toast.error("An error occurred");
    }
  };

  const getOptions = (items: { name: string; value: string }[] | null) =>
    (items || []).map((item) => item.name);

  return (
    <Modal
      show={showModal}
      onHide={closeModal}
      backdrop="static"
      keyboard={false}
      size="lg"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title
          style={{ textAlign: "center", width: "100%", color: "#3081cd" }}
          className="machine-form-title"
        >
          Create Machine
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="modal-container">
        <Form
          noValidate
          className="machine-form"
          onSubmit={handleSubmit}
          style={{ justifyContent: "center" }}
        >
          <Row>
            <Col sm={12} md={6} lg={6}>
              <Row>
                {" "}
                <Form.Group className="mb-3" controlId="machine_type">
                  <Form.Label>
                    Machine Type <span className="text-danger">*</span>
                  </Form.Label>
                  <div className="radio-group">
                    <Form.Check
                      type="radio"
                      label="Hardwire"
                      name="machine_type"
                      value="hardwire"
                      checked={machines.machine_type === "hardwire"}
                      onChange={(e) =>
                        setMachines({
                          ...machines,
                          machine_type: e.target.value,
                        })
                      }
                      className="radio-option"
                    />
                    <Form.Check
                      type="radio"
                      label="Controller"
                      name="machine_type"
                      value="controller"
                      checked={machines.machine_type === "controller"}
                      onChange={(e) =>
                        setMachines({
                          ...machines,
                          machine_type: e.target.value,
                        })
                      }
                      className="radio-option"
                    />
                  </div>
                </Form.Group>
              </Row>
              <Row>
                {machines.machine_type === "controller" ? (
                  <Form.Group className="mb-3" controlId="controllerType">
                    <Form.Label>Controller type</Form.Label>

                    <Form.Control
                      as="select"
                      name="controllerType"
                      value={machines.controllerType || ""}
                      onChange={getMachineData}
                      required
                    >
                      <option value="">Select Controller Type</option>
                      {controllerTypeOptions?.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </Form.Control>
                  </Form.Group>
                ) : null}
              </Row>
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="machineName"
                type="text"
                placeholder="Enter machine name"
                name="machineName"
                value={machines.machineName}
                onChange={getMachineData}
                label="Machine Name"
              />
            </Col>
          </Row>
          {/* Machine Location Area */}
          <Row>
            <Col md={12}>
              <CustomFormGroup
                controlId="machineLocation"
                label="Machine Location"
                type="text"
                placeholder="Select From Facility, Cell, Layout, Line"
                name="machineLocation"
                value={[
                  selectedFacility,
                  selectedCell,
                  selectedLayout,
                  selectedLine,
                ]
                  .filter(Boolean)
                  .join(", ")}
                onChange={(e) => setSelectedLocation(e.target.value)}
              />
            </Col>

            <Col sm={12} md={6} lg={3}>
              <CustomFormGroup
                controlId="facilitySelect"
                label="Facility"
                type="select"
                name="selectedFacility"
                value={selectedFacility}
                onChange={(e) => setSelectedFacility(e.target.value)}
                options={getOptions(facilities)}
              />
            </Col>
            <Col sm={12} md={6} lg={3}>
              <CustomFormGroup
                controlId="cellSelect"
                label="Cell"
                type="select"
                name="selectedCell"
                value={selectedCell}
                onChange={(e) => setSelectedCell(e.target.value)}
                options={getOptions(cells)}
              />
            </Col>
            <Col sm={12} md={6} lg={3}>
              <CustomFormGroup
                controlId="layoutSelect"
                label="Layout"
                type="select"
                name="selectedLayout"
                value={selectedLayout}
                onChange={(e) => setSelectedLayout(e.target.value)}
                options={getOptions(layouts)}
              />
            </Col>
            <Col sm={12} md={6} lg={3}>
              <CustomFormGroup
                controlId="lineSelect"
                label="Line"
                type="select"
                name="selectedLine"
                value={selectedLine}
                onChange={(e) => setSelectedLine(e.target.value)}
                options={getOptions(lines)}
              />
            </Col>
          </Row>
          {/* Machine Location Area  End*/}
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="machineMake"
                type="text"
                placeholder="Enter machine make"
                name="machineMake"
                value={machines.machineMake}
                onChange={getMachineData}
                label="Machine Make"
              />
            </Col>

            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="machineMakeYear"
                label="Machine Make Year"
                type="number"
                placeholder="Enter machine make year"
                name="machineMakeYear"
                value={machines.machineMakeYear}
                onChange={getMachineData}
              />
              {yearWarning && <Alert variant="warning">{yearWarning}</Alert>}
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="maintenancePerson"
                type="text"
                placeholder="Enter Maintenance Person Name"
                name="maintenancePerson"
                value={machines.maintenancePerson}
                onChange={getMachineData}
                label="Maintenance Person"
              />
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="maintainanceContact"
                type="text"
                placeholder="Enter Maintenance Contact Number"
                pattern="[0-9]{10}"
                name="maintenanceContact"
                value={machines.maintenanceContact}
                onChange={getMachineData}
                label="Maintenance Contact"
              />
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="mfgEmail"
                type="email"
                placeholder="Enter manufacturer email"
                name="mfgEmail"
                value={machines.mfgEmail}
                onChange={getMachineData}
                label="Mfg Email"
                pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}"
              />
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="machineWarranty"
                type="text"
                placeholder="Enter Warranty"
                name="machineWarranty"
                value={machines.machineWarranty}
                onChange={getMachineData}
                label="Machine Warranty"
              />
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={12} lg={12}>
              {" "}
              <Form.Group
                className="mb-3"
                controlId="inputMethod"
                style={{ textAlign: "center" }}
              >
                <Form.Label
                  style={{
                    justifyContent: "center",
                    textAlign: "center",
                  }}
                >
                  Input method
                </Form.Label>
                <div className="radio-group">
                  <Form.Check
                    type="radio"
                    label="STABILIZER"
                    name="inputMethod"
                    value="STABILIZER"
                    checked={machines.inputMethod === "STABILIZER"}
                    onChange={getMachineData}
                    className="radio-option"
                  />
                  <Form.Check
                    type="radio"
                    label="UPS"
                    name="inputMethod"
                    value="UPS"
                    checked={machines.inputMethod === "UPS"}
                    onChange={getMachineData}
                    className="radio-option"
                  />
                  <Form.Check
                    type="radio"
                    label="Other"
                    name="inputMethod"
                    value="Other"
                    checked={machines.inputMethod === "Other"}
                    onChange={getMachineData}
                    className="radio-option"
                  />
                </div>
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="powerSupplyRating"
                type="text"
                placeholder="Enter power supply rating"
                name="powerSupplyRating"
                value={machines.powerSupplyRating}
                onChange={getMachineData}
                label="Power supply rating"
              />
            </Col>
            <Col sm={12} md={6} lg={6}>
              {" "}
              <CustomFormGroup
                controlId="controllerMake"
                type="text"
                placeholder="Enter controller make"
                name="controllerMake"
                value={machines.controllerMake}
                onChange={getMachineData}
                label="Controller Make"
              />
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="controllerMakeYear"
                label="Controller Make Year"
                type="number"
                placeholder="Enter controller make year"
                name="controllerMakeYear"
                value={machines.controllerMakeYear}
                onChange={getMachineData}
              />
              {yearWarning && <Alert variant="warning">{yearWarning}</Alert>}
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="controllerModel"
                type="text"
                placeholder="Enter controller Model"
                name="controllerModel"
                value={machines.controllerModel}
                onChange={getMachineData}
                label="Controller Model"
              />
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="subscribeTopic"
                type="text"
                placeholder="Enter Subscribe Topic"
                name="subscribeTopic"
                value={machines.subscribeTopic}
                onChange={getMachineData}
                label="Subscribe Topic"
              />
            </Col>
            <Col sm={12} md={6} lg={6}>
              <CustomFormGroup
                controlId="publishTopic"
                type="text"
                placeholder="Enter Publish Topic"
                name="publishTopic"
                value={machines.publishTopic}
                onChange={getMachineData}
                label="Publish Topic"
              />
            </Col>
          </Row>
          <Row>
            {" "}
            <Row>
              <Col sm={12} md={6} lg={6}>
                <Form.Group className="mb-3" controlId="machinePhoto">
                  <Form.Label>Machine photo</Form.Label>
                  <Form.Control
                    type="file"
                    name="machinePhoto"
                    accept="image/*"
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      handleFileChange(e, "machinePhoto")
                    }
                  />
                </Form.Group>{" "}
                {machines.machinePhoto && (
                  <img
                    src={URL.createObjectURL(machines.machinePhoto)}
                    alt="Machine"
                    style={{ maxWidth: "100px", maxHeight: "100px" }}
                  />
                )}
              </Col>

              <Col sm={12} md={6} lg={6}>
                {" "}
                <Form.Group className="mb-3" controlId="controllerPhoto">
                  <Form.Label>Machine Controller photo</Form.Label>
                  <Form.Control
                    type="file"
                    name="controllerPhoto"
                    accept="image/*"
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      handleFileChange(e, "controllerPhoto")
                    }
                  />
                </Form.Group>
                {machines.controllerPhoto && (
                  <img
                    src={URL.createObjectURL(machines.controllerPhoto)}
                    alt="Machine Controller"
                    style={{ maxWidth: "100px", maxHeight: "100px" }}
                  />
                )}
              </Col>
            </Row>{" "}
          </Row>
          <Row>
            <Col sm={6} md={3} lg={3}>
              <CustomFormGroup
                controlId="downtimeReason"
                type="text"
                placeholder="Enter Downtime reason"
                name="downtimeReason"
                value={machines.downtimeReason}
                onChange={getMachineData}
                label="Downtime reason"
              />
            </Col>
            <Col sm={6} md={3} lg={3}>
              <CustomFormGroup
                controlId="lockRegister"
                type="text"
                placeholder="Enter Lock register"
                name="lockRegister"
                value={machines.lockRegister}
                onChange={getMachineData}
                label="Lock register"
              />
            </Col>
            <Col sm={6} md={3} lg={3}>
              <CustomFormGroup
                controlId="partCode"
                type="text"
                placeholder="Enter Part Code Number"
                name="partCode"
                value={machines.partCode}
                onChange={getMachineData}
                label="Part Code Number"
              />
            </Col>
            <Col sm={6} md={3} lg={3}>
              <CustomFormGroup
                controlId="operatorId"
                type="text"
                placeholder="Enter Operator Id"
                name="operatorId"
                value={machines.operatorId}
                onChange={getMachineData}
                label="Operator Id"
              />
            </Col>
          </Row>
          <Row>
            <Col sm={12} md={6} lg={4}>
              <CustomFormGroup
                controlId="lockCommand"
                type="text"
                placeholder="Enter lock Command"
                name="lockCommand"
                value={machines.lockCommand}
                onChange={getMachineData}
                label="lock Command"
              />
            </Col>
            <Col sm={12} md={6} lg={4}>
              <CustomFormGroup
                controlId="unlockCommand"
                type="text"
                placeholder="Enter Unlock Command"
                name="unlockCommand"
                value={machines.unlockCommand}
                onChange={getMachineData}
                label="Unlock Command"
              />
            </Col>
            <Col sm={12} md={6} lg={4}>
              <CustomFormGroup
                controlId="flushCommand"
                type="text"
                placeholder="Enter Flush Command"
                name="flushCommand"
                value={machines.flushCommand}
                onChange={getMachineData}
                label="Flush Command"
              />
            </Col>
          </Row>
          <Button variant="primary" type="submit">
            Add Machine Details
          </Button>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default CreateMachine;
