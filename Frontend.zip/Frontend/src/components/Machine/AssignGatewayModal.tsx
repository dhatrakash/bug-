import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  InputAdornment,
  Tooltip,
  CircularProgress,
} from "@mui/material";
import { Edit as EditIcon } from "@mui/icons-material";
import {
  useMachinewiseDispatch,
  useMachinewiseSelector,
} from "../../redux/hooks";
import { fetchGateways } from "../../redux/gatewaySlice"; // Import the fetchGateways action
import { assignGateway } from "../../redux/machineSlice";
import { Gateway, Machine } from "../../redux/types";
import { toast } from "react-toastify";

interface AssignGatewayModalProps {
  open: boolean;
  onClose: () => void;
  machineData?: Machine | null;
  handleAssignGateway: (gatewayDetails: Gateway) => void;
}

const initialGatewayData: Gateway = {
  macId: "",
  name: "",
  ip: "",
  port: 0,
  gatewayId: "",
  isActive: false,
};

const AssignGatewayModal: React.FC<AssignGatewayModalProps> = ({
  open,
  onClose,
  machineData,
  handleAssignGateway,
}) => {
  const dispatch = useMachinewiseDispatch();
  const { gateways, loading, error } = useMachinewiseSelector(
    (state) => state.gateway
  );
  // eslint-disable-next-line
  const [gatewayData, setGatewayData] = useState<Gateway>(initialGatewayData);
  const [isEdit, setIsEdit] = useState(false);
  const [selectedGatewayId, setSelectedGatewayId] = useState<string | null>(
    machineData?.gatewayId || ""
  );

  useEffect(() => {
    // Fetch the gateways when the component mounts
    dispatch(fetchGateways());
    setSelectedGatewayId(machineData?.gatewayId || "");
  }, [dispatch, machineData]);

  // Use the selected gateway's ID when in "display" mode
  const selectedGatewayName = selectedGatewayId
    ? gateways?.find((gateway) => gateway.gatewayId === selectedGatewayId)
        ?.macId
    : "Gateway Not Assigned or Not Found";

  const handleEditClick = () => {
    setIsEdit(true); // Switch to edit mode when the edit icon is clicked
  };

  // const handleCancelEdit = () => {
  //   setIsEdit(false); // Switch back to display mode and discard changes
  // };
  // const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
  //   setSelectedGatewayId(event.target.value); // Update the selected gateway ID while editing
  // };
  const handleSubmit = () => {
    console.log("gateway data", gatewayData);
    // const selectedGateway = gateways?.find(
    //   (gateway) => gateway.gatewayId === gatewayData.gatewayId
    // );
    const selectedGateway = gateways?.find(
      (gateway) => gateway.gatewayId === selectedGatewayId
    );
    console.log("Selected gateway", selectedGateway);

    if (!selectedGateway) {
      console.error("Selected gateway not found.");
      toast.error("Selected gateway not found."); // Display an error toast message
      return;
    }

    const gatewayId = selectedGateway.gatewayId; // Use the selected gateway's macId
    const machineId = machineData?.machineId;

    console.log("Passing Ids:", gatewayId, machineId);

    // Create the data object to dispatch
    const requestData = {
      machineId: machineId,
      gatewayId: gatewayId,
    };

    dispatch(assignGateway(requestData));
    toast.success("Gateway assigned successfully!");
    onClose();
  };

  // const handleGatewayChange = (value: string) => {
  //   const updatedGateway = { ...gatewayData, gatewayId: value };
  //   setGatewayData(updatedGateway);
  // };

  const handleGatewaySelect = (value: string) => {
    setSelectedGatewayId(value); // Update the selected gateway ID
    setIsEdit(false); // Switch back to "display" mode
  };
  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle
        style={{ color: "#1976d2", textAlign: "center", fontWeight: "bold" }}
      >
        Assign Gateway to {machineData?.machineName}
      </DialogTitle>{" "}
      <DialogContent>
        {loading ? (
          <div>
            Loading... <CircularProgress />
          </div>
        ) : error ? (
          <div>
            Error: {typeof error === "string" ? error : "An error occurred."}
          </div>
        ) : (
          <form style={{ padding: "20px" }} onSubmit={handleSubmit}>
            <Grid container spacing={1}>
              <Grid item xs={6}>
                <TextField
                  label="Machine Name"
                  name="machineName"
                  value={machineData?.machineName}
                  fullWidth
                  margin="normal"
                  disabled
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Machine Id"
                  name="machineId"
                  value={machineData?.machineId}
                  fullWidth
                  margin="normal"
                  disabled
                />
              </Grid>
              <Grid item xs={6}>
                {isEdit ? (
                  <FormControl fullWidth margin="normal">
                    <InputLabel>Select Gateway</InputLabel>
                    <Select
                      value={selectedGatewayName}
                      label="Select Gateway"
                      onChange={(e) =>
                        handleGatewaySelect(e.target.value as string)
                      }
                    >
                      {gateways?.map((gateway: Gateway) => (
                        <MenuItem
                          key={gateway.gatewayId}
                          value={gateway.gatewayId}
                        >
                          {gateway.name} | {gateway.macId}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                ) : (
                  <TextField
                    label="Selected Gateway"
                    value={selectedGatewayName}
                    fullWidth
                    margin="normal"
                    disabled
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="end">
                          <Tooltip title="Add or Update Gateway">
                            <IconButton onClick={handleEditClick}>
                              <EditIcon />
                            </IconButton>
                          </Tooltip>
                        </InputAdornment>
                      ),
                    }}
                  />
                )}
              </Grid>
            </Grid>
          </form>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="primary">
          Cancel
        </Button>
        <Button onClick={handleSubmit} color="primary">
          Assign Gateway
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AssignGatewayModal;
