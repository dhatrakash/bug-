import React, { useEffect, useState } from "react";
import { Machine } from "../../redux/types";
import {
  Dialog,
  DialogContent,
  Typography,
  Paper,
  Slide,
  AppBar,
  Toolbar,
  IconButton,
  Grid,
  Box,
  Tabs,
  Tab,
  Divider,
} from "@mui/material";
import { Close as CloseIcon } from "@mui/icons-material";
import { TransitionProps } from "@mui/material/transitions";
import "../../assets/css/MachineDetails.css";
import { fetchFacilityById } from "../../redux/facilitySlice";
import { fetchCellById } from "../../redux/cellSlice";
import { fetchLayoutById } from "../../redux/layoutSlice";
import { fetchLineById } from "../../redux/lineSlice";
import { useMachinewiseDispatch } from "../../redux/hooks";
interface MachineDetailsModalProps {
  open: boolean;
  machineData: Machine | null;
  onClose: () => void;
}

interface MachinePhotoObject {
  base64: {
    data: string;
  };
}

const Transition = React.forwardRef(function Transition(
  props: TransitionProps & {
    children: React.ReactElement;
  },
  ref: React.Ref<unknown>
) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const MachineDetailsModal: React.FC<MachineDetailsModalProps> = ({
  open,
  machineData,
  onClose,
}) => {
  const dispatch = useMachinewiseDispatch();
  const [machinePhotoURL, setMachinePhotoURL] = useState<string | undefined>();
  const [controllerPhotoURL, setControllerPhotoURL] = useState<
    string | undefined
  >();
  const [selectedTab, setSelectedTab] = useState(0);
  const [locationNames, setLocationNames] = useState<{
    facility: string | undefined;
    cell: string | undefined;
    layout: string | undefined;
    line: string | undefined;
  }>({
    facility: "Not Assigned",
    cell: "Not Assigned",
    layout: "Not Assigned",
    line: "Not Assigned",
  });

  const fetchLocationName = async (id: string, locationType: string) => {
    let locationName: string = "Value not assigned";

    // Use the appropriate fetch method based on the location type
    switch (locationType) {
      case "facility":
        // console.log("Fetching Facility Name for ID:", id);
        const facilityAction = await dispatch(fetchFacilityById(id));
        if (fetchFacilityById.fulfilled.match(facilityAction)) {
          locationName = facilityAction.payload.name;
        }
        break;
      case "cell":
        const cellAction = await dispatch(fetchCellById(id));

        if (fetchCellById.fulfilled.match(cellAction)) {
          locationName = cellAction.payload.name;
        }
        break;
      case "layout":
        const layoutAction = await dispatch(fetchLayoutById(id));

        if (fetchLayoutById.fulfilled.match(layoutAction)) {
          locationName = layoutAction.payload.name;
        }
        break;
      case "line":
        const lineAction = await dispatch(fetchLineById(id));

        if (fetchLineById.fulfilled.match(lineAction)) {
          locationName = lineAction.payload.name;
        }
        break;
      default:
        break;
    }

    setLocationNames((prevNames) => ({
      ...prevNames,
      [locationType]: locationName,
    }));
  };
  // to fetch the names of machine Location based on facility,cell,layout or line
  /* eslint-disable react-hooks/exhaustive-deps */
  useEffect(() => {
    if (machineData && machineData.machineLocation) {
      if (machineData.machineLocation.facility) {
        fetchLocationName(
          machineData.machineLocation.facility as string,
          "facility"
        );
      }
      if (machineData.machineLocation.cell) {
        fetchLocationName(machineData.machineLocation.cell as string, "cell");
      }
      if (machineData.machineLocation.layout) {
        fetchLocationName(
          machineData.machineLocation.layout as string,
          "layout"
        );
      }
      if (machineData.machineLocation.line) {
        fetchLocationName(machineData.machineLocation.line as string, "line");
      }
    }
  }, [machineData]);
  /* eslint-disable react-hooks/exhaustive-deps */
  //to fetch and handle photo/images
  useEffect(() => {
    const handlePhoto = (
      photoData: string | File | MachinePhotoObject | undefined,
      setPhotoURL: (url: string | undefined) => void
    ) => {
      if (photoData) {
        if (typeof photoData === "string") {
          setPhotoURL(photoData);
        } else if (photoData instanceof File) {
          const reader = new FileReader();
          reader.onload = (event) => {
            setPhotoURL(event.target?.result as string);
          };
          reader.readAsDataURL(photoData);
        } else if (typeof photoData === "object" && "base64" in photoData) {
          const base64String = (photoData as any).base64;

          if (typeof base64String === "string") {
            setPhotoURL(`data:image/png;base64,${base64String}`);
          } else {
            setPhotoURL(undefined);
          }
        } else {
          setPhotoURL(undefined);
        }
      } else {
        setPhotoURL(undefined);
      }
    };

    if (machineData) {
      if (machineData.machinePhoto) {
        handlePhoto(machineData.machinePhoto, setMachinePhotoURL);
      } else {
        setMachinePhotoURL(undefined);
      }

      if (machineData.controllerPhoto) {
        handlePhoto(machineData.controllerPhoto, setControllerPhotoURL);
      } else {
        setControllerPhotoURL(undefined);
      }
    } else {
      setMachinePhotoURL(undefined);
      setControllerPhotoURL(undefined);
    }
  }, [machineData]);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setSelectedTab(newValue);
  };
  return (
    <Paper sx={{ marginBottom: 2 }}>
      <Dialog
        fullScreen
        open={open}
        maxWidth="sm"
        TransitionComponent={Transition}
      >
        <AppBar position="relative" sx={{ backgroundColor: "primary.main" }}>
          <Toolbar>
            <Typography
              variant="h6"
              component="div"
              sx={{ marginLeft: 2, flex: 1 }}
            >
              Machine Details
            </Typography>
            <IconButton
              edge="end"
              color="inherit"
              onClick={onClose}
              aria-label="close"
            >
              <CloseIcon />
            </IconButton>
          </Toolbar>
        </AppBar>
        <DialogContent>
          {/* //style={{ backgroundColor: "#f8f9fa" }} */}
          <Grid container spacing={2}>
            <Grid item xs={12} sm={4} md={4}>
              <Box className="card" style={{ height: "80vh" }}>
                <Divider style={{ color: "#1976d2", fontSize: "15px" }}>
                  Machine ID
                </Divider>
                <Typography
                  variant="h6"
                  style={{
                    fontSize: "13px",
                    textAlign: "center",
                  }}
                >
                  {machineData?.machineId}
                </Typography>

                <Divider style={{ color: "#1976d2", fontSize: "15px" }}>
                  Machine Photo
                </Divider>
                <Box className="card-body profile-card pt-3 d-flex flex-column align-items-center">
                  <div className="machine-card-image">
                    {machinePhotoURL ? (
                      <>
                        <img
                          src={machinePhotoURL}
                          alt={machineData?.machineName}
                          style={{
                            width: "100%",
                            height: "100%",
                            borderRadius: "20px",
                          }}
                        />
                      </>
                    ) : (
                      <div>No Machine Photo Available</div>
                    )}
                  </div>
                </Box>
                <Divider style={{ color: "#1976d2", fontSize: "15px" }}>
                  Controller Photo
                </Divider>
                <Box className="card-body profile-card pt-2 d-flex flex-column align-items-center">
                  <div className="machine-card-image">
                    {controllerPhotoURL ? (
                      <>
                        <img
                          src={controllerPhotoURL}
                          alt={machineData?.machineName}
                          style={{
                            width: "100%",
                            height: "100%",
                            borderRadius: "20px",
                          }}
                        />
                      </>
                    ) : (
                      <div>No Controller Photo Available</div>
                    )}
                  </div>
                </Box>
              </Box>
            </Grid>

            <Grid item xs={12} sm={8} md={8} className="section profile">
              <Box className="card" style={{ height: "80vh" }}>
                <Box className="card-body   profile-card pt-3 d-flex flex-column ">
                  <Tabs
                    className="nav nav-tabs nav-tabs-bordered"
                    value={selectedTab}
                    onChange={handleTabChange}
                  >
                    <Tab className="nav-item" label="Overview" />
                    <Tab className="nav-item" label="MIsc." />
                  </Tabs>
                  <div className="tab-content pt-2">
                    <div
                      className="tab-pane fade show active profile-overview"
                      id="profile-overview"
                    >
                      <TabPanel value={selectedTab} index={0}>
                        {" "}
                        <Typography variant="h5" className="card-title">
                          Machine Details
                        </Typography>
                        <div className="row">
                          <Typography className="col-lg-3 col-md-4 col-sm-4 col-xs-6  col-6 label">
                            Name
                          </Typography>
                          <Typography className="col-lg-9 col-md-8 col-sm-8 col-xs-6 col-6">
                            {machineData?.machineName || "Not Assigned"}
                          </Typography>
                        </div>
                        <div className="row">
                          <Typography className="col-lg-3 col-md-4 col-sm-4 col-xs-6  col-6 label">
                            Type
                          </Typography>
                          <Typography className="col-lg-9 col-md-8 col-sm-8 col-xs-6 col-6">
                            {machineData?.machine_type || "Not Assigned"}
                          </Typography>
                        </div>
                        <div className="row">
                          <Typography className="col-lg-3 col-md-4 col-sm-4 col-xs-6  col-6 label">
                            Location
                          </Typography>
                          <div className="col-lg-9 col-md-8 col-sm-8 col-xs-6 col-6">
                            {machineData?.machineLocation ? (
                              <div>
                                <Typography>
                                  Facility: {locationNames.facility}
                                </Typography>
                                <Typography>
                                  Cell: {locationNames.cell}
                                </Typography>{" "}
                                <Typography>
                                  Layout: {locationNames.layout}
                                </Typography>
                                <Typography>
                                  Line: {locationNames.line}
                                </Typography>
                              </div>
                            ) : (
                              "Not Assigned"
                            )}
                          </div>
                        </div>
                        <div className="row">
                          <Typography className="col-lg-3 col-md-4 col-sm-4 col-xs-6  col-6 label">
                            Make
                          </Typography>
                          <Typography className="col-lg-9 col-md-8 col-sm-8 col-xs-6 col-6">
                            {machineData?.machineMake || "Not Assigned"}
                          </Typography>
                        </div>
                        <div className="row">
                          <Typography className="col-lg-3 col-md-4 col-sm-4 col-xs-6  col-6 label">
                            Mfg. Email
                          </Typography>
                          <Typography className="col-lg-9 col-md-8 col-sm-8 col-xs-6 col-6">
                            {machineData?.mfgEmail || "Not Assigned"}
                          </Typography>
                        </div>
                        <div className="row">
                          <Typography className="col-lg-3 col-md-4 col-sm-4 col-xs-6  col-6 label">
                            Make Year
                          </Typography>
                          <Typography className="col-lg-9 col-md-8 col-sm-8 col-xs-6 col-6">
                            {machineData?.machineMakeYear || "Not Assigned"}
                          </Typography>
                        </div>
                        <div className="row">
                          <Typography className="col-lg-3 col-md-4 col-sm-4 col-xs-6  col-6 label">
                            Warranty
                          </Typography>
                          <Typography className="col-lg-9 col-md-8 col-sm-8 col-xs-6 col-6">
                            {machineData?.machineWarranty || "Not Assigned"}{" "}
                            years
                          </Typography>
                        </div>
                      </TabPanel>
                    </div>
                    <div
                      className="tab-pane fade show active profile-overview"
                      id="profile-overview"
                    >
                      <TabPanel value={selectedTab} index={1}>
                        {" "}
                        <Typography variant="h5" className="card-title">
                          Other Details
                        </Typography>
                        <div className="row">
                          <Typography className="col-lg-3 col-md-5 col-sm-6 col-xs-6  col-6 label">
                            Controller Model
                          </Typography>
                          <Typography className="col-lg-9 col-md-7 col-sm-6 col-xs-6 col-6">
                            {machineData?.controllerModel ||
                              "Not Assigned" ||
                              "Not Assigned"}
                          </Typography>
                        </div>
                        <div className="row">
                          <Typography className="col-lg-3 col-md-5 col-sm-6 col-xs-6  col-6 label">
                            Controller Make
                          </Typography>
                          <Typography className="col-lg-9 col-md-7 col-sm-6 col-xs-6 col-6">
                            {machineData?.controllerMake || "Not Assigned"}
                          </Typography>
                        </div>
                        <div className="row">
                          <Typography className="col-lg-3 col-md-5 col-sm-6 col-xs-6  col-6 label">
                            Controller Make Year
                          </Typography>
                          <Typography className="col-lg-9 col-md-7 col-sm-6 col-xs-6 col-6">
                            {machineData?.controllerMakeYear || "Not Assigned"}
                          </Typography>
                        </div>
                        <div className="row">
                          <Typography className="col-lg-3 col-md-5 col-sm-6 col-xs-6  col-6 label">
                            Input Method
                          </Typography>
                          <Typography className="col-lg-9 col-md-7 col-sm-6 col-xs-6 col-6">
                            {machineData?.inputMethod || "Not Assigned"}
                          </Typography>
                        </div>{" "}
                        <div className="row">
                          <Typography className="col-lg-3 col-md-5 col-sm-6 col-xs-6  col-6 label">
                            Power Supply Rating
                          </Typography>
                          <Typography className="col-lg-9 col-md-7 col-sm-6 col-xs-6 col-6">
                            {machineData?.powerSupplyRating || "Not Assigned"}
                          </Typography>
                        </div>{" "}
                        <div className="row">
                          <Typography className="col-lg-3 col-md-5 col-sm-6 col-xs-6  col-6 label">
                            Maintenance Person
                          </Typography>
                          <Typography className="col-lg-9 col-md-7 col-sm-6 col-xs-6 col-6">
                            {machineData?.maintenancePerson || "Not Assigned"}
                          </Typography>
                        </div>{" "}
                        <div className="row">
                          <Typography className="col-lg-3 col-md-5 col-sm-6 col-xs-6  col-6 label">
                            Maintenance Contact
                          </Typography>
                          <Typography className="col-lg-9 col-md-7 col-sm-6 col-xs-6 col-6">
                            {machineData?.maintenanceContact || "Not Assigned"}
                          </Typography>
                        </div>
                      </TabPanel>
                    </div>
                  </div>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </DialogContent>
      </Dialog>
    </Paper>
  );
};

function TabPanel(props: {
  children?: React.ReactNode;
  value: number;
  index: number;
}) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`vertical-tabpanel-${index}`}
      aria-labelledby={`vertical-tab-${index}`}
      {...other}
    >
      {value === index && <Box>{children}</Box>}
    </div>
  );
}
export default MachineDetailsModal;
