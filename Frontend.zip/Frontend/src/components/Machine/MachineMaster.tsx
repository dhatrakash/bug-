import React, { useEffect, useState } from "react";
import AllMachine from "./AllMachine";
import { useMachinewiseDispatch } from "../../redux/hooks";
import { fetchMachines } from "../../redux/machineSlice";
// eslint-disable-next-line
import NotFound from "../NotFound";
import NotFound1 from "../NotFound1";

const Machines: React.FC = () => {
  const dispatch = useMachinewiseDispatch();
  const [machineStatus, setMachineStatus] = useState<boolean>(false);
  // eslint-disable-next-line
  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  const handleMachineStatus = async () => {
    if (sessionStorage.getItem("role") === "superAdmin") {
      try {
        // Make a POST request to the API
        const response = await fetch(
          "http://localhost:3000/v1/superAdmins/viewAllMachines",
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${sessionStorage.getItem("access-token")}`,
            },
          }
        );
        response.status !== 200 ? openModal() : closeModal();
        console.warn("response " + response);
        const data = await response.json();
        setMachineStatus(data.msg);
        console.log(data.msg);
        console.warn("machinseStatus1 " + machineStatus);
      } catch (err) {
        console.log(err);
      }
    } else {
      try {
        // Make a POST request to the API
        const response = await fetch(
          "http://localhost:3000/v1/users/viewAllMachines",
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${sessionStorage.getItem("access-token")}`,
            },
          }
        );
        response.status !== 200 ? openModal() : closeModal();
        closeModal();
        console.warn("response " + response);
        const data = await response.json();
        setMachineStatus(data.msg);
        console.log(data.msg);
        console.warn("machinseStatus2 " + machineStatus);
      } catch (err) {
        console.log(err);
      }
    }
  };
  /* eslint-disable react-hooks/exhaustive-deps */
  useEffect(() => {
    handleMachineStatus();
  }, []);

  // Fetch machines when the component mounts
  useEffect(() => {
    dispatch(fetchMachines());
  }, [dispatch]);

  console.warn("machineStatus3 " + machineStatus);

  return (
    <>
      {machineStatus ? (
        <div className="machine-container">
          <h5>
            <span>All Machines</span>
          </h5>

          <AllMachine />
        </div>
      ) : (
        <div>
          {/* <h3>...Loading</h3> */}
          <NotFound1 />
        </div>
      )}
      {/* {!machineStatus && <NotFound1/>} */}
    </>
  );
};

export default Machines;
