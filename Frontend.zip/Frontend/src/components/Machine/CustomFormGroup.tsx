import React, { type ComponentPropsWithoutRef } from "react";
import { Form } from "react-bootstrap";

type CustomFormGroupProps = {
  controlId: string;
  label: string;
  // type: "text" | "number" | "select" | "email"; // Adjust the type based on your needs
  name: string;
  value?: string | number;
  onChange: (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => void;
  options?: string[]; // Only for type 'select'
  placeholder?: string;
  pattern?: string;
} & ComponentPropsWithoutRef<"input">;

const CustomFormGroup: React.FC<CustomFormGroupProps> = ({
  controlId,
  label,
  type,
  name,
  value,
  onChange,
  options,
  placeholder,
}) => (
  <Form.Group className="mb-3" controlId={controlId}>
    <Form.Label>{label}</Form.Label>
    {type === "select" ? (
      <Form.Control
        as="select"
        name={name}
        value={value as string}
        onChange={onChange}
      >
        <option value="">Select</option>
        {options?.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </Form.Control>
    ) : (
      <Form.Control
        type={type}
        placeholder={placeholder || `Enter ${label}`}
        name={name}
        value={value as string}
        onChange={onChange}
      />
    )}
  </Form.Group>
);

export default CustomFormGroup;
