import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
} from "@mui/material";

interface ArchiveAssociationModalProps {
  open: boolean;
  onClose: () => void;
  onArchive: () => void;
}

const ArchiveMachineGatewayAssociation: React.FC<
  ArchiveAssociationModalProps
> = ({ open, onClose, onArchive }) => {
  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>Confirm Archive</DialogTitle>
      <DialogContent>
        <DialogContentText>
          Your Association will be Archived!!!! Are yo Sure?
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="primary">
          Cancel
        </Button>
        <Button onClick={onArchive} color="primary">
          Archive
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ArchiveMachineGatewayAssociation;
