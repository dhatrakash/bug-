import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../../redux/store";
import { fetchGateways } from "../../../redux/gatewaySlice";
import { fetchMachines } from "../../../redux/machineSlice";
import { toast } from "react-toastify";
import {
  Gateway,
  GatewaySensorAssociation,
  Machine,
  MachineGatewayAssociation,
} from "../../../redux/types";
import { fetchAllMappings } from "../../../redux/gatewaySensorAsscSlice";
import { createMachineGatewayAssociation } from "../../../redux/machineGatewayAsscSlice"; // Import the createMachineGatewayAssociation action

interface CreateMachineGatewayAssociationProps {
  open: boolean;
  onClose: () => void;
  machineData?: Machine | null;
}

const initialGatewayData: Gateway = {
  macId: "",
  name: "",
  ip: "",
  port: 0,
  gatewayId: "",
  isActive: false,
};
// eslint-disable-next-line
const initialGatewaySensorAssociationData: GatewaySensorAssociation = {
  mappingId: "",
  sensorNodeName: "",
  gatewayId: "",
  sensorId: "",
  slaveId: "",
  tag: "",
};
const initialMachineGatewayAssociationData: MachineGatewayAssociation = {
  sensorNodeName: "",
  machineMappingId: "",
  machineId: "",
  mappingId: "",
  // gatewayId: "",
};

const CreateMachineGatewayAssociation: React.FC<
  CreateMachineGatewayAssociationProps
> = ({ open, onClose, machineData }) => {
  const dispatch = useDispatch();

  const { gateways } = useSelector((state: RootState) => state.gateway);
  const [gatewayData, setGatewayData] = useState<Gateway>(initialGatewayData);

  const { gatewaySensorAssociations } = useSelector(
    (state: RootState) => state.gatewaySensorAssociation
  );

  const [formData, setFormData] = useState<MachineGatewayAssociation>(
    initialMachineGatewayAssociationData
  );

  const [filteredSensorNodeNames, setFilteredSensorNodeNames] = useState<
    string[]
  >([]);

  useEffect(() => {
    dispatch(fetchGateways() as any);

    dispatch(fetchAllMappings() as any).then((result: any) => {
      // console.log("fetchAllMappings result:", result);

      if (Array.isArray(result.payload)) {
        dispatch({
          type: "gatewaySensorAssociation/setGatewaySensorAssociations",
          payload: result.payload,
        } as any);
      }
    });

    // Set the initial machineId here based on machineData
    setFormData((prevFormData) => ({
      ...prevFormData,
      machineId: machineData?.machineId || "",
    }));
  }, [dispatch, machineData]);

  // const handleGatewayChange = (value: string) => {
  //   const updatedGateway = { ...gatewayData, macId: value };
  //   setGatewayData(updatedGateway);
  // };
  /* eslint-disable react-hooks/exhaustive-deps */
  useEffect(() => {
    if (machineData?.gatewayId) {
      const selectedGateway = gateways?.find(
        (gateway) => gateway.gatewayId === machineData.gatewayId
      );
      if (selectedGateway) {
        setGatewayData(selectedGateway);
      }
      const filteredNames = (
        machineData?.gatewayId
          ? gatewaySensorAssociations
              ?.filter((gsa) => gsa.gatewayId === machineData.gatewayId)
              .map((gsa) => gsa.sensorNodeName)
          : []
      ) as string[];

      setFilteredSensorNodeNames(filteredNames);
    } else {
      // If machineData doesn't have a gatewayId, reset the filtered names
      setFilteredSensorNodeNames([]);
    }
  }, [machineData?.gatewayId, gatewaySensorAssociations]);

  const handleNodeNameChange = (value: string) => {
    console.log("Selected Sensor NodeName:", value);
    setFormData({
      ...formData,
      sensorNodeName: value,
    });
  };

  const handleSubmit = async () => {
    try {
      // const selectedGateway = gateways?.find(
      //   (gateway) => gateway.macId === gatewayData.macId
      // );

      // if (!selectedGateway) {
      //   throw new Error("Selected gateway not found.");
      // }

      // const gatewayId: string = selectedGateway?.gatewayId ?? "";

      const selectedSensorNode = gatewaySensorAssociations?.find(
        (gsa) => gsa.sensorNodeName === formData.sensorNodeName
      );

      if (!selectedSensorNode) {
        throw new Error("Selected sensorNode not found.");
      }

      const mappingId: string = selectedSensorNode?.mappingId ?? "";

      const associationData = {
        machineId: formData.machineId,
        mappingId: mappingId,
        sensorNodeName: formData.sensorNodeName,
      };

      await dispatch(createMachineGatewayAssociation(associationData) as any);
      onClose();
      await dispatch(fetchMachines() as any);
      setFormData(initialMachineGatewayAssociationData);

      toast.success("Gateway-Sensors assigned successfully!");
    } catch (error) {
      toast.error("Something went wrong with the association!");
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm">
      <DialogTitle
        style={{ color: "#1976d2", textAlign: "center", fontWeight: "bold" }}
      >
        Assign Gateway-Sensor to {machineData?.machineName}
      </DialogTitle>
      <DialogContent>
        <form style={{ padding: "20px" }} onSubmit={handleSubmit}>
          <Grid container spacing={1}>
            <Grid item xs={6}>
              <TextField
                label="Machine Name"
                size="small"
                name="machineName"
                value={machineData?.machineName}
                fullWidth
                margin="normal"
                disabled
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Machine Id"
                name="machineId"
                size="small"
                value={machineData?.machineId}
                fullWidth
                margin="normal"
                disabled
              />
            </Grid>
            {/* <FormControl fullWidth size="small" margin="normal">
                <InputLabel>Select Gateway</InputLabel>
                <Select
                  id="demo-simple-select"
                  value={gatewayData.macId}
                  label="Select Gateway"
                  onChange={(e) =>
                    handleGatewayChange(e.target.value as string)
                  }
                >
                  {gateways?.map((gateway) => (
                    <MenuItem key={gateway.macId} value={gateway.macId}>
                      {gateway.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl> */}
            {machineData?.gatewayId && gatewayData.macId ? (
              <>
                <Grid item xs={6}>
                  <TextField
                    label="Gateway Id"
                    size="small"
                    name="gatewayName"
                    value={machineData?.gatewayId}
                    fullWidth
                    margin="normal"
                    disabled
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    label="Gateway MAC ID"
                    size="small"
                    name="gatewayMacId"
                    value={gatewayData.macId}
                    fullWidth
                    margin="normal"
                    disabled
                  />
                </Grid>
              </>
            ) : (
              <Grid item xs={12}>
                <Typography
                  variant="body1"
                  color="textSecondary"
                  textAlign={"center"}
                >
                  {machineData?.gatewayId
                    ? "No MAC ID available for this gateway."
                    : "No gateway is assigned to this machine."}
                </Typography>
              </Grid>
            )}
            {filteredSensorNodeNames.length > 0 ? (
              <Grid item xs={6}>
                <FormControl fullWidth size="small" margin="normal">
                  <InputLabel>Select Sensor NodeName</InputLabel>
                  <Select
                    value={formData.sensorNodeName}
                    label="Select Sensor Nodename"
                    onChange={(e) =>
                      handleNodeNameChange(e.target.value as string)
                    }
                  >
                    {filteredSensorNodeNames.map((nodeName) => (
                      <MenuItem key={nodeName} value={nodeName}>
                        {nodeName}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            ) : (
              <Grid item xs={12}>
                <Typography
                  variant="body1"
                  color="textSecondary"
                  textAlign="center"
                >
                  {machineData?.gatewayId
                    ? "No sensor node names available for this gateway."
                    : "Please ! Assign a Gateway to your Machine"}
                </Typography>
              </Grid>
            )}
          </Grid>
        </form>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="primary">
          Cancel
        </Button>
        <Button onClick={handleSubmit} color="primary">
          Assign Sensors
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CreateMachineGatewayAssociation;
