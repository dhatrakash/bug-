import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { RootState } from "../../../redux/store";
import DetailsModal from "./SlaveDetailsModal"; // Import the modal component
import { Machine, MachineGatewayAssociation } from "../../../redux/types";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Paper,
  Typography,
  IconButton,
  Tooltip,
} from "@mui/material";
import {
  Delete as DeleteIcon,
  Archive as ArchiveIcon,
  Visibility as ViewIcon,
} from "@mui/icons-material";

import {
  archiveMachineGatewayAssociation,
  deleteMachineGatewayAssociation,
  fetchMachineGatewayAssociationById,
} from "../../../redux/machineGatewayAsscSlice";
import ArchiveMachineGatewayAssociation from "../ArchiveMachineGatewayAssociation";
import DeleteMachineGatewayAssociation from "../DeleteMachineGatewayAssociation";
import { toast } from "react-toastify";

const MachineGatewayAssociationDetails: React.FC = () => {
  const { machineId } = useParams<{ machineId: string }>();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [selectedAssociation, setSelectedAssociation] = useState<any>(null);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [selectedAssociationForDelete, setSelectedAssociationForDelete] =
    useState<MachineGatewayAssociation | null>(null);
  // eslint-disable-next-line
  const [expandedAccordion, setExpandedAccordion] = useState<string | false>(
    false
  );
  const [archiveModalOpen, setArchiveModalOpen] = useState(false);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false); // State for the modal
  const [selectedDetails, setSelectedDetails] = useState<{
    machineId: string;
    mappingId: string;
  } | null>(null);

  useEffect(() => {
    if (machineId) {
      dispatch(fetchMachineGatewayAssociationById(machineId) as any)
        .then((response: any) => {
          console.log("Fetch response:", response);
        })
        .catch((error: any) => {
          console.error("Fetch error:", error);
        });
    }
  }, [dispatch, machineId]);

  const selectedMachine: Machine | null | undefined = useSelector(
    (state: RootState) =>
      state.machine.machines.find(
        (machine: Machine) => machine.machineId === machineId
      )
  );
  const machineGatewayAssociations: MachineGatewayAssociation[] | null =
    useSelector(
      (state: RootState) =>
        state.machineGatewayAssociation.machineGatewayAssociations
    );

  // Create a separate variable to store the data received from dispatch
  const fetchedAssociations = machineGatewayAssociations || [];

  console.log("machineGatewayAssociations", fetchedAssociations);

  if (!selectedMachine) {
    return <Typography variant="h5">Machine not found</Typography>;
  }

  const handleDeleteClick = (association: MachineGatewayAssociation) => {
    setSelectedAssociationForDelete(association);
    setDeleteModalOpen(true);
  };

  const handleCloseDeleteModal = () => {
    setSelectedAssociationForDelete(null);
    setDeleteModalOpen(false);
  };

  const handleDeleteAssociation = async () => {
    if (
      !selectedAssociationForDelete ||
      !selectedAssociationForDelete.mappingId
    ) {
      // Handle the case where selectedAssociationForDelete or mappingId is missing
      return;
    }

    try {
      // Dispatch the delete action with machineId and sensorNodeName
      await dispatch(
        deleteMachineGatewayAssociation({
          machineId: selectedAssociationForDelete.machineId,
          sensorNodeName: selectedAssociationForDelete.sensorNodeName,
        }) as any
      );
      navigate(`/machineGatewayAssociation/${machineId}`);
      toast.success("Association deleted successfully");
    } catch (error) {
      // Handle any errors
      console.error("Error deleting association:", error);
      toast.error("Error deleting association. Please try again.");
    }

    // Close the delete confirmation modal
    handleCloseDeleteModal();
  };

  const handleArchiveClick = (association: MachineGatewayAssociation) => {
    setSelectedAssociation(association);
    setArchiveModalOpen(true);
  };
  const handleCloseArchiveModal = () => {
    setSelectedAssociation(null);
    setArchiveModalOpen(false);
  };
  const handleArchiveAssociation = async () => {
    if (!selectedAssociation || !selectedAssociation.mappingId) {
      return;
    }

    try {
      // Dispatch the archive action
      await dispatch(
        archiveMachineGatewayAssociation({
          machineId: selectedAssociation.machineId,
          sensorNodeName: selectedAssociation.sensorNodeName,
        }) as any
      );
      navigate(`/machineGatewayAssociation/${machineId}`);
      toast.success("Association archived!!!");
    } catch (error) {
      // Handle any errors
      console.error("Error while archive:", error);
      toast.error("Error while archive.");
    }

    // Close the delete confirmation modal
    handleCloseArchiveModal();
  };
  // Function to handle opening the accordion and modal
  const handleAccordionClick = (machineId: string, mappingId: string) => {
    setSelectedDetails({ machineId, mappingId });
    setExpandedAccordion(machineId); // Expand the specific accordion
    setDetailsModalOpen(true); // Open the modal
  };
  // eslint-disable-next-line
  const handleOpenDetailsModal = (machineId: string, mappingId: string) => {
    setSelectedDetails({ machineId, mappingId });
    setDetailsModalOpen(true); // Open the modal
  };

  // Function to close the modal
  const handleCloseDetailsModal = () => {
    setSelectedDetails(null);
    setDetailsModalOpen(false);
  };

  return (
    <div className="gateway-sensor-details">
      <h2 style={{ color: "#1976d2", textAlign: "center", fontWeight: "500" }}>
        Machine Gateway Associations Slaves
      </h2>
      <Paper className="details-paper">
        <Typography variant="h5" paddingBottom={"20px"}>
          Machine Name: {selectedMachine.machineName}
        </Typography>{" "}
        {/* <div className="filter-fields">ADD FILTERS</div> */}
        {/* {console.log("Should render table:", fetchedAssociations)} */}
        {/* Render the table if data is available */}
        {fetchedAssociations.length > 0 ? (
          <Table className="details-table">
            <TableHead>
              <TableRow>
                <TableCell>Machine ID</TableCell>
                <TableCell>Gateway Sensor Mapping ID</TableCell>
                <TableCell>Sensor Node Name</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {machineGatewayAssociations &&
                machineGatewayAssociations.flat().map((association) => (
                  <TableRow key={association._id}>
                    <TableCell>{association.machineId}</TableCell>
                    <TableCell>{association.mappingId}</TableCell>
                    <TableCell>{association.sensorNodeName}</TableCell>
                    {/* Add more cells for other properties if needed */}
                    <TableCell>
                      {" "}
                      <Tooltip title="See Details">
                        <IconButton
                          onClick={() =>
                            handleAccordionClick(
                              association.machineId,
                              association.mappingId
                            )
                          }
                        >
                          <ViewIcon />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Archive " arrow>
                        <IconButton
                          color="primary"
                          onClick={() => handleArchiveClick(association)}
                        >
                          <ArchiveIcon />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete Association permanently">
                        <IconButton
                          color="error"
                          onClick={() => handleDeleteClick(association)}
                        >
                          <DeleteIcon />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}{" "}
            </TableBody>
          </Table>
        ) : (
          <Typography variant="h6">No associations found.</Typography>
        )}
      </Paper>
      <DeleteMachineGatewayAssociation
        open={deleteModalOpen}
        onClose={handleCloseDeleteModal}
        onDelete={handleDeleteAssociation}
      />
      <ArchiveMachineGatewayAssociation
        open={archiveModalOpen}
        onClose={handleCloseArchiveModal}
        onArchive={handleArchiveAssociation}
      />{" "}
      {/* Render the details modal */}
      {selectedDetails && (
        <DetailsModal
          open={detailsModalOpen}
          onClose={handleCloseDetailsModal}
          machineId={selectedDetails.machineId}
          mappingId={selectedDetails.mappingId}
        />
      )}
    </div>
  );
};

export default MachineGatewayAssociationDetails;
