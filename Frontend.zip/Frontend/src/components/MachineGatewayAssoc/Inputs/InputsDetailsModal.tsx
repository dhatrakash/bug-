import React, { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { fetchMachineById } from "../../../redux/machineSlice";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Divider,
} from "@mui/material";

import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { getGatewayInputsAssociationById } from "../../../redux/gatewayInputAsscSlice";

interface DetailsModalProps {
  open: boolean;
  onClose: () => void;
  machineId: string;
  mappingId: string;
}

const DetailsModal: React.FC<DetailsModalProps> = ({
  open,
  onClose,
  machineId,
  mappingId,
}) => {
  const dispatch = useDispatch();
  const [machineDetails, setMachineDetails] = useState<any>(null);
  const [associationDetails, setAssociationDetails] = useState<any>(null);
  useEffect(() => {
    if (machineId) {
      // Dispatch the action to fetch machine details
      dispatch(fetchMachineById(machineId) as any)
        .then((response: any) => {
          console.log("Machine Details:", response.payload);
          // Set the response data to the state
          setMachineDetails(response.payload);
        })
        .catch((error: any) => {
          console.error("Error fetching machine details:", error);
        });
    }
  }, [dispatch, machineId]);
  useEffect(() => {
    if (mappingId) {
      dispatch(getGatewayInputsAssociationById(mappingId) as any)
        .then((response: any) => {
          console.log("Association Details:", response.payload);
          // Set the response data to the state
          setAssociationDetails(response.payload);
        })
        .catch((error: any) => {
          console.error("Error fetching association details:", error);
        });
    }
  }, [dispatch, mappingId]);
  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle
        style={{ color: "#1976d2", textAlign: "center", fontWeight: "bold" }}
      >
        Additional Details
      </DialogTitle>
      <DialogContent>
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            Details for Machine ID: {machineId}
          </AccordionSummary>
          <AccordionDetails>
            {machineDetails ? (
              <>
                {" "}
                <Divider
                  style={{
                    color: "#1976d2",
                    paddingTop: "10px",
                    paddingBottom: "10px",
                  }}
                >
                  <Typography
                    variant="h4"
                    fontSize="20px"
                    style={{ color: "#1976d2" }}
                  >
                    Machine Details
                  </Typography>
                </Divider>
                <Typography>Machine ID: {machineId}</Typography>
                {machineDetails.machineName && (
                  <Typography>
                    Machine Name: {machineDetails.machineName}
                  </Typography>
                )}
                {machineDetails.machine_type && (
                  <Typography>
                    Machine Type: {machineDetails.machine_type}
                  </Typography>
                )}
              </>
            ) : (
              <Typography>Loading Machine Details...</Typography>
            )}
          </AccordionDetails>
        </Accordion>
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            Details for Mapping ID: {mappingId}
          </AccordionSummary>
          <Divider />
          <AccordionDetails>
            {associationDetails ? (
              <>
                {" "}
                <Divider
                  style={{
                    color: "#1976d2",
                    paddingTop: "10px",
                    paddingBottom: "10px",
                  }}
                >
                  <Typography
                    variant="h4"
                    fontSize="20px"
                    style={{ color: "#1976d2" }}
                  >
                    Gateway Sensor Inputs Mapping Details
                  </Typography>
                </Divider>
                <Typography>Mapping ID: {mappingId}</Typography>
                <Typography>Di Id: {associationDetails.diId}</Typography>
                <Typography>Tag: {associationDetails.tag}</Typography>{" "}
                {associationDetails.sensorNodeName && (
                  <Typography>
                    Sensor Node Name: {associationDetails.sensorNodeName}
                  </Typography>
                )}{" "}
                <Divider
                  style={{
                    color: "#1976d2",
                    paddingTop: "10px",
                    paddingBottom: "10px",
                  }}
                >
                  <Typography
                    variant="h4"
                    fontSize="20px"
                    style={{ color: "#1976d2" }}
                  >
                    Gateway Details
                  </Typography>
                </Divider>
                {associationDetails.gatewayId ? (
                  <>
                    <Typography>
                      Gateway Mac ID: {associationDetails.gatewayId.macId}
                    </Typography>
                    <Typography>
                      Gateway Name: {associationDetails.gatewayId.name}
                    </Typography>
                    <Typography>
                      Gateway IP: {associationDetails.gatewayId.ip}
                    </Typography>
                    <Typography>
                      Gateway Port: {associationDetails.gatewayId.port}
                    </Typography>
                  </>
                ) : (
                  <Typography>Error: Gateway Details Not Found</Typography>
                )}
                <Divider
                  style={{
                    color: "#1976d2",
                    paddingTop: "10px",
                    paddingBottom: "10px",
                  }}
                >
                  <Typography
                    variant="h4"
                    fontSize="20px"
                    style={{ color: "#1976d2" }}
                  >
                    Sensor Details
                  </Typography>
                </Divider>
                {associationDetails.sensorId ? (
                  <>
                    <Typography>
                      Sensor Name: {associationDetails.sensorId.sensorName}
                    </Typography>
                    <Typography>
                      Sensor Type: {associationDetails.sensorId.sensorType}
                    </Typography>
                  </>
                ) : (
                  <Typography>Error: Sensor Details Not Found</Typography>
                )}
                {associationDetails.sensorNodeName && (
                  <Typography>
                    Sensor Node Name: {associationDetails.sensorNodeName}
                  </Typography>
                )}
              </>
            ) : (
              <Typography>Loading Association Details...</Typography>
            )}
          </AccordionDetails>
        </Accordion>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="primary">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DetailsModal;
