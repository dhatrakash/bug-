import axios from "axios";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { MachineMapping } from "./types";

interface MachineMappingState {
  machineMappings: MachineMapping[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: MachineMappingState = {
  machineMappings: [],
  loading: false,
  error: null,
};

// Create ;👍
export const createMachineMapping = createAsyncThunk(
  "machineMapping/createMachineMapping",
  async (machineMappingData: MachineMapping, { rejectWithValue }) => {
    try {
      const response = await axios.post<MachineMapping>(
        `${process.env.REACT_APP_BASE_URL}/v1/machineMappings/mappings`,
        machineMappingData
      );

      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while creating the machineMapping"
      );
    }
  }
);

// fetch by machineId👍
export const fetchActiveMappingsByMachineId = createAsyncThunk(
  "machineMapping/fetchMachineMappingByMachineId",
  async (machineId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/machineMappings/mappings/active/${machineId}`
      );
      console.log("response received", response);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the machineMapping by ID"
      );
    }
  }
);
// fetch all by machine mapping id
// export const findAllMachineMappings = createAsyncThunk(
//   "machineMapping/findAllMachineMappings",
//   async (_, { rejectWithValue }) => {
//     try {
//       const response = await axios.get(
//         `${process.env.REACT_APP_BASE_URL}/v1/machineMappings/`
//       );
//       return response.data;
//     } catch (error) {
//       return rejectWithValue("An error occurred while fetching facilities");
//     }
//   }
// );

// find mapping by machine mapping id
export const findMappingByMachineMappingId = createAsyncThunk(
  "machineMapping/findMappingByMachineMappingId",
  async (machineMappingId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/machineMappings/mappings/${machineMappingId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the machineMapping by ID"
      );
    }
  }
);

// permanent delete by machine mapping id 👍
export const deleteMachineMapping = createAsyncThunk(
  "machineMapping/deleteMachineMapping",
  async (
    {
      machineMappingId,
    }: {
      machineMappingId: string;
    },
    { rejectWithValue }
  ) => {
    try {
      await axios.delete(
        `${process.env.REACT_APP_BASE_URL}/v1/machineMappings/mappings/${machineMappingId}`,
        {
          data: {
            machineMappingId,
          },
        }
      );
      return machineMappingId;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while deleting the machineMapping"
      );
    }
  }
);

// soft-delete or archive  by machine mapping id 👍
export const archiveMachineMapping = createAsyncThunk(
  "machineMapping/archiveMachineMapping",
  async (
    {
      machineMappingId,
    }: {
      machineMappingId: string;
    },
    { rejectWithValue }
  ) => {
    try {
      await axios.put(
        `${process.env.REACT_APP_BASE_URL}/v1/machineMappings/mappings/${machineMappingId}/`,
        {
          data: {
            machineMappingId,
          },
        }
      );
      return machineMappingId;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while archiving the machineMapping"
      );
    }
  }
);
// soft-delete or archive  specific mapping in machine mapping by machinemappingid and mappingid 👍
export const archiveMapping = createAsyncThunk(
  "machineMapping/archiveMapping",
  async (
    {
      machineMappingId,
      mappingId,
    }: {
      machineMappingId: string;
      mappingId: string;
    },
    { rejectWithValue }
  ) => {
    try {
      console.log("Archiving mapping...", machineMappingId, mappingId);

      await axios.patch(
        `${process.env.REACT_APP_BASE_URL}/v1/machineMappings/mappings/${machineMappingId}/${mappingId}`,
        {
          data: {
            machineMappingId,
            mappingId,
          },
        }
      );
      console.log("Mapping archived successfully!");
      return mappingId;
    } catch (error: any) {
      console.error("Error while archiving the mapping:", error);
      console.error("Detailed error response:", error.response);
      return rejectWithValue("An error occurred while archiving the Mapping");
    }
  }
);

const machineMappingSlice = createSlice({
  name: "machineMapping",
  initialState,
  reducers: {
    setMachineMapping: (state, action: PayloadAction<MachineMapping[]>) => {
      state.machineMappings = action.payload;
    },
    clearMachineMapping: (state, action: PayloadAction<string>) => {
      const machineMappingId = action.payload;

      state.machineMappings = state.machineMappings!.filter(
        (machineMapping) => machineMapping._id !== machineMappingId
      );
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createMachineMapping.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createMachineMapping.fulfilled, (state, action) => {
        state.loading = false;
        state.machineMappings?.push(action.payload);
      })
      .addCase(createMachineMapping.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to create machineMapping";
      })

      .addCase(findMappingByMachineMappingId.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(findMappingByMachineMappingId.fulfilled, (state, action) => {
        state.loading = false;
        state.machineMappings = action.payload;
      })
      .addCase(findMappingByMachineMappingId.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch machineMappings";
      })

      .addCase(deleteMachineMapping.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteMachineMapping.fulfilled, (state, action) => {
        state.loading = false;
        const deletedMachineMappingId = action.payload;
        if (state.machineMappings) {
          // Check if machineMapping is not null
          state.machineMappings = state.machineMappings.filter(
            (machineMapping) =>
              machineMapping.machineMappingId !== deletedMachineMappingId
          );
        }
      })
      .addCase(deleteMachineMapping.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      /////////////////////////////////////////////////////////
      .addCase(archiveMachineMapping.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(archiveMachineMapping.fulfilled, (state, action) => {
        state.loading = false;
        const archiveMachineMappingId = action.payload;
        if (state.machineMappings) {
          // Check if machineMapping is not null
          state.machineMappings = state.machineMappings.filter(
            (machineMapping) =>
              machineMapping.machineMappingId !== archiveMachineMappingId
          );
        }
      })
      .addCase(archiveMachineMapping.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      ////////////////////////////////////////////////////
      .addCase(archiveMapping.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(archiveMapping.fulfilled, (state, action) => {
        state.loading = false;
        const archiveMappingId = action.payload;
        if (state.machineMappings) {
          // Check if machineMappings is not null
          state.machineMappings = state.machineMappings.map((mapping) => ({
            ...mapping,
            mappings: mapping.mappings.filter(
              (item) => item.mappingId !== archiveMappingId
            ),
          }));
        }
      })

      .addCase(archiveMapping.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(fetchActiveMappingsByMachineId.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchActiveMappingsByMachineId.fulfilled, (state, action) => {
        state.loading = false;
        // Update the state with the fetched machineMapping data
        state.machineMappings = [action.payload];
      })
      .addCase(fetchActiveMappingsByMachineId.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to fetch machineMapping by ID";
      });
  },
});

export default machineMappingSlice.reducer;
