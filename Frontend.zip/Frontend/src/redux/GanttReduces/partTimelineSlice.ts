import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import moment from 'moment-timezone';

interface FetchPartTimelineDataArgs {
  hours: number;
  machine: string;
  observationName: string;
}

interface ApiResponseItem {
  time: string; // Change the type of 'time' to string
  partName: string;
  // Add other fields from your API response here
}

export const fetchPartTimelineData = createAsyncThunk<
  ApiResponseItem[],
  FetchPartTimelineDataArgs
>('partTimeline/fetchData', async ({ hours, machine, observationName }) => {
  try {
    const response = await axios.get(
      `http://localhost:3000/v1/fanuc/data/${machine}/${hours}/${observationName}`
    );

    console.log('API Response:', response.data); // Log the API response

    const convertedData = response.data.map((item: ApiResponseItem) => {
      // No need to convert the time in this slice
      return item;
    });

    console.log('Converted Data:', convertedData); // Log the converted data

    return convertedData;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
});

interface PartTimelineState {
  data: { [key: string]: ApiResponseItem[] };
  status: 'idle' | 'loading' | 'failed';
  message: string;
}

const initialState: PartTimelineState = {
  data: {},
  status: 'idle',
  message: '',
};

const partTimelineSlice = createSlice({
  name: 'partTimeline',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchPartTimelineData.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchPartTimelineData.fulfilled, (state, action) => {
        const machine = action.meta.arg.machine;
        state.data[machine] = action.payload;
        state.status = 'idle';
      })
      .addCase(fetchPartTimelineData.rejected, (state, action) => {
        const machine = action.meta.arg.machine;
        state.data[machine] = [];
        state.status = 'failed';
        state.message = 'An error occurred while fetching the data.';
      });
  },
});

export default partTimelineSlice.reducer;



// import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
// import axios from 'axios';

// interface FetchPartTimelineDataArgs {
//   hours: number;
//   machine: string;
//   observationName: string;
// }

// interface ApiResponseItem {
//   time: string;
//   partName: string;
//   sweep: boolean | null; // Include the 'sweep' field as it can be true, false, or null
// }

// export const fetchPartTimelineData = createAsyncThunk<
//   ApiResponseItem[],
//   FetchPartTimelineDataArgs
// >('partTimeline/fetchData', async ({ hours, machine, observationName }) => {
//   try {
//     const response = await axios.get(
//       `http://localhost:3000/v1/fanuc/data/${machine}/${hours}/${observationName}`
//     );

//     console.log('API Response:', response.data); // Log the API response

//     // Directly return the data as it should already contain the 'sweep' field
//     return response.data;
//   } catch (error) {
//     console.error('API Error:', error);
//     throw error;
//   }
// });

// interface PartTimelineState {
//   data: { [key: string]: ApiResponseItem[] };
//   status: 'idle' | 'loading' | 'failed';
//   message: string;
// }

// const initialState: PartTimelineState = {
//   data: {},
//   status: 'idle',
//   message: '',
// };

// const partTimelineSlice = createSlice({
//   name: 'partTimeline',
//   initialState,
//   reducers: {},
//   extraReducers: (builder) => {
//     builder
//       .addCase(fetchPartTimelineData.pending, (state) => {
//         state.status = 'loading';
//       })
//       .addCase(fetchPartTimelineData.fulfilled, (state, action) => {
//         const machine = action.meta.arg.machine;
//         // Ensure the data for the specific machine is updated with the new payload
//         state.data[machine] = action.payload;
//         state.status = 'idle';
//       })
//       .addCase(fetchPartTimelineData.rejected, (state, action) => {
//         const machine = action.meta.arg.machine;
//         // On failure, clear the data for the specific machine and set the status
//         state.data[machine] = [];
//         state.status = 'failed';
//         state.message = action.error.message || 'An error occurred while fetching the data.';
//       });
//   },
// });

// export default partTimelineSlice.reducer;
