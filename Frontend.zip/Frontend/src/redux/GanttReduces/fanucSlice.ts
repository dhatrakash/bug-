import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import moment from 'moment-timezone';

interface FetchFanucDataArgs {
  hours: number;
  machine: string;
}

interface FanucData {
  time: number;
  run: number | null;
  feed: number | null;
}

interface ApiResponseData {
  time: string;
  run: number | null;
  feed: number | null;
}

interface FanucState {
  data: { [key: string]: FanucData[] };
  status: 'idle' | 'loading' | 'failed';
  message: string;
}

const initialState: FanucState = {
  data: {},
  status: 'idle',
  message: '',
};

export const fetchFanucData = createAsyncThunk(
  'fanuc/fetchData',
  async ({ hours, machine }: FetchFanucDataArgs) => {
    const response = await axios.get(`http://localhost:3000/v1/fanuc/feed_uptime/${machine}/${hours}`);
    return response.data.map((item: ApiResponseData) => ({
      time: moment(item.time).valueOf(),
      run: item.run,
      feed: item.feed 
    }));
  }
);

const fanucSlice = createSlice({
  name: 'fanuc',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchFanucData.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchFanucData.fulfilled, (state, action) => {
        const machine = action.meta.arg.machine;
        state.data[machine] = action.payload;
        state.status = 'idle';
        state.message = '';
      })
      .addCase(fetchFanucData.rejected, (state, action) => {
        const machine = action.meta.arg.machine;
        state.status = 'failed';
        state.data[machine] = [];
        state.message = action.error.message || 'Failed to fetch data';
      });
  },
});

export default fanucSlice.reducer;



// import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
// import axios from 'axios';
// import moment from 'moment-timezone';

// interface FetchFanucDataArgs {
//   hours: number;
//   machine: string;
// }

// interface FanucData {
//   time: number;
//   run: number | null;
//   feed: number | null;
//   sweep: boolean
// }

// interface ApiResponseData {
//   time: string;
//   run: number | null;
//   feed: number | null;
//   sweep: boolean
// }

// interface FanucState {
//   data: { [key: string]: FanucData[] };
//   status: 'idle' | 'loading' | 'failed';
//   message: string;
// }

// const initialState: FanucState = {
//   data: {},
//   status: 'idle',
//   message: '',
// };

// export const fetchFanucData = createAsyncThunk(
//   'fanuc/fetchData',
//   async ({ hours, machine }: FetchFanucDataArgs) => {
//     const response = await axios.get(`http://localhost:3000/v1/fanuc/feed_uptime/${machine}/${hours}`);
//     return response.data.map((item: ApiResponseData) => ({
//       time: moment(item.time).valueOf(),
//       run: item.run,
//       feed: item.feed,
//       sweep: item.sweep // Adding sweep here
//     }));
//   }
// );


// const fanucSlice = createSlice({
//   name: 'fanuc',
//   initialState,
//   reducers: {},
//   extraReducers: (builder) => {
//     builder
//       .addCase(fetchFanucData.pending, (state) => {
//         state.status = 'loading';
//       })
//       .addCase(fetchFanucData.fulfilled, (state, action) => {
//         const machine = action.meta.arg.machine;
//         state.data[machine] = action.payload;
//         state.status = 'idle';
//         state.message = '';
//       })
//       .addCase(fetchFanucData.rejected, (state, action) => {
//         const machine = action.meta.arg.machine;
//         state.status = 'failed';
//         state.data[machine] = [];
//         state.message = action.error.message || 'Failed to fetch data';
//       });
//   },
// });

// export default fanucSlice.reducer;






