import axios from "axios";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { GatewayInputsAssociation } from "./types";

interface GatewayInputsAssociationState {
  gatewayInputsAssociations: GatewayInputsAssociation[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: GatewayInputsAssociationState = {
  gatewayInputsAssociations: [],
  loading: false,
  error: null,
};

// Create
export const createGatewayInputsAssociation = createAsyncThunk(
  "gatewayInputsAssociation/createGatewayInputsAssociation",
  async (
    gatewayInputsAssociationData: GatewayInputsAssociation,
    { rejectWithValue }
  ) => {
    try {
      console.log(gatewayInputsAssociationData);
      const response = await axios.post<GatewayInputsAssociation>(
        "http://localhost:3000/v1/gatewayInputs/",
        gatewayInputsAssociationData
      );
      //if (response.data)

      console.log(response);
      return response.data;
    } catch (error: any) {
      if (error.response && error.response.data && error.response.data.error) {
        // Handle the specific error case where the association already exists
        return rejectWithValue(error.response.data.error);
      }

      // Handle other errors
      return rejectWithValue(
        "An error occurred while creating the gatewayInputsAssociation"
      );
    }
  }
);

// fetch

export const fetchGatewayInputsAssociationById = createAsyncThunk(
  "gatewayInputsAssociation/fetchGatewayInputsAssociationById",
  async (gatewayInputsAssociationId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:3000/v1/gatewayInputs/findGatewayInputsAssociationById/${gatewayInputsAssociationId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the gatewayInputsAssociation by ID"
      );
    }
  }
);

export const fetchAllMappings = createAsyncThunk(
  "gatewayInputsAssociation/fetchAllMappings",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        "http://localhost:3000/v1/gatewayInputs/"
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching facilities");
    }
  }
);

export const findByMappingGatewayId = createAsyncThunk(
  "gatewayInputsAssociation/findByMappingGatewayId",
  async (gatewayId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:3000/v1/gatewayInputs/gateway/${gatewayId}`
      );

      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the gatewayInputsAssociation by ID"
      );
    }
  }
);

export const getGatewayInputsAssociationById = createAsyncThunk(
  "gatewayInputsAssociation/getGatewayInputsAssociationById",
  async (mappingId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:3000/v1/gatewayInputs/${mappingId}`
      );

      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching  association by mappingId"
      );
    }
  }
);

export const updateGatewayInputsAssociation = createAsyncThunk(
  "gatewayInputsAssociation/updateGatewayInputsAssociation",
  async (
    updatedGatewayInputsAssociationData: GatewayInputsAssociation,
    { rejectWithValue }
  ) => {
    try {
      const response = await axios.put(
        `http://localhost:3000/v1/gatewayInputs/${updatedGatewayInputsAssociationData.mappingId}`,
        updatedGatewayInputsAssociationData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while updating the gatewayInputsAssociation"
      );
    }
  }
);
export const deleteGatewayInputsAssociation = createAsyncThunk(
  "gatewayInputsAssociation/deleteGatewayInputsAssociation",
  async (gatewayInputsAssociationId: string, { rejectWithValue }) => {
    try {
      await axios.delete(
        `http://localhost:3000/v1/gatewayInputs/${gatewayInputsAssociationId}`
      );
      return gatewayInputsAssociationId;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while deleting the gatewayInputsAssociation"
      );
    }
  }
);
// soft-delete or archive
export const archiveGatewayInputsAssociation = createAsyncThunk(
  "gatewayInputsAssociation/archiveGatewayInputsAssociation",
  async (gatewayInputsAssociationId: string, { rejectWithValue }) => {
    try {
      await axios.patch(
        `http://localhost:3000/v1/gatewayInputs/${gatewayInputsAssociationId}`
      );
      return gatewayInputsAssociationId;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while archiving the gatewayInputsAssociation"
      );
    }
  }
);

const gatewayInputsAssociationSlice = createSlice({
  name: "gatewayInputsAssociation",
  initialState,
  reducers: {
    setGatewayInputsAssociation: (
      state,
      action: PayloadAction<GatewayInputsAssociation[]>
    ) => {
      state.gatewayInputsAssociations = action.payload;
    },
    setGatewayInputsAssociations: (
      state,
      action: PayloadAction<GatewayInputsAssociation[]>
    ) => {
      state.gatewayInputsAssociations = action.payload;
    },
    clearGatewayInputsAssociation: (state, action: PayloadAction<string>) => {
      const gatewayInputsAssociationId = action.payload;

      state.gatewayInputsAssociations = state.gatewayInputsAssociations!.filter(
        (gatewayInputsAssociation) =>
          gatewayInputsAssociation._id !== gatewayInputsAssociationId
      );
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createGatewayInputsAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createGatewayInputsAssociation.fulfilled, (state, action) => {
        state.loading = false;
        state.gatewayInputsAssociations?.push(action.payload);
      })
      .addCase(createGatewayInputsAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to create gatewayInputsAssociation";
      })

      .addCase(findByMappingGatewayId.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(findByMappingGatewayId.fulfilled, (state, action) => {
        state.loading = false;
        state.gatewayInputsAssociations = action.payload;
      })
      .addCase(findByMappingGatewayId.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to fetch gatewayInputsAssociations";
      })
      .addCase(updateGatewayInputsAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateGatewayInputsAssociation.fulfilled, (state, action) => {
        state.loading = false;
        const updatedGatewayInputsAssociation = action.payload;

        if (state.gatewayInputsAssociations) {
          const index = state.gatewayInputsAssociations.findIndex(
            (gatewayInputsAssociation) =>
              gatewayInputsAssociation._id ===
              updatedGatewayInputsAssociation._id
          );

          if (index !== -1) {
            // Update the specific gatewayInputsAssociation in the state
            state.gatewayInputsAssociations[index] =
              updatedGatewayInputsAssociation;
          }
        }
      })
      .addCase(updateGatewayInputsAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to update gatewayInputsAssociation";
      })
      .addCase(deleteGatewayInputsAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteGatewayInputsAssociation.fulfilled, (state, action) => {
        state.loading = false;
        const deletedGatewayInputsAssociationId = action.payload;
        if (state.gatewayInputsAssociations) {
          // Check if gatewayInputsAssociation is not null
          state.gatewayInputsAssociations =
            state.gatewayInputsAssociations.filter(
              (gatewayInputsAssociation) =>
                gatewayInputsAssociation.mappingId !==
                deletedGatewayInputsAssociationId
            );
        }
      })
      .addCase(deleteGatewayInputsAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      /////////////////////////////////////////////////////////
      .addCase(archiveGatewayInputsAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(archiveGatewayInputsAssociation.fulfilled, (state, action) => {
        state.loading = false;
        const archiveGatewayInputsAssociationId = action.payload;
        if (state.gatewayInputsAssociations) {
          // Check if gatewayInputsAssociation is not null
          state.gatewayInputsAssociations =
            state.gatewayInputsAssociations.filter(
              (gatewayInputsAssociation) =>
                gatewayInputsAssociation.mappingId !==
                archiveGatewayInputsAssociationId
            );
        }
      })
      .addCase(archiveGatewayInputsAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(fetchGatewayInputsAssociationById.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchGatewayInputsAssociationById.fulfilled, (state, action) => {
        state.loading = false;
        // Update the state with the fetched gatewayInputsAssociation data
        state.gatewayInputsAssociations = [action.payload];
      })
      .addCase(fetchGatewayInputsAssociationById.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message ||
          "Failed to fetch gatewayInputsAssociation by ID";
      });
  },
});

export const { setGatewayInputsAssociation } =
  gatewayInputsAssociationSlice.actions;

export default gatewayInputsAssociationSlice.reducer;
