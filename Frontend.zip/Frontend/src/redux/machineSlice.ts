import {
  createSlice,
  createAsyncThunk,
  PayloadAction,
  Dispatch,
} from "@reduxjs/toolkit";
// import { GatewayDetails } from "../components/Machine/DefineGatewayModal";
import { Machine } from "./types";
import axios from "axios";
interface MachineState {
  machines: Machine[];
  loading: boolean;
  error: string | null;
}

type ResponseType = Machine[];

const initialState: MachineState = {
  machines: [],
  loading: false,
  error: null,
};
// Create
export const createMachine = createAsyncThunk(
  "machine/createMachine",
  async (formData: FormData, { rejectWithValue }) => {
    try {
      console.log(formData);
      const response = await fetch(
        "http://localhost:3000/v1/machines/addmachine",
        {
          method: "POST",
          body: formData, // Use the FormData object directly
        }
      );

      const responseData = await response.json();

      return responseData;
    } catch (error) {
      return rejectWithValue("An error occurred while creating the machine");
    }
  }
);

// fetch
export const fetchMachines = createAsyncThunk<
  Machine[],
  void,
  { dispatch: Dispatch }
>("machine/fetchMachines", async (_, { dispatch, rejectWithValue }) => {
  try {
    const response = await fetch(
      "http://localhost:3000/v1/machines/findAllMachines"
    );

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data: ResponseType = await response.json();
    // console.log("Fetched data:", data);

    // Dispatch the data to set it in the Redux store
    dispatch(machineSlice.actions.setMachines(data));

    return data;
  } catch (error: any) {
    return rejectWithValue(error.message || "Failed to fetch machines");
  }
});

export const fetchMachineById = createAsyncThunk(
  "machine/fetchMachineById",
  async (machineId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:3000/v1/machines/findMachineById/${machineId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the machine by ID"
      );
    }
  }
);

// Update
export const editMachine = createAsyncThunk(
  "machine/editMachine",
  async (
    {
      machineId,
      formData, // This should be a FormData object containing updated machine data and images
    }: { machineId: string; formData: FormData },
    { rejectWithValue }
  ) => {
    try {
      const response = await fetch(
        `http://localhost:3000/v1/machines/updateMachine/${machineId}`,
        {
          method: "PUT",
          body: formData,
        }
      );

      const responseData = await response.json();

      return responseData;
    } catch (error) {
      return rejectWithValue("An error occurred while updating the machine");
    }
  }
);

//delete
export const deleteMachine = createAsyncThunk(
  "machine/deleteMachine",
  async (machineId: string, { rejectWithValue }) => {
    try {
      // Logging the machine ID to the console
      console.log("Deleting machine with ID:", machineId);
      // Sending a DELETE request to the API with the machine ID
      await fetch(
        `http://localhost:3000/v1/machines/deleteMachine/${machineId}`,
        {
          method: "DELETE",
        }
      );
      // Returning the machine ID
      return machineId;
    } catch (error) {
      // Returning an error message if an error occurs
      return rejectWithValue("An error occurred while deleting the machine");
    }
  }
);

//gateway updation
// export const defineGateway = createAsyncThunk(
//   "machine/defineGateway",
//   async (
//     payload: { machineId: string; gatewayDetails: GatewayDetails },
//     { rejectWithValue }
//   ) => {
//     try {
//       const { machineId, gatewayDetails } = payload;
//       const response = await fetch(
//         `http://localhost:3000/v1/machines/defineGateway/${machineId}`, ///defineGateway/:machineId
//         {
//           method: "PUT",
//           body: JSON.stringify(gatewayDetails),
//           headers: {
//             "Content-Type": "application/json",
//           },
//         }
//       );

//       const responseData = await response.json();

//       return responseData;
//     } catch (error) {
//       return rejectWithValue("An error occurred while defining the gateway");
//     }
//   }
// );

// Assign Gateway
export const assignGateway = createAsyncThunk(
  "machine/assignGateway",
  async (
    payload: { machineId?: string; gatewayId?: string },
    { rejectWithValue }
  ) => {
    try {
      // const { machineId, gatewayId } = payload;

      const response = await fetch(
        // Replace with your actual API endpoint
        `http://localhost:3000/v1/machines/defineGateway/`,
        {
          method: "PUT",
          body: JSON.stringify(payload), // Correctly stringify the entire object
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (!response.ok) {
        // Handle non-successful responses here
        const errorData = await response.json();
        return rejectWithValue(errorData);
      }

      const responseData = await response.json();
      return responseData;
    } catch (error) {
      return rejectWithValue("An error occurred while assigning the gateway");
    }
  }
);

const machineSlice = createSlice({
  name: "machine",
  initialState,
  reducers: {
    setMachines: (state, action: PayloadAction<Machine[]>) => {
      state.machines = action.payload;
    },
    removeMachine: (state, action: PayloadAction<string>) => {
      const machineId = action.payload;
      state.machines = state.machines.filter(
        (machine) => machine._id !== machineId
      );
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchMachines.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchMachines.fulfilled, (state, action) => {
        state.loading = false;
        state.machines = action.payload;
      })
      .addCase(fetchMachines.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch machines";
      })
      .addCase(createMachine.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createMachine.fulfilled, (state, action) => {
        state.loading = false;
        state.machines.push(action.payload);
        // state.machines = action.payload;
      })
      // .addCase(createMachine.error, (state, action) => {
      //   state.loading = false;
      //   state.error = action.payload;
      // })
      .addCase(editMachine.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(editMachine.fulfilled, (state, action) => {
        state.loading = false;
      })
      .addCase(editMachine.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to update the machine";
      })
      .addCase(fetchMachineById.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchMachineById.fulfilled, (state, action) => {
        state.loading = false;
        // Update the state with the fetched gateway data
        state.machines = [action.payload];
      })
      .addCase(fetchMachineById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch gateway by ID";
      })
      .addCase(deleteMachine.fulfilled, (state, action) => {
        const machineId = action.payload;
        state.loading = false;
        state.machines = state.machines.filter(
          (machine) => machine._id !== machineId
        );
      })
      .addCase(deleteMachine.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to delete the machine";
      });
    // .addCase(defineGateway.pending, (state) => {
    //   state.loading = true;
    //   state.error = null;
    // })
    // .addCase(defineGateway.fulfilled, (state, action) => {
    //   state.loading = false;
    // })
    // .addCase(defineGateway.rejected, (state, action) => {
    //   state.loading = false;
    //   state.error = action.error.message || "Failed to delete the gateway";
    // });
  },
});
export const { removeMachine } = machineSlice.actions;
export default machineSlice.reducer;
