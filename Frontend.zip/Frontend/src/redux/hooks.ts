import {
  useDispatch,
  useSelector,
  type TypedUseSelectorHook,
} from "react-redux";

import { AppDispatch, RootState } from "./store";

type DispatchFunction = () => AppDispatch;

export const useMachinewiseDispatch: DispatchFunction = useDispatch;
export const useMachinewiseSelector: TypedUseSelectorHook<RootState> =
  useSelector;
