import axios from "axios";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { Sensor } from "./types";

interface SensorState {
  sensors: Sensor[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: SensorState = {
  sensors: [],
  loading: false,
  error: null,
};

// Create
export const createSensor = createAsyncThunk(
  "sensor/createSensor",
  async (sensorData: Sensor, { rejectWithValue }) => {
    try {
      const response = await axios.post<Sensor>(
        `${process.env.REACT_APP_BASE_URL}/v1/sensors`,
        sensorData
      );

      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while creating the sensor");
    }
  }
);
export const fetchSensorById = createAsyncThunk(
  "sensor/fetchSensorById",
  async (sensorId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/sensors/${sensorId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the sensor by ID"
      );
    }
  }
);

export const fetchSensors = createAsyncThunk(
  "sensor/fetchSensors",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/sensors`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching sensors");
    }
  }
);
export const updateSensor = createAsyncThunk(
  "sensor/updateSensor",
  async (updatedSensorData: Sensor, { rejectWithValue }) => {
    try {
      console.log("in slice updated data:", updatedSensorData);
      console.log("in slice updated data:", updatedSensorData._id);
      const response = await axios.put(
        `${process.env.REACT_APP_BASE_URL}/v1/sensors/${updatedSensorData.sensorId}`,
        updatedSensorData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while updating the sensor");
    }
  }
);
export const deleteSensor = createAsyncThunk(
  "sensor/deleteSensor",
  async (sensorId: string, { rejectWithValue }) => {
    try {
      console.log();
      console.log("deleting sensor with id:", sensorId);
      await axios.delete(
        `${process.env.REACT_APP_BASE_URL}/v1/sensors/${sensorId}`
      );
      return sensorId;
    } catch (error) {
      return rejectWithValue("An error occurred while deleting the sensor");
    }
  }
);

const sensorSlice = createSlice({
  name: "sensor",
  initialState,
  reducers: {
    setSensor: (state, action: PayloadAction<Sensor[]>) => {
      state.sensors = action.payload;
    },
    clearSensor: (state, action: PayloadAction<string>) => {
      const sensorId = action.payload;

      state.sensors = state.sensors!.filter(
        (sensor) => sensor._id !== sensorId
      );
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createSensor.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createSensor.fulfilled, (state, action) => {
        state.loading = false;
        state.sensors?.push(action.payload);
      })
      .addCase(createSensor.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to create sensor";
      })
      .addCase(fetchSensors.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchSensors.fulfilled, (state, action) => {
        state.loading = false;
        state.sensors = action.payload;
      })
      .addCase(fetchSensors.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch sensors";
      })
      .addCase(updateSensor.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateSensor.fulfilled, (state, action) => {
        state.loading = false;
        const updatedSensor = action.payload;

        if (state.sensors) {
          const index = state.sensors.findIndex(
            (sensor) => sensor._id === updatedSensor._id
          );

          if (index !== -1) {
            // Update the specific sensor in the state
            state.sensors[index] = updatedSensor;
          }
        }
      })
      .addCase(updateSensor.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to update sensor";
      })
      .addCase(deleteSensor.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteSensor.fulfilled, (state, action) => {
        state.loading = false;
        const deletedSensorId = action.payload;
        if (state.sensors) {
          // Check if sensor is not null
          state.sensors = state.sensors.filter(
            (sensor) => sensor._id !== deletedSensorId
          );
        }
      })
      .addCase(deleteSensor.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(fetchSensorById.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchSensorById.fulfilled, (state, action) => {
        state.loading = false;
        // Update the state with the fetched sensor data
        state.sensors = [action.payload];
      })
      .addCase(fetchSensorById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch sensor by ID";
      });
  },
});

export default sensorSlice.reducer;
