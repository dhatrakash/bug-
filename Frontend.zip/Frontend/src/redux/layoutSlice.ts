import axios from "axios";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { Layout } from "./types";

interface LayoutState {
  layouts: Layout[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: LayoutState = {
  layouts: [],
  loading: false,
  error: null,
};

// Create
export const createLayout = createAsyncThunk(
  "layout/createLayout",
  async (layoutData: Layout, { rejectWithValue }) => {
    try {
      const response = await axios.post<Layout>(
        `${process.env.REACT_APP_BASE_URL}/v1/layouts/addlayout`,
        layoutData
      );

      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while creating the layout");
    }
  }
);
export const fetchLayoutById = createAsyncThunk(
  "layout/fetchLayoutById",
  async (layoutId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/layouts/findLayoutById/${layoutId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the layout by ID"
      );
    }
  }
);
export const fetchLayouts = createAsyncThunk(
  "layout/fetchLayouts",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/layouts/findAllLayouts`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching layouts");
    }
  }
);
export const updateLayout = createAsyncThunk(
  "layout/updateLayout",
  async (updatedLayoutData: Layout, { rejectWithValue }) => {
    try {
      console.log("sensding from slice", updatedLayoutData);
      const response = await axios.put(
        `${process.env.REACT_APP_BASE_URL}/v1/layouts/updateLayout/${updatedLayoutData._id}`,
        updatedLayoutData
      );
      console.log("response received", response);
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while updating the layout");
    }
  }
);
export const deleteLayout = createAsyncThunk(
  "layout/deleteLayout",
  async (layoutId: string, { rejectWithValue }) => {
    try {
      await axios.delete(
        `${process.env.REACT_APP_BASE_URL}/v1/layouts/deleteLayout/${layoutId}`
      );
      return layoutId;
    } catch (error) {
      return rejectWithValue("An error occurred while deleting the layout");
    }
  }
);

const layoutSlice = createSlice({
  name: "layout",
  initialState,
  reducers: {
    setLayout: (state, action: PayloadAction<Layout[]>) => {
      state.layouts = action.payload;
    },
    clearLayout: (state, action: PayloadAction<string>) => {
      const layoutId = action.payload;
      state.layouts = state.layouts!.filter(
        (layout) => layout._id !== layoutId
      );
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createLayout.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createLayout.fulfilled, (state, action) => {
        state.loading = false;
        state.layouts?.push(action.payload);
      })
      .addCase(createLayout.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to create layout";
      })
      .addCase(fetchLayouts.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchLayouts.fulfilled, (state, action) => {
        state.loading = false;
        state.layouts = action.payload;
      })
      .addCase(fetchLayouts.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch layouts";
      })
      .addCase(updateLayout.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateLayout.fulfilled, (state, action) => {
        state.loading = false;
        const updatedLayout = action.payload;

        if (state.layouts) {
          const index = state.layouts.findIndex(
            (layout) => layout._id === updatedLayout._id
          );

          if (index !== -1) {
            state.layouts[index] = updatedLayout;
          }
        }
      })
      .addCase(updateLayout.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to update layout";
      })
      .addCase(deleteLayout.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteLayout.fulfilled, (state, action) => {
        state.loading = false;
        const deletedLayoutId = action.payload;
        if (state.layouts) {
          state.layouts = state.layouts.filter(
            (layout) => layout._id !== deletedLayoutId
          );
        }
      })
      .addCase(deleteLayout.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const {} = layoutSlice.actions;
export default layoutSlice.reducer;
