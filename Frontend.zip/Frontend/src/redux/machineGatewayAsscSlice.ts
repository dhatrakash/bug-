import axios from "axios";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { MachineGatewayAssociation } from "./types";

interface MachineGatewayAssociationState {
  machineGatewayAssociations: MachineGatewayAssociation[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: MachineGatewayAssociationState = {
  machineGatewayAssociations: [],
  loading: false,
  error: null,
};

// Create
export const createMachineGatewayAssociation = createAsyncThunk(
  "machineGatewayAssociation/createMachineGatewayAssociation",
  async (
    machineGatewayAssociationData: MachineGatewayAssociation,
    { rejectWithValue }
  ) => {
    try {
      const response = await axios.post<MachineGatewayAssociation>(
        "http://localhost:3000/v1/associationMachineGateway/",
        machineGatewayAssociationData
      );

      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while creating the machineGatewayAssociation"
      );
    }
  }
);

// fetch bymachineId
export const fetchMachineGatewayAssociationById = createAsyncThunk(
  "machineGatewayAssociation/fetchMachineGatewayAssociationByMachineId",
  async (machineId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:3000/v1/associationMachineGateway/${machineId}`
      );
      console.log("response received", response);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the machineGatewayAssociation by ID"
      );
    }
  }
);
// fetch all
export const findAllMachineGatewayAssociations = createAsyncThunk(
  "machineGatewayAssociation/findAllMachineGatewayAssociations",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        "http://localhost:3000/v1/associationMachineGateway/"
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching facilities");
    }
  }
);

export const findByMappingGatewayId = createAsyncThunk(
  "machineGatewayAssociation/findByMappingGatewayId",
  async (gatewayId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:3000/v1/associationMachineGateway/find/${gatewayId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the machineGatewayAssociation by ID"
      );
    }
  }
);

export const updateMachineGatewayAssociation = createAsyncThunk(
  "machineGatewayAssociation/updateMachineGatewayAssociation",
  async (
    updatedMachineGatewayAssociationData: MachineGatewayAssociation,
    { rejectWithValue }
  ) => {
    try {
      const response = await axios.put(
        `http://localhost:3000/v1/associationMachineGateway/${updatedMachineGatewayAssociationData.machineMappingId}`,
        updatedMachineGatewayAssociationData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while updating the machineGatewayAssociation"
      );
    }
  }
);

// permanent delete
export const deleteMachineGatewayAssociation = createAsyncThunk(
  "machineGatewayAssociation/deleteMachineGatewayAssociation",
  async (
    {
      machineId,
      sensorNodeName,
    }: {
      machineId: string;
      sensorNodeName: string;
    },
    { rejectWithValue }
  ) => {
    try {
      await axios.delete(
        `http://localhost:3000/v1/associationMachineGateway/${machineId}/${sensorNodeName}`,
        {
          data: {
            machineId,
            sensorNodeName,
          },
        }
      );
      return machineId;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while deleting the machineGatewayAssociation"
      );
    }
  }
);

// soft-delete or archive
export const archiveMachineGatewayAssociation = createAsyncThunk(
  "machineGatewayAssociation/archiveMachineGatewayAssociation",
  async (
    {
      machineId,
      sensorNodeName,
    }: {
      machineId: string;
      sensorNodeName: string;
    },
    { rejectWithValue }
  ) => {
    try {
      await axios.patch(
        `http://localhost:3000/v1/associationMachineGateway/${machineId}/${sensorNodeName}`,
        {
          data: {
            machineId,
            sensorNodeName,
          },
        }
      );
      return machineId;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while archiving the machineGatewayAssociation"
      );
    }
  }
);

const machineGatewayAssociationSlice = createSlice({
  name: "machineGatewayAssociation",
  initialState,
  reducers: {
    setMachineGatewayAssociation: (
      state,
      action: PayloadAction<MachineGatewayAssociation[]>
    ) => {
      state.machineGatewayAssociations = action.payload;
    },
    clearMachineGatewayAssociation: (state, action: PayloadAction<string>) => {
      const machineGatewayAssociationId = action.payload;

      state.machineGatewayAssociations =
        state.machineGatewayAssociations!.filter(
          (machineGatewayAssociation) =>
            machineGatewayAssociation._id !== machineGatewayAssociationId
        );
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createMachineGatewayAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createMachineGatewayAssociation.fulfilled, (state, action) => {
        state.loading = false;
        state.machineGatewayAssociations?.push(action.payload);
      })
      .addCase(createMachineGatewayAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to create machineGatewayAssociation";
      })

      .addCase(findByMappingGatewayId.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(findByMappingGatewayId.fulfilled, (state, action) => {
        state.loading = false;
        state.machineGatewayAssociations = action.payload;
      })
      .addCase(findByMappingGatewayId.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to fetch machineGatewayAssociations";
      })
      .addCase(updateMachineGatewayAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateMachineGatewayAssociation.fulfilled, (state, action) => {
        state.loading = false;
        const updatedMachineGatewayAssociation = action.payload;

        if (state.machineGatewayAssociations) {
          const index = state.machineGatewayAssociations.findIndex(
            (machineGatewayAssociation) =>
              machineGatewayAssociation._id ===
              updatedMachineGatewayAssociation._id
          );

          if (index !== -1) {
            // Update the specific machineGatewayAssociation in the state
            state.machineGatewayAssociations[index] =
              updatedMachineGatewayAssociation;
          }
        }
      })
      .addCase(updateMachineGatewayAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to update machineGatewayAssociation";
      })
      .addCase(deleteMachineGatewayAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteMachineGatewayAssociation.fulfilled, (state, action) => {
        state.loading = false;
        const deletedMachineGatewayAssociationId = action.payload;
        if (state.machineGatewayAssociations) {
          // Check if machineGatewayAssociation is not null
          state.machineGatewayAssociations =
            state.machineGatewayAssociations.filter(
              (machineGatewayAssociation) =>
                machineGatewayAssociation.mappingId !==
                deletedMachineGatewayAssociationId
            );
        }
      })
      .addCase(deleteMachineGatewayAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      /////////////////////////////////////////////////////////
      .addCase(archiveMachineGatewayAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(archiveMachineGatewayAssociation.fulfilled, (state, action) => {
        state.loading = false;
        const archiveMachineGatewayAssociationId = action.payload;
        if (state.machineGatewayAssociations) {
          // Check if machineGatewayAssociation is not null
          state.machineGatewayAssociations =
            state.machineGatewayAssociations.filter(
              (machineGatewayAssociation) =>
                machineGatewayAssociation.mappingId !==
                archiveMachineGatewayAssociationId
            );
        }
      })
      .addCase(archiveMachineGatewayAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(fetchMachineGatewayAssociationById.pending, (state) => {
        state.loading = true;
      })
      .addCase(
        fetchMachineGatewayAssociationById.fulfilled,
        (state, action) => {
          state.loading = false;
          // Update the state with the fetched machineGatewayAssociation data
          state.machineGatewayAssociations = [action.payload];
        }
      )
      .addCase(fetchMachineGatewayAssociationById.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message ||
          "Failed to fetch machineGatewayAssociation by ID";
      });
  },
});

export default machineGatewayAssociationSlice.reducer;
