import axios from "axios";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { Gateway } from "./types";

interface GatewayState {
  gateways: Gateway[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: GatewayState = {
  gateways: [],
  loading: false,
  error: null,
};

// Create
export const createGateway = createAsyncThunk(
  "gateway/createGateway",
  async (gatewayData: Gateway, { rejectWithValue }) => {
    try {
      // console.log(gatewayData);
      const response = await axios.post<Gateway>(
        "http://localhost:3000/v1/gateway",
        gatewayData
      );

      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while creating the gateway");
    }
  }
);
export const fetchGatewayById = createAsyncThunk(
  "gateway/fetchGatewayById",
  async (gatewayId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:3000/v1/gateway/${gatewayId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the gateway by ID"
      );
    }
  }
);

export const fetchGateways = createAsyncThunk(
  "gateway/fetchGateways",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get("http://localhost:3000/v1/gateway");
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching gateways");
    }
  }
);
export const updateGateway = createAsyncThunk(
  "gateway/updateGateway",
  async (updatedGatewayData: Gateway, { rejectWithValue }) => {
    try {
      // console.log("in slice updated data:", updatedGatewayData);
      // console.log("in slice updated data:", updatedGatewayData._id);
      const response = await axios.put(
        `http://localhost:3000/v1/gateway/${updatedGatewayData.gatewayId}`,
        updatedGatewayData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while updating the gateway");
    }
  }
);
export const deleteGateway = createAsyncThunk(
  "gateway/deleteGateway",
  async (gatewayId: string, { rejectWithValue }) => {
    try {
      await axios.delete(`http://localhost:3000/v1/gateway/${gatewayId}`);
      return gatewayId;
    } catch (error) {
      return rejectWithValue("An error occurred while deleting the gateway");
    }
  }
);

const gatewaySlice = createSlice({
  name: "gateway",
  initialState,
  reducers: {
    setGateway: (state, action: PayloadAction<Gateway[]>) => {
      state.gateways = action.payload;
    },
    clearGateway: (state, action: PayloadAction<string>) => {
      const gatewayId = action.payload;

      state.gateways = state.gateways!.filter(
        (gateway) => gateway._id !== gatewayId
      );
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createGateway.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createGateway.fulfilled, (state, action) => {
        state.loading = false;
        state.gateways?.push(action.payload);
      })
      .addCase(createGateway.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to create gateway";
      })
      .addCase(fetchGateways.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchGateways.fulfilled, (state, action) => {
        state.loading = false;
        state.gateways = action.payload;
      })
      .addCase(fetchGateways.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch gateways";
      })
      .addCase(updateGateway.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateGateway.fulfilled, (state, action) => {
        state.loading = false;
        const updatedGateway = action.payload;

        if (state.gateways) {
          const index = state.gateways.findIndex(
            (gateway) => gateway._id === updatedGateway._id
          );

          if (index !== -1) {
            // Update the specific gateway in the state
            state.gateways[index] = updatedGateway;
          }
        }
      })
      .addCase(updateGateway.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to update gateway";
      })
      .addCase(deleteGateway.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteGateway.fulfilled, (state, action) => {
        state.loading = false;
        const deletedGatewayId = action.payload;
        if (state.gateways) {
          // Check if gateway is not null
          state.gateways = state.gateways.filter(
            (gateway) => gateway._id !== deletedGatewayId
          );
        }
      })
      .addCase(deleteGateway.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(fetchGatewayById.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchGatewayById.fulfilled, (state, action) => {
        state.loading = false;
        // Update the state with the fetched gateway data
        state.gateways = [action.payload];
      })
      .addCase(fetchGatewayById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch gateway by ID";
      });
  },
});

export default gatewaySlice.reducer;
