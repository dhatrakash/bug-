import axios from "axios";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { MachineInputsAssociation } from "./types";

interface MachineInputsAssociationState {
  machineInputsAssociations: MachineInputsAssociation[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: MachineInputsAssociationState = {
  machineInputsAssociations: [],
  loading: false,
  error: null,
};

// Create
export const createMachineInputsAssociation = createAsyncThunk(
  "machineInputsAssociation/createMachineInputsAssociation",
  async (
    machineInputsAssociationData: MachineInputsAssociation,
    { rejectWithValue }
  ) => {
    try {
      const response = await axios.post<MachineInputsAssociation>(
        "http://localhost:3000/v1/machineInputs/",
        machineInputsAssociationData
      );

      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while creating the machineInputsAssociation"
      );
    }
  }
);

// fetch bymachineId
export const fetchMachineInputsAssociationById = createAsyncThunk(
  "machineInputsAssociation/fetchMachineInputsAssociationByMachineId",
  async (machineId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:3000/v1/machineInputs/${machineId}`
      );
      console.log("response received", response);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the machineInputsAssociation by ID"
      );
    }
  }
);
// fetch all
export const findAllMachineInputsAssociations = createAsyncThunk(
  "machineInputsAssociation/findAllMachineInputsAssociations",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        "http://localhost:3000/v1/machineInputs/"
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching facilities");
    }
  }
);
// fetch by machineInputMappingId
export const findBymachineInputMappingId = createAsyncThunk(
  "machineInputsAssociation/findBymachineInputMappingId",
  async (machineInputMappingId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:3000/v1/machineInputs/inputId/${machineInputMappingId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the machineInputsAssociation by ID"
      );
    }
  }
);

export const updateMachineInputsAssociation = createAsyncThunk(
  "machineInputsAssociation/updateMachineInputsAssociation",
  async (
    updatedMachineInputsAssociationData: MachineInputsAssociation,
    { rejectWithValue }
  ) => {
    try {
      const response = await axios.put(
        `http://localhost:3000/v1/machineInputs/${updatedMachineInputsAssociationData.machineInputMappingId}`,
        updatedMachineInputsAssociationData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while updating the machineInputsAssociation"
      );
    }
  }
);

// permanent delete
export const deleteMachineInputsAssociation = createAsyncThunk(
  "machineInputsAssociation/deleteMachineInputsAssociation",
  async (
    {
      machineId,
      sensorNodeName,
    }: {
      machineId: string;
      sensorNodeName: string;
    },
    { rejectWithValue }
  ) => {
    try {
      await axios.delete(
        `http://localhost:3000/v1/machineInputs/${machineId}/${sensorNodeName}`,
        {
          data: {
            machineId,
            sensorNodeName,
          },
        }
      );
      return machineId;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while deleting the machineInputsAssociation"
      );
    }
  }
);

// soft-delete or archive
export const archiveMachineInputsAssociation = createAsyncThunk(
  "machineInputsAssociation/archiveMachineInputsAssociation",
  async (
    {
      machineId,
      sensorNodeName,
    }: {
      machineId: string;
      sensorNodeName: string;
    },
    { rejectWithValue }
  ) => {
    try {
      await axios.patch(
        `http://localhost:3000/v1/machineInputs/${machineId}/${sensorNodeName}`,
        {
          data: {
            machineId,
            sensorNodeName,
          },
        }
      );
      return machineId;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while archiving the machineInputsAssociation"
      );
    }
  }
);

const machineInputsAssociationSlice = createSlice({
  name: "machineInputsAssociation",
  initialState,
  reducers: {
    setMachineInputsAssociation: (
      state,
      action: PayloadAction<MachineInputsAssociation[]>
    ) => {
      state.machineInputsAssociations = action.payload;
    },
    clearMachineInputsAssociation: (state, action: PayloadAction<string>) => {
      const machineInputsAssociationId = action.payload;

      state.machineInputsAssociations = state.machineInputsAssociations!.filter(
        (machineInputsAssociation) =>
          machineInputsAssociation._id !== machineInputsAssociationId
      );
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createMachineInputsAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createMachineInputsAssociation.fulfilled, (state, action) => {
        state.loading = false;
        state.machineInputsAssociations?.push(action.payload);
      })
      .addCase(createMachineInputsAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to create machineInputsAssociation";
      })

      .addCase(findBymachineInputMappingId.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(findBymachineInputMappingId.fulfilled, (state, action) => {
        state.loading = false;
        state.machineInputsAssociations = action.payload;
      })
      .addCase(findBymachineInputMappingId.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to fetch machineInputsAssociations";
      })
      .addCase(updateMachineInputsAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateMachineInputsAssociation.fulfilled, (state, action) => {
        state.loading = false;
        const updatedMachineInputsAssociation = action.payload;

        if (state.machineInputsAssociations) {
          const index = state.machineInputsAssociations.findIndex(
            (machineInputsAssociation) =>
              machineInputsAssociation._id ===
              updatedMachineInputsAssociation._id
          );

          if (index !== -1) {
            // Update the specific machineInputsAssociation in the state
            state.machineInputsAssociations[index] =
              updatedMachineInputsAssociation;
          }
        }
      })
      .addCase(updateMachineInputsAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to update machineInputsAssociation";
      })
      .addCase(deleteMachineInputsAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteMachineInputsAssociation.fulfilled, (state, action) => {
        state.loading = false;
        const deletedMachineInputsAssociationId = action.payload;
        if (state.machineInputsAssociations) {
          // Check if machineInputsAssociation is not null
          state.machineInputsAssociations =
            state.machineInputsAssociations.filter(
              (machineInputsAssociation) =>
                machineInputsAssociation.mappingId !==
                deletedMachineInputsAssociationId
            );
        }
      })
      .addCase(deleteMachineInputsAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      /////////////////////////////////////////////////////////
      .addCase(archiveMachineInputsAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(archiveMachineInputsAssociation.fulfilled, (state, action) => {
        state.loading = false;
        const archiveMachineInputsAssociationId = action.payload;
        if (state.machineInputsAssociations) {
          // Check if machineInputsAssociation is not null
          state.machineInputsAssociations =
            state.machineInputsAssociations.filter(
              (machineInputsAssociation) =>
                machineInputsAssociation.mappingId !==
                archiveMachineInputsAssociationId
            );
        }
      })
      .addCase(archiveMachineInputsAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(fetchMachineInputsAssociationById.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchMachineInputsAssociationById.fulfilled, (state, action) => {
        state.loading = false;
        // Update the state with the fetched machineInputsAssociation data
        state.machineInputsAssociations = [action.payload];
      })
      .addCase(fetchMachineInputsAssociationById.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message ||
          "Failed to fetch machineInputsAssociation by ID";
      });
  },
});

export default machineInputsAssociationSlice.reducer;
