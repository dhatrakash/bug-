// functionalitySlice.ts
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { Functionality } from "../redux/types";

const storedFunctionalities = sessionStorage.getItem("functionalities");

// Define the initial state with your desired structure
const initialState: Functionality = storedFunctionalities
  ? JSON.parse(storedFunctionalities)
  : {
      viewMach: false,
      machAsssignToSuper: false,
      createNewMach: false,
      createNewUsers: false,
      assignRepo: false,
      assignPermi: false,
      whatsAppAPI: false,
      machAsssignToUser: false,
      shiftCreat: false,
      locaCreat: false,
      mastrPartList: false,
      viewLimRepo: false,
      machAsssignToOper: false,
      reportProb: false,
      viewHtmlOnLarScr: false,
      custPermi: false,
    };
const initialState1 = {
  viewMach: false,
  machAsssignToSuper: false,
  createNewMach: false,
  createNewUsers: false,
  assignRepo: false,
  assignPermi: false,
  whatsAppAPI: false,
  machAsssignToUser: false,
  shiftCreat: false,
  locaCreat: false,
  mastrPartList: false,
  viewLimRepo: false,
  machAsssignToOper: false,
  reportProb: false,
  viewHtmlOnLarScr: false,
  custPermi: false,
};

const functionalitySlice = createSlice({
  name: "functionality",
  initialState,
  reducers: {
    // Define reducers to update individual functionality properties
    setViewMach: (state, action: PayloadAction<boolean>) => {
      state.viewMach = action.payload;
    },
    setMachAsssignToSuper: (state, action: PayloadAction<boolean>) => {
      state.machAsssignToSuper = action.payload;
    },
    // Define reducers for other functionality properties
    setCreateNewMach: (state, action: PayloadAction<boolean>) => {
      state.createNewMach = action.payload;
    },
    setCreateNewUsers: (state, action: PayloadAction<boolean>) => {
      state.createNewUsers = action.payload;
    },
    setAssignRepo: (state, action: PayloadAction<boolean>) => {
      state.assignRepo = action.payload;
    },
    setAssignPermi: (state, action: PayloadAction<boolean>) => {
      state.assignPermi = action.payload;
    },
    setWhatsAppAPI: (state, action: PayloadAction<boolean>) => {
      state.whatsAppAPI = action.payload;
    },
    setMachAsssignToUser: (state, action: PayloadAction<boolean>) => {
      state.machAsssignToUser = action.payload;
    },
    setShiftCreat: (state, action: PayloadAction<boolean>) => {
      state.shiftCreat = action.payload;
    },
    setLocaCreat: (state, action: PayloadAction<boolean>) => {
      state.locaCreat = action.payload;
    },
    setMastrPartList: (state, action: PayloadAction<boolean>) => {
      state.mastrPartList = action.payload;
    },
    setViewLimRepo: (state, action: PayloadAction<boolean>) => {
      state.viewLimRepo = action.payload;
    },
    setMachAsssignToOper: (state, action: PayloadAction<boolean>) => {
      state.machAsssignToOper = action.payload;
    },
    setReportProb: (state, action: PayloadAction<boolean>) => {
      state.reportProb = action.payload;
    },
    setViewHtmlOnLarScr: (state, action: PayloadAction<boolean>) => {
      state.viewHtmlOnLarScr = action.payload;
    },
    setCustPermi: (state, action: PayloadAction<boolean>) => {
      state.custPermi = action.payload;
    },
    resetFunctionalities: (state) => {
      return initialState1;
    },
    // generic action to update multiple functionalities at once
    updateFunctionalities: (state, action: PayloadAction<Functionality>) => {
      return { ...state, ...action.payload };
    },
  },
});

// Export the action creators
export const {
  setViewMach,
  setMachAsssignToSuper,
  setCreateNewMach,
  setCreateNewUsers,
  setAssignRepo,
  setAssignPermi,
  setWhatsAppAPI,
  setMachAsssignToUser,
  setShiftCreat,
  setLocaCreat,
  setMastrPartList,
  setViewLimRepo,
  setMachAsssignToOper,
  setReportProb,
  setViewHtmlOnLarScr,
  setCustPermi,
  resetFunctionalities,
  updateFunctionalities,
} = functionalitySlice.actions;

export default functionalitySlice.reducer;
