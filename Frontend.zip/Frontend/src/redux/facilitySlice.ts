import axios from "axios";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { Facility } from "./types";

interface FacilityState {
  facilities: Facility[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: FacilityState = {
  facilities: [],
  loading: false,
  error: null,
};

// Create
export const createFacility = createAsyncThunk(
  "facility/createFacility",
  async (facilityData: Facility, { rejectWithValue }) => {
    try {
      const response = await axios.post<Facility>(
        `${process.env.REACT_APP_BASE_URL}/v1/facilities/addfacility`,
        facilityData
      );

      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while creating the facility");
    }
  }
);
export const fetchFacilityById = createAsyncThunk(
  "facility/fetchFacilityById",
  async (facilityId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/facilities/findFacilityById/${facilityId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the facility by ID"
      );
    }
  }
);

export const fetchFacilities = createAsyncThunk(
  "facility/fetchFacilities",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/facilities/findAllFacilities`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching facilities");
    }
  }
);
export const updateFacility = createAsyncThunk(
  "facility/updateFacility",
  async (updatedFacilityData: Facility, { rejectWithValue }) => {
    try {
      console.log("sending from slice", updatedFacilityData);
      const response = await axios.put(
        `${process.env.REACT_APP_BASE_URL}/v1/facilities/updateFacility/${updatedFacilityData._id}`,
        updatedFacilityData
      );
      console.log("response from slice", response.data);
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while updating the facility");
    }
  }
);
export const deleteFacility = createAsyncThunk(
  "facility/deleteFacility",
  async (facilityId: string, { rejectWithValue }) => {
    try {
      await axios.delete(
        `${process.env.REACT_APP_BASE_URL}/v1/facilities/deleteFacility/${facilityId}`
      );
      return facilityId;
    } catch (error) {
      return rejectWithValue("An error occurred while deleting the facility");
    }
  }
);

const facilitySlice = createSlice({
  name: "facility",
  initialState,
  reducers: {
    setFacility: (state, action: PayloadAction<Facility[]>) => {
      state.facilities = action.payload;
    },
    clearFacility: (state, action: PayloadAction<string>) => {
      const facilityId = action.payload;

      state.facilities = state.facilities!.filter(
        (facility) => facility._id !== facilityId
      );
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createFacility.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createFacility.fulfilled, (state, action) => {
        state.loading = false;
        state.facilities?.push(action.payload);
      })
      .addCase(createFacility.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to create facility";
      })
      .addCase(fetchFacilities.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchFacilities.fulfilled, (state, action) => {
        state.loading = false;
        state.facilities = action.payload;
      })
      .addCase(fetchFacilities.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch facilities";
      })
      .addCase(updateFacility.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateFacility.fulfilled, (state, action) => {
        state.loading = false;
        const updatedFacility = action.payload;

        if (state.facilities) {
          const index = state.facilities.findIndex(
            (facility) => facility._id === updatedFacility._id
          );

          if (index !== -1) {
            // Update the specific facility in the state
            state.facilities[index] = updatedFacility;
          }
        }
      })
      .addCase(updateFacility.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to update facility";
      })
      .addCase(deleteFacility.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteFacility.fulfilled, (state, action) => {
        state.loading = false;
        const deletedFacilityId = action.payload;
        if (state.facilities) {
          // Check if facility is not null
          state.facilities = state.facilities.filter(
            (facility) => facility._id !== deletedFacilityId
          );
        }
      })
      .addCase(deleteFacility.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(fetchFacilityById.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchFacilityById.fulfilled, (state, action) => {
        state.loading = false;
        // Update the state with the fetched facility data
        state.facilities = [action.payload];
      })
      .addCase(fetchFacilityById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch facility by ID";
      });
  },
});

export default facilitySlice.reducer;
