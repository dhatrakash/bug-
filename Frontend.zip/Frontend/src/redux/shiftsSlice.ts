import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { Shift } from "./types";
import axios from "axios";
interface ShiftsState {
  shifts: Shift[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: ShiftsState = {
  shifts: [],
  loading: false,
  error: null,
};

//Create Shift
export const createShift = createAsyncThunk(
  "shift/createShift",
  async (shiftData: Shift, { rejectWithValue }) => {
    try {
      const response = await axios.post<Shift>(
        `${process.env.REACT_APP_BASE_URL}/v1/shifts`,
        shiftData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An Error Occured While Creating Shift..");
    }
  }
);

//Fetch Shifts
export const fetchShifts = createAsyncThunk(
  "shift/fetchShifts",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/shifts`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching shifts");
    }
  }
);

//Update Shift
export const updateShift = createAsyncThunk(
  "shift/updateShift",
  async (updatedShiftData: Shift, { rejectWithValue }) => {
    try {
      console.log("in slice updated data:", updatedShiftData);
      console.log("in slice updated data:", updatedShiftData._id);
      const response = await axios.put(
        `${process.env.REACT_APP_BASE_URL}/v1/shifts/${updatedShiftData.shiftId}`,
        updatedShiftData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while updating the shift");
    }
  }
);
//deleteShift
export const deleteShift = createAsyncThunk(
  "shift/deleteShift",
  async (shiftId: string, { rejectWithValue }) => {
    try {
      console.log();
      console.log("deleting shift with id:", shiftId);
      await axios.delete(
        `${process.env.REACT_APP_BASE_URL}/v1/shifts/${shiftId}`
      );
      return shiftId;
    } catch (error) {
      return rejectWithValue("An error occurred while deleting the shift");
    }
  }
);
const shiftsSlice = createSlice({
  name: "shifts",
  initialState,
  reducers: {
    setShift: (state, action: PayloadAction<Shift[]>) => {
      state.shifts = action.payload;
    },
    clearShift: (state, action: PayloadAction<string>) => {
      const shiftId = action.payload;
      state.shifts = state.shifts!.filter((shift) => shift.shiftId !== shiftId);
    },
    addShift: (state, action: PayloadAction<Shift>) => {
      state.shifts?.push(action.payload);
    },

    // deleteShift: (state, action: PayloadAction<string>) => {
    //   state.shifts = state.shifts?.filter(
    //     (shift) => shift.shiftId !== action.payload
    //   );
    // },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createShift.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createShift.fulfilled, (state, action) => {
        state.loading = false;
        state.shifts?.push(action.payload);
      })
      .addCase(createShift.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to create shift";
      })
      .addCase(fetchShifts.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchShifts.fulfilled, (state, action) => {
        state.loading = false;
        state.shifts = action.payload;
      })
      .addCase(fetchShifts.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch shifts";
      })
      .addCase(updateShift.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateShift.fulfilled, (state, action) => {
        state.loading = false;
        const updatedShift = action.payload;

        if (state.shifts) {
          const index = state.shifts.findIndex(
            (shift) => shift._id === updatedShift._id
          );

          if (index !== -1) {
            // Update the specific shift in the state
            state.shifts[index] = updatedShift;
          }
        }
      })
      .addCase(updateShift.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to update shift";
      });
    //   .addCase(deleteShift.pending, (state) => {
    //     state.loading = true;
    //     state.error = null;
    //   })
    //   .addCase(deleteShift.fulfilled, (state, action) => {
    //     state.loading = false;
    //     const deletedShiftId = action.payload;
    //     if (state.shifts) {
    //       // Check if shift is not null
    //       state.shifts = state.shifts.filter(
    //         (shift) => shift._id !== deletedShiftId
    //       );
    //     }
    //   })
    //   .addCase(deleteShift.rejected, (state, action) => {
    //     state.loading = false;
    //     state.error = action.payload as string;
    //   });
  },
});

export default shiftsSlice.reducer;
