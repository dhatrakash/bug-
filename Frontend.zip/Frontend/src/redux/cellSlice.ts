import axios from "axios";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { Cell } from "./types";

interface CellState {
  cells: Cell[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: CellState = {
  cells: [],
  loading: false,
  error: null,
};

// Create
export const createCell = createAsyncThunk(
  "cell/createCell",
  async (cellData: Cell, { rejectWithValue }) => {
    try {
      const response = await axios.post<Cell>(
        `${process.env.REACT_APP_BASE_URL}/v1/cells/addcell`,
        cellData
      );

      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while creating the cell");
    }
  }
);
export const fetchCellById = createAsyncThunk(
  "cell/fetchCellById",
  async (cellId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/cells/findCellById/${cellId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching the cell by ID");
    }
  }
);
export const fetchCells = createAsyncThunk(
  "cell/fetchCells",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/cells/findAllCells`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching cells");
    }
  }
);
export const updateCell = createAsyncThunk(
  "cell/updateCell",
  async (updatedCellData: Cell, { rejectWithValue }) => {
    try {
      const response = await axios.put(
        `${process.env.REACT_APP_BASE_URL}/v1/cells/updateCell/${updatedCellData._id}`,
        updatedCellData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while updating the cell");
    }
  }
);
export const deleteCell = createAsyncThunk(
  "cell/deleteCell",
  async (cellId: string, { rejectWithValue }) => {
    try {
      await axios.delete(
        `${process.env.REACT_APP_BASE_URL}/v1/cells/deleteCell/${cellId}`
      );
      return cellId;
    } catch (error) {
      return rejectWithValue("An error occurred while deleting the cell");
    }
  }
);

const cellSlice = createSlice({
  name: "cell",
  initialState,
  reducers: {
    setCell: (state, action: PayloadAction<Cell[]>) => {
      state.cells = action.payload;
    },
    clearCell: (state, action: PayloadAction<string>) => {
      const cellId = action.payload;

      state.cells = state.cells!.filter((cell) => cell._id !== cellId);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createCell.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createCell.fulfilled, (state, action) => {
        state.loading = false;
        state.cells?.push(action.payload);
      })
      .addCase(createCell.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to create cell";
      })
      .addCase(fetchCells.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCells.fulfilled, (state, action) => {
        state.loading = false;
        state.cells = action.payload;
      })
      .addCase(fetchCells.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch cells";
      })
      .addCase(updateCell.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateCell.fulfilled, (state, action) => {
        state.loading = false;
        const updatedCell = action.payload;

        if (state.cells) {
          const index = state.cells.findIndex(
            (cell) => cell._id === updatedCell._id
          );

          if (index !== -1) {
            // Update the specific cell in the state
            state.cells[index] = updatedCell;
          }
        }
      })
      .addCase(updateCell.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to update cell";
      })
      .addCase(deleteCell.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteCell.fulfilled, (state, action) => {
        state.loading = false;
        const deletedCellId = action.payload;
        if (state.cells) {
          // Check if cell is not null
          state.cells = state.cells.filter(
            (cell) => cell._id !== deletedCellId
          );
        }
      })
      .addCase(deleteCell.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { setCell } = cellSlice.actions;
export default cellSlice.reducer;
