export interface Machine {
  _id?: string;
  machineName: string;
  machine_type: string;
  controllerType?: string;
  machineLocation: {
    facility: string | Facility;
    cell: string | Cell;
    layout: string | Layout;
    line: string | Line;
  };
  machineMake: string;
  machineMakeYear: number;
  maintenancePerson: string;
  maintenanceContact: string;
  mfgEmail: string;
  machineWarranty: string;
  powerSupplyRating: number;
  inputMethod: string;
  controllerMake: string;
  controllerModel: string;
  controllerMakeYear: number;
  machineId?: string;
  gatewayId?: string;
  machinePhoto: File | null;
  controllerPhoto: File | null;
  subscribeTopic?: string;
  publishTopic?: string;
  downtimeReason?: string;
  lockRegister?: string;
  operatorId?: string;
  partCode?: string;
  lockCommand?: string;
  unlockCommand?: string;
  flushCommand?: string;
}

export interface Facility {
  _id?: string;
  name: string;
  value: string;
}

export interface Cell {
  _id?: string;
  name: string;
  value: string;
}

export interface Layout {
  _id?: string;
  name: string;
  value: string;
}

export interface Line {
  _id?: string;
  name: string;
  value: string;
}

export interface Gateway {
  _id?: string;
  gatewayId?: string;
  macId: string;
  name: string;
  ip: string;
  port: number;
  issuedDate?: Date;
  updatedDate?: Date;
  isActive: boolean;
}
export interface Input {
  diId: string;
  sensorId: string;
  tag: string;
}
export interface Slaves {
  sid: string;
  connectedSensors: ConnectedSensor[];
}
export interface ConnectedSensor {
  sensorId?: string;
  tag: string;
}

export interface Conversion {
  unit: string;
  scale: number;
  sourceUnit: string;
  targetUnit: string;
  formula: string;
  precision: number;
  description: string;
}

export interface Sensor {
  _id?: string;
  sensorId?: string;
  sensorName: string;
  sensorType: string; //"BOOLEAN" | "INTEGER" | "OTHER"
  valueForOne?: number | null; // Add optional property based on sensorType
  sensorUse?: string; //"PRODUCTIVE" | "IDLE" | "PARTCOUNT" | "OTHER";
  isActive?: boolean;
  location?: string;
  manufacturer?: string;
  model?: string;
  serialNumber?: string;
  calibrationDate?: Date;
  accuracy?: string;
  measurementRange?: string;
  operatingTemperature?: string;
  powerSupply?: string;
  dataFormat?: string;
  sensorStatus?: string;
  sensorDescription?: string;
  conversion: Conversion[];
  createdAt?: Date; // Add optional createdAt property based on timestamps
  updatedAt?: Date; // Add optional updatedAt property based on timestamps
}

export interface AppState {
  macId: string;
  selectedDate: Date | null;
  uniqueMacArray: { mac: string; di2Sum: number }[];
  productionData: any[];
  widgetStartDate: Date | null;
  widgetEndDate: Date | null;
  widgetMacId: string;
  machineInfo: any[];
  selectedOption: "1h";
}

export interface RootState {
  widgetEndDate: any;
  widgetStartDate: any;
  macId: string;
  selectedDate: Date | null;
  selectedOption: string;
  widgetMacId: string;
  machineInfo: any[];
}

export interface GatewaySensorAssociation {
  _id?: string;
  sensorNodeName: string;
  slaveId: string;
  tag: string;
  sensorId?: string | Sensor; // Reference to the Sensor model
  mappingId?: string;
  gatewayId?: string | Gateway; // Reference to the Gateway model
  deletedAt?: Date | null;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface GatewayInputsAssociation {
  _id?: string;
  sensorNodeName: string;
  slaveId: string;
  tag: string;
  sensorId?: string;
  mappingId?: string;
  gatewayId?: string | Gateway;
  deletedAt?: Date | null;
  updatedAt?: Date;
}

export interface MachineGatewayAssociation {
  _id?: string;
  machineMappingId?: string;
  machineId: string;
  //gatewayId: string;
  mappingId: string;
  isActive?: boolean;
  sensorNodeName: string;
  deletedAt?: string;
}
export interface MachineInputsAssociation {
  _id?: string;
  machineInputMappingId?: string;
  machineId: string;
  //gatewayId: string;
  mappingId: string;
  isActive?: boolean;
  sensorNodeName: string;
  deletedAt?: string;
}

export interface UtilityDemo {
  companyName: string;
  contactPersonName: string;
  contactPersonNumber: string;
  email: string;
  address: string;
  city: string;
  numOfMachines: number;
  numOfHardwireMachines: number;
  numOfControllerMachines: number;
  demoReportDuration: number;
  demoType: string;
}
export interface Mapping {
  mappingId: string;
  deletedAt?: Date | null;
  sensorNodeType: "io" | "modbus";
  uniqueRef?: string;
}

export interface MachineMapping {
  _id?: string;
  machineMappingId?: string;
  machineId: string;
  isActive?: boolean;
  mappings: Mapping[];
  createdAt?: Date;
  updatedAt?: Date;
}
export interface Functionality {
  [key: string]: boolean;
}

export interface Shift {
  _id?: string;
  shiftId?: string;
  shiftName: string;
  startTime: string;
  endTime: string;
}
