import { createSlice } from "@reduxjs/toolkit";
import { AppState } from "./types";

const initialState: AppState = {
  macId: "",
  selectedDate: null,
  uniqueMacArray: [], // Initial state for uniqueMacArray
  productionData: [],
  widgetStartDate: new Date(Date.now() - 24 * 60 * 60 * 1000),
  widgetEndDate: new Date(),
  widgetMacId: "",
  machineInfo: [],
  selectedOption: "1h",
};

const appSlice = createSlice({
  name: "app",
  initialState,
  reducers: {
    setMacId: (state, action) => {
      state.macId = action.payload;
    },
    setSelectedDate: (state, action) => {
      state.selectedDate = action.payload;
    },
    setUniqueMacArray: (state, action) => {
      state.uniqueMacArray = action.payload;
    },
    setProductionData: (state, action) => {
      state.productionData = action.payload;
    },
    setSelectedOption: (state, action) => {
      state.selectedOption = action.payload;
    },
    setWidgetStartDate: (state, action) => {
      state.widgetStartDate = action.payload;
    },
    setWidgetEndDate: (state, action) => {
      state.widgetEndDate = action.payload;
    },
    setWidgetMacId: (state, action) => {
      state.widgetMacId = action.payload;
    },
    setMachineInfo: (state, action) => {
      state.machineInfo = action.payload;
    },
    setTodayAsSelectedDate: (state) => {
      state.selectedDate = new Date(); // Set the selectedDate to today's date
    },
  },
});

export const {
  setMacId,
  setSelectedDate,
  setUniqueMacArray,
  setProductionData,
  setSelectedOption,
  setWidgetStartDate,
  setWidgetEndDate,
  setWidgetMacId,
  setMachineInfo,
  setTodayAsSelectedDate,
} = appSlice.actions;

export default appSlice.reducer;



// import { AppState } from "./types";

// const initialState: AppState = {
//   macId: "",
//   selectedDate: null,
//   uniqueMacArray: [], // Initial state for uniqueMacArray
//   productionData: [],
//   widgetStartDate: new Date(Date.now() - 24 * 60 * 60 * 1000),
//   widgetEndDate: new Date(),
//   widgetMacId: "",
//   machineInfo: [],
//   selectedOption: "1h",
// };

// type Action = {
//   type: string;
//   payload: any;
// };

// const rootReducer = (state: AppState = initialState, action: Action) => {
//   switch (action.type) {
//     case "SET_MAC_ID":
//       return { ...state, macId: action.payload };
//     case "SET_SELECTED_DATE":
//       return { ...state, selectedDate: action.payload };
//     case "SET_UNIQUE_MAC_ARRAY":
//       return { ...state, uniqueMacArray: action.payload };
//     case "SET_PRODUCTION_DATA":
//       return { ...state, productionData: action.payload };
//     case "SET_SELECTED_OPTION":
//       return { ...state, selectedOption: action.payload };
//     case "SET_WIDGET_START_DATE":
//       return { ...state, widgetStartDate: action.payload };
//     case "SET_WIDGET_END_DATE":
//       return { ...state, widgetEndDate: action.payload };
//     case "SET_Widget_MacId":
//       return { ...state, widgetMacId: action.payload };
//     case "SET_MACHINE_INFO":
//       return { ...state, machineInfo: action.payload };
//     default:
//       return state;
//   }
// };

// export default rootReducer;
