import axios from "axios";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { Input } from "./types";

interface InputState {
  inputs: Input[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: InputState = {
  inputs: [],
  loading: false,
  error: null,
};

// Create
export const createInputRecord = createAsyncThunk(
  "input/createInput",
  async (
    {
      gatewayId,
      diId,
      inputData,
    }: { gatewayId: string; diId: string; inputData: Input },
    { rejectWithValue }
  ) => {
    try {
      const response = await axios.post<Input>(
        `http://localhost:3000/v1/gateway/${gatewayId}/io/${diId}`,
        {
          ...inputData,
          gatewayId,
        }
      );

      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while creating the input");
    }
  }
);

export const updateInput = createAsyncThunk(
  "input/updateInput",
  async (updatedInputData: Input, { rejectWithValue }) => {
    try {
      const response = await axios.put(
        `http://localhost:3000/v1/inputs/updateInput/${updatedInputData.diId}`,
        updatedInputData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while updating the input");
    }
  }
);

const inputSlice = createSlice({
  name: "input",
  initialState,
  reducers: {
    setInput: (state, action: PayloadAction<Input[]>) => {
      state.inputs = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createInputRecord.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createInputRecord.fulfilled, (state, action) => {
        state.loading = false;
        state.inputs?.push(action.payload);
      })
      .addCase(createInputRecord.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to create input";
      })
      .addCase(updateInput.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateInput.fulfilled, (state, action) => {
        state.loading = false;
        // const updatedInput = action.payload;
      })
      .addCase(updateInput.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to update input";
      });
  },
});

export default inputSlice.reducer;
