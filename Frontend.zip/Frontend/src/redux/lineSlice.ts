import axios from "axios";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { Line } from "./types";

interface LineState {
  lines: Line[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: LineState = {
  lines: [],
  loading: false,
  error: null,
};

// Create
export const createLine = createAsyncThunk(
  "line/createLine",
  async (lineData: Line, { rejectWithValue }) => {
    try {
      const response = await axios.post<Line>(
        `${process.env.REACT_APP_BASE_URL}/v1/lines/addline`,
        lineData
      );

      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while creating the line");
    }
  }
);
export const fetchLineById = createAsyncThunk(
  "line/fetchLineById",
  async (lineId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/lines/findLineById/${lineId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching the line by ID");
    }
  }
);
export const fetchLines = createAsyncThunk(
  "line/fetchLines",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_URL}/v1/lines/findAllLines`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching lines");
    }
  }
);
export const updateLine = createAsyncThunk(
  "line/updateLine",
  async (updatedLineData: Line, { rejectWithValue }) => {
    try {
      const response = await axios.put(
        `${process.env.REACT_APP_BASE_URL}/v1/lines/updateLine/${updatedLineData._id}`,
        updatedLineData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while updating the line");
    }
  }
);
export const deleteLine = createAsyncThunk(
  "line/deleteLine",
  async (lineId: string, { rejectWithValue }) => {
    try {
      await axios.delete(
        `${process.env.REACT_APP_BASE_URL}/v1/lines/deleteLine/${lineId}`
      );
      return lineId;
    } catch (error) {
      return rejectWithValue("An error occurred while deleting the line");
    }
  }
);

const lineSlice = createSlice({
  name: "line",
  initialState,
  reducers: {
    setLine: (state, action: PayloadAction<Line[]>) => {
      state.lines = action.payload;
    },
    clearLine: (state, action: PayloadAction<string>) => {
      const lineId = action.payload;

      state.lines = state.lines!.filter((line) => line._id !== lineId);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createLine.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createLine.fulfilled, (state, action) => {
        state.loading = false;
        state.lines?.push(action.payload);
      })
      .addCase(createLine.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to create line";
      })
      .addCase(fetchLines.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchLines.fulfilled, (state, action) => {
        state.loading = false;
        state.lines = action.payload;
      })
      .addCase(fetchLines.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to fetch lines";
      })
      .addCase(updateLine.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateLine.fulfilled, (state, action) => {
        state.loading = false;
        const updatedLine = action.payload;

        if (state.lines) {
          const index = state.lines.findIndex(
            (line) => line._id === updatedLine._id
          );

          if (index !== -1) {
            state.lines[index] = updatedLine;
          }
        }
      })
      .addCase(updateLine.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || "Failed to update line";
      })
      .addCase(deleteLine.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteLine.fulfilled, (state, action) => {
        state.loading = false;
        const deletedLineId = action.payload;
        if (state.lines) {
          state.lines = state.lines.filter(
            (line) => line._id !== deletedLineId
          );
        }
      })
      .addCase(deleteLine.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const {} = lineSlice.actions;
export default lineSlice.reducer;
