import axios from "axios";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { GatewaySensorAssociation } from "./types";

interface GatewaySensorAssociationState {
  gatewaySensorAssociations: GatewaySensorAssociation[] | null;
  loading: boolean;
  error: string | null;
}

const initialState: GatewaySensorAssociationState = {
  gatewaySensorAssociations: [],
  loading: false,
  error: null,
};

// Create
export const createGatewaySensorAssociation = createAsyncThunk(
  "gatewaySensorAssociation/createGatewaySensorAssociation",
  async (
    gatewaySensorAssociationData: GatewaySensorAssociation,
    { rejectWithValue }
  ) => {
    try {
      const response = await axios.post<GatewaySensorAssociation>(
        "http://localhost:3000/v1/associationGatewaySensor/",
        gatewaySensorAssociationData
      );

      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while creating the gatewaySensorAssociation"
      );
    }
  }
);

// Create
export const createMultipleGatewaySensorAssociation = createAsyncThunk(
  "gatewaySensorAssociation/createMultipleGatewaySensorAssociation",
  async (
    {
      gatewayId,
      slaveId,
      associationData,
    }: {
      gatewayId: string;
      slaveId: string;
      associationData: {
        tag: string;
        sensorNodeName: string;
        sensorId: string;
      }[];
    },
    { rejectWithValue }
  ) => {
    try {
      const response = await axios.post<GatewaySensorAssociation[]>(
        "http://localhost:3000/v1/associationGatewaySensor/createMultiple",
        {
          gatewayId,
          slaveId,
          associationData,
        }
      );

      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while creating the gatewaySensorAssociation"
      );
    }
  }
);

export const fetchGatewaySensorAssociationById = createAsyncThunk(
  "gatewaySensorAssociation/fetchGatewaySensorAssociationById",
  async (gatewaySensorAssociationId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:3000/v1/gatewaySensorAssociations/findGatewaySensorAssociationById/${gatewaySensorAssociationId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the gatewaySensorAssociation by ID"
      );
    }
  }
);

export const fetchAllMappings = createAsyncThunk(
  "gatewaySensorAssociation/fetchAllMappings",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        "http://localhost:3000/v1/associationGatewaySensor/"
      );
      return response.data;
    } catch (error) {
      return rejectWithValue("An error occurred while fetching facilities");
    }
  }
);

export const findByMappingGatewayId = createAsyncThunk(
  "gatewaySensorAssociation/findByMappingGatewayId",
  async (gatewayId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:3000/v1/associationGatewaySensor/find/${gatewayId}`
      );

      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching the gatewaySensorAssociation by ID"
      );
    }
  }
);
export const getGatewaySensorAssociationById = createAsyncThunk(
  "gatewaySensorAssociation/getGatewaySensorAssociationById",
  async (mappingId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:3000/v1/associationGatewaySensor/${mappingId}`
      );

      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while fetching  association by mappingId"
      );
    }
  }
);

export const updateGatewaySensorAssociation = createAsyncThunk(
  "gatewaySensorAssociation/updateGatewaySensorAssociation",
  async (
    updatedGatewaySensorAssociationData: GatewaySensorAssociation,
    { rejectWithValue }
  ) => {
    try {
      const response = await axios.put(
        `http://localhost:3000/v1/associationGatewaySensor/${updatedGatewaySensorAssociationData.mappingId}`,
        updatedGatewaySensorAssociationData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while updating the gatewaySensorAssociation"
      );
    }
  }
);
export const deleteGatewaySensorAssociation = createAsyncThunk(
  "gatewaySensorAssociation/deleteGatewaySensorAssociation",
  async (gatewaySensorAssociationId: string, { rejectWithValue }) => {
    try {
      await axios.delete(
        `http://localhost:3000/v1/associationGatewaySensor/${gatewaySensorAssociationId}`
      );
      return gatewaySensorAssociationId;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while deleting the gatewaySensorAssociation"
      );
    }
  }
);
// soft-delete or archive
export const archiveGatewaySensorAssociation = createAsyncThunk(
  "gatewaySensorAssociation/archiveGatewaySensorAssociation",
  async (gatewaySensorAssociationId: string, { rejectWithValue }) => {
    try {
      await axios.patch(
        `http://localhost:3000/v1/associationGatewaySensor/softdel/${gatewaySensorAssociationId}`
      );
      return gatewaySensorAssociationId;
    } catch (error) {
      return rejectWithValue(
        "An error occurred while archiving the gatewaySensorAssociation"
      );
    }
  }
);

const gatewaySensorAssociationSlice = createSlice({
  name: "gatewaySensorAssociation",
  initialState,
  reducers: {
    setGatewaySensorAssociation: (
      state,
      action: PayloadAction<GatewaySensorAssociation[]>
    ) => {
      state.gatewaySensorAssociations = action.payload;
    },
    setGatewaySensorAssociations: (
      state,
      action: PayloadAction<GatewaySensorAssociation[]>
    ) => {
      state.gatewaySensorAssociations = action.payload;
    },
    clearGatewaySensorAssociation: (state, action: PayloadAction<string>) => {
      const gatewaySensorAssociationId = action.payload;

      state.gatewaySensorAssociations = state.gatewaySensorAssociations!.filter(
        (gatewaySensorAssociation) =>
          gatewaySensorAssociation._id !== gatewaySensorAssociationId
      );
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createGatewaySensorAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createGatewaySensorAssociation.fulfilled, (state, action) => {
        state.loading = false;
        state.gatewaySensorAssociations?.push(action.payload);
      })
      .addCase(createGatewaySensorAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to create gatewaySensorAssociation";
      })
      .addCase(createMultipleGatewaySensorAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        createMultipleGatewaySensorAssociation.fulfilled,
        (state, action) => {
          state.loading = false;
          // Here, you should update the state accordingly based on your data structure
          // For example, if action.payload is an array of associations, you can append them to the state
          // state.gatewaySensorAssociations?.push(...action.payload);
        }
      )
      .addCase(
        createMultipleGatewaySensorAssociation.rejected,
        (state, action) => {
          state.loading = false;
          state.error = action.error.message || "An error occurred";
        }
      )
      .addCase(findByMappingGatewayId.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(findByMappingGatewayId.fulfilled, (state, action) => {
        state.loading = false;
        state.gatewaySensorAssociations = action.payload;
      })
      .addCase(findByMappingGatewayId.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to fetch gatewaySensorAssociations";
      })
      .addCase(getGatewaySensorAssociationById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getGatewaySensorAssociationById.fulfilled, (state, action) => {
        state.loading = false;
        state.gatewaySensorAssociations = action.payload;
      })
      .addCase(getGatewaySensorAssociationById.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to fetch gatewaySensorAssociations";
      })
      .addCase(updateGatewaySensorAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateGatewaySensorAssociation.fulfilled, (state, action) => {
        state.loading = false;
        const updatedGatewaySensorAssociation = action.payload;

        if (state.gatewaySensorAssociations) {
          const index = state.gatewaySensorAssociations.findIndex(
            (gatewaySensorAssociation) =>
              gatewaySensorAssociation._id ===
              updatedGatewaySensorAssociation._id
          );

          if (index !== -1) {
            // Update the specific gatewaySensorAssociation in the state
            state.gatewaySensorAssociations[index] =
              updatedGatewaySensorAssociation;
          }
        }
      })
      .addCase(updateGatewaySensorAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message || "Failed to update gatewaySensorAssociation";
      })
      .addCase(deleteGatewaySensorAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteGatewaySensorAssociation.fulfilled, (state, action) => {
        state.loading = false;
        const deletedGatewaySensorAssociationId = action.payload;
        if (state.gatewaySensorAssociations) {
          // Check if gatewaySensorAssociation is not null
          state.gatewaySensorAssociations =
            state.gatewaySensorAssociations.filter(
              (gatewaySensorAssociation) =>
                gatewaySensorAssociation.mappingId !==
                deletedGatewaySensorAssociationId
            );
        }
      })
      .addCase(deleteGatewaySensorAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      /////////////////////////////////////////////////////////
      .addCase(archiveGatewaySensorAssociation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(archiveGatewaySensorAssociation.fulfilled, (state, action) => {
        state.loading = false;
        const archiveGatewaySensorAssociationId = action.payload;
        if (state.gatewaySensorAssociations) {
          // Check if gatewaySensorAssociation is not null
          state.gatewaySensorAssociations =
            state.gatewaySensorAssociations.filter(
              (gatewaySensorAssociation) =>
                gatewaySensorAssociation.mappingId !==
                archiveGatewaySensorAssociationId
            );
        }
      })
      .addCase(archiveGatewaySensorAssociation.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(fetchGatewaySensorAssociationById.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchGatewaySensorAssociationById.fulfilled, (state, action) => {
        state.loading = false;
        // Update the state with the fetched gatewaySensorAssociation data
        state.gatewaySensorAssociations = [action.payload];
      })
      .addCase(fetchGatewaySensorAssociationById.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.error.message ||
          "Failed to fetch gatewaySensorAssociation by ID";
      });
  },
});

export const { setGatewaySensorAssociation } =
  gatewaySensorAssociationSlice.actions;

export default gatewaySensorAssociationSlice.reducer;
