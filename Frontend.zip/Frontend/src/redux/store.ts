import { configureStore } from "@reduxjs/toolkit";
import machineReducer from "./machineSlice";
import facilityReducer from "./facilitySlice";
import cellReducer from "./cellSlice";
import layoutReducer from "./layoutSlice";
import lineReducer from "./lineSlice";
import gatewayReducer from "./gatewaySlice";
import sensorReduceer from "./sensorSlice";
import inputReducer from "./inputsSlice";
import gatewaySensorAssociationReducer from "./gatewaySensorAsscSlice";
import gatewayInputsAssociationReducer from "./gatewayInputAsscSlice";
import machineGatewayAssociationReducer from "./machineGatewayAsscSlice";
import machineInputsAssociationReducer from "./machineInputAsscSlice";
import machineMappingReducer from "./machineMappingSlice";
import utilityDemoReducer from "./utilityDemoSlice";
import functionalityReducer from "./functionalitySlice";
import shiftsReducer from "./shiftsSlice";
import rootReducer from "./Dashboard/reducers";
import fanucReducer from "./GanttReduces/fanucSlice";
import feedReducer from "./GanttReduces/feedSlice";
import partTimelineReducer from "./GanttReduces/partTimelineSlice";
import machineReducers from "./GanttReduces/machineSlice"



const store = configureStore({
  reducer: {
    app: rootReducer,
    machine: machineReducer,
    facility: facilityReducer,
    cell: cellReducer,
    layout: layoutReducer,
    line: lineReducer,
    gateway: gatewayReducer,
    sensor: sensorReduceer,
    input: inputReducer,
    gatewaySensorAssociation: gatewaySensorAssociationReducer,
    machineGatewayAssociation: machineGatewayAssociationReducer,
    gatewayInputsAssociation: gatewayInputsAssociationReducer,
    machineInputsAssociation: machineInputsAssociationReducer,
    machineMapping: machineMappingReducer,
    utilityDemo: utilityDemoReducer,
    functionalities: functionalityReducer,
    shifts: shiftsReducer,
    fanuc: fanucReducer,
    feed: feedReducer,
    partTimeline: partTimelineReducer,
    machines: machineReducers,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
