import React, { useEffect, useState } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  useNavigate,
  Navigate,
} from "react-router-dom";
import Navbar from "./components/Navbar";
import HomePage from "./components/HomePage";
import LoginPage from "./components/LoginPage";
import RegisterPage from "./components/RegisterPage";
import Sidebar from "./components/Sidebar"; // Import the Sidebar component
import "./App.css";
import "./index.css";
import { ToastContainer, toast } from "react-toastify";
import Footer from "./components/Footer";
import PermissionPage from "./components/PermissionPage";
import SuperAdminLoginPage from "./components/SuperAdminLoginPage";
import { Provider, useDispatch } from "react-redux";
import store from "./redux/store";
import RoleBasedRoute from "./components/RoleBasedRoute";
import CreateUserPage from "./components/CreateUser";
import Machines from "./components/Machine/MachineMaster";
import Gateways from "./components/Gateway/GatewayMaster";
import Sensors from "./components/Sensor/SensorMaster";
import Facility from "./components/Infrastructure/Facility/FacilityMaster";
import CellsMaster from "./components/Infrastructure/Cell/CellMaster";
import LayoutsMaster from "./components/Infrastructure/Layout/LayoutMaster";
import LinesMaster from "./components/Infrastructure/Line/LineMaster";
import Dashboard from "./components/Dashboard/Dashboard";
import MachineDetails from "./components/Dashboard/MachineInfo/MachineDetail";
import FileUploadForm from "./components/Reports/FileUploadForm";
import CustomPdf from "./components/Reports/CustomPdf";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import GatewaySensorAssociationPage from "./components/GatewaySensorAssoc/Slaves/GatewaySensorAssociationPage";
import GatewayInputsAssociationPage from "./components/GatewaySensorAssoc/Inputs/GatewayInputsAssociationPage";
import MachineGatewayAssociationPage from "./components/MachineGatewayAssoc/Slaves/MachineGatewayAssociationPage";
import MachineInputsAssociationPage from "./components/MachineGatewayAssoc/Inputs/MachineInputsAssociationPage";
import NotFound from "./components/NotFound";
import { setViewMach, resetFunctionalities } from "./redux/functionalitySlice";
import MachineMappingsPage from "./components/MachineMappings/MachineMappingsPage";
import ShiftForm from "./components/Shifts/ShiftForm";
import ShiftsList from "./components/Shifts/ShiftsList";

function App() {
  const dispatch = useDispatch();

  useEffect(() => {
    const clearSessionStorageAfter30Minutes = () => {
      const sessionStartTime = sessionStorage.getItem("sessionStartTime");
      if (sessionStartTime) {
        const currentTime = new Date().getTime();
        const timeElapsed = currentTime - parseInt(sessionStartTime, 10);

        // Check if 30 minutes have passed (30 minutes = 1800000 milliseconds)
        if (timeElapsed >= 1800000) {
          // Clear session storage
          sessionStorage.clear();
          console.log("Session storage cleared.");
        }
      }
    };

    // Set up an interval to check and clear session storage every minute
    const intervalId = setInterval(clearSessionStorageAfter30Minutes, 60000);

    // Clear the interval when the component unmounts to prevent memory leaks
    return () => {
      clearInterval(intervalId);
    };
  }, []);

  const [isLoggedIn, setIsLoggedIn] = useState(false); // Manage login state

  // Function to handle logout
  const handleLogout = async () => {
    const refreshToken = sessionStorage.getItem("refresh-token");
    const requestBody = {
      refreshToken: `${refreshToken}`,
    };
    console.log("request body " + requestBody);
    const name = sessionStorage.getItem("name");
    if (sessionStorage.getItem("role") === "superAdmin") {
      try {
        // Make a POST request to the API
        const response = await fetch(
          "http://localhost:3000/v1/superAdminAuth/logoutSuperAdmin",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(requestBody),
          }
        );
        response.status === 204
          ? toast.success("SignOut successfully " + name, {
              position: "top-right",
            })
          : toast.error("something went wrong", { position: "top-right" });
      } catch (err) {
        console.log(err);
      }
    } else {
      try {
        // Make a POST request to the API
        const response = await fetch("http://localhost:3000/v1/auth/logout", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(requestBody),
        });
        response.status === 204
          ? toast.success("SignOut successfully " + name, {
              position: "top-right",
            })
          : toast.error("something went wrong", { position: "top-right" });
      } catch (err) {
        console.log(err);
      }
    }

    sessionStorage.clear();
    setIsLoggedIn(false);
    dispatch(resetFunctionalities()); // Dispatch the new action to reset functionalities
  };

  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const isAuthenticated = !!sessionStorage.getItem("access-token");
  const role = sessionStorage.getItem("role");

  const theme = createTheme();

  const [showModal, setShowModal] = useState(true);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(true);

  return (
    <React.Fragment>
      <ThemeProvider theme={theme}>
        <BrowserRouter>
          <div className="App">
            <div className="content" style={{ backgroundColor: "#f1f1f1" }}>
              <Navbar
                isLoggedIn={isLoggedIn} // Pass the isLoggedIn prop
                handleLogout={handleLogout} // Pass the handleLogout prop
                toggleSidebar={toggleSidebar} // You can implement toggleSidebar logic here
              />
              <Sidebar
                handleLogout={handleLogout}
                isLoggedIn={isLoggedIn}
                open={sidebarOpen}
                onClose={toggleSidebar}
              />
              <Routes>
                <Route path="/createUser" element={<CreateUserPage />} />
                <Route path="/" element={<Dashboard />} />
                <Route path="/home" element={<Dashboard />} />
                <Route
                  path="/login"
                  element={<LoginPage setIsLoggedIn={setIsLoggedIn} />}
                />
                <Route path="/register" element={<RegisterPage />} />
                {/* <Route path="/permission" element={<PermissionPage />} /> */}
                {/* <Route path="/dashboard" element={<Dashboard />} /> */}
                <Route
                  path="/superAdminLogin"
                  element={
                    <SuperAdminLoginPage setIsLoggedIn={setIsLoggedIn} />
                  }
                />
                {/* <Route
                  path="/dashboard"
                  element={
                    <RoleBasedRoute
                      isAuthenticated={isAuthenticated}
                      requiredRoles={["superAdmin", "manager"]}
                      redirectTo="/superAdminLogin"
                    >
                      <Dashboard />
                    </RoleBasedRoute>
                  }
                /> */}
                <Route
                  path="/permission"
                  element={
                    <RoleBasedRoute
                      isAuthenticated={isAuthenticated}
                      requiredRoles={["superAdmin", "admin"]}
                      redirectTo="/superAdminLogin"
                    >
                      <PermissionPage />
                    </RoleBasedRoute>
                  }
                />
                <Route path="/shifts" element={<ShiftsList />} />
                <Route path="/machines" element={<Machines />} />
                <Route path="/gateway" element={<Gateways />} />
                <Route path="/sensor" element={<Sensors />} />
                <Route path="/facility" element={<Facility />} />
                <Route path="/cell" element={<CellsMaster />} />
                <Route path="/layout" element={<LayoutsMaster />} />
                <Route path="/line" element={<LinesMaster />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="machine/:macId" element={<MachineDetails />} />
                <Route path="/fileUpload" element={<FileUploadForm />} />
                <Route path="/customPdf" element={<CustomPdf />} />
                <Route
                  path="/machineGatewayAssociation/:machineId"
                  element={<MachineGatewayAssociationPage />}
                />
                <Route
                  path="/machineInputsAssociation/:machineId"
                  element={<MachineInputsAssociationPage />}
                />
                <Route path="/gateway" element={<Gateways />} />
                <Route
                  path="/gatewaySensorAssociation/:gatewayId"
                  element={<GatewaySensorAssociationPage />}
                />{" "}
                <Route
                  path="/gatewayInputsAssociation/:gatewayId"
                  element={<GatewayInputsAssociationPage />}
                />
                <Route
                  path="/machineMappings/:machineId"
                  element={<MachineMappingsPage />}
                />
                <Route
                  path="/notFound"
                  element={
                    <NotFound showModal={showModal} closeModal={closeModal} />
                  }
                />
              </Routes>
            </div>
            <Footer />
          </div>
          <ToastContainer />
        </BrowserRouter>
      </ThemeProvider>
    </React.Fragment>
  );
}

export default App;
